<?php
/**
 * Contentgem Uninstall
 *
 * Fired when the plugin is uninstalled.
 *
 * @package Contentgem
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove plugin options.
$options = array(
	'contentgem_version',
	'contentgem_settings',
	'contentgem_api_key',
	'contentgem_openai_key',
	'contentgem_gsc_token',
	'contentgem_gsc_property',
	'contentgem_license',
	'contentgem_clusters',
	'contentgem_onboarding_complete',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// Remove custom database tables.
global $wpdb;
$tables = array(
	$wpdb->prefix . 'cgm_clusters',
	$wpdb->prefix . 'cgm_pillars',
	$wpdb->prefix . 'cgm_gaps',
	$wpdb->prefix . 'cgm_jobs',
	$wpdb->prefix . 'cgm_analysis_runs',
	$wpdb->prefix . 'cgm_competitors',
	$wpdb->prefix . 'cgm_serp_results',
	$wpdb->prefix . 'cgm_overlaps',
);

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
