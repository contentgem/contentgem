<?php
/**
 * Class CGM_NLP_Engine
 *
 * Serverside tekstanalyse zonder externe ML-bibliotheken:
 *
 *  TF-IDF keyword-extractie
 *    - Sublineaire TF (1 + ln(count)) × smooth IDF (ln(1 + N/(1+df)) + 1)
 *    - Titeltokens tellen TITLE_WEIGHT (3×) mee in de gewogen frequentie
 *    - Bigrams van opeenvolgende contenttokens worden meegenomen
 *    - Optionele corpusopbouw via set_corpus() voor betere IDF-scores
 *
 *  Named-entity-recognition (NER)
 *    - Kapitalisatieheuristiek per zin (eerste woord overgeslagen)
 *    - Contextpatronen voor personen (titelprefixen), organisaties
 *      (legale suffixen) en plaatsen (preposities NL + EN)
 *    - Multi-word entities via aaneengesloten-hoofdletter-sequentie
 *
 *  Taaldetectie
 *    - Tokenfrequentie van taalspecifieke signaalwoorden (NL vs EN)
 *    - Fallback naar 'nl' bij gelijkspel of lege invoer
 *
 * Gebruik:
 *   $nlp = new CGM_NLP_Engine();
 *   $nlp->set_corpus( $all_posts );                // optioneel maar aanbevolen
 *   $keywords = $nlp->extract_keywords( $post );   // string[]
 *   $lang     = $nlp->detect_language( $text );    // 'nl' | 'en'
 *   $entities = $nlp->extract_entities( $text );   // array{persons,places,orgs,misc}
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_NLP_Engine {

	// ── Afstembare parameters ─────────────────────────────────────────────────

	/** Tokens korter dan deze waarde worden gefilterd. */
	private const MIN_TOKEN_LEN = 3;

	/** Titeltokens wegen TITLE_WEIGHT keer zwaarder dan bodytokens. */
	private const TITLE_WEIGHT = 3;

	/** Standaard maximaal aantal terug te geven keywords. */
	private const TOP_N = 10;

	/** Tekstlengte (tekens) die wordt geanalyseerd voor taaldetectie. */
	private const LANG_SAMPLE_LEN = 600;

	/** Bigram wordt alleen meegenomen als het minstens zo vaak voorkomt. */
	private const BIGRAM_MIN_FREQ = 2;

	// ── Corpus-state ─────────────────────────────────────────────────────────

	/** Smooth-IDF per term; leeg tot set_corpus() is aangeroepen. */
	private array $idf         = [];
	private int   $corpus_size = 0;

	// ── Stopwoordenlijsten ────────────────────────────────────────────────────

	private const STOPWORDS_NL = [
		'aan', 'achter', 'al', 'aldus', 'alle', 'alles', 'als', 'andere', 'ben', 'bent',
		'bestaan', 'beste', 'bij', 'blijft', 'blijven', 'bovendien', 'dan', 'daar', 'daarin',
		'daarmee', 'daarna', 'daartoe', 'daarvan', 'daarvoor', 'dat', 'de', 'den', 'der',
		'derhalve', 'deze', 'die', 'dit', 'doen', 'doet', 'door', 'dus', 'echter', 'een',
		'eerste', 'eigen', 'elke', 'en', 'er', 'erg', 'eerste', 'gaan', 'gaat', 'geeft',
		'geen', 'geven', 'grote', 'had', 'haar', 'heeft', 'hebben', 'heel', 'hem', 'hen',
		'het', 'hier', 'hij', 'hoewel', 'hoe', 'houden', 'houdt', 'hun', 'immers', 'inden',
		'indien', 'intussen', 'ik', 'je', 'jij', 'jou', 'jullie', 'kan', 'kleine', 'komt',
		'komen', 'kon', 'kregen', 'krijgt', 'kunnen', 'laatste', 'laat', 'laten', 'lijkt',
		'lijken', 'maakt', 'maken', 'maar', 'mag', 'meer', 'mij', 'mijn', 'mits', 'mocht',
		'mogen', 'moet', 'moeten', 'naast', 'nadat', 'namelijk', 'naar', 'nemen', 'neemt',
		'nieuwe', 'niet', 'noch', 'nooit', 'nu', 'of', 'om', 'omdat', 'onder', 'ons',
		'ook', 'op', 'over', 'reeds', 'się', 'sindsdien', 'soms', 'staat', 'staan',
		'stelt', 'stellen', 'steeds', 'te', 'tegen', 'terwijl', 'tenzij', 'toch', 'tot',
		'totdat', 'tweede', 'tussen', 'uit', 'uw', 'van', 'verder', 'vinden', 'vindt',
		'voor', 'vragen', 'vraagt', 'waar', 'waarbij', 'waardoor', 'wanneer', 'want',
		'was', 'wat', 'we', 'werd', 'werden', 'werden', 'werken', 'werkt', 'weinig',
		'welke', 'welk', 'wie', 'wij', 'wil', 'wordt', 'worden', 'zal', 'ze', 'zelf',
		'zekere', 'zich', 'zien', 'zijn', 'zij', 'zo', 'zodat', 'zou', 'zonder',
	];

	private const STOPWORDS_EN = [
		'a', 'about', 'after', 'against', 'all', 'also', 'although', 'among', 'an', 'and',
		'any', 'are', 'as', 'at', 'back', 'be', 'been', 'before', 'being', 'between',
		'both', 'but', 'by', 'can', 'could', 'did', 'do', 'does', 'doing', 'done',
		'during', 'each', 'even', 'every', 'few', 'for', 'from', 'get', 'given', 'had',
		'has', 'have', 'having', 'he', 'her', 'here', 'him', 'his', 'how', 'if', 'in',
		'into', 'is', 'it', 'its', 'itself', 'just', 'let', 'like', 'made', 'may', 'me',
		'might', 'more', 'most', 'much', 'must', 'my', 'no', 'nor', 'not', 'now', 'of',
		'off', 'on', 'once', 'only', 'or', 'other', 'our', 'out', 'over', 'own', 'same',
		'she', 'since', 'so', 'some', 'still', 'such', 'than', 'that', 'the', 'their',
		'them', 'then', 'there', 'these', 'they', 'this', 'those', 'through', 'to', 'too',
		'under', 'until', 'up', 'us', 'used', 'using', 'very', 'was', 'we', 'were',
		'what', 'when', 'where', 'which', 'while', 'who', 'will', 'with', 'would', 'yet',
		'you', 'your',
	];

	// ── Taaldetectie-signaalwoorden (hoge frequentie, taalspecifiek) ──────────

	/** Woorden die sterk indicatief zijn voor Nederlands. */
	private const SIGNALS_NL = [
		'aan', 'al', 'als', 'ben', 'bij', 'dat', 'de', 'dit', 'door', 'dus',
		'een', 'en', 'er', 'geen', 'heeft', 'het', 'hij', 'ik', 'in', 'is',
		'je', 'kan', 'maar', 'meer', 'met', 'naar', 'niet', 'of', 'om', 'ook',
		'op', 'over', 'te', 'tot', 'van', 'voor', 'was', 'we', 'zijn', 'ze',
	];

	/** Woorden die sterk indicatief zijn voor Engels. */
	private const SIGNALS_EN = [
		'a', 'also', 'an', 'and', 'are', 'as', 'at', 'be', 'been', 'but',
		'by', 'can', 'do', 'does', 'for', 'from', 'has', 'have', 'he', 'how',
		'if', 'in', 'is', 'it', 'its', 'may', 'my', 'no', 'not', 'of',
		'on', 'or', 'our', 'she', 'that', 'the', 'their', 'there', 'they', 'this',
		'to', 'was', 'we', 'were', 'what', 'which', 'who', 'will', 'with', 'you',
	];

	// ── Corpus management ─────────────────────────────────────────────────────

	/**
	 * Pre-computeert IDF-scores op basis van een documentcorpus.
	 *
	 * Aanroepen vóór extract_keywords() voor accurate cross-document weging.
	 * Berekent zowel unigram- als bigram-IDF, zodat alle scorings-
	 * lookups in extract_keywords() corpus-IDF gebruiken.
	 *
	 * IDF-formule: ln(1 + N / (1 + df(t))) + 1  (smooth, altijd ≥ 1)
	 *
	 * @param \WP_Post[] $posts Alle posts waarvoor keyword-extractie wordt gedaan.
	 */
	public function set_corpus( array $posts ): void {
		$n = count( $posts );

		if ( $n === 0 ) {
			return;
		}

		$df            = [];
		$all_stopwords = $this->get_stopwords( 'nl' ); // gecombineerde lijst

		foreach ( $posts as $post ) {
			$tokens = $this->tokenize( $this->extract_text( $post ) );

			// Unigram document-frequency (één keer per doc tellen).
			foreach ( array_unique( $tokens ) as $token ) {
				$df[ $token ] = ( $df[ $token ] ?? 0 ) + 1;
			}

			// Bigram document-frequency (gefilterde tokens, uniek per doc).
			$filtered = array_values( array_filter(
				$tokens,
				fn( string $t ): bool =>
					strlen( $t ) >= self::MIN_TOKEN_LEN &&
					! in_array( $t, $all_stopwords, true )
			) );

			$bigrams_this_doc = [];
			$cnt              = count( $filtered );
			for ( $i = 0; $i < $cnt - 1; $i++ ) {
				$bigrams_this_doc[ $filtered[ $i ] . ' ' . $filtered[ $i + 1 ] ] = true;
			}

			foreach ( array_keys( $bigrams_this_doc ) as $bigram ) {
				$df[ $bigram ] = ( $df[ $bigram ] ?? 0 ) + 1;
			}
		}

		// Smooth IDF.
		foreach ( $df as $term => $count ) {
			$this->idf[ $term ] = log( 1.0 + $n / ( 1.0 + $count ) ) + 1.0;
		}

		$this->corpus_size = $n;
	}

	// ── Publieke analysemethoden ──────────────────────────────────────────────

	/**
	 * Extraheert de meest relevante keywords uit een post via TF-IDF.
	 *
	 * Algoritme:
	 *  1. Detecteer taal → selecteer stopwoordenlijst.
	 *  2. Tokeniseer titel (×TITLE_WEIGHT) en body apart.
	 *  3. Verwijder stopwoorden en tokens < MIN_TOKEN_LEN.
	 *  4. Bouw gewogen frequentietabel.
	 *  5. Bereken sublineaire TF × smooth IDF per term.
	 *  6. Voeg relevante bigrams toe (freq ≥ BIGRAM_MIN_FREQ).
	 *  7. Sorteer op score en retourneer top-$top_n.
	 *
	 * @param  \WP_Post $post
	 * @param  int      $top_n Maximaal terug te geven keywords (standaard 10).
	 * @return string[]        Gesorteerd op TF-IDF score, hoog → laag.
	 */
	public function extract_keywords( WP_Post $post, int $top_n = self::TOP_N ): array {
		$lang      = $this->detect_language( $post->post_content );
		$stopwords = $this->get_stopwords( $lang );

		// Tokeniseer titel en body afzonderlijk.
		$title_tokens = $this->tokenize( $post->post_title );
		$body_tokens  = $this->tokenize( wp_strip_all_tags( $post->post_content ) );

		// Filter: minimale lengte + geen stopwoord.
		$is_valid = static fn( string $t ): bool =>
			strlen( $t ) >= self::MIN_TOKEN_LEN &&
			! in_array( $t, $stopwords, true );

		$title_filtered = array_values( array_filter( $title_tokens, $is_valid ) );
		$body_filtered  = array_values( array_filter( $body_tokens, $is_valid ) );

		// Gewogen termfrequentie: titel telt TITLE_WEIGHT× zwaarder.
		$freq = [];
		foreach ( $title_filtered as $token ) {
			$freq[ $token ] = ( $freq[ $token ] ?? 0 ) + self::TITLE_WEIGHT;
		}
		foreach ( $body_filtered as $token ) {
			$freq[ $token ] = ( $freq[ $token ] ?? 0 ) + 1;
		}

		if ( empty( $freq ) ) {
			return [];
		}

		// TF-IDF scores voor unigrams.
		$scores = $this->compute_tfidf_scores( $freq );

		// Voeg bigrams toe (bigrammen zitten altijd in de bodycontext).
		foreach ( $this->extract_bigrams( $body_filtered ) as $bigram => $count ) {
			// Bigram-IDF: uit corpus als beschikbaar, anders iets hoger dan de fallback.
			$idf             = $this->idf[ $bigram ] ?? ( log( 2.0 ) + 1.5 );
			$scores[ $bigram ] = ( 1.0 + log( (float) $count ) ) * $idf;
		}

		arsort( $scores );

		return array_slice( array_keys( $scores ), 0, $top_n );
	}

	/**
	 * Detecteert de taal van een tekst: 'nl' of 'en'.
	 *
	 * Neemt een sample van LANG_SAMPLE_LEN tekens, tokeniseert en telt
	 * hoeveel tokens overeenkomen met de taalspecifieke signaalwoordensets.
	 * Bij gelijkspel of lege invoer wordt 'nl' geretourneerd.
	 *
	 * @param  string $text Ruwe tekst (mag HTML bevatten).
	 * @return string 'nl' | 'en'
	 */
	public function detect_language( string $text ): string {
		if ( $text === '' ) {
			return 'nl';
		}

		$sample = mb_strtolower(
			wp_strip_all_tags( mb_substr( $text, 0, self::LANG_SAMPLE_LEN ) )
		);

		$tokens = preg_split( '/[^\p{L}]+/u', $sample, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $tokens ) ) {
			return 'nl';
		}

		$token_set = array_flip( $tokens );

		$nl_score = count( array_intersect_key( array_flip( self::SIGNALS_NL ), $token_set ) );
		$en_score = count( array_intersect_key( array_flip( self::SIGNALS_EN ), $token_set ) );

		return $nl_score >= $en_score ? 'nl' : 'en';
	}

	/**
	 * Herkent named entities in een tekst via kapitalisatieheuristiek.
	 *
	 * Strategie per zin:
	 *  - Het eerste woord (mogelijk zinshoofdletter) wordt overgeslagen.
	 *  - Aaneengesloten Title-Case-woorden (niet-ALLCAPS) op positie > 0
	 *    worden samengevoegd tot een multi-word entity.
	 *  - Classificatie via contextpatroon:
	 *      personen  → voorafgegaan door titelprefixen (Dr., Prof., Dhr. …)
	 *      organisaties → entiteit eindigt op legaal suffix (BV, Ltd., Inc. …)
	 *      plaatsen  → voorafgegaan door plaatspreposities (in, te, bij, at …)
	 *      overig    → misc
	 *
	 * Bekende beperking: entiteiten op de eerste positie van een zin worden
	 * niet herkend tenzij ze elders in de tekst ook voorkomen.
	 *
	 * @param  string $text Ruwe tekst (mag HTML bevatten).
	 * @return array{persons: string[], places: string[], orgs: string[], misc: string[]}
	 */
	public function extract_entities( string $text ): array {
		$clean = html_entity_decode(
			wp_strip_all_tags( $text ),
			ENT_QUOTES | ENT_HTML5,
			'UTF-8'
		);

		// Splits in zinnen op sententiegrens.
		$sentences = preg_split(
			'/(?<=[.!?\n])\s+/',
			$clean,
			-1,
			PREG_SPLIT_NO_EMPTY
		);

		$entities = [ 'persons' => [], 'places' => [], 'orgs' => [], 'misc' => [] ];

		foreach ( $sentences as $sentence ) {
			$found = $this->extract_entities_from_sentence( $sentence );
			foreach ( $found as $category => $items ) {
				$entities[ $category ] = array_merge( $entities[ $category ], $items );
			}
		}

		// Dedupliceer elke categorie.
		foreach ( $entities as &$list ) {
			$list = array_values( array_unique( $list ) );
		}
		unset( $list );

		return $entities;
	}

	// ── Private helpers ───────────────────────────────────────────────────────

	/**
	 * Tokeniseert en normaliseert tekst naar lowercase unigrams.
	 *
	 * - Verwijdert HTML en decodeert HTML-entities.
	 * - Verwijdert URLs (http/https).
	 * - Splitst op niet-letter/niet-cijfer (Unicode-aware).
	 *
	 * @return string[]
	 */
	private function tokenize( string $text ): array {
		$text = wp_strip_all_tags( $text );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/https?:\/\/\S+/i', ' ', $text ) ?? $text;
		$text = mb_strtolower( $text );

		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		return $tokens ?? [];
	}

	/**
	 * Extraheert de volledige platte tekst uit een post (titel + body).
	 * Gebruikt Elementor-data als die beschikbaar is.
	 */
	private function extract_text( WP_Post $post ): string {
		$content = wp_strip_all_tags( $post->post_content );

		// Haal Elementor content op als die beschikbaar is
		$elementor_content = get_post_meta( $post->ID, '_elementor_data', true );
		if ( ! empty( $elementor_content ) ) {
			$decoded = json_decode( $elementor_content, true );
			if ( is_array( $decoded ) ) {
				$text = $this->extract_text_from_elementor( $decoded );
				if ( ! empty( $text ) ) {
					$content = $text;
				}
			}
		}

		return $post->post_title . ' ' . $content;
	}

	/**
	 * Extraheert platte tekst recursief uit Elementor-elementen.
	 *
	 * @param  array[] $elements  Geneste Elementor-elementenstructuur.
	 * @return string
	 */
	private function extract_text_from_elementor( array $elements ): string {
		$text = '';
		foreach ( $elements as $element ) {
			if ( isset( $element['settings']['editor'] ) ) {
				$text .= ' ' . wp_strip_all_tags( $element['settings']['editor'] );
			}
			if ( isset( $element['settings']['title'] ) ) {
				$text .= ' ' . $element['settings']['title'];
			}
			if ( isset( $element['settings']['description'] ) ) {
				$text .= ' ' . $element['settings']['description'];
			}
			if ( ! empty( $element['elements'] ) ) {
				$text .= ' ' . $this->extract_text_from_elementor( $element['elements'] );
			}
		}
		return $text;
	}

	/**
	 * Retourneert de gecombineerde stopwoordenlijst voor de opgegeven taal.
	 *
	 * Taal 'nl' geeft de samengevoegde NL+EN lijst (Nederlandse teksten
	 * bevatten regelmatig Engelse vaktermen die ook gestopt moeten worden).
	 * Taal 'en' geeft alleen de Engelse lijst.
	 *
	 * @return string[]
	 */
	private function get_stopwords( string $lang ): array {
		if ( 'en' === $lang ) {
			return self::STOPWORDS_EN;
		}

		// 'nl': unie van beide lijsten, gesorteerd en gededupliceerd.
		static $combined = null;
		if ( $combined === null ) {
			$combined = array_values( array_unique(
				array_merge( self::STOPWORDS_NL, self::STOPWORDS_EN )
			) );
		}

		return $combined;
	}

	/**
	 * Berekent sublineaire TF-IDF scores.
	 *
	 * TF:  1 + ln(freq)   — dempt high-freq terms zonder ze te negeren.
	 * IDF: ln(1+N/(1+df)) + 1 uit corpus; fallback ln(2)+1 ≈ 1.69 als
	 *      geen corpus geladen is of de term daarin ontbreekt.
	 *
	 * @param  array<string, int> $freq   Term → gewogen frequentie.
	 * @return array<string, float>       Term → TF-IDF score.
	 */
	private function compute_tfidf_scores( array $freq ): array {
		$fallback = log( 2.0 ) + 1.0; // ≈ 1.693

		$scores = [];
		foreach ( $freq as $term => $count ) {
			$tf             = 1.0 + log( (float) $count );
			$idf            = $this->idf[ $term ] ?? $fallback;
			$scores[ $term ] = $tf * $idf;
		}

		return $scores;
	}

	/**
	 * Extraheert bigrams uit een reeks al-gefilterde tokens.
	 *
	 * Tokens zijn al schoongemaakt (geen stopwoorden, voldoende lengte).
	 * Opeenvolgende paren worden samengevoegd; alleen bigrams met freq
	 * ≥ BIGRAM_MIN_FREQ worden teruggegeven.
	 *
	 * @param  string[]            $tokens Gefilterde contenttokens.
	 * @return array<string, int>          Bigram → frequentie.
	 */
	private function extract_bigrams( array $tokens ): array {
		$bigrams = [];
		$cnt     = count( $tokens );

		for ( $i = 0; $i < $cnt - 1; $i++ ) {
			$bigram            = $tokens[ $i ] . ' ' . $tokens[ $i + 1 ];
			$bigrams[ $bigram ] = ( $bigrams[ $bigram ] ?? 0 ) + 1;
		}

		return array_filter(
			$bigrams,
			static fn( int $c ): bool => $c >= self::BIGRAM_MIN_FREQ
		);
	}

	/**
	 * Extraheert named entities uit één zin.
	 *
	 * @return array{persons: string[], places: string[], orgs: string[], misc: string[]}
	 */
	private function extract_entities_from_sentence( string $sentence ): array {
		$result = [ 'persons' => [], 'places' => [], 'orgs' => [], 'misc' => [] ];

		// Verwijder leestekens aan het begin en einde van de zin.
		$sentence = trim( $sentence, " \t\n\r.,;:!?\"'" );

		// Splits op witruimte; behoud originele case voor kapitalisatiecheck.
		$words = preg_split( '/\s+/u', $sentence, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $words ) ) {
			return $result;
		}

		$count = count( $words );

		// Titelprefixen (NL + EN) die een persoonsvermelding inleiden.
		$person_prefixes = [
			'dr', 'drs', 'prof', 'mr', 'mrs', 'ms', 'miss', 'sir', 'lord',
			'ir', 'ing', 'dhr', 'mevr', 'mevrouw', 'meneer', 'heer',
		];

		// Legale organisatiesuffixen.
		$org_suffixes = [
			'bv', 'nv', 'vof', 'bvba', 'cv', 'inc', 'ltd', 'llc', 'corp',
			'gmbh', 'ag', 'sa', 'plc', 'foundation', 'stichting', 'vereniging',
			'groep', 'group', 'holding', 'solutions', 'services', 'technologies',
		];

		// Preposities die een plaatsnaam inleiden (NL + EN).
		$place_prepositions = [
			'in', 'te', 'bij', 'naar', 'vanuit', 'richting',
			'at', 'from', 'to', 'near', 'outside', 'inside',
		];

		$i = 0;
		while ( $i < $count ) {
			// Sla het eerste woord over — zinshoofdletter is onbetrouwbaar.
			if ( 0 === $i ) {
				$i++;
				continue;
			}

			$raw_word = $words[ $i ];

			// Strip aanhangende leestekens voor de check.
			$clean_word = rtrim( $raw_word, '.,;:!?\'")-' );
			$clean_word = ltrim( $clean_word, '"\'(' );

			// Title-Case-check: begint met hoofdletter gevolgd door kleine letter.
			// Sluit ALLCAPS-afkortingen (API, SEO) en volledig-kleine-letter woorden uit.
			if ( ! preg_match( '/^\p{Lu}\p{Ll}/u', $clean_word ) ) {
				$i++;
				continue;
			}

			// Bouw multi-word entity door opeenvolgende hoofdletterwoorden samen te voegen.
			$entity_parts = [ $clean_word ];
			$j            = $i + 1;

			while ( $j < $count ) {
				$next_clean = rtrim( $words[ $j ], '.,;:!?\'")-' );
				$next_clean = ltrim( $next_clean, '"\'(' );

				// Accepteer zowel Title-Case als ALL-CAPS als vervolgwoord (bijv. "Philips NV").
				if ( preg_match( '/^\p{Lu}/u', $next_clean ) ) {
					$entity_parts[] = $next_clean;
					$j++;
				} else {
					break;
				}
			}

			$entity    = implode( ' ', $entity_parts );
			$prev_raw  = strtolower( trim( $words[ $i - 1 ], '.,;:!?\'"' ) );
			$last_part = mb_strtolower( end( $entity_parts ) );

			if ( in_array( $prev_raw, $person_prefixes, true ) ) {
				$result['persons'][] = $entity;
			} elseif ( in_array( $last_part, $org_suffixes, true ) ) {
				$result['orgs'][] = $entity;
			} elseif ( in_array( $prev_raw, $place_prepositions, true ) ) {
				$result['places'][] = $entity;
			} else {
				$result['misc'][] = $entity;
			}

			$i = $j; // Sla alle verwerkte woorden over.
		}

		return $result;
	}
}
