<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Pillar_Repository {
	public function get_pillar_for_cluster( int $cluster_id ): ?array { return ( new CGM_Cluster_Repository() )->get_cluster_pillar( $cluster_id ); }
	public function get_all_pillars(): array {
		$clusters = ( new CGM_Cluster_Repository() )->get_all_clusters();
		$out = [];
		foreach ( $clusters as $cluster ) { $pillar = $this->get_pillar_for_cluster( (int) $cluster['id'] ); if ( $pillar ) { $out[] = $pillar; } }
		return $out;
	}
	public function cluster_has_pillar( int $cluster_id ): bool { return null !== $this->get_pillar_for_cluster( $cluster_id ); }
}
