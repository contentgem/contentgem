<?php
/**
 * Class CGM_Gap_Analyzer
 *
 * Detecteert ontbrekende subtopics per cluster, berekent een priority_score
 * en slaat de gevonden gaps op in {prefix}cgm_gaps.
 * Detecteert ook cannibaliserende post-paren binnen een cluster.
 *
 * Pipeline (aanroepen via analyze()):
 *  1. Laad clusters uit cgm_topics voor de huidige site.
 *  2. Bouw TF-IDF corpus (voor cannibalisatiedetectie).
 *  3. Genereer per cluster kandidaat-gaps via regelgebaseerde patronen op de clusternaam.
 *  4. Filter kandidaten waarvan de titel al gedekt is door bestaande posts.
 *  5. Bereken priority_score = impression_factor × gap_factor × intent_weight.
 *  6. Detecteer cannibaliserende post-paren (Jaccard ≥ 0.5 op top-10 keywords).
 *  7. Sla gaps op (verwijdert eerst alle bestaande gaps voor de site).
 *
 * Priority-score formule (0–10 schaal):
 *   raw   = (1 + ln(1 + gsc_impressions)) × (1 − coverage_score) × intent_weight
 *   score = min(10, raw / PRIORITY_SCALE)
 *   intent_weight: commercial 1.5 · navigational 1.2 · informational 1.0
 *
 * GSC-impressies:
 *   Injecteren via constructor als ['zoekterm' => impressies].
 *   Gaps zonder match krijgen gsc_impressions = 0 maar worden wél opgeslagen.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Gap_Analyzer {

	// ── Constanten ────────────────────────────────────────────────────────────

	/** Jaccard-drempel waarbij twee posts als cannibaliserend worden beschouwd. */
	private const CANNIBALIZATION_THRESHOLD = 0.5;

	/** Word-overlap drempel (overlap/max) voor titelgelijkenis. */
	private const TITLE_SIMILARITY_THRESHOLD = 0.70;

	/** Jaccard-drempel waarbij een kandidaattitel als al gedekt wordt beschouwd. */
	private const COVERAGE_THRESHOLD = 0.6;

	/** Maximum aantal gaps dat per cluster wordt opgeslagen. */
	private const MAX_GAPS_PER_CLUSTER = 5;

	/** Maximum aantal gaps per handmatig gedefinieerd cluster. */
	private const MAX_MANUAL_GAPS_PER_CLUSTER = 5;

	/**
	 * Schaalwaarde om de priority-score te normaliseren naar 0–10.
	 * Afgeleid van: ln(1 + 10 000) × 1.5 ≈ 15.3 → schaalwaarde 1.53.
	 */
	private const PRIORITY_SCALE = 1.53;

	/** Gewicht per search-intent voor de priority-berekening. */
	private const INTENT_WEIGHTS = [
		'commercial'    => 1.5,
		'navigational'  => 1.2,
		'informational' => 1.0,
	];

	// ── State ─────────────────────────────────────────────────────────────────

	private int            $site_id;
	private array          $gsc_impressions; // ['zoekterm (lowercase)' => int impressies]
	private array          $gsc_clicks;     // ['zoekterm (lowercase)' => int clicks]
	private CGM_NLP_Engine $nlp;
	private ?CGM_Claude_Client $claude_client;

	/** Cache voor extract_keywords()-resultaten om herberekening per analyse te vermijden. */
	private array $keyword_cache = []; // [post_id => string[]]

	/**
	 * Niche-woordset afgeleid van contentgem_niche + contentgem_niche_description.
	 * Leeg array = geen filtering (analyseer alle clusters).
	 *
	 * @var array<string, true>  ['woord' => true, ...]
	 */
	private array $niche_words = [];

	/**
	 * @param int                   $site_id         Site-ID uit cgm_sites.
	 * @param array<string,int>     $gsc_impressions  Optionele GSC-data; zoekterm → impressies.
	 * @param CGM_NLP_Engine|null   $nlp             Optionele DI voor tests.
	 * @param CGM_Claude_Client|null $claude_client   Optioneel voor AI-gegenereerde titels.
	 * @param array<string,int>     $gsc_clicks       Optionele GSC-data; zoekterm → clicks.
	 */
	public function __construct(
		int $site_id,
		array $gsc_impressions = [],
		?CGM_NLP_Engine $nlp = null,
		?CGM_Claude_Client $claude_client = null,
		array $gsc_clicks = []
	) {
		$this->site_id        = $site_id;
		$this->nlp            = $nlp ?? new CGM_NLP_Engine();
		$this->claude_client  = $claude_client;

		// Normaliseer GSC-keys naar lowercase voor case-insensitieve matching.
		$this->gsc_impressions = array_combine(
			array_map( 'mb_strtolower', array_keys( $gsc_impressions ) ),
			array_values( $gsc_impressions )
		) ?: [];

		$this->gsc_clicks = array_combine(
			array_map( 'mb_strtolower', array_keys( $gsc_clicks ) ),
			array_values( $gsc_clicks )
		) ?: [];

		// Bouw niche-woordset voor cluster-filtering.
		$niche = trim( (string) get_option( 'contentgem_niche', '' ) );
		$desc  = trim( (string) get_option( 'contentgem_niche_description', '' ) );

		if ( '' !== $niche ) {
			$this->niche_words = $this->build_word_set( $niche . ' ' . $desc );
		}
	}

	// ── Publieke API ──────────────────────────────────────────────────────────

	/**
	 * Voert de volledige gap-analyse uit en retourneert het aantal opgeslagen gaps.
	 *
	 * Wanneer handmatige clusters zijn ingesteld via contentgem_clusters worden deze
	 * gebruikt als basis; anders worden alle clusters uit cgm_topics geanalyseerd.
	 *
	 * @return int Aantal nieuwe gaps in cgm_gaps.
	 */
	public function analyze(): int {
		$manual_names = $this->load_manual_clusters();
		$is_manual    = ! empty( $manual_names );

		if ( $is_manual ) {
			$clusters = $this->get_topics_for_manual_clusters( $manual_names );
		} else {
			$clusters = $this->get_clusters();
		}

		if ( empty( $clusters ) ) {
			return 0;
		}

		// Laad alle clusterpost in één batch en bouw het NLP-corpus op
		// zodat extract_keywords() nauwkeurigere IDF-scores gebruikt.
		$this->prime_nlp_corpus( $clusters );

		$all_gaps = [];
		foreach ( $clusters as $cluster ) {
			// Handmatige clusters zijn al door de gebruiker gevalideerd — geen relevantiecheck.
			if ( ! $is_manual && ! $this->is_relevant_cluster( $cluster->cluster_name ) ) {
				continue;
			}
			$gaps     = $this->find_gaps_for_cluster( $cluster, $is_manual );
			$all_gaps = array_merge( $all_gaps, $gaps );
		}

		// Voeg GSC-gebaseerde gaps toe: queries zonder matching post.
		if ( ! empty( $this->gsc_impressions ) ) {
			$gsc_gaps = $this->find_gsc_query_gaps( $clusters );
			$all_gaps = array_merge( $all_gaps, $gsc_gaps );
		}

		// Detecteer cannibalisatie en vuur hook voor verdere verwerking.
		$pairs = $this->detect_cannibalization();
		if ( ! empty( $pairs ) ) {
			do_action( 'contentgem/cannibalization_found', $this->site_id, $pairs );
		}

		// Sorteer afwisselend: eerst per cluster (topic_id), dan priority hoog→laag.
		usort( $all_gaps, static function ( array $a, array $b ): int {
			if ( $a['topic_id'] !== $b['topic_id'] ) {
				return $a['topic_id'] <=> $b['topic_id'];
			}
			return $b['priority_score'] <=> $a['priority_score'];
		} );

		$this->save_gaps( $all_gaps );

		return count( $all_gaps );
	}

	/**
	 * Laadt handmatig gedefinieerde clusters uit de WordPress-instellingen.
	 *
	 * Verwacht JSON: een flat array van strings of een array van objecten/arrays
	 * met een 'name'-sleutel.
	 *
	 * @return string[]  Genormaliseerde clusternamen; leeg als niet ingesteld.
	 */
	private function load_manual_clusters(): array {
		$raw = get_option( 'contentgem_clusters', '' );

		if ( empty( $raw ) ) {
			return [];
		}

		$decoded = json_decode( (string) $raw, true );

		if ( ! is_array( $decoded ) ) {
			return [];
		}

		$names = [];
		foreach ( $decoded as $item ) {
			if ( is_string( $item ) && '' !== trim( $item ) ) {
				$names[] = trim( $item );
			} elseif ( is_array( $item ) && isset( $item['name'] ) && '' !== trim( (string) $item['name'] ) ) {
				$names[] = trim( (string) $item['name'] );
			}
		}

		return $names;
	}

	/**
	 * Koppelt een lijst van handmatige clusternamen aan bestaande cgm_topics-records.
	 *
	 * Als er geen overeenkomend record gevonden wordt, wordt een synthetisch object
	 * aangemaakt met coverage_score = 0 en lege post_ids.
	 *
	 * @param  string[]  $cluster_names  Handmatige clusternamen.
	 * @return object[]
	 */
	private function get_topics_for_manual_clusters( array $cluster_names ): array {
		global $wpdb;

		$db_topics = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, cluster_name, coverage_score, post_ids
				 FROM {$wpdb->prefix}cgm_topics
				 WHERE site_id = %d",
				$this->site_id
			)
		) ?: [];

		// Indexeer DB-topics op lowercase naam voor snelle lookup.
		$indexed = [];
		foreach ( $db_topics as $topic ) {
			$indexed[ mb_strtolower( $topic->cluster_name ) ] = $topic;
		}

		$result = [];
		foreach ( $cluster_names as $name ) {
			$key = mb_strtolower( $name );

			if ( isset( $indexed[ $key ] ) ) {
				$result[] = $indexed[ $key ];
			} else {
				// Synthetisch topic-object voor clusters zonder DB-record.
				$synthetic                 = new stdClass();
				$synthetic->id             = 0;
				$synthetic->cluster_name   = $name;
				$synthetic->coverage_score = 0.0;
				$synthetic->post_ids       = '[]';
				$result[]                  = $synthetic;
			}
		}

		return $result;
	}

	/**
	 * Detecteert ontbrekende subtopics voor één cluster via regelgebaseerde patronen.
	 *
	 * Stap 1: Genereer kandidaat-titels (handmatig: spec-templates; automatisch: NLP-patronen).
	 * Stap 2: Filter titels die al gedekt zijn door bestaande posts (Jaccard + substring).
	 * Stap 3: Filter kandidaten die de kwaliteitscheck niet doorstaan.
	 * Stap 4: Bereken priority_score en retourneer top-N.
	 *
	 * @param  object $topic      Row uit cgm_topics (of synthetisch object).
	 * @param  bool   $is_manual  true = handmatige clustermodus.
	 * @return array[]  Gap-records: topic_id, suggested_title, search_intent,
	 *                  gsc_impressions, priority_score.
	 */
	public function find_gaps_for_cluster( object $topic, bool $is_manual = false ): array {
		$coverage_score  = (float) $topic->coverage_score;
		$post_ids        = $this->decode_post_ids( $topic->post_ids ?? '' );
		$existing_titles = $this->get_post_titles( $post_ids );

		if ( $is_manual ) {
			$candidates = $this->generate_manual_gap_candidates( $topic->cluster_name, $existing_titles );
			$lang       = $this->get_forced_language_code( $topic->cluster_name ) ?: $this->nlp->detect_language( $topic->cluster_name );
			$max        = self::MAX_MANUAL_GAPS_PER_CLUSTER;
		} else {
			$lang       = $this->get_forced_language_code( $topic->cluster_name ) ?: $this->nlp->detect_language( $topic->cluster_name );
			$parts      = array_map( 'trim', explode( '+', $topic->cluster_name ) );
			$primary    = $parts[0];
			$subtheme   = $parts[1] ?? '';
			$candidates = $this->generate_gap_candidates( $primary, $subtheme, $lang );
			$max        = self::MAX_GAPS_PER_CLUSTER;
		}

		$new_candidates = $this->filter_covered_titles( $candidates, $existing_titles );

		$gaps = [];
		foreach ( $new_candidates as $title ) {
			// Valideer titels al in deze stap zodat slechte kandidaten de sortering niet verstoren.
			if ( ! $this->validate_gap_title( $title ) ) {
				continue;
			}

			$intent      = $this->detect_search_intent( $title, $lang );
			$impressions = $this->match_gsc_impressions( $title );

			if ( $is_manual ) {
				$score = $this->calculate_manual_priority_score( $coverage_score, $impressions );
			} else {
				$score = $this->calculate_priority_score( $title, $impressions, $coverage_score, $intent );
			}

			$gaps[] = [
				'topic_id'        => (int) $topic->id,
				'suggested_title' => $title,
				'search_intent'   => $intent,
				'gsc_impressions' => $impressions,
				'gsc_clicks'      => $this->match_gsc_clicks( $title ),
				'priority_score'  => $score,
			];
		}

		usort( $gaps, static fn( array $a, array $b ) => $b['priority_score'] <=> $a['priority_score'] );

		// Voeg variatie toe per gap binnen een handmatig cluster: elke volgende gap -5.
		if ( $is_manual ) {
			foreach ( $gaps as $i => &$gap ) {
				$gap['priority_score'] = max( 5.0, (float) $gap['priority_score'] - ( $i * 5.0 ) );
			}
			unset( $gap );
		}

		return array_slice( $gaps, 0, $max );
	}

	/**
	 * Berekent de priority_score (0.0–10.0) voor één gap.
	 *
	 * raw   = (1 + ln(1 + impressions)) × (1 − coverage) × intent_weight
	 * score = min(10, raw / PRIORITY_SCALE)
	 *
	 * Factoren:
	 *  - Impressie-factor: logaritmisch geschaald; bij 0 impressies = 1.0.
	 *  - Gap-factor: (1 − coverage) — slecht gedekte clusters krijgen hogere prioriteit.
	 *  - Intent-gewicht: commercial (1.5) > navigational (1.2) > informational (1.0).
	 *
	 * @param  string $title
	 * @param  int    $impressions  GSC-impressies voor dit keyword.
	 * @param  float  $coverage_score Coverage van het cluster (0.0–1.0).
	 * @param  string $intent       'informational' | 'commercial' | 'navigational'
	 * @return float 0.0–10.0
	 */
	public function calculate_priority_score(
		string $title,
		int $impressions,
		float $coverage_score,
		string $intent
	): float {
		$intent_weight     = self::INTENT_WEIGHTS[ $intent ] ?? 1.0;
		$impression_factor = 1.0 + log( 1.0 + (float) $impressions );
		$gap_factor        = 1.0 - min( 1.0, max( 0.0, $coverage_score ) );

		$raw = $impression_factor * $gap_factor * $intent_weight;

		return round( min( 10.0, $raw / self::PRIORITY_SCALE ), 4 );
	}

	/**
	 * Berekent de priority_score voor handmatige clusters.
	 *
	 * Formule: max(5, round(100 − coverage_pct × 0.9))
	 * coverage_score wordt automatisch naar 0–100 geschaald als ≤ 1.0.
	 *
	 * Voorbeelden:
	 *  - coverage 0%   → priority 100
	 *  - coverage 20%  → priority 82
	 *  - coverage 40%  → priority 64
	 *  - coverage 60%  → priority 46
	 *  - coverage 80%  → priority 28
	 *  - coverage 100% → priority 10
	 *
	 * @param  float $coverage_score Coverage van het cluster (0.0–1.0 of 0–100).
	 * @param  int   $impressions    GSC-impressies (niet gebruikt in nieuwe formule).
	 * @return float Priority-score (hogere waarde = hogere prioriteit).
	 */
	public function calculate_manual_priority_score( float $coverage_score, int $impressions ): float {
		// Normaliseer coverage naar 0–100 als de waarde als fractie (0–1) is opgeslagen.
		$coverage_pct = $coverage_score <= 1.0 ? $coverage_score * 100.0 : $coverage_score;
		$score        = max( 5.0, round( 100.0 - ( $coverage_pct * 0.9 ) ) );

		return (float) $score;
	}

	/**
	 * Detecteert cannibaliserende post-paren binnen elk cluster.
	 *
	 * Een paar geldt als cannibaliserend als minimaal één van de volgende
	 * criteria waar is:
	 *  a) Jaccard-gelijkenis op top-10 TF-IDF keywords ≥ 0.5.
	 *  b) Titelgelijkenis (word-overlap / max) > 0.70.
	 *  c) Hetzelfde primaire keyword in beide titels.
	 *
	 * Gevonden paren worden opgeslagen in cgm_cannibalization (overslaan als
	 * het paar al bestaat in een niet-ignored status).
	 *
	 * @return array[] Elk element: {post_id_a, post_id_b, overlap, cluster_id, cluster_name}.
	 *                 Gesorteerd op overlap DESC.
	 */
	public function detect_cannibalization(): array {
		$clusters = $this->get_clusters();
		$pairs    = [];

		foreach ( $clusters as $cluster ) {
			$post_ids = $this->decode_post_ids( $cluster->post_ids ?? '' );

			if ( count( $post_ids ) < 2 ) {
				continue;
			}

			// Extraheer keyword-sets en titels per post.
			$keyword_sets = $this->build_keyword_sets( $post_ids );
			$titles       = $this->get_post_titles_map( $post_ids );
			$ids          = array_keys( $keyword_sets );
			$n            = count( $ids );

			for ( $i = 0; $i < $n - 1; $i++ ) {
				for ( $j = $i + 1; $j < $n; $j++ ) {
					$id_a = $ids[ $i ];
					$id_b = $ids[ $j ];

					// Bereken semantische overlap score (0–100).
					$overlap_score = $this->calculate_overlap_score(
						$id_a,
						$id_b,
						$keyword_sets,
						$titles,
						$cluster
					);

					// Sla alleen paren op met score > 50 (matig tot kritiek risico).
					if ( $overlap_score > 50 ) {
						$jaccard = $this->jaccard( $keyword_sets[ $id_a ], $keyword_sets[ $id_b ] );
						$pairs[] = [
							'post_id_a'     => $id_a,
							'post_id_b'     => $id_b,
							'overlap'       => round( $jaccard, 4 ),
							'overlap_score' => $overlap_score,
							'cluster_id'    => (int) $cluster->id,
							'cluster_name'  => $cluster->cluster_name,
						];
					}
				}
			}
		}

		usort( $pairs, static fn( array $a, array $b ) => $b['overlap_score'] <=> $a['overlap_score'] );

		$this->save_cannibalization_pairs( $pairs );

		return $pairs;
	}

	/**
	 * Berekent de semantische overlap score (0–100) voor een post-paar.
	 *
	 * Formule:
	 *  a) Title keyword overlap : Jaccard(tfidf_a, tfidf_b) × 40 punten
	 *  b) Cluster overlap       : zelfde cluster = 30, aangrenzend = 15
	 *  c) Search intent match   : zelfde intent = 30 punten
	 *
	 * Score-interpretatie:
	 *   0–30  : geen probleem
	 *  31–50  : licht risico
	 *  51–65  : matig risico
	 *  66–80  : hoog risico
	 *  81–100 : kritiek cannibalisatie
	 *
	 * @param  int                         $id_a
	 * @param  int                         $id_b
	 * @param  array<int, array<string,int>> $keyword_sets
	 * @param  array<int, string>          $titles
	 * @param  object                      $cluster  Row uit cgm_topics.
	 * @return int  0–100
	 */
	private function calculate_overlap_score(
		int $id_a,
		int $id_b,
		array $keyword_sets,
		array $titles,
		object $cluster
	): int {
		$score = 0;

		// a) Title keyword overlap: Jaccard(tfidf_a, tfidf_b) × 40
		$kw_a   = $keyword_sets[ $id_a ] ?? [];
		$kw_b   = $keyword_sets[ $id_b ] ?? [];
		$score += (int) round( $this->jaccard( $kw_a, $kw_b ) * 40 );

		// b) Cluster overlap: alle paren in deze iteratie zijn hetzelfde cluster.
		$score += 30;

		// c) Search intent match: zelfde intent = 30 punten.
		$title_a = $titles[ $id_a ] ?? '';
		$title_b = $titles[ $id_b ] ?? '';
		$lang    = $this->get_forced_language_code( $cluster->cluster_name ) ?: $this->nlp->detect_language( $cluster->cluster_name );

		if ( $this->detect_search_intent( $title_a, $lang ) === $this->detect_search_intent( $title_b, $lang ) ) {
			$score += 30;
		}

		return min( 100, $score );
	}


	private function get_forced_language_code( ?string $fallback_text = null ): ?string {
		$forced = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		$forced = str_replace( '_', '-', $forced );
		if ( 'auto' !== $forced && preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $forced ) ) {
			$parts = explode( '-', $forced );
			return sanitize_key( $parts[0] );
		}
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$locale = strtolower( str_replace( '_', '-', (string) $locale ) );
		if ( preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $locale ) ) {
			$parts = explode( '-', $locale );
			if ( ! empty( $parts[0] ) ) {
				return sanitize_key( $parts[0] );
			}
		}
		if ( null !== $fallback_text && '' !== trim( $fallback_text ) ) {
			return $this->nlp->detect_language( $fallback_text );
		}
		return null;
	}

	private function english_leak_score( string $title ): int {
		$title = ' ' . mb_strtolower( $title ) . ' ';
		$markers = [ ' the ', ' and ', ' how ', ' why ', ' guide', ' market', ' stocks', ' stock ', ' investing', ' beginner', ' analysis', ' world ', ' trend', ' blue chip' ];
		$score = 0;
		foreach ( $markers as $marker ) {
			if ( false !== strpos( $title, $marker ) ) {
				$score++;
			}
		}
		return $score;
	}

	private function title_matches_language( string $title, string $lang ): bool {
		$title = mb_strtolower( trim( $title ) );
		if ( '' === $title ) {
			return false;
		}
		if ( 'en' === $lang ) {
			return true;
		}
		if ( $this->english_leak_score( $title ) >= 2 ) {
			return false;
		}
		return true;
	}


	/**
	 * Valideert een gap-titel op kwaliteit.
	 *
	 * Retourneert false als de titel:
	 *  - Minder dan 5 woorden bevat.
	 *  - Langer is dan 70 tekens.
	 *  - Eindigt op "handleiding" zonder minstens 2 specifieke woorden ervoor.
	 *  - Overeenkomt met het generieke patroon "hoe begin(nen) je met {woord}".
	 *
	 * @param  string $title
	 * @return bool
	 */
	public function validate_gap_title( string $title ): bool {
		$trimmed = trim( $title );

		// Minder dan 5 woorden.
		$word_count = count( preg_split( '/\s+/u', $trimmed, -1, PREG_SPLIT_NO_EMPTY ) );
		if ( $word_count < 5 ) {
			return false;
		}

		// Langer dan 70 tekens.
		if ( mb_strlen( $trimmed ) > 70 ) {
			return false;
		}

		$lower = mb_strtolower( $trimmed );

		// Eindigt op "handleiding" zonder voldoende specifieke context.
		if ( str_ends_with( $lower, 'handleiding' ) ) {
			$generic = [ 'stap', 'voor', 'een', 'de', 'het', 'complete', 'volledige', 'ultieme', 'handleiding' ];
			$tokens  = preg_split( '/[^\p{L}\p{N}]+/u', $lower, -1, PREG_SPLIT_NO_EMPTY );
			$specific = array_filter(
				$tokens ?? [],
				static fn( string $w ): bool => mb_strlen( $w ) >= 4 && ! in_array( $w, $generic, true )
			);
			if ( count( $specific ) < 2 ) {
				return false;
			}
		}

		// Generiek patroon: "hoe begin(nen) je met {één woord}" (geen verdere context).
		if ( (bool) preg_match( '/^hoe beginn?e?n? je met \S+$/iu', $lower ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Slaat nieuwe cannibalisatie-paren op in cgm_cannibalization.
	 * Overslaat paren die al bestaan met status 'open' of 'merged'.
	 *
	 * @param array[] $pairs Resultaat van detect_cannibalization().
	 */
	private function save_cannibalization_pairs( array $pairs ): void {
		global $wpdb;

		$table = $wpdb->prefix . 'cgm_cannibalization';

		foreach ( $pairs as $pair ) {
			$id_1 = min( $pair['post_id_a'], $pair['post_id_b'] );
			$id_2 = max( $pair['post_id_a'], $pair['post_id_b'] );

			// Controleer of het paar al bestaat (any non-ignored status).
			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$table}
					 WHERE site_id = %d AND post_id_1 = %d AND post_id_2 = %d
					   AND status != 'ignored'",
					$this->site_id,
					$id_1,
					$id_2
				)
			);

			if ( $exists ) {
				// Update overlap_score bij heranalyse.
				$wpdb->update(
					$table,
					[ 'overlap_score' => (int) ( $pair['overlap_score'] ?? 0 ) ],
					[
						'site_id'   => $this->site_id,
						'post_id_1' => $id_1,
						'post_id_2' => $id_2,
					],
					[ '%d' ],
					[ '%d', '%d', '%d' ]
				);
				continue;
			}

			$wpdb->insert(
				$table,
				[
					'site_id'          => $this->site_id,
					'post_id_1'        => $id_1,
					'post_id_2'        => $id_2,
					'similarity_score' => (float) $pair['overlap'],
					'overlap_score'    => (int) ( $pair['overlap_score'] ?? 0 ),
					'status'           => 'open',
				],
				[ '%d', '%d', '%d', '%f', '%d', '%s' ]
			);
		}
	}

	/**
	 * Berekent de word-overlap titelgelijkenis: |intersectie| / max(|A|, |B|).
	 *
	 * @param  string $a
	 * @param  string $b
	 * @return float 0.0–1.0
	 */
	private function title_similarity( string $a, string $b ): float {
		$set_a = $this->words( mb_strtolower( $a ) );
		$set_b = $this->words( mb_strtolower( $b ) );

		if ( empty( $set_a ) || empty( $set_b ) ) {
			return 0.0;
		}

		$intersection = count( array_intersect_key( $set_a, $set_b ) );
		$max          = max( count( $set_a ), count( $set_b ) );

		return $max > 0 ? $intersection / $max : 0.0;
	}

	/**
	 * Extraheert het primaire keyword uit een titel: het eerste woord van ≥4 tekens
	 * dat geen functiewoord is.
	 *
	 * @param  string $title
	 * @return string Lowercase keyword, of '' als niet gevonden.
	 */
	private function extract_primary_keyword( string $title ): string {
		static $stopwords = [
			// NL
			'hoe', 'begin', 'stap', 'voor', 'naar', 'door', 'over', 'zonder',
			'maken', 'beste', 'meest', 'worden', 'heeft', 'zijn', 'complete',
			// EN
			'start', 'step', 'your', 'guide', 'best', 'most', 'with', 'from',
			'into', 'that', 'this', 'what', 'about', 'tips', 'ways', 'using',
		];

		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $title ), -1, PREG_SPLIT_NO_EMPTY );

		foreach ( $tokens ?? [] as $token ) {
			if ( mb_strlen( $token ) >= 4 && ! in_array( $token, $stopwords, true ) ) {
				return $token;
			}
		}

		return '';
	}

	/**
	 * Verwijdert alle bestaande gaps voor de site en slaat de nieuwe op.
	 *
	 * Bij elke heranalyse wordt een volledige DELETE uitgevoerd zodat verouderde
	 * of onjuiste gaps niet blijven staan. In-progress drafts zijn gekoppeld via
	 * de draft-tabel en zijn niet afhankelijk van de gap-status.
	 *
	 * Duplicate prevention: een gap wordt overgeslagen als de word-overlap met
	 * een al opgeslagen gap ≥ 50% is (|intersectie| / max(|A|, |B|)).
	 *
	 * @param array[] $gaps Gap-records (zie find_gaps_for_cluster()).
	 */
	public function save_gaps( array $gaps ): void {
		global $wpdb;

		$table = $wpdb->prefix . 'cgm_gaps';

		// Verwijder ALLE bestaande gaps voor een schone heranalyse.
		$wpdb->delete(
			$table,
			[ 'site_id' => $this->site_id ],
			[ '%d' ]
		);

		$saved_titles = []; // Bijhouden welke titels al opgeslagen zijn voor duplicate-check.
		$saved_count  = 0;

		foreach ( $gaps as $gap ) {
			$title = $this->clean_duplicate_words( $gap['suggested_title'] );

			// Sla gaps over waarvan de titel de kwaliteitscheck niet doorstaat.
			if ( ! $this->validate_gap_title( $title ) ) {
				continue;
			}

			// Sla op bij exacte titelduplicate (case-insensitief).
			if ( in_array( mb_strtolower( $title ), array_map( 'mb_strtolower', $saved_titles ), true ) ) {
				continue;
			}

			$wpdb->insert(
				$table,
				[
					'site_id'         => $this->site_id,
					'topic_id'        => (int) $gap['topic_id'],
					'suggested_title' => sanitize_text_field( $title ),
					'search_intent'   => $gap['search_intent'],
					'gsc_impressions' => (int) $gap['gsc_impressions'],
					'gsc_clicks'      => (int) ( $gap['gsc_clicks'] ?? 0 ),
					'priority_score'  => (float) $gap['priority_score'],
				],
				[ '%d', '%d', '%s', '%s', '%d', '%d', '%f' ]
			);

			$saved_titles[] = $title;
			++$saved_count;
		}

		do_action( 'contentgem/gaps_saved', $this->site_id, $saved_count );
	}

	/**
	 * Controleert of een titel een te grote word-overlap heeft met een van de gegeven titels.
	 *
	 * @param  string   $title            Nieuwe kandidaattitel.
	 * @param  string[] $existing_titles  Al opgeslagen titels.
	 * @param  float    $threshold        Overlap-drempel (0.0–1.0); standaard 0.5.
	 * @return bool  true als overlap ≥ threshold bij minstens één bestaande titel.
	 */
	private function has_word_overlap( string $title, array $existing_titles, float $threshold = 0.5 ): bool {
		if ( empty( $existing_titles ) ) {
			return false;
		}

		$title_words = $this->words( mb_strtolower( $title ) );

		if ( empty( $title_words ) ) {
			return false;
		}

		foreach ( $existing_titles as $existing ) {
			$existing_words = $this->words( mb_strtolower( $existing ) );

			if ( empty( $existing_words ) ) {
				continue;
			}

			$intersection = count( array_intersect_key( $title_words, $existing_words ) );
			$max          = max( count( $title_words ), count( $existing_words ) );

			if ( $max > 0 && ( $intersection / $max ) >= $threshold ) {
				return true;
			}
		}

		return false;
	}

	// ── Clusterdata ───────────────────────────────────────────────────────────

	/**
	 * Haalt alle clusters op voor de huidige site.
	 *
	 * @return object[]
	 */
	private function get_clusters(): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, cluster_name, coverage_score, post_ids
				 FROM {$wpdb->prefix}cgm_topics
				 WHERE site_id = %d
				 ORDER BY coverage_score ASC",
				$this->site_id
			)
		) ?: [];
	}

	/**
	 * Decodeert de JSON post_ids kolom naar een array van integers.
	 *
	 * @return int[]
	 */
	private function decode_post_ids( string $json ): array {
		$decoded = json_decode( $json, true );

		if ( ! is_array( $decoded ) ) {
			return [];
		}

		return array_map( 'intval', $decoded );
	}

	/**
	 * Haalt post_title op als map [post_id => title] voor gebruik in cannibalisatiedetectie.
	 *
	 * @param  int[]                $post_ids
	 * @return array<int, string>
	 */
	private function get_post_titles_map( array $post_ids ): array {
		if ( empty( $post_ids ) ) {
			return [];
		}

		global $wpdb;

		$clean        = array_map( 'intval', $post_ids );
		$placeholders = implode( ',', array_fill( 0, count( $clean ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_title FROM {$wpdb->prefix}posts
				 WHERE ID IN ({$placeholders}) AND post_status = 'publish'",
				...$clean
			)
		);

		$map = [];
		foreach ( $rows ?: [] as $row ) {
			$map[ (int) $row->ID ] = $row->post_title;
		}

		return $map;
	}

	/**
	 * Haalt de post_title op voor een reeks post-IDs via één query.
	 *
	 * @param  int[]    $post_ids
	 * @return string[]
	 */
	private function get_post_titles( array $post_ids ): array {
		if ( empty( $post_ids ) ) {
			return [];
		}

		global $wpdb;

		$clean        = array_map( 'intval', $post_ids );
		$placeholders = implode( ',', array_fill( 0, count( $clean ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$results = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_title FROM {$wpdb->prefix}posts
				 WHERE ID IN ({$placeholders}) AND post_status = 'publish'",
				...$clean
			)
		);

		return $results ?: [];
	}

	// ── Corpus-initialisatie ─────────────────────────────────────────────────

	/**
	 * Verzamelt alle unieke post-IDs uit de clusters en bouwt het NLP-corpus,
	 * zodat extract_keywords() nauwkeurigere IDF-scores retourneert.
	 *
	 * @param object[] $clusters
	 */
	private function prime_nlp_corpus( array $clusters ): void {
		$all_ids = [];

		foreach ( $clusters as $cluster ) {
			$ids     = $this->decode_post_ids( $cluster->post_ids ?? '' );
			$all_ids = array_merge( $all_ids, $ids );
		}

		$unique_ids = array_unique( $all_ids );

		if ( empty( $unique_ids ) ) {
			return;
		}

		$posts = array_values( array_filter(
			array_map( 'get_post', $unique_ids ),
			static fn( $p ) => $p instanceof WP_Post
		) );

		if ( ! empty( $posts ) ) {
			$this->nlp->set_corpus( $posts );
		}
	}

	// ── Gap-kandidaatgeneratie ────────────────────────────────────────────────

	/**
	 * Genereert kandidaat-gap-titels voor een handmatig gedefinieerd cluster.
	 *
	 * Probeert eerst Claude API te gebruiken voor menselijke, redactionele titels.
	 * Valt terug op verbeterde templates als Claude niet beschikbaar is.
	 *
	 * @param  string   $cluster_name     Volledige naam van het handmatige cluster.
	 * @param  string[] $existing_titles  Bestaande artikeltitels in dit cluster.
	 * @return string[]
	 */
	private function generate_manual_gap_candidates( string $cluster_name, array $existing_titles = [] ): array {
		$lang = $this->get_forced_language_code( $cluster_name ) ?: $this->nlp->detect_language( $cluster_name . ' ' . implode( ' ', $existing_titles ) );
		if ( null !== $this->claude_client ) {
			try {
				$niche   = trim( (string) get_option( 'contentgem_niche', '' ) );
				$niche   = '' !== $niche ? $niche : $cluster_name;
				$titles  = $this->claude_client->suggest_gap_titles( $cluster_name, $existing_titles, $niche );
				$titles  = array_values( array_filter( $titles, function( $title ) use ( $lang ) { return $this->title_matches_language( (string) $title, $lang ); } ) );
				if ( ! empty( $titles ) ) {
					return $titles;
				}
			} catch ( \Exception $e ) {
				// Fallback naar templates bij API-fout.
			}
		}

		// Fallback templates: no "complete guide", "step-by-step", "everything you need to know".
		$c = $cluster_name;

		if ( 'en' === $lang ) {
			return [
				"The most common {$c} mistakes and how to avoid them",
				"How to choose the right approach for {$c}",
				"{$c}: the best options compared",
				"When is {$c} the right choice for you",
				"How to get better results with {$c}",
			];
		}

		return [
			"Veelgemaakte fouten bij {$c} en hoe je ze voorkomt",
			"Hoe je de juiste aanpak voor {$c} kiest",
			"{$c}: de beste opties vergeleken",
			"Wanneer is {$c} de juiste keuze voor jou",
			"Hoe je betere resultaten behaalt met {$c}",
		];
	}

	/**
	 * Genereert kandidaat-gap-titels op basis van het cluster hoofd- en subthema.
	 *
	 * De patronen zijn niche-agnostisch: ze embedden het hoofdonderwerp ($primary)
	 * direct in elke titel, zodat de output altijd specifiek en contextueel is.
	 * Wanneer een subthema beschikbaar is (bijv. "Beginners" uit "Hardlopen + Beginners")
	 * worden extra titels toegevoegd die het subthema combineren met het hoofdthema.
	 *
	 * De `filter_covered_titles()` stap verwijdert aansluitend titels die al gedekt
	 * zijn door bestaande posts (Jaccard ≥ COVERAGE_THRESHOLD of exacte substring).
	 *
	 * @param  string $primary  Hoofdonderwerp van het cluster (vóór " + ").
	 * @param  string $subtheme Subthema van het cluster (na " + "), of leeg.
	 * @param  string $lang     'nl' | 'en'
	 * @return string[]
	 */
	private function generate_gap_candidates( string $primary, string $subtheme, string $lang ): array {
		$p = $primary;
		$s = $subtheme;

		if ( 'en' === $lang ) {
			$candidates = [
				"Getting started with {$p}: a practical overview",
				"Benefits of {$p} you should know about",
				"Common {$p} mistakes and how to avoid them",
				"How to improve your {$p} results",
				"Advanced {$p}: taking it to the next level",
				"{$p} in practice: tips and real-world examples",
				"Most frequently asked questions about {$p}",
				"How to track your {$p} progress",
				"Making the most of {$p}: an overview",
				"Top {$p} myths debunked",
				"Best approach to {$p}: options compared",
				"{$p}: free versus paid options",
			];
			if ( '' !== $s ) {
				$candidates[] = "{$p} for {$s}: a practical approach";
				$candidates[] = "How {$s} can get the most out of {$p}";
			}
			return $candidates;
		}

		$candidates = [
			"Beginnen met {$p}: een praktisch overzicht",
			"De voordelen van {$p} die je moet kennen",
			"Veelgemaakte fouten bij {$p} en hoe je ze voorkomt",
			"Hoe je betere resultaten behaalt met {$p}",
			"Verdieping in {$p}: van basis naar volgende stap",
			"{$p} in de praktijk: tips en concrete voorbeelden",
			"Veelgestelde vragen over {$p}",
			"Hoe je je voortgang met {$p} meet",
			"Meer halen uit {$p}: een compleet overzicht",
			"De grootste misverstanden over {$p}",
			"De beste aanpak voor {$p}: opties vergeleken",
			"{$p}: gratis versus betaalde opties",
		];
		if ( '' !== $s ) {
			$candidates[] = "{$p} voor {$s}: een praktische aanpak";
			$candidates[] = "Hoe {$s} meer uit {$p} kan halen";
		}
		return $candidates;
	}

	// ── Niche-filtering ───────────────────────────────────────────────────────

	/**
	 * Bepaalt of een clusternaam relevant genoeg is om gaps voor te genereren.
	 *
	 * Retourneert false als:
	 *  - De naam een generiek woord bevat (sample, page, uncategorized, hello world, test).
	 *  - De naam minder dan 2 delen heeft na splitsen op '+'.
	 *  - Er een niche is ingesteld én de clusternaam geen relatie heeft met die niche.
	 *
	 * @param  string $cluster_name
	 * @return bool
	 */
	private function is_relevant_cluster( string $cluster_name ): bool {
		$lower = mb_strtolower( $cluster_name );

		// Generieke blacklist.
		foreach ( [ 'sample', 'page', 'uncategorized', 'hello world', 'test' ] as $word ) {
			if ( str_contains( $lower, $word ) ) {
				return false;
			}
		}

		// Minimaal 2 delen vereist na splitsen op '+'.
		$parts = array_filter( array_map( 'trim', explode( '+', $cluster_name ) ) );
		if ( count( $parts ) < 2 ) {
			return false;
		}

		// Niche-filter via bestaande cluster_matches_niche()-logica.
		return $this->cluster_matches_niche( $cluster_name );
	}

	/**
	 * Controleert of een clusternaam semantisch gerelateerd is aan de ingestelde niche.
	 *
	 * Als geen niche is geconfigureerd (leeg), worden alle clusters geaccepteerd.
	 *
	 * Matchinglogica (twee stappen — bij een treffer in stap 1 stopt de check):
	 *  1. Directe substring: bevat cluster_name de niche-term of vice versa?
	 *  2. Prefix-overlap (4 tekens): deelt een woord uit cluster_name een 4-char
	 *     prefix met een woord uit de niche-woordset? Dit vangt verbuigingen op
	 *     (hardlopen / hardlopers / hardloper → "hard").
	 *
	 * @param  string $cluster_name
	 * @return bool   true als verwant (of geen niche geconfigureerd).
	 */
	private function cluster_matches_niche( string $cluster_name ): bool {
		if ( empty( $this->niche_words ) ) {
			return true; // Geen niche ingesteld → analyseer alles.
		}

		$lower = mb_strtolower( $cluster_name );

		// Stap 1: directe substring-check voor elk niche-woord.
		foreach ( array_keys( $this->niche_words ) as $niche_word ) {
			if ( str_contains( $lower, $niche_word ) ) {
				return true;
			}
		}

		// Stap 2: 4-char prefix-overlap om verbuigingen te vangen.
		$cluster_word_set = $this->build_word_set( $cluster_name );

		foreach ( array_keys( $cluster_word_set ) as $cw ) {
			$cw_prefix = mb_substr( $cw, 0, 4 );
			foreach ( array_keys( $this->niche_words ) as $nw ) {
				if ( mb_substr( $nw, 0, 4 ) === $cw_prefix ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Bouwt een word-set (lowercase, ≥4 tekens) uit een tekst.
	 *
	 * @param  string $text
	 * @return array<string, true>
	 */
	private function build_word_set( string $text ): array {
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $text ), -1, PREG_SPLIT_NO_EMPTY );
		$set    = [];
		foreach ( $tokens ?? [] as $token ) {
			if ( mb_strlen( $token ) >= 4 ) {
				$set[ $token ] = true;
			}
		}
		return $set;
	}

	// ── Filtering ─────────────────────────────────────────────────────────────

	/**
	 * Filtert kandidaten weg die al voldoende gedekt zijn door bestaande titels.
	 *
	 * @param  string[] $candidates
	 * @param  string[] $existing_titles
	 * @return string[]
	 */
	private function filter_covered_titles( array $candidates, array $existing_titles ): array {
		if ( empty( $existing_titles ) ) {
			return $candidates;
		}

		return array_values( array_filter(
			$candidates,
			fn( string $candidate ): bool => ! $this->is_title_covered( $candidate, $existing_titles )
		) );
	}

	/**
	 * Controleert of een kandidaattitel al gedekt is.
	 *
	 * Twee checks:
	 *  1. Jaccard-gelijkenis ≥ COVERAGE_THRESHOLD op de woordsets.
	 *  2. Substring-check: kandidaat staat letterlijk in een bestaande titel.
	 */
	private function is_title_covered( string $candidate, array $existing_titles ): bool {
		$cand_set   = $this->words( mb_strtolower( $candidate ) );
		$cand_lower = mb_strtolower( $candidate );

		foreach ( $existing_titles as $existing ) {
			$exist_lower = mb_strtolower( $existing );

			if ( $this->jaccard( $cand_set, $this->words( $exist_lower ) ) >= self::COVERAGE_THRESHOLD ) {
				return true;
			}

			if ( str_contains( $exist_lower, $cand_lower ) ) {
				return true;
			}
		}

		return false;
	}

	// ── Cannibalisatie ────────────────────────────────────────────────────────

	/**
	 * Bouwt een map van post_id → keyword-set (array_flip van top-10 keywords).
	 *
	 * @param  int[]                    $post_ids
	 * @return array<int, array<string,int>>
	 */
	private function build_keyword_sets( array $post_ids ): array {
		$sets = [];

		foreach ( $post_ids as $post_id ) {
			$keywords = $this->get_post_keywords( $post_id, 10 );

			if ( ! empty( $keywords ) ) {
				$sets[ $post_id ] = array_flip( $keywords );
			}
		}

		return $sets;
	}

	// ── Keyword-cache helper ──────────────────────────────────────────────────

	/**
	 * Retourneert de top-$limit keywords voor een post, met instance-level caching.
	 *
	 * Herhaalde aanroepen voor dezelfde post_id + limit slaan de NLP-berekening over.
	 * De cache-key bevat de limit zodat aanroepen met verschillende limieten beiden
	 * gecached worden.
	 *
	 * @param  int    $post_id
	 * @param  int    $limit
	 * @return string[]
	 */
	private function get_post_keywords( int $post_id, int $limit ): array {
		$cache_key = "{$post_id}:{$limit}";

		if ( isset( $this->keyword_cache[ $cache_key ] ) ) {
			return $this->keyword_cache[ $cache_key ];
		}

		$post = get_post( $post_id );

		if ( ! $post instanceof WP_Post ) {
			$this->keyword_cache[ $cache_key ] = [];
			return [];
		}

		$keywords = $this->nlp->extract_keywords( $post, $limit );

		$this->keyword_cache[ $cache_key ] = $keywords;

		return $keywords;
	}

	// ── Intent-detectie ───────────────────────────────────────────────────────

	/**
	 * Bepaalt de zoekintent op basis van titelwoorden.
	 *
	 * @param  string $title
	 * @param  string $lang  'nl' | 'en'
	 * @return string 'informational' | 'commercial' | 'navigational'
	 */
	private function detect_search_intent( string $title, string $lang ): string {
		$lower = mb_strtolower( $title );

		$commercial_nl   = [ 'kopen', 'prijs', 'kosten', 'goedkoop', 'beste', 'vergelijken',
			'vergelijking', 'optie', 'kiezen', 'aanbieding', 'korting', 'budget', 'betaalbaar',
			'gratis', 'proberen', 'abonnement' ];
		$commercial_en   = [ 'buy', 'price', 'cost', 'cheap', 'best', 'compare',
			'deal', 'discount', 'budget', 'affordable', 'free', 'trial', 'subscription' ];
		$navigational_nl = [ 'inloggen', 'login', 'contact', 'over ons', 'download',
			'aanmelden', 'registreren', 'support', 'helpdesk' ];
		$navigational_en = [ 'login', 'contact', 'about us', 'download',
			'sign up', 'register', 'support', 'helpdesk' ];

		$commercial_terms   = 'nl' === $lang ? $commercial_nl : $commercial_en;
		$navigational_terms = 'nl' === $lang ? $navigational_nl : $navigational_en;

		foreach ( $commercial_terms as $term ) {
			if ( str_contains( $lower, $term ) ) {
				return 'commercial';
			}
		}

		foreach ( $navigational_terms as $term ) {
			if ( str_contains( $lower, $term ) ) {
				return 'navigational';
			}
		}

		return 'informational';
	}

	// ── GSC-matching ──────────────────────────────────────────────────────────

	/**
	 * Koppelt een titeltekst aan de bijbehorende GSC-impressies.
	 *
	 * Strategie (volgorde van meest naar minst specifiek):
	 *  1. Exacte match op de volledige titel (lowercase).
	 *  2. Partieel: een GSC-zoekterm staat als substring in de titel.
	 *  3. Partieel: de titel staat als substring in een GSC-zoekterm.
	 * Retourneert de hoogste gevonden waarde bij meerdere partial matches.
	 *
	 * @param  string $title
	 * @return int    GSC-impressies, 0 als geen match.
	 */
	private function match_gsc_impressions( string $title ): int {
		if ( empty( $this->gsc_impressions ) ) {
			return 0;
		}

		$lower = mb_strtolower( $title );

		// Exacte match.
		if ( isset( $this->gsc_impressions[ $lower ] ) ) {
			return (int) $this->gsc_impressions[ $lower ];
		}

		// Partiële match: neem het maximum over alle treffers.
		$best = 0;
		foreach ( $this->gsc_impressions as $query => $impressions ) {
			if ( str_contains( $lower, $query ) || str_contains( $query, $lower ) ) {
				$best = max( $best, (int) $impressions );
			}
		}

		return $best;
	}

	/**
	 * Geeft het aantal GSC-clicks terug voor een gap-titel (fuzzy match).
	 *
	 * @param  string $title
	 * @return int
	 */
	private function match_gsc_clicks( string $title ): int {
		if ( empty( $this->gsc_clicks ) ) {
			return 0;
		}

		$lower = mb_strtolower( $title );

		if ( isset( $this->gsc_clicks[ $lower ] ) ) {
			return (int) $this->gsc_clicks[ $lower ];
		}

		$best = 0;
		foreach ( $this->gsc_clicks as $query => $clicks ) {
			if ( str_contains( $lower, $query ) || str_contains( $query, $lower ) ) {
				$best = max( $best, (int) $clicks );
			}
		}

		return $best;
	}

	/**
	 * Genereert aanvullende gaps op basis van GSC-queries die geen matching post hebben.
	 *
	 * Queries met ≥10 impressies die niet al gedekt worden door een bestaande post
	 * worden als gap-kandidaat toegevoegd aan het best-matchende cluster.
	 *
	 * @param  object[] $clusters  Cluster-objecten (uit cgm_topics of synthetisch).
	 * @return array[]  Gap-records in hetzelfde formaat als find_gaps_for_cluster().
	 */
	private function find_gsc_query_gaps( array $clusters ): array {
		if ( empty( $this->gsc_impressions ) ) {
			return [];
		}

		// Bouw cluster-index op: lowercase naam → topic_id (alleen echte DB-records).
		$cluster_index = [];
		foreach ( $clusters as $cluster ) {
			if ( (int) $cluster->id > 0 ) {
				$cluster_index[ mb_strtolower( $cluster->cluster_name ) ] = (int) $cluster->id;
			}
		}

		if ( empty( $cluster_index ) ) {
			return [];
		}

		// Haal alle bestaande post-titels op voor dekkingscheck.
		$all_titles = $this->get_all_published_titles();

		$gaps = [];
		foreach ( $this->gsc_impressions as $query => $impressions ) {
			// Alleen queries met voldoende volume.
			if ( $impressions < 10 ) {
				continue;
			}

			$query_title = ucfirst( $query );

			// Skip als de query al gedekt wordt door een bestaande post.
			$uncovered = $this->filter_covered_titles( [ $query_title ], $all_titles );
			if ( empty( $uncovered ) ) {
				continue;
			}

			// Basisvalidatie.
			if ( ! $this->validate_gap_title( $query_title ) ) {
				continue;
			}

			// Zoek het best-matchende cluster.
			$topic_id = $this->find_best_cluster_for_query( $query, $cluster_index );
			if ( 0 === $topic_id ) {
				continue;
			}

			$intent  = $this->detect_search_intent( $query_title, 'nl' );
			$clicks  = (int) ( $this->gsc_clicks[ $query ] ?? 0 );
			$score   = $this->calculate_priority_score( $query_title, $impressions, 0.0, $intent );

			$gaps[] = [
				'topic_id'        => $topic_id,
				'suggested_title' => $query_title,
				'search_intent'   => $intent,
				'gsc_impressions' => $impressions,
				'gsc_clicks'      => $clicks,
				'priority_score'  => $score,
			];
		}

		return $gaps;
	}

	/**
	 * Zoekt het cluster (topic_id) dat het beste past bij een GSC-query.
	 *
	 * @param  string           $query          Zoekterm (lowercase).
	 * @param  array<string,int> $cluster_index  [cluster_name_lc => topic_id].
	 * @return int  topic_id of 0 als geen match.
	 */
	private function find_best_cluster_for_query( string $query, array $cluster_index ): int {
		$query_words  = $this->build_word_set( $query );
		$best_id      = 0;
		$best_overlap = 0;

		foreach ( $cluster_index as $cluster_name => $topic_id ) {
			$cluster_words = $this->build_word_set( $cluster_name );
			$overlap       = count( array_intersect_key( $query_words, $cluster_words ) );

			if ( $overlap > $best_overlap ) {
				$best_overlap = $overlap;
				$best_id      = $topic_id;
			}
		}

		// Accepteer ook een eerste cluster als er geen woordoverlap is maar slechts één cluster bestaat.
		if ( 0 === $best_id && count( $cluster_index ) === 1 ) {
			$best_id = reset( $cluster_index );
		}

		return $best_id;
	}

	/**
	 * Haalt alle gepubliceerde post-titels op als platte array.
	 *
	 * @return string[]
	 */
	private function get_all_published_titles(): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$titles = $wpdb->get_col(
			"SELECT post_title FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type = 'post'"
		);

		return $titles ?: [];
	}

	// ── Generieke helpers ─────────────────────────────────────────────────────

	/**
	 * Converteert een tekst naar een word-set (array_flip) voor Jaccard-berekening.
	 * Woorden van minder dan 3 tekens worden genegeerd.
	 *
	 * @return array<string, int>
	 */
	private function words( string $text ): array {
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		return array_flip( array_filter(
			$tokens ?? [],
			static fn( string $w ): bool => strlen( $w ) >= 3
		) );
	}

	/**
	 * Berekent de Jaccard-gelijkenis van twee word-sets (array_flip-formaat).
	 *
	 * Jaccard(A, B) = |A ∩ B| / |A ∪ B|
	 * array_intersect_key geeft de ∩; array_merge op associatieve arrays geeft de ∪
	 * (duplicate sleutels worden overschreven, waardoor de unie gevormd wordt).
	 *
	 * @param array<string,int> $a
	 * @param array<string,int> $b
	 * @return float 0.0–1.0
	 */
	private function jaccard( array $a, array $b ): float {
		if ( empty( $a ) || empty( $b ) ) {
			return 0.0;
		}

		$intersection = count( array_intersect_key( $a, $b ) );
		$union        = count( array_merge( $a, $b ) );

		return $union > 0 ? $intersection / $union : 0.0;
	}

	// ── Titel-gebaseerde cannibalisatiedetectie ───────────────────────────────

	/**
	 * Detecteert cannibaliserende post-paren op basis van titeloverlap voor ALLE
	 * gepubliceerde posts (niet alleen posts binnen clusters).
	 *
	 * Algoritme:
	 *  1. Haal alle gepubliceerde posts op.
	 *  2. Vergelijk elk uniek paar (combinaties zonder duplicaten).
	 *  3. Bereken overlap_score:
	 *       - Splits titels op spaties.
	 *       - Filter Nederlandse stopwoorden.
	 *       - score = (gedeelde keywords / totaal unieke keywords) × 100
	 *  4. Paren met score >= 40 worden opgeslagen.
	 *  5. Bestaande records voor deze site worden eerst verwijderd.
	 *
	 * @return int Aantal opgeslagen paren.
	 */
	public function detect_cannibalization_and_save(): int {
		global $wpdb;

		static $stopwords = [
			'de', 'het', 'een', 'van', 'voor', 'met', 'bij', 'op', 'in',
			'en', 'of', 'als', 'te', 'naar', 'is', 'zijn', 'je', 'jouw', 'uw',
		];

		$posts = get_posts( [
			'numberposts'             => -1,
			'post_status'             => 'publish',
			'post_type'               => 'post',
			'no_found_rows'           => true,
			'update_post_meta_cache'  => true,
			'update_post_term_cache'  => true,
			'suppress_filters'        => true,
			'lang'                    => '',
		] );

		if ( count( $posts ) < 2 ) {
			return 0;
		}

		$post_vectors = [];
		foreach ( $posts as $post ) {
			$title_tokens    = $this->normalize_cannibalization_tokens( (string) $post->post_title, $stopwords );
			$content         = wp_strip_all_tags( (string) $post->post_content );
			$content         = mb_substr( $content, 0, 2500 );
			$content_tokens  = $this->normalize_cannibalization_tokens( $content, $stopwords );
			$semantic_meta   = get_post_meta( $post->ID, '_cgm_semantic_keywords', true );
			$semantic_tokens = [];
			if ( is_array( $semantic_meta ) ) {
				$semantic_tokens = $this->normalize_cannibalization_tokens( implode( ' ', $semantic_meta ), $stopwords );
			}
			$focus = (string) get_post_meta( $post->ID, '_cgm_focus_keyword', true );
			$focus_tokens = $this->normalize_cannibalization_tokens( $focus, $stopwords );

			$post_vectors[ (int) $post->ID ] = [
				'title'    => array_values( array_unique( $title_tokens ) ),
				'content'  => array_values( array_unique( array_merge( $title_tokens, $content_tokens ) ) ),
				'semantic' => array_values( array_unique( array_merge( $semantic_tokens, $focus_tokens ) ) ),
				'intent'   => $this->infer_cannibalization_intent( (string) $post->post_title . ' ' . $content ),
				'cluster'  => (string) get_post_meta( $post->ID, '_cgm_cluster', true ),
			];
		}

		$ids   = array_keys( $post_vectors );
		$n     = count( $ids );
		$pairs = [];

		for ( $i = 0; $i < $n - 1; $i++ ) {
			for ( $j = $i + 1; $j < $n; $j++ ) {
				$id_a = $ids[ $i ];
				$id_b = $ids[ $j ];
				$a    = $post_vectors[ $id_a ];
				$b    = $post_vectors[ $id_b ];

				$title_overlap    = $this->token_jaccard( $a['title'], $b['title'] );
				$content_overlap  = $this->token_jaccard( $a['content'], $b['content'] );
				$semantic_overlap = $this->token_jaccard( $a['semantic'], $b['semantic'] );
				$intent_bonus     = ( $a['intent'] !== '' && $a['intent'] === $b['intent'] ) ? 0.15 : 0.0;
				$cluster_bonus    = ( $a['cluster'] !== '' && $a['cluster'] === $b['cluster'] ) ? 0.10 : 0.0;

				$combined = min( 1, ( $title_overlap * 0.35 ) + ( $content_overlap * 0.35 ) + ( $semantic_overlap * 0.20 ) + $intent_bonus + $cluster_bonus );
				$score    = (int) round( $combined * 100 );

				if ( $score >= 45 ) {
					$pairs[] = [
						'post_id_1'        => min( $id_a, $id_b ),
						'post_id_2'        => max( $id_a, $id_b ),
						'similarity_score' => round( $combined, 4 ),
						'overlap_score'    => $score,
					];
				}
			}
		}

		$table = $wpdb->prefix . 'cgm_cannibalization';
		$wpdb->delete( $table, [ 'site_id' => $this->site_id ], [ '%d' ] );

		$inserted = 0;
		foreach ( $pairs as $pair ) {
			$result = $wpdb->insert(
				$table,
				[
					'site_id'          => $this->site_id,
					'post_id_1'        => $pair['post_id_1'],
					'post_id_2'        => $pair['post_id_2'],
					'similarity_score' => $pair['similarity_score'],
					'overlap_score'    => $pair['overlap_score'],
					'status'           => 'open',
				],
				[ '%d', '%d', '%d', '%f', '%d', '%s' ]
			);
			if ( false !== $result ) {
				++$inserted;
			}
		}

		return $inserted;
	}

	private function normalize_cannibalization_tokens( string $text, array $stopwords = [] ): array {
		$text   = mb_strtolower( wp_strip_all_tags( $text ) );
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		$tokens = array_filter( $tokens ?: [], static function( string $token ) use ( $stopwords ): bool {
			$token = trim( $token );
			return '' !== $token && mb_strlen( $token ) >= 3 && ! in_array( $token, $stopwords, true );
		} );
		return array_values( array_unique( $tokens ) );
	}

	private function token_jaccard( array $a, array $b ): float {
		if ( empty( $a ) || empty( $b ) ) {
			return 0.0;
		}
		$intersection = count( array_intersect( $a, $b ) );
		$union        = count( array_unique( array_merge( $a, $b ) ) );
		return $union > 0 ? ( $intersection / $union ) : 0.0;
	}

	private function infer_cannibalization_intent( string $text ): string {
		$text = mb_strtolower( $text );
		if ( preg_match( '/\b(kopen|prijs|kosten|beste|review|vergelijk|broker|aanbieding)\b/u', $text ) ) {
			return 'commercial';
		}
		if ( preg_match( '/\b(wat is|uitleg|handleiding|gids|hoe werkt|beginnen met|definitie)\b/u', $text ) ) {
			return 'informational';
		}
		if ( preg_match( '/\b(inschrijven|download|aanmelden|proberen|tool)\b/u', $text ) ) {
			return 'transactional';
		}
		return '';
	}

	/**
	 * Verwijdert dubbele woorden uit een gap-titel.
	 *
	 * Stappen:
	 *  1. Verwijdert opeenvolgende duplicaten ("je je" → "je").
	 *  2. Verwijdert bijna-duplicaten binnen een venster van 3 woorden.
	 *  3. Past een blacklist van bekende dubbele patronen toe via str_replace.
	 *
	 * @param  string $title
	 * @return string  Gecleande titel.
	 */
	private function clean_duplicate_words( string $title ): string {
		$blacklist = [
			'je je', 'de de', 'het het', 'een een',
			'van van', 'voor voor',
		];

		// Stap 3: blacklist-patronen vervangen (ook als ze er dubbel in staan na andere stappen).
		$title = str_ireplace( $blacklist, array_map( static fn( string $p ): string => explode( ' ', $p )[0], $blacklist ), $title );

		$words  = preg_split( '/(\s+)/u', $title, -1, PREG_SPLIT_DELIM_CAPTURE );
		$tokens = array_values( array_filter( $words, static fn( string $w ): bool => trim( $w ) !== '' ) );

		if ( empty( $tokens ) ) {
			return $title;
		}

		$result = [];
		$window = 3; // Venstergrootte voor bijna-duplicaat check.

		foreach ( $tokens as $i => $word ) {
			$lower = mb_strtolower( $word );

			// Stap 1 & 2: controleer of dit woord al voorkomt in de vorige $window tokens.
			$is_duplicate = false;
			for ( $j = max( 0, count( $result ) - $window ); $j < count( $result ); $j++ ) {
				if ( mb_strtolower( $result[ $j ] ) === $lower ) {
					$is_duplicate = true;
					break;
				}
			}

			if ( ! $is_duplicate ) {
				$result[] = $word;
			}
		}

		return implode( ' ', $result );
	}


	private function cluster_has_pillar_page( string $cluster_name ): bool {
		$pillar_map = get_option( 'contentgem_pillar_pages', [] );
		if ( ! is_array( $pillar_map ) || '' === trim( $cluster_name ) ) { return false; }
		foreach ( $pillar_map as $saved_cluster => $raw_ids ) {
			if ( sanitize_title( (string) $saved_cluster ) === sanitize_title( $cluster_name ) ) {
				$ids = is_array( $raw_ids ) ? array_filter( array_map( 'absint', $raw_ids ) ) : [ absint( $raw_ids ) ];
				return ! empty( $ids );
			}
		}
		return false;
	}

	private function pad_cluster_gaps( array $gaps, string $cluster_name, array $existing_titles, string $lang, float $coverage_score, int $target_min ): array {
		if ( count( $gaps ) >= $target_min ) { return $gaps; }
		$seen_titles = array_map( static fn( array $gap ) => strtolower( (string) ( $gap['suggested_title'] ?? '' ) ), $gaps );
		$supplemental_titles = 'nl' === $lang ? [ "Veelgemaakte fouten bij {$cluster_name}", "{$cluster_name}: checklist voor implementatie", "Praktische voorbeelden van {$cluster_name}", "Hoe je {$cluster_name} meet en optimaliseert", "Beste tools voor {$cluster_name}", "{$cluster_name} in de praktijk: stappenplan" ] : [ "Common {$cluster_name} mistakes to avoid", "{$cluster_name} implementation checklist", "Practical {$cluster_name} examples", "How to measure and optimize {$cluster_name}", "Best tools for {$cluster_name}", "{$cluster_name} workflow and execution plan" ];
		foreach ( $supplemental_titles as $title ) {
			$title = sanitize_text_field( $title );
			if ( '' === $title || in_array( strtolower( $title ), $seen_titles, true ) ) { continue; }
			$gaps[] = [ 'topic_id' => 0, 'suggested_title' => $title, 'search_intent' => 'informational', 'gsc_impressions' => 0, 'gsc_clicks' => 0, 'priority_score' => round( max( 5.0, 90.0 - ( min( 1.0, max( 0.0, $coverage_score ) ) * 30.0 ) ), 2 ) ];
			$seen_titles[] = strtolower( $title );
			if ( count( $gaps ) >= $target_min ) break;
		}
		usort( $gaps, static fn( array $a, array $b ) => $b['priority_score'] <=> $a['priority_score'] );
		return $gaps;
	}

}
