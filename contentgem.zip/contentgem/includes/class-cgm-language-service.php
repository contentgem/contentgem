<?php
/**
 * Central language service for Contentgem AI output.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Language_Service {
	public function get_language_code(): string {
		$configured = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		$custom     = sanitize_text_field( (string) get_option( 'contentgem_content_language_custom', '' ) );
		if ( 'custom' === $configured && '' !== $custom ) {
			$normalized = $this->normalize_language_code( $custom );
			if ( '' !== $normalized && 'custom' !== $normalized && 'auto' !== $normalized ) {
				return $normalized;
			}
		}
		$normalized = $this->normalize_language_code( $configured );
		if ( '' !== $normalized && 'custom' !== $normalized && 'auto' !== $normalized ) {
			return $normalized;
		}
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$locale = strtolower( (string) $locale );
		if ( preg_match( '/^[a-z]{2,3}(?:[-_][a-z0-9]{2,8})?$/', $locale ) ) {
			$locale = str_replace( '_', '-', $locale );
			$parts = explode( '-', $locale );
			return sanitize_key( $parts[0] ?: 'en' );
		}
		return 'en';
	}

	public function get_language_label( ?string $code = null ): string {
		$code = $code ?: $this->get_language_code();
		$map = [
			'nl' => 'Dutch', 'en' => 'English', 'de' => 'German', 'fr' => 'French', 'es' => 'Spanish',
			'it' => 'Italian', 'pt' => 'Portuguese', 'sv' => 'Swedish', 'pl' => 'Polish',
			'no' => 'Norwegian', 'da' => 'Danish', 'fi' => 'Finnish', 'ja' => 'Japanese',
		];
		return $map[ $code ] ?? 'English';
	}

	public function build_language_rules( ?string $language = null ): string {
		$language = $language ?: $this->get_language_code();
		if ( 'nl' === $language ) {
			return "Return all output in Dutch only.
Do not use English unless it is a necessary brand or technical term.
Do not mix languages.
If source inputs are English, translate the final output into natural Dutch.
Titels, subtitels, beschrijvingen en keywords moeten in het Nederlands zijn tenzij een merknaam of technische productnaam behouden moet blijven.";
		}
		return "Return all output in English only.
Do not use Dutch.
Do not mix languages.
If source inputs are Dutch, translate the final output into natural English.
Titles, subtitles, descriptions and keywords must all be in English unless a brand or technical product name must remain unchanged.";
	}

	public function validate_output_language( string $text, ?string $language = null ): bool {
		$language = $language ?: $this->get_language_code();
		$text_lc  = function_exists( 'mb_strtolower' ) ? mb_strtolower( ' ' . $text . ' ' ) : strtolower( ' ' . $text . ' ' );
		if ( 'nl' === $language ) {
			$foreign = [ ' how ', ' best ', ' guide ', ' compare ', ' mistakes ', ' tools ', ' beginner ', ' practical strategies ', ' content opportunities ' ];
			$hits = 0;
			foreach ( $foreign as $marker ) {
				if ( false !== strpos( $text_lc, $marker ) ) { $hits++; }
			}
			return $hits < 2;
		}
		$foreign = [ ' hoe ', ' beste ', ' gids ', ' vergelijken ', ' fouten ', ' voor beginners ', ' praktische ', ' strategieën ', ' strategieen ' ];
		$hits = 0;
		foreach ( $foreign as $marker ) {
			if ( false !== strpos( $text_lc, $marker ) ) { $hits++; }
		}
		return $hits < 2;
	}

	public function normalize_language_code( string $language ): string {
		$language = strtolower( trim( sanitize_text_field( $language ) ) );
		$map = [
			'dutch' => 'nl', 'nederlands' => 'nl', 'nl-nl' => 'nl',
			'english' => 'en', 'engels' => 'en', 'en-us' => 'en', 'en-gb' => 'en',
			'deutsch' => 'de', 'german' => 'de',
			'francais' => 'fr', 'français' => 'fr', 'french' => 'fr',
			'espanol' => 'es', 'español' => 'es', 'spanish' => 'es',
			'italiano' => 'it', 'italian' => 'it',
			'portugues' => 'pt', 'português' => 'pt', 'portuguese' => 'pt',
			'svenska' => 'sv', 'swedish' => 'sv',
			'polski' => 'pl', 'polish' => 'pl',
			'norsk' => 'no', 'norwegian' => 'no',
			'dansk' => 'da', 'danish' => 'da',
			'suomi' => 'fi', 'finnish' => 'fi',
			'japanese' => 'ja', '日本語' => 'ja',
		];
		if ( isset( $map[ $language ] ) ) { return $map[ $language ]; }
		if ( 'auto' === $language || 'custom' === $language ) { return $language; }
		$language = str_replace( '_', '-', $language );
		if ( preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $language ) ) {
			$parts = explode( '-', $language );
			return sanitize_key( $parts[0] );
		}
		return '';
	}
}
