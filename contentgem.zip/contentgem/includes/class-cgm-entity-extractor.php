<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Entity_Extractor {
	public function extract_entities_from_text( string $text ): array {
		$text = preg_replace( '/\s+/', ' ', $text );
		preg_match_all( '/([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})/u', $text, $matches );
		$entities = array_values( array_unique( array_filter( array_map( 'trim', $matches[1] ?? [] ) ) ) );
		return array_slice( $entities, 0, 25 );
	}
	public function extract_entities_from_post( int $post_id ): array { $post = get_post( $post_id ); return $post ? $this->extract_entities_from_text( wp_strip_all_tags( (string) $post->post_title . ' ' . (string) $post->post_content ) ) : []; }
	public function normalize_entities( array $entities ): array { return array_values( array_unique( array_filter( array_map( static function( $e ) { return sanitize_text_field( (string) $e ); }, $entities ) ) ) ); }
}
