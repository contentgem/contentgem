<?php
/**
 * Class CGM_GSC_Connector
 *
 * Beheert de OAuth2-koppeling met Google Search Console en haalt zoekanalysedata op.
 *
 * Tokens worden opgeslagen als WordPress-opties met autoload=false zodat ze niet
 * bij elke paginalading worden ingeladen.
 *
 * Flow:
 *  1. Sla client_id en client_secret op via update_option.
 *  2. get_auth_url() → redirect gebruiker naar Google.
 *  3. Google redirect naar get_redirect_uri() met ?code=...&state=...
 *  4. handle_callback($code, $state) → wisselt code in voor tokens.
 *  5. Vervolg via get_top_queries() / get_search_analytics() etc.
 *
 * @package Contentgem
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_GSC_Connector {

	private const AUTH_URL  = 'https://accounts.google.com/o/oauth2/v2/auth';
	private const REDIRECT_PAGE_SLUG = 'contentgem';
	private const TOKEN_URL = 'https://oauth2.googleapis.com/token';
	private const API_BASE  = 'https://www.googleapis.com/webmasters/v3';
	private const SCOPE     = 'https://www.googleapis.com/auth/webmasters.readonly';

	// ── Publieke API ──────────────────────────────────────────────────────────

	/**
	 * Genereert de OAuth2 autorisatie-URL naar Google.
	 *
	 * @return string  Lege string als geen client_id is ingesteld.
	 */
	public function get_auth_url(): string {
		$client_id = (string) get_option( 'contentgem_gsc_client_id', '' );
		if ( empty( $client_id ) ) {
			return '';
		}

		// Genereer een state-token voor CSRF-bescherming.
		$state = wp_hash( 'gsc_oauth_' . get_current_user_id() . wp_create_nonce( 'cgm_gsc_connect' ) );
		update_option( 'contentgem_gsc_oauth_state', $state, false );

		$redirect_uri = $this->get_redirect_uri();
		$query_args   = [
			'client_id'     => $client_id,
			'redirect_uri'  => $redirect_uri,
			'response_type' => 'code',
			'scope'         => self::SCOPE,
			'access_type'   => 'offline',
			'prompt'        => 'consent',
			'state'         => $state,
		];

		// Build the OAuth URL explicitly so redirect_uri keeps its full encoded query string.
		$auth_url = self::AUTH_URL . '?' . http_build_query( $query_args, '', '&', PHP_QUERY_RFC3986 );

		$this->store_debug_payload( [
			'generated_at'   => current_time( 'mysql' ),
			'client_id_hint' => $this->get_client_id_hint( $client_id ),
			'redirect_uri'   => $redirect_uri,
			'auth_url'       => $auth_url,
			'page_slug'      => self::REDIRECT_PAGE_SLUG,
		] );

		return $auth_url;
	}

	/**
	 * Verwerkt de OAuth2 callback en wisselt de autorisatiecode in voor tokens.
	 *
	 * @param  string $code   Autorisatiecode van Google.
	 * @param  string $state  State-parameter ter validatie van CSRF.
	 * @return bool  true bij succes.
	 */
	public function handle_callback( string $code, string $state = '' ): bool {
		// Valideer state ter voorkoming van CSRF.
		$stored_state = (string) get_option( 'contentgem_gsc_oauth_state', '' );
		if ( '' !== $state && '' !== $stored_state && ! hash_equals( $stored_state, $state ) ) {
			$this->store_debug_payload( [
				'generated_at' => current_time( 'mysql' ),
				'redirect_uri' => $this->get_redirect_uri(),
				'callback_status' => 'state_mismatch',
			] );
			return false;
		}

		$response = wp_remote_post(
			self::TOKEN_URL,
			[
				'timeout' => 30,
				'body'    => [
					'code'          => $code,
					'client_id'     => (string) get_option( 'contentgem_gsc_client_id', '' ),
					'client_secret' => (string) get_option( 'contentgem_gsc_client_secret', '' ),
					'redirect_uri'  => $this->get_redirect_uri(),
					'grant_type'    => 'authorization_code',
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			$this->store_debug_payload( [
				'generated_at'    => current_time( 'mysql' ),
				'redirect_uri'    => $this->get_redirect_uri(),
				'callback_status' => 'token_request_wp_error',
				'token_request'   => [
					'redirect_uri'  => $this->get_redirect_uri(),
					'client_id_hint' => $this->get_client_id_hint( (string) get_option( 'contentgem_gsc_client_id', '' ) ),
				],
				'callback_error'  => $response->get_error_message(),
			] );
			return false;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['access_token'] ) ) {
			$this->store_debug_payload( [
				'generated_at'    => current_time( 'mysql' ),
				'redirect_uri'    => $this->get_redirect_uri(),
				'callback_status' => 'token_missing',
				'token_http_code' => (int) wp_remote_retrieve_response_code( $response ),
				'token_request'   => [
					'redirect_uri'   => $this->get_redirect_uri(),
					'client_id_hint' => $this->get_client_id_hint( (string) get_option( 'contentgem_gsc_client_id', '' ) ),
				],
				'callback_response' => is_array( $data ) ? array_intersect_key( $data, array_flip( [ 'error', 'error_description' ] ) ) : [],
			] );
			return false;
		}

		update_option( 'contentgem_gsc_access_token', $data['access_token'], false );

		if ( ! empty( $data['refresh_token'] ) ) {
			update_option( 'contentgem_gsc_refresh_token', $data['refresh_token'], false );
		}

		$expires_in = (int) ( $data['expires_in'] ?? 3600 );
		update_option( 'contentgem_gsc_token_expires', time() + $expires_in - 60, false );

		// State is eenmalig — verwijder na gebruik.
		delete_option( 'contentgem_gsc_oauth_state' );
		$this->store_debug_payload( [
			'generated_at' => current_time( 'mysql' ),
			'redirect_uri' => $this->get_redirect_uri(),
			'callback_status' => 'connected',
			'has_refresh_token' => ! empty( $data['refresh_token'] ),
		] );

		return true;
	}

	/**
	 * Vernieuwt het verlopen access token via het opgeslagen refresh token.
	 *
	 * @return bool  true bij succes.
	 */
	public function refresh_access_token(): bool {
		$refresh_token = (string) get_option( 'contentgem_gsc_refresh_token', '' );
		if ( empty( $refresh_token ) ) {
			return false;
		}

		$response = wp_remote_post(
			self::TOKEN_URL,
			[
				'timeout' => 30,
				'body'    => [
					'refresh_token' => $refresh_token,
					'client_id'     => (string) get_option( 'contentgem_gsc_client_id', '' ),
					'client_secret' => (string) get_option( 'contentgem_gsc_client_secret', '' ),
					'grant_type'    => 'refresh_token',
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			$this->store_debug_payload( [
				'generated_at'    => current_time( 'mysql' ),
				'redirect_uri'    => $this->get_redirect_uri(),
				'callback_status' => 'token_request_wp_error',
				'token_request'   => [
					'redirect_uri'  => $this->get_redirect_uri(),
					'client_id_hint' => $this->get_client_id_hint( (string) get_option( 'contentgem_gsc_client_id', '' ) ),
				],
				'callback_error'  => $response->get_error_message(),
			] );
			return false;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['access_token'] ) ) {
			$this->store_debug_payload( [
				'generated_at'    => current_time( 'mysql' ),
				'redirect_uri'    => $this->get_redirect_uri(),
				'callback_status' => 'token_missing',
				'token_http_code' => (int) wp_remote_retrieve_response_code( $response ),
				'token_request'   => [
					'redirect_uri'   => $this->get_redirect_uri(),
					'client_id_hint' => $this->get_client_id_hint( (string) get_option( 'contentgem_gsc_client_id', '' ) ),
				],
				'callback_response' => is_array( $data ) ? array_intersect_key( $data, array_flip( [ 'error', 'error_description' ] ) ) : [],
			] );
			return false;
		}

		update_option( 'contentgem_gsc_access_token', $data['access_token'], false );

		$expires_in = (int) ( $data['expires_in'] ?? 3600 );
		update_option( 'contentgem_gsc_token_expires', time() + $expires_in - 60, false );

		return true;
	}

	/**
	 * Controleert of de GSC-koppeling actief is (access token aanwezig).
	 */
	public function is_connected(): bool {
		return '' !== $this->get_valid_token();
	}

	/**
	 * Haalt de lijst van beschikbare GSC properties op.
	 *
	 * @return array[]  Elk element: ['url' => string, 'permission' => string].
	 */
	public function get_site_list(): array {
		$token = $this->get_valid_token();
		if ( empty( $token ) ) {
			return [];
		}

		$response = wp_remote_get(
			self::API_BASE . '/sites',
			[
				'timeout' => 30,
				'headers' => [
					'Authorization' => 'Bearer ' . $token,
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['siteEntry'] ) || ! is_array( $data['siteEntry'] ) ) {
			return [];
		}

		return array_map(
			static fn( array $entry ): array => [
				'url'        => $entry['siteUrl'] ?? '',
				'permission' => $entry['permissionLevel'] ?? '',
			],
			$data['siteEntry']
		);
	}

	/**
	 * Haalt zoekanalysedata op voor de geselecteerde property.
	 *
	 * @param  string $site_url    GSC property URL (bijv. "sc-domain:example.com").
	 * @param  string $start_date  Startdatum (Y-m-d).
	 * @param  string $end_date    Einddatum (Y-m-d).
	 * @return array[]  Rijen met keys, impressions, clicks, ctr, position.
	 */
	public function get_search_analytics( string $site_url, string $start_date, string $end_date ): array {
		$token = $this->get_valid_token();
		if ( empty( $token ) ) {
			return [];
		}

		$endpoint = self::API_BASE . '/sites/' . rawurlencode( $site_url ) . '/searchAnalytics/query';

		$response = wp_remote_post(
			$endpoint,
			[
				'timeout' => 30,
				'headers' => [
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode(
					[
						'startDate'  => $start_date,
						'endDate'    => $end_date,
						'dimensions' => [ 'query' ],
						'rowLimit'   => 1000,
					]
				),
			]
		);

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return $data['rows'] ?? [];
	}

	/**
	 * Haalt de top zoekwoorden op voor de gekoppelde property (laatste 90 dagen).
	 *
	 * @param  int $limit  Maximum aantal zoekwoorden. Standaard 100.
	 * @return array[]  Elk element: ['query', 'impressions', 'clicks', 'ctr', 'position'].
	 */
	public function get_top_queries( int $limit = 100 ): array {
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );
		if ( empty( $site_url ) ) {
			return [];
		}

		$end_date   = gmdate( 'Y-m-d' );
		$start_date = gmdate( 'Y-m-d', strtotime( '-90 days' ) );

		$rows = $this->get_search_analytics( $site_url, $start_date, $end_date );
		if ( empty( $rows ) ) {
			return [];
		}

		// Sorteer op impressies desc.
		usort( $rows, static fn( array $a, array $b ): int => (int) $b['impressions'] - (int) $a['impressions'] );

		$queries = [];
		foreach ( array_slice( $rows, 0, $limit ) as $row ) {
			$query = $row['keys'][0] ?? '';
			if ( '' === $query ) {
				continue;
			}
			$queries[] = [
				'query'       => $query,
				'impressions' => (int) $row['impressions'],
				'clicks'      => (int) $row['clicks'],
				'ctr'         => round( (float) $row['ctr'] * 100, 1 ),
				'position'    => round( (float) $row['position'], 1 ),
			];
		}

		return $queries;
	}

	/**
	 * Verwijdert alle GSC tokens. Behoudt client_id, client_secret en site_url.
	 */
	public function disconnect(): void {
		delete_option( 'contentgem_gsc_access_token' );
		delete_option( 'contentgem_gsc_refresh_token' );
		delete_option( 'contentgem_gsc_token_expires' );
		delete_option( 'contentgem_gsc_oauth_state' );
	}

	/**
	 * Retourneert de redirect URI voor de OAuth2 flow.
	 */
	public function get_redirect_uri(): string {
		return add_query_arg(
			[
				'page'         => self::REDIRECT_PAGE_SLUG,
				'gsc_callback' => '1',
			],
			admin_url( 'admin.php' )
		);
	}

	public function get_debug_payload(): array {
		$debug = get_option( 'contentgem_gsc_debug', [] );
		return is_array( $debug ) ? $debug : [];
	}

	private function store_debug_payload( array $payload ): void {
		update_option( 'contentgem_gsc_debug', $payload, false );
	}

	private function get_client_id_hint( string $client_id ): string {
		if ( '' === $client_id ) {
			return '';
		}
		return substr( $client_id, 0, 12 ) . '…';
	}

	// ── Private helpers ───────────────────────────────────────────────────────

	/**
	 * Haalt een geldig access token op; vernieuwt automatisch als verlopen.
	 */
	private function get_valid_token(): string {
		$token   = (string) get_option( 'contentgem_gsc_access_token', '' );
		$expires = (int) get_option( 'contentgem_gsc_token_expires', 0 );

		if ( '' === $token ) {
			$refresh = (string) get_option( 'contentgem_gsc_refresh_token', '' );
			if ( '' !== $refresh && $this->refresh_access_token() ) {
				$token = (string) get_option( 'contentgem_gsc_access_token', '' );
			}
		}

		if ( '' === $token ) {
			return '';
		}

		if ( $expires > 0 && time() >= $expires ) {
			if ( ! $this->refresh_access_token() ) {
				return '';
			}
			$token = (string) get_option( 'contentgem_gsc_access_token', '' );
		}

		return $token;
	}
}
