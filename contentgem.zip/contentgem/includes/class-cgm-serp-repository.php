<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_SERP_Repository {
	private function table(): string { global $wpdb; return $wpdb->prefix . 'cgm_serp_snapshots'; }
	public function create_snapshot( array $data ): int { global $wpdb; $wpdb->insert( $this->table(), $data ); return (int) $wpdb->insert_id; }
	public function get_latest_snapshot( string $query, string $locale = 'en', string $device = 'desktop' ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE query = %s AND locale = %s AND device_type = %s ORDER BY id DESC LIMIT 1", $query, $locale, $device ), ARRAY_A ); return is_array( $row ) ? $row : null; }
	public function get_snapshots_for_keyword_node( int $keyword_node_id ): array { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE keyword_node_id = %d ORDER BY id DESC", $keyword_node_id ), ARRAY_A ); }
}
