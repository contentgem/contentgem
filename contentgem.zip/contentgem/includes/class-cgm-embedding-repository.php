<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Embedding_Repository {
	private function table(): string { global $wpdb; return $wpdb->prefix . 'cgm_embeddings'; }
	public function save_embedding( array $data ): int { global $wpdb; $wpdb->insert( $this->table(), $data ); return (int) $wpdb->insert_id; }
	public function get_embedding( string $object_type, int $object_id, string $content_hash ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE object_type = %s AND object_id = %d AND content_hash = %s ORDER BY id DESC LIMIT 1", $object_type, $object_id, $content_hash ), ARRAY_A ); return is_array( $row ) ? $row : null; }
	public function delete_embeddings_for_object( string $object_type, int $object_id ): bool { global $wpdb; $wpdb->delete( $this->table(), [ 'object_type' => $object_type, 'object_id' => $object_id ], [ '%s', '%d' ] ); return true; }
}
