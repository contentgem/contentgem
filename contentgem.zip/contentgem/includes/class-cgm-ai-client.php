<?php
/**
 * Class CGM_AI_Client
 *
 * Provider-agnostische AI wrapper die zowel Anthropic Claude als OpenAI ondersteunt.
 * Alle andere classes gebruiken deze client in plaats van CGM_Claude_Client direct.
 *
 * Ondersteunde providers:
 *  - 'claude'  → Anthropic Claude API (claude-sonnet-4-5)
 *  - 'openai'  → OpenAI API (gpt-4o)
 *
 * @package Contentgem
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_AI_Client {

	private const CLAUDE_API_URL  = 'https://api.anthropic.com/v1/messages';
	private const OPENAI_API_URL  = 'https://api.openai.com/v1/chat/completions';
	// Models updated automatically — change here to upgrade
	private const CLAUDE_MODEL    = 'claude-opus-4-5';
	private const OPENAI_MODEL    = 'gpt-4o';
	private const MAX_TOKENS      = 12000;
	private const OPENAI_MAX_COMPLETION_TOKENS = 12000;
	private const CLAUDE_MAX_COMPLETION_TOKENS = 12000;

	private string $provider;
	private string $api_key;

	/**
	 * @param string $provider  'claude' | 'openai'
	 * @param string $api_key   API sleutel voor de gekozen provider.
	 * @throws \InvalidArgumentException Bij onbekende provider.
	 */
	public function __construct( string $provider, string $api_key ) {
		if ( ! in_array( $provider, [ 'claude', 'openai' ], true ) ) {
			throw new \InvalidArgumentException( "Unknown AI provider: {$provider}" );
		}
		$this->provider = $provider;
		$this->api_key  = $api_key;
	}

	/**
	 * Maak een AI client op basis van de ingestelde WordPress opties.
	 *
	 * @return static
	 * @throws \RuntimeException Als er geen API key is ingesteld.
	 */
	public static function from_settings(): static {
		$provider   = (string) get_option( 'contentgem_ai_provider', 'claude' );
		$claude_key = (string) get_option( 'contentgem_claude_api_key', '' );
		if ( '' === $claude_key ) {
			$claude_key = (string) get_option( 'contentgem_api_key', '' );
		}
		$openai_key = (string) get_option( 'contentgem_openai_api_key', '' );

		if ( 'openai' === $provider ) {
			if ( '' !== $openai_key ) {
				return new static( 'openai', $openai_key );
			}
			if ( '' !== $claude_key ) {
				return new static( 'claude', $claude_key );
			}
			throw new \RuntimeException( 'No valid OpenAI or Claude API key set. Add at least one AI provider key in Contentgem Settings.' );
		}

		if ( '' !== $claude_key ) {
			return new static( 'claude', $claude_key );
		}
		if ( '' !== $openai_key ) {
			return new static( 'openai', $openai_key );
		}
		throw new \RuntimeException( 'No valid Claude or OpenAI API key set. Add at least one AI provider key in Contentgem Settings.' );
	}

	/**
	 * Niet-streaming chat call.
	 *
	 * @param array  $messages      [['role' => 'user'|'assistant', 'content' => string], ...]
	 * @param string $system        System prompt.
	 * @param int    $max_tokens    Maximum output tokens.
	 * @return array{text: string, tokens_used: int}
	 * @throws \RuntimeException Bij API-fouten.
	 */
	public function chat( array $messages, string $system = '', int $max_tokens = 1024 ): array {
		if ( 'openai' === $this->provider ) {
			return $this->openai_chat( $messages, $system, $max_tokens );
		}
		return $this->claude_chat( $messages, $system, $max_tokens );
	}

	/**
	 * Streaming chat call.
	 *
	 * @param array    $messages
	 * @param string   $system
	 * @param callable $on_chunk   fn(string $chunk): void
	 * @return array{text: string, tokens_used: int}
	 * @throws \RuntimeException Bij API-fouten.
	 */
	public function chat_stream( array $messages, string $system, callable $on_chunk ): array {
		if ( 'openai' === $this->provider ) {
			return $this->openai_stream( $messages, $system, $on_chunk );
		}
		return $this->claude_stream( $messages, $system, $on_chunk );
	}

	/**
	 * Geeft de naam van de actieve provider terug.
	 */
	public function get_provider(): string {
		return $this->provider;
	}

	/**
	 * Geeft het model van de actieve provider terug.
	 */
	public function get_model(): string {
		return 'openai' === $this->provider ? self::OPENAI_MODEL : self::CLAUDE_MODEL;
	}

	private function clamp_max_tokens( int $requested ): int {
		$requested = max( 256, $requested );
		$limit = 'openai' === $this->provider ? self::OPENAI_MAX_COMPLETION_TOKENS : self::CLAUDE_MAX_COMPLETION_TOKENS;
		return min( $requested, $limit );
	}

	// ── Claude implementatie ──────────────────────────────────────────────────

	private function claude_chat( array $messages, string $system, int $max_tokens ): array {
		$max_tokens = $this->clamp_max_tokens( $max_tokens );
		$payload = [
			'model'      => self::CLAUDE_MODEL,
			'max_tokens' => $max_tokens,
			'messages'   => $messages,
		];

		if ( '' !== $system ) {
			$payload['system'] = $system;
		}

		$response = wp_remote_post( self::CLAUDE_API_URL, [
			'timeout' => 120,
			'headers' => [
				'x-api-key'         => $this->api_key,
				'anthropic-version' => '2023-06-01',
				'content-type'      => 'application/json',
			],
			'body'    => wp_json_encode( $payload ),
		] );

		if ( is_wp_error( $response ) ) {
			throw new \RuntimeException( 'Claude API unreachable: ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			throw new \RuntimeException( sprintf( 'Claude API error %d: %s', $code, $body['error']['message'] ?? 'Unknown' ) );
		}

		return [
			'text'        => $body['content'][0]['text'] ?? '',
			'tokens_used' => ( (int) ( $body['usage']['input_tokens'] ?? 0 ) ) + ( (int) ( $body['usage']['output_tokens'] ?? 0 ) ),
		];
	}

	private function claude_stream( array $messages, string $system, callable $on_chunk ): array {
		set_time_limit( 0 );
		ignore_user_abort( true );

		$accumulated = '';
		$tokens_used = 0;
		$buffer      = '';
		$curl_error  = null;

		$body = wp_json_encode( [
			'model'      => self::CLAUDE_MODEL,
			'max_tokens' => $this->clamp_max_tokens( self::MAX_TOKENS ),
			'stream'     => true,
			'system'     => $system,
			'messages'   => $messages,
		] );

		$ch = curl_init( self::CLAUDE_API_URL );
		curl_setopt_array( $ch, [
			CURLOPT_POST           => true,
			CURLOPT_POSTFIELDS     => $body,
			CURLOPT_RETURNTRANSFER => false,
			CURLOPT_TIMEOUT        => 0,
			CURLOPT_CONNECTTIMEOUT => 30,
			CURLOPT_HTTPHEADER     => [
				'x-api-key: '          . $this->api_key,
				'anthropic-version: 2023-06-01',
				'content-type: application/json',
				'accept: text/event-stream',
			],
			CURLOPT_WRITEFUNCTION  => function ( $ch, $chunk ) use ( &$buffer, &$accumulated, &$tokens_used, $on_chunk ) {
				$buffer .= $chunk;
				$lines   = explode( "\n", $buffer );
				$buffer  = array_pop( $lines );

				foreach ( $lines as $line ) {
					$line = trim( $line );
					if ( ! str_starts_with( $line, 'data: ' ) ) continue;

					$data  = substr( $line, 6 );
					$event = json_decode( $data, true );
					if ( ! is_array( $event ) ) continue;

					$type = $event['type'] ?? '';

					if ( 'content_block_delta' === $type && ( $event['delta']['type'] ?? '' ) === 'text_delta' ) {
						$text = $event['delta']['text'] ?? '';
						if ( '' !== $text ) {
							$accumulated .= $text;
							( $on_chunk )( $text );
							if ( ob_get_level() > 0 ) ob_flush();
							flush();
						}
					}

					if ( 'message_delta' === $type ) {
						$tokens_used = (int) ( $event['usage']['output_tokens'] ?? $tokens_used );
					}
				}

				return strlen( $chunk );
			},
		] );

		curl_exec( $ch );
		if ( curl_errno( $ch ) ) $curl_error = curl_error( $ch );
		curl_close( $ch );

		if ( null !== $curl_error ) {
			throw new \RuntimeException( 'Claude streaming error: ' . $curl_error );
		}

		// Extraheer meta comment
		$meta = '';
		$html = ltrim( $accumulated );
		if ( preg_match( '/^<!--\s*meta:\s*(.+?)\s*-->/s', $html, $matches ) ) {
			$meta = trim( $matches[1] );
			$html = ltrim( substr( $html, strlen( $matches[0] ) ) );
		}

		return [ 'text' => $html, 'meta' => $meta, 'tokens_used' => $tokens_used ];
	}

	// ── OpenAI implementatie ──────────────────────────────────────────────────

	private function openai_chat( array $messages, string $system, int $max_tokens ): array {
		$registry = new CGM_Task_Registry();
		$flags = new CGM_Feature_Flags();
		$optimizer = new CGM_Token_Optimizer( $flags );
		$task = $optimizer->optimize_task_config( $registry->get( 'ai_assistant_research' ), [ 'short_mode' => $max_tokens < 1200 ] );
		$task['max_output_tokens'] = min( (int) $task['max_output_tokens'], $this->clamp_max_tokens( $max_tokens ) );
		$client = new CGM_OpenAI_Client( $this->api_key );
		$result = $client->create_response( 'ai_assistant_research', $task, [
			'instructions' => $system,
			'messages' => $messages,
		] );
		return [
			'text' => (string) ( $result['content'] ?? '' ),
			'tokens_used' => (int) ( $result['usage']['total_tokens'] ?? 0 ),
		];
	}

	private function openai_stream( array $messages, string $system, callable $on_chunk ): array {
		set_time_limit( 0 );
		ignore_user_abort( true );

		$openai_messages = [];
		if ( '' !== $system ) {
			$openai_messages[] = [ 'role' => 'system', 'content' => $system ];
		}
		foreach ( $messages as $msg ) {
			$openai_messages[] = $msg;
		}

		$accumulated = '';
		$tokens_used = 0;
		$buffer      = '';
		$curl_error  = null;

		$body = wp_json_encode( [
			'model'      => self::OPENAI_MODEL,
			'max_tokens' => $this->clamp_max_tokens( self::MAX_TOKENS ),
			'stream'     => true,
			'messages'   => $openai_messages,
		] );

		$ch = curl_init( self::OPENAI_API_URL );
		curl_setopt_array( $ch, [
			CURLOPT_POST           => true,
			CURLOPT_POSTFIELDS     => $body,
			CURLOPT_RETURNTRANSFER => false,
			CURLOPT_TIMEOUT        => 0,
			CURLOPT_CONNECTTIMEOUT => 30,
			CURLOPT_HTTPHEADER     => [
				'Authorization: Bearer ' . $this->api_key,
				'content-type: application/json',
				'accept: text/event-stream',
			],
			CURLOPT_WRITEFUNCTION  => function ( $ch, $chunk ) use ( &$buffer, &$accumulated, &$tokens_used, $on_chunk ) {
				$buffer .= $chunk;
				$lines   = explode( "\n", $buffer );
				$buffer  = array_pop( $lines );

				foreach ( $lines as $line ) {
					$line = trim( $line );
					if ( ! str_starts_with( $line, 'data: ' ) ) continue;

					$data = substr( $line, 6 );
					if ( '[DONE]' === $data ) continue;

					$event = json_decode( $data, true );
					if ( ! is_array( $event ) ) continue;

					$text = $event['choices'][0]['delta']['content'] ?? '';
					if ( '' !== $text ) {
						$accumulated .= $text;
						( $on_chunk )( $text );
						if ( ob_get_level() > 0 ) ob_flush();
						flush();
					}

					// OpenAI stuurt usage in het laatste chunk
					if ( isset( $event['usage']['total_tokens'] ) ) {
						$tokens_used = (int) $event['usage']['total_tokens'];
					}
				}

				return strlen( $chunk );
			},
		] );

		curl_exec( $ch );
		if ( curl_errno( $ch ) ) $curl_error = curl_error( $ch );
		curl_close( $ch );

		if ( null !== $curl_error ) {
			throw new \RuntimeException( 'OpenAI streaming error: ' . $curl_error );
		}

		// Extraheer meta comment (zelfde formaat als Claude)
		$meta = '';
		$html = ltrim( $accumulated );
		if ( preg_match( '/^<!--\s*meta:\s*(.+?)\s*-->/s', $html, $matches ) ) {
			$meta = trim( $matches[1] );
			$html = ltrim( substr( $html, strlen( $matches[0] ) ) );
		}

		return [ 'text' => $html, 'meta' => $meta, 'tokens_used' => $tokens_used ];
	}
}
