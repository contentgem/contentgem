<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Post_Repository {
	public function get_post( int $post_id ): ?WP_Post {
		$post = get_post( $post_id );
		return $post instanceof WP_Post ? $post : null;
	}

	public function get_all_content_posts( array $args = [] ): array {
		$defaults = [
			'post_type'      => [ 'post', 'page' ],
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		];
		return get_posts( array_merge( $defaults, $args ) );
	}

	public function get_posts_by_cluster( int $cluster_id ): array {
		global $wpdb;

		$cluster_repo = new CGM_Cluster_Repository();
		$cluster      = $cluster_repo->get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return [];
		}

		$post_ids = [];
		$post_ids_json = $wpdb->get_var( $wpdb->prepare( "SELECT post_ids FROM {$wpdb->prefix}cgm_topics WHERE id = %d LIMIT 1", $cluster_id ) );
		$raw_ids = json_decode( (string) $post_ids_json, true );
		if ( is_array( $raw_ids ) ) {
			$post_ids = array_merge( $post_ids, array_map( 'intval', $raw_ids ) );
		}

		$pillar_id = (int) ( $cluster['pillar_post_id'] ?? 0 );
		if ( $pillar_id > 0 ) {
			$post_ids[] = $pillar_id;
		}

		$cluster_name = sanitize_text_field( (string) ( $cluster['cluster_name'] ?? '' ) );
		if ( $cluster_name !== '' ) {
			$meta_ids = get_posts([
				'post_type'      => [ 'post', 'page' ],
				'post_status'    => [ 'publish', 'draft' ],
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => [
					[
						'key'     => '_cgm_cluster',
						'value'   => $cluster_name,
						'compare' => '=',
					],
				],
			]);
			if ( is_array( $meta_ids ) ) {
				$post_ids = array_merge( $post_ids, array_map( 'intval', $meta_ids ) );
			}
		}

		$post_ids = array_values( array_unique( array_filter( array_map( 'intval', $post_ids ) ) ) );
		if ( empty( $post_ids ) ) {
			return [];
		}

		return get_posts([
			'post_type'      => [ 'post', 'page' ],
			'post_status'    => [ 'publish', 'draft' ],
			'post__in'       => $post_ids,
			'posts_per_page' => -1,
			'orderby'        => 'post__in',
		]);
	}

	public function get_published_posts(): array {
		return $this->get_all_content_posts( [ 'post_status' => 'publish' ] );
	}

	public function get_draft_posts(): array {
		return $this->get_all_content_posts( [ 'post_status' => 'draft' ] );
	}

	public function get_post_content_hash( int $post_id ): string {
		$post = $this->get_post( $post_id );
		return $post ? md5( (string) $post->post_title . "\n" . (string) $post->post_content ) : '';
	}

	public function get_post_meta_payload( int $post_id ): array {
		return [
			'title'    => get_the_title( $post_id ),
			'excerpt'  => (string) get_post_field( 'post_excerpt', $post_id ),
			'url'      => get_permalink( $post_id ) ?: '',
			'modified' => get_post_modified_time( 'U', true, $post_id ),
		];
	}
}
