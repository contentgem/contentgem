<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Competitor_REST_Controller {
	protected CGM_Intelligence_Kernel $kernel;
	public function __construct( CGM_Intelligence_Kernel $kernel ) { $this->kernel = $kernel; }
	public function register_routes(): void {
		register_rest_route( CONTENTGEM_REST_NS, '/competitor/reverse-engineer', [ 'methods' => 'POST', 'callback' => [ $this, 'reverse_engineer' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
		register_rest_route( CONTENTGEM_REST_NS, '/competitor/keyword', [ 'methods' => 'GET', 'callback' => [ $this, 'get_keyword_analysis' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
	}
	public function reverse_engineer( WP_REST_Request $request ) { $keyword = sanitize_text_field( (string) $request->get_param( 'keyword' ) ); if ( '' === $keyword ) { return new WP_Error( 'invalid_keyword', 'Keyword is required', [ 'status' => 400 ] ); } $cluster_id = (int) $request->get_param( 'cluster_id' ); $analysis = $this->kernel->competitor_service()->analyze_keyword( $keyword, [ 'cluster_id' => $cluster_id ] ); $run_id = ( new CGM_Job_Queue() )->enqueue( 'competitor_reverse_engineering', [ 'keyword' => $keyword, 'cluster_id' => $cluster_id ] ); ( new CGM_Analysis_Run_Repository() )->update_run( $run_id, [ 'status' => 'completed', 'result_json' => wp_json_encode( $analysis ), 'started_at' => current_time( 'mysql', true ), 'finished_at' => current_time( 'mysql', true ) ] ); return rest_ensure_response( [ 'success' => true, 'run_id' => $run_id, 'status' => 'completed', 'data' => $analysis ] ); }
	public function get_keyword_analysis( WP_REST_Request $request ) { $keyword = sanitize_text_field( (string) $request->get_param( 'keyword' ) ); if ( '' === $keyword ) { return new WP_Error( 'invalid_keyword', 'Keyword is required', [ 'status' => 400 ] ); } return rest_ensure_response( [ 'success' => true, 'data' => $this->kernel->competitor_service()->analyze_keyword( $keyword ) ] ); }
}
