<?php
/**
 * Title normalization and quality filtering service.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Title_Quality_Service {
	private CGM_Language_Service $language_service;

	public function __construct( ?CGM_Language_Service $language_service = null ) {
		$this->language_service = $language_service ?: new CGM_Language_Service();
	}

	public function normalize_title( string $title, ?string $language = null ): string {
		$title = wp_strip_all_tags( $title );
		$title = preg_replace( '/\s+/', ' ', trim( $title ) );
		$title = preg_replace( '/^[\-–—:\s\|]+/', '', (string) $title );
		$title = preg_replace( '/[\-–—:\s\|]+$/', '', (string) $title );
		$title = preg_replace( '/^\d+\s+(for|to)\s+/i', '', (string) $title );
		$title = preg_replace( '/\b(?:content opportunities|practical strategies for|a practical guide with examples)\b/i', '', (string) $title );
		$title = preg_replace( '/\s+/', ' ', trim( (string) $title ) );
		$title = preg_replace( '/\s+:\s+/', ': ', (string) $title );
		return sanitize_text_field( $title );
	}

	public function is_generic_title( string $title, string $cluster = '' ): bool {
		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $title ) ) : strtolower( trim( $title ) );
		$cluster_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $cluster ) ) : strtolower( trim( $cluster ) );
		$patterns = [
			'/^\d+\b/',
			'/how to use \d+/i',
			'/practical strategies for/i',
			'/better content opportunities/i',
			'/content gap solutions/i',
			'/a practical guide with examples/i',
			'/guide:\s*a practical guide/i',
			'/which approach fits best\??$/i',
			'/^suggestion$/i',
			'/^everything you need to know about /i',
			'/^the smartest way to approach /i',
			'/^the most important questions about /i',
			'/^the core principles behind /i',
			'/^key questions to ask before you commit to /i',
			'/^alles wat je moet weten over /i',
			'/^de slimste manier om /i',
			'/^de belangrijkste vragen over /i',
			'/^de kernprincipes achter /i',
		];
		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $title ) ) {
				return true;
			}
		}
		if ( '' !== $cluster_lc && $title_lc === $cluster_lc ) {
			return true;
		}
		$words = preg_split( '/\s+/', $title_lc );
		if ( count( array_filter( $words ) ) < 5 ) {
			return true;
		}
		$genericFragments = [
			'guide', 'strategy', 'optimization', 'analysis', 'tools', 'content', 'plugin', 'plugins'
		];
		$wordHits = 0;
		foreach ( $genericFragments as $frag ) {
			if ( false !== strpos( $title_lc, $frag ) ) $wordHits++;
		}
		if ( $wordHits >= 4 && preg_match( '/\b(guide|comparison|explained)\b/i', $title_lc ) ) {
			return true;
		}
		return false;
	}

	public function is_valid_title( string $title, string $language = 'en', string $cluster = '' ): bool {
		$title = $this->normalize_title( $title, $language );
		if ( '' === $title ) {
			return false;
		}
		if ( $this->is_generic_title( $title, $cluster ) ) {
			return false;
		}
		return $this->language_service->validate_output_language( $title, $language );
	}

	public function normalize_keyword( string $keyword ): string {
		$keyword = wp_strip_all_tags( $keyword );
		$keyword = preg_replace( '/\s+/', ' ', trim( $keyword ) );
		return sanitize_text_field( $keyword );
	}
}
