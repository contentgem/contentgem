<?php
defined( 'ABSPATH' ) || exit;

class CGM_Analytics {
	public function log_request( string $task_name, array $meta ): void {
		$log = get_option( 'cgm_ai_request_log', [] );
		$log = is_array( $log ) ? $log : [];
		array_unshift( $log, [
			'timestamp' => gmdate( 'c' ),
			'task' => sanitize_key( $task_name ),
			'model' => sanitize_text_field( (string) ( $meta['model'] ?? '' ) ),
			'usage' => is_array( $meta['usage'] ?? null ) ? $meta['usage'] : [],
			'service_tier' => sanitize_text_field( (string) ( $meta['service_tier'] ?? '' ) ),
			'grounded' => ! empty( $meta['grounded'] ),
		] );
		update_option( 'cgm_ai_request_log', array_slice( $log, 0, 200 ), false );
	}
}
