<?php
/**
 * Legacy jobs helper kept for backward compatibility.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Jobs {
	public const ACTIVE_ANALYSE_OPTION = 'cgm_active_analyse_job_id';
	public const LAST_ANALYSE_OPTION   = 'cgm_last_analyse_job_id';

	private static function repo(): CGM_Job_Repository {
		return new CGM_Job_Repository();
	}

	private static function service(): CGM_Job_Service {
		return new CGM_Job_Service( self::repo() );
	}

	public static function get_job( string $job_id ): ?array {
		$job = self::repo()->get_by_key( $job_id );
		if ( $job ) {
			return [
				'status' => CGM_Job_Service::to_legacy_status( (string) $job['status'] ),
				'normalized_status' => (string) $job['status'],
				'progress' => (int) ( 'completed' === $job['status'] ? 100 : min( 99, (int) $job['progress_percentage'] ) ),
				'message' => (string) ( $job['message'] ?? '' ),
				'step' => (string) ( $job['step'] ?? '' ),
				'token' => (string) ( $job['job_token'] ?? '' ),
				'site_id' => (int) ( $job['site_id'] ?? 0 ),
				'result' => $job['result'] ?? null,
				'error' => is_array( $job['error'] ?? null ) ? (string) ( $job['error']['message'] ?? '' ) : '',
				'updated' => time(),
				'started' => time(),
			];
		}
		$legacy = get_option( 'cgm_job_' . $job_id, null );
		return is_array( $legacy ) ? $legacy : null;
	}

	public static function save_job( string $job_id, array $job ): void {
		$existing = self::repo()->get_by_key( $job_id );
		if ( $existing ) {
			self::repo()->update( (int) $existing['id'], [
				'status' => (string) ( $job['normalized_status'] ?? $job['status'] ?? 'queued' ),
				'progress_current' => (int) ( $job['progress'] ?? 0 ),
				'step' => (string) ( $job['step'] ?? '' ),
				'message' => (string) ( $job['message'] ?? '' ),
				'payload_json' => $job['payload'] ?? [],
				'result_json' => $job['result'] ?? [],
				'error_json' => [ 'message' => (string) ( $job['error'] ?? '' ) ],
				'job_token' => (string) ( $job['token'] ?? '' ),
				'site_id' => (int) ( $job['site_id'] ?? 0 ),
			] );
			return;
		}
		update_option( 'cgm_job_' . $job_id, $job, false );
	}

	public static function get_active_analysis_job_id(): string {
		return (string) get_option( self::ACTIVE_ANALYSE_OPTION, '' );
	}

	public static function get_active_analysis_job(): ?array {
		$job_id = self::get_active_analysis_job_id();
		if ( '' === $job_id ) {
			return null;
		}
		$job = self::repo()->get_by_key( $job_id );
		if ( ! $job || ! in_array( $job['status'], [ 'queued', 'processing', 'finalizing' ], true ) ) {
			delete_option( self::ACTIVE_ANALYSE_OPTION );
			return null;
		}
		$job['job_id'] = $job_id;
		$job['token'] = $job['job_token'];
		return $job;
	}

	public static function create_analysis_job( int $site_id ): array {
		$existing = self::get_active_analysis_job();
		if ( is_array( $existing ) ) {
			return [
				'job_id' => (string) $existing['job_id'],
				'job_token' => (string) ( $existing['job_token'] ?? '' ),
				'site_id' => (int) ( $existing['site_id'] ?? $site_id ),
				'existing' => true,
			];
		}
		$job = self::service()->start_job( 'analyze_site', [ 'site_id' => $site_id ], [
			'site_id' => $site_id,
			'message' => 'Preparing analysis...',
			'idempotency_key' => 'analyze_site:' . $site_id,
		] );
		update_option( self::LAST_ANALYSE_OPTION, $job['job_key'], false );
		update_option( self::ACTIVE_ANALYSE_OPTION, $job['job_key'], false );
		return [
			'job_id' => $job['job_key'],
			'job_token' => $job['job_token'],
			'site_id' => (int) $job['site_id'],
			'existing' => ! empty( $job['existing'] ),
		];
	}

	public static function update_job( string $job_id, string $status, int $progress, string $message, ?array $result = null, string $step = '' ): array {
		$normalized = [ 'running' => 'processing', 'done' => 'completed', 'error' => 'failed' ][ $status ] ?? $status;
		$job = self::service()->advance( $job_id, $normalized, $progress, $message, $step, $result );
		if ( ! $job ) {
			return [];
		}
		if ( in_array( $job['status'], [ 'completed', 'failed' ], true ) && self::get_active_analysis_job_id() === $job_id ) {
			delete_option( self::ACTIVE_ANALYSE_OPTION );
		}
		return self::get_job( $job_id ) ?: [];
	}
}
