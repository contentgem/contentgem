<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Overlap_Repository {
	private function table(): string { global $wpdb; return $wpdb->prefix . 'cgm_content_overlap'; }
	public function save_overlap( array $data ): int { global $wpdb; $data = array_merge( [ 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ], $data ); $wpdb->insert( $this->table(), $data ); return (int) $wpdb->insert_id; }
	public function get_overlap_for_post( int $post_id ): array { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE source_post_id = %d ORDER BY similarity_score DESC", $post_id ), ARRAY_A ); }
	public function get_overlap_pair( int $post_id_a, int $post_id_b ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE source_post_id = %d AND compare_post_id = %d LIMIT 1", $post_id_a, $post_id_b ), ARRAY_A ); return is_array( $row ) ? $row : null; }
}
