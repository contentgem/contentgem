<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Analysis_Run_Repository {
	private function table(): string { global $wpdb; return $wpdb->prefix . 'cgm_analysis_runs'; }
	public function create_run( array $data ): int { global $wpdb; $defaults = [ 'status' => 'queued', 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ]; $wpdb->insert( $this->table(), array_merge( $defaults, $data ) ); return (int) $wpdb->insert_id; }
	public function update_run( int $run_id, array $data ): bool { global $wpdb; $data['updated_at'] = current_time( 'mysql', true ); return false !== $wpdb->update( $this->table(), $data, [ 'id' => $run_id ] ); }
	public function get_run( int $run_id ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE id = %d LIMIT 1", $run_id ), ARRAY_A ); return is_array( $row ) ? $row : null; }
	public function get_recent_runs( string $run_type, int $limit = 20 ): array { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE run_type = %s ORDER BY id DESC LIMIT %d", $run_type, $limit ), ARRAY_A ); }
}
