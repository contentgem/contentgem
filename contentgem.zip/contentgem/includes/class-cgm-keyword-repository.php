<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Keyword_Repository {
	public function get_keywords_for_cluster( int $cluster_id ): array { return ( new CGM_Cluster_Repository() )->get_cluster_keywords( $cluster_id ); }
	public function save_keyword_node( array $data ): int {
		$graph = new CGM_Graph_Repository();
		$slug = sanitize_title( (string) ( $data['slug'] ?? $data['keyword'] ?? '' ) );
		$existing = $graph->find_node( 'keyword', $slug );
		if ( $existing ) { return (int) $existing['id']; }
		return $graph->create_node( [ 'node_type' => 'keyword', 'slug' => $slug, 'title' => sanitize_text_field( (string) ( $data['title'] ?? $data['keyword'] ?? '' ) ), 'status' => 'active', 'meta_json' => wp_json_encode( $data ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ] );
	}
	public function find_keyword_by_slug( string $slug ): ?array { return ( new CGM_Graph_Repository() )->find_node( 'keyword', sanitize_title( $slug ) ); }
}
