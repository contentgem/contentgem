<?php
/**
 * PHP 7.4 polyfills for functions introduced in PHP 8.0.
 * These are only defined if not already present (i.e. on PHP < 8.0).
 *
 * @package Contentgem
 */

if ( ! function_exists( 'str_contains' ) ) {
	/**
	 * Polyfill for str_contains() (PHP 8.0+).
	 *
	 * @param string $haystack The string to search in.
	 * @param string $needle   The substring to search for.
	 * @return bool
	 */
	function str_contains( string $haystack, string $needle ): bool {
		return '' === $needle || false !== strpos( $haystack, $needle );
	}
}

if ( ! function_exists( 'str_starts_with' ) ) {
	/**
	 * Polyfill for str_starts_with() (PHP 8.0+).
	 *
	 * @param string $haystack The string to search in.
	 * @param string $needle   The prefix to look for.
	 * @return bool
	 */
	function str_starts_with( string $haystack, string $needle ): bool {
		return '' === $needle || 0 === strncmp( $haystack, $needle, strlen( $needle ) );
	}
}

if ( ! function_exists( 'str_ends_with' ) ) {
	/**
	 * Polyfill for str_ends_with() (PHP 8.0+).
	 *
	 * @param string $haystack The string to search in.
	 * @param string $needle   The suffix to look for.
	 * @return bool
	 */
	function str_ends_with( string $haystack, string $needle ): bool {
		return '' === $needle || (
			strlen( $haystack ) >= strlen( $needle ) &&
			substr( $haystack, -strlen( $needle ) ) === $needle
		);
	}
}
