<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Authority_Service {
	protected CGM_Post_Repository $post_repo;
	protected CGM_Cluster_Repository $cluster_repo;
	protected CGM_Keyword_Repository $keyword_repo;
	protected CGM_Graph_Service $graph_service;
	protected CGM_Entity_Extractor $entity_extractor;

	public function __construct( CGM_Post_Repository $post_repo, CGM_Cluster_Repository $cluster_repo, CGM_Keyword_Repository $keyword_repo, CGM_Graph_Service $graph_service, CGM_Entity_Extractor $entity_extractor ) {
		$this->post_repo         = $post_repo;
		$this->cluster_repo      = $cluster_repo;
		$this->keyword_repo      = $keyword_repo;
		$this->graph_service     = $graph_service;
		$this->entity_extractor  = $entity_extractor;
	}

	public function calculate_cluster_authority( int $cluster_id ): array {
		$cluster_map      = $this->build_cluster_map( $cluster_id );
		$coverage         = $this->calculate_coverage_score( $cluster_map );
		$entity           = $this->calculate_entity_score( $cluster_map );
		$link             = $this->calculate_internal_link_score( $cluster_map );
		$pillar           = $this->calculate_pillar_score( $cluster_map );
		$post_depth       = $this->calculate_post_depth_score( $cluster_map );
		$competitor_score = $this->calculate_competitor_score( $cluster_map );

		$weighted_sum = (
			$coverage * 0.26 +
			$entity * 0.12 +
			$link * 0.14 +
			$pillar * 0.22 +
			$post_depth * 0.18 +
			$competitor_score * 0.08
		);

		$score = $weighted_sum * 100;
		if ( empty( $cluster_map['has_pillar'] ) && empty( $cluster_map['posts'] ) ) {
			$score = min( $score, 12.0 );
		} elseif ( empty( $cluster_map['has_pillar'] ) && count( $cluster_map['posts'] ) <= 1 ) {
			$score = min( $score, 44.0 );
		}
		$score = round( max( 0.0, min( 100.0, $score ) ), 1 );

		return [
			'cluster_id'           => $cluster_id,
			'cluster_name'         => $cluster_map['cluster_name'],
			'authority_score'      => $score,
			'real_score'           => $score,
			'coverage_score'       => round( $coverage * 100, 1 ),
			'entity_score'         => round( $entity * 100, 1 ),
			'internal_link_score'  => round( $link * 100, 1 ),
			'pillar_score'         => round( $pillar * 100, 1 ),
			'post_depth_score'     => round( $post_depth * 100, 1 ),
			'competitor_score'     => round( $competitor_score * 100, 1 ),
			'post_count'           => count( $cluster_map['posts'] ),
			'missing_topics'       => $cluster_map['missing_topics'],
			'priority_articles'    => array_slice( $cluster_map['missing_topics'], 0, 5 ),
			'has_pillar'           => ! empty( $cluster_map['has_pillar'] ),
			'pillar_post_id'       => (int) ( $cluster_map['pillar_post_id'] ?? 0 ),
		];
	}

	public function build_cluster_map( int $cluster_id ): array {
		$cluster = $this->cluster_repo->get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return [
				'cluster_name'     => '',
				'keywords'         => [],
				'posts'            => [],
				'raw_posts'        => [],
				'entities'         => [],
				'missing_topics'   => [],
				'has_pillar'       => false,
				'pillar_post_id'   => 0,
				'internal_links'   => 0,
				'competitor_meta'  => [],
			];
		}

		$cluster_name = sanitize_text_field( (string) ( $cluster['cluster_name'] ?? '' ) );
		$keywords = array_values( array_unique( array_filter( array_merge(
			(array) $this->keyword_repo->get_keywords_for_cluster( $cluster_id ),
			(array) $this->get_cluster_keywords_from_options( $cluster_name )
		) ) ) );

		$posts        = $this->post_repo->get_posts_by_cluster( $cluster_id );
		$pillar_post_id = $this->resolve_pillar_post_id( $cluster, $cluster_name );
		if ( $pillar_post_id > 0 ) {
			$pillar_post = get_post( $pillar_post_id );
			if ( $pillar_post instanceof WP_Post ) {
				$posts[ $pillar_post->ID ] = $pillar_post;
			}
		}

		if ( empty( $posts ) && '' !== $cluster_name ) {
			$posts = $this->find_related_posts_by_cluster_name( $cluster_name, $keywords );
		}
		$posts = $this->normalize_posts( $posts );

		$entities = [];
		$internal_links = 0;
		foreach ( $posts as $post ) {
			$entities       = array_merge( $entities, $this->entity_extractor->extract_entities_from_post( (int) $post->ID ) );
			$internal_links += $this->count_internal_links_in_post( $post );
		}
		$entities = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $entities ) ) ) );
		$has_pillar = $pillar_post_id > 0 && get_post( $pillar_post_id ) instanceof WP_Post;

		$missing = [];
		if ( ! empty( $keywords ) ) {
			foreach ( $keywords as $keyword ) {
				$covered = false;
				$needle  = strtolower( trim( (string) $keyword ) );
				foreach ( $posts as $post ) {
					$haystack = strtolower( (string) $post->post_title . ' ' . wp_strip_all_tags( (string) $post->post_content ) );
					if ( '' !== $needle && false !== strpos( $haystack, $needle ) ) {
						$covered = true;
						break;
					}
				}
				if ( ! $covered ) {
					$missing[] = $keyword;
				}
			}
		}

		return [
			'cluster_id'     => $cluster_id,
			'cluster_name'   => $cluster_name,
			'keywords'       => $keywords,
			'posts'          => array_map( static fn( $p ) => [ 'id' => (int) $p->ID, 'title' => (string) $p->post_title ], $posts ),
			'raw_posts'      => $posts,
			'entities'       => $entities,
			'missing_topics' => $missing,
			'has_pillar'     => $has_pillar,
			'pillar_post_id' => $pillar_post_id,
			'internal_links' => $internal_links,
			'competitor_meta'=> $this->get_cluster_competitor_meta( $cluster_name ),
		];
	}

	protected function get_cluster_keywords_from_options( string $cluster_name ): array {
		$all_maps = [
			get_option( 'cgm_cluster_keywords', [] ),
			get_option( 'contentgem_cluster_keywords', [] ),
		];
		$variants = array_values( array_unique( array_filter( [
			$cluster_name,
			sanitize_title( $cluster_name ),
		] ) ) );
		$keywords = [];
		foreach ( $all_maps as $map ) {
			if ( ! is_array( $map ) ) {
				continue;
			}
			foreach ( $variants as $variant ) {
				if ( ! empty( $map[ $variant ] ) && is_array( $map[ $variant ] ) ) {
					$keywords = array_merge( $keywords, $map[ $variant ] );
				}
			}
		}
		return array_values( array_unique( array_filter( array_map( static function( $keyword ) {
			return sanitize_text_field( (string) $keyword );
		}, $keywords ) ) ) );
	}

	protected function resolve_pillar_post_id( array $cluster, string $cluster_name ): int {
		$pillar_post_id = (int) ( $cluster['pillar_post_id'] ?? 0 );
		if ( $pillar_post_id > 0 && get_post( $pillar_post_id ) instanceof WP_Post ) {
			return $pillar_post_id;
		}
		$map = get_option( 'contentgem_pillar_pages', [] );
		if ( ! is_array( $map ) || '' === $cluster_name ) {
			return 0;
		}
		$variants = [ $cluster_name, sanitize_title( $cluster_name ) ];
		foreach ( $variants as $variant ) {
			if ( empty( $map[ $variant ] ) ) {
				continue;
			}
			$raw = $map[ $variant ];
			$pillar_id = is_array( $raw ) ? (int) ( $raw[0] ?? 0 ) : (int) $raw;
			if ( $pillar_id > 0 && get_post( $pillar_id ) instanceof WP_Post ) {
				return $pillar_id;
			}
		}
		return 0;
	}

	protected function normalize_posts( array $posts ): array {
		$normalized = [];
		foreach ( $posts as $post ) {
			if ( $post instanceof WP_Post ) {
				$normalized[ (int) $post->ID ] = $post;
			}
		}
		return array_values( $normalized );
	}

	protected function find_related_posts_by_cluster_name( string $cluster_name, array $keywords = [] ): array {
		$needles = array_values( array_unique( array_filter( array_map( static function( $item ) {
			return sanitize_text_field( (string) $item );
		}, array_merge( [ $cluster_name ], $keywords ) ) ) ) );
		if ( empty( $needles ) ) {
			return [];
		}
		$posts = get_posts([
			'post_type'      => [ 'post', 'page' ],
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			's'              => $cluster_name,
		]);
		$matched = [];
		foreach ( $posts as $post ) {
			$haystack = strtolower( (string) $post->post_title . ' ' . wp_strip_all_tags( (string) $post->post_content ) );
			foreach ( $needles as $needle ) {
				$needle = strtolower( trim( $needle ) );
				if ( '' !== $needle && false !== strpos( $haystack, $needle ) ) {
					$matched[ (int) $post->ID ] = $post;
					break;
				}
			}
		}

		$category_matches = get_posts([
			'post_type'      => [ 'post' ],
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			'category_name'  => sanitize_title( $cluster_name ),
		]);
		foreach ( $category_matches as $post ) {
			$matched[ (int) $post->ID ] = $post;
		}
		return array_values( $matched );
	}

	protected function count_internal_links_in_post( WP_Post $post ): int {
		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$home_host = is_string( $home_host ) ? preg_replace( '/^www\./', '', strtolower( $home_host ) ) : '';
		preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\']/i', (string) $post->post_content, $matches );
		$count = 0;
		foreach ( (array) ( $matches[1] ?? [] ) as $href ) {
			$host = wp_parse_url( html_entity_decode( (string) $href ), PHP_URL_HOST );
			$host = is_string( $host ) ? preg_replace( '/^www\./', '', strtolower( $host ) ) : '';
			if ( '' === $host || $host === $home_host ) {
				$count++;
			}
		}
		return $count;
	}

	protected function get_cluster_competitor_meta( string $cluster_name ): array {
		$key = sanitize_title( $cluster_name );
		$grouped = get_option( 'contentgem_competitor_history_by_cluster', [] );
		$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
		$rows = [];
		if ( is_array( $grouped ) && ! empty( $grouped[ $key ] ) && is_array( $grouped[ $key ] ) ) {
			$rows = array_values( array_filter( $grouped[ $key ], 'is_array' ) );
		}
		if ( is_array( $latest_by_cluster ) && ! empty( $latest_by_cluster[ $key ] ) && is_array( $latest_by_cluster[ $key ] ) ) {
			$rows[] = $latest_by_cluster[ $key ];
		}
		if ( empty( $rows ) ) {
			return [];
		}
		$total_gaps = 0;
		$critical_gaps = 0;
		foreach ( $rows as $row ) {
			$total_gaps += (int) ( $row['gap_count'] ?? $row['gaps_count'] ?? count( (array) ( $row['gaps'] ?? [] ) ) );
			$critical_gaps += (int) ( $row['critical_gap_count'] ?? $row['critical_gaps'] ?? 0 );
		}
		return [
			'reports'       => count( $rows ),
			'total_gaps'    => $total_gaps,
			'critical_gaps' => $critical_gaps,
		];
	}

	protected function calculate_coverage_score( array $map ): float {
		$keywords_count = count( $map['keywords'] ?? [] );
		$post_count = count( $map['posts'] ?? [] );
		if ( $post_count <= 0 ) {
			return 0.0;
		}
		if ( $keywords_count <= 0 ) {
			return min( 0.35, 0.12 + ( $post_count * 0.08 ) );
		}
		$covered = max( 0, $keywords_count - count( $map['missing_topics'] ?? [] ) );
		return max( 0.0, min( 1.0, $covered / $keywords_count ) );
	}

	protected function calculate_entity_score( array $map ): float {
		$keywords = max( 1, count( $map['keywords'] ?? [] ) );
		$entities = count( $map['entities'] ?? [] );
		if ( $entities <= 0 || count( $map['posts'] ?? [] ) <= 0 ) {
			return 0.0;
		}
		return max( 0.0, min( 1.0, $entities / max( 6, $keywords * 2 ) ) );
	}

	protected function calculate_internal_link_score( array $map ): float {
		$posts = count( $map['posts'] ?? [] );
		$link_count = (int) ( $map['internal_links'] ?? 0 );
		if ( $posts <= 0 || $link_count <= 0 ) {
			return 0.0;
		}
		$expected = max( 2, $posts * 2 );
		return max( 0.0, min( 1.0, $link_count / $expected ) );
	}

	protected function calculate_pillar_score( array $map ): float {
		return ! empty( $map['has_pillar'] ) ? 1.0 : 0.0;
	}

	protected function calculate_post_depth_score( array $map ): float {
		$post_count = count( $map['posts'] ?? [] );
		if ( $post_count <= 0 ) {
			return 0.0;
		}
		return max( 0.0, min( 1.0, log( 1 + $post_count, 2 ) / log( 7, 2 ) ) );
	}

	protected function calculate_competitor_score( array $map ): float {
		$meta = (array) ( $map['competitor_meta'] ?? [] );
		$reports = (int) ( $meta['reports'] ?? 0 );
		if ( $reports <= 0 ) {
			return ! empty( $map['has_pillar'] ) || ! empty( $map['posts'] ) ? 0.12 : 0.0;
		}
		$total_gaps = max( 0, (int) ( $meta['total_gaps'] ?? 0 ) );
		$critical   = max( 0, (int) ( $meta['critical_gaps'] ?? 0 ) );
		$gap_penalty = min( 0.78, ( $total_gaps / max( 5, $reports * 4 ) ) * 0.45 + ( $critical / max( 3, $reports * 2 ) ) * 0.55 );
		return max( 0.02, min( 1.0, 1.0 - $gap_penalty ) );
	}
}
