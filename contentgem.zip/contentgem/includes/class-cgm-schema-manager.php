<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Schema_Manager {
	public const SCHEMA_VERSION = '1.0.0';
	public function maybe_upgrade(): void { CGM_Activator::upgrade(); }
	public function get_schema_version(): string { return (string) get_option( 'contentgem_db_version', '0.0.0' ); }
}
