<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CGM_Differentiation_Service {
	protected CGM_Post_Repository $post_repo;
	protected CGM_Content_Parser $content_parser;
	protected CGM_Overlap_Repository $overlap_repo;

	public function __construct(
		CGM_Post_Repository $post_repo,
		CGM_Content_Parser $content_parser,
		CGM_Overlap_Repository $overlap_repo
	) {
		$this->post_repo = $post_repo;
		$this->content_parser = $content_parser;
		$this->overlap_repo = $overlap_repo;
	}

	public function analyze_gap_against_existing_content( array $payload ): array {
		$title = sanitize_text_field( (string) ( $payload['title'] ?? '' ) );
		$keyword = sanitize_text_field( (string) ( $payload['keyword'] ?? '' ) );
		$brief = sanitize_textarea_field( (string) ( $payload['brief'] ?? '' ) );
		$cluster_id = isset( $payload['cluster_id'] ) ? (int) $payload['cluster_id'] : 0;

		$matches = $this->find_similar_posts( $title, $keyword, $brief, $cluster_id );
		$max = 0.0;
		foreach ( $matches as $m ) {
			$max = max( $max, (float) ( $m['similarity_score'] ?? 0 ) );
		}

		$brief_data = $this->build_differentiation_brief( [
			'title' => $title,
			'keyword' => $keyword,
			'brief' => $brief,
			'cluster_id' => $cluster_id,
			'matches' => $matches,
			'overlap_score' => $max,
		] );

		return [
			'overlap_score' => round( $max * 100, 1 ),
			'risk_level' => $this->risk_level( $max ),
			'similar_posts' => $matches,
			'recommendations' => $brief_data,
		];
	}

	public function find_similar_posts( string $title, string $keyword, string $brief = '', int $cluster_id = 0 ): array {
		$title = trim( $title );
		$keyword = trim( $keyword );
		$brief = trim( $brief );

		$candidates = $cluster_id > 0 ? $this->post_repo->get_posts_by_cluster( $cluster_id ) : [];
		if ( empty( $candidates ) ) {
			$candidates = $this->post_repo->get_all_content_posts( [ 'post_status' => [ 'publish', 'draft', 'future', 'pending' ] ] );
		}

		$needle_title = strtolower( $title );
		$needle_keyword = strtolower( $keyword );
		$needle_body = strtolower( trim( $title . ' ' . $keyword . ' ' . $brief ) );

		if ( '' === $needle_body ) {
			return [];
		}

		$results = [];

		foreach ( $candidates as $post ) {
			if ( ! $post instanceof WP_Post ) { continue; }

			$post_title = (string) $post->post_title;
			$post_text = $this->content_parser->extract_plain_text( (string) $post->post_content );
			$hay_title = strtolower( $post_title );
			$hay_body = strtolower( trim( $post_title . ' ' . $post_text ) );

			if ( '' === $hay_body ) { continue; }

			$title_score = $this->calculate_text_similarity( $needle_title, $hay_title );
			$body_score = $this->calculate_text_similarity( $needle_body, substr( $hay_body, 0, 4000 ) );
			$keyword_bonus = 0.0;

			if ( '' !== $needle_keyword && false !== strpos( $hay_body, $needle_keyword ) ) {
				$keyword_bonus += 0.10;
			}
			if ( '' !== $needle_title && false !== strpos( $hay_title, $needle_title ) ) {
				$keyword_bonus += 0.20;
			}

			$score = min( 1.0, ( $title_score * 0.55 ) + ( $body_score * 0.35 ) + $keyword_bonus );

			if ( $cluster_id > 0 ) {
				$score = min( 1.0, $score + 0.08 );
			}

			if ( $score >= 0.28 ) {
				$results[] = [
					'post_id' => (int) $post->ID,
					'title' => $post_title,
					'status' => (string) $post->post_status,
					'similarity_score' => round( $score, 5 ),
				];
			}
		}

		$results = $this->dedupe_by_title( $results );

		usort( $results, static function( $a, $b ) {
			return (float) $b['similarity_score'] <=> (float) $a['similarity_score'];
		} );

		return array_slice( $results, 0, 5 );
	}

	protected function calculate_text_similarity( string $needle, string $haystack ): float {
		$needle = trim( $needle );
		$haystack = trim( $haystack );
		if ( '' === $needle || '' === $haystack ) {
			return 0.0;
		}

		$needle_tokens = $this->tokenize( $needle );
		$hay_tokens = $this->tokenize( $haystack );
		if ( empty( $needle_tokens ) || empty( $hay_tokens ) ) {
			return 0.0;
		}

		$overlap = array_intersect( $needle_tokens, $hay_tokens );
		$jaccard = count( $overlap ) / max( 1, count( array_unique( array_merge( $needle_tokens, $hay_tokens ) ) ) );

		similar_text( substr( $needle, 0, 1200 ), substr( $haystack, 0, 1200 ), $percent );
		$text_score = max( 0.0, min( 1.0, $percent / 100 ) );

		return min( 1.0, ( $jaccard * 0.60 ) + ( $text_score * 0.40 ) );
	}

	protected function tokenize( string $text ): array {
		$text = strtolower( preg_replace( '/[^a-z0-9\s-]+/i', ' ', $text ) );
		$tokens = preg_split( '/\s+/', $text );
		$tokens = array_filter( array_map( 'trim', $tokens ), static function( $token ) {
			return strlen( $token ) >= 3;
		} );
		return array_values( array_unique( $tokens ) );
	}

	protected function dedupe_by_title( array $items ): array {
		$seen = [];
		$out = [];
		foreach ( $items as $item ) {
			$key = strtolower( trim( (string) ( $item['title'] ?? '' ) ) );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[] = $item;
		}
		return $out;
	}

	public function build_differentiation_brief( array $context ): array {
		$score = (float) ( $context['overlap_score'] ?? 0 );
		$keyword = (string) ( $context['keyword'] ?? '' );
		$angle = $this->recommend_alternate_angle( $context );
		$intent = $this->recommend_alternate_intent( $context );
		$structure = $this->recommend_alternate_structure( $context );

		return [
			'angle' => $angle,
			'intent' => $intent,
			'structure' => $structure,
			'writer_brief' => sprintf(
				'Position this piece around %1$s, target a %2$s intent and use a %3$s structure so it stands apart from existing %4$s coverage.',
				$angle,
				$intent,
				$structure,
				$keyword !== '' ? $keyword : 'site'
			),
			'uniqueness_target' => $score >= 0.70 ? 'Strong differentiation required' : ( $score >= 0.45 ? 'Moderate differentiation recommended' : 'Low overlap risk' ),
		];
	}

	public function recommend_alternate_angle( array $context ): string {
		$score = (float) ( $context['overlap_score'] ?? 0 );
		if ( $score >= 0.70 ) { return 'a contrarian or framework-driven angle'; }
		if ( $score >= 0.45 ) { return 'a practical execution angle'; }
		return 'a comprehensive educational angle';
	}

	public function recommend_alternate_intent( array $context ): string {
		$keyword = strtolower( (string) ( $context['keyword'] ?? '' ) );
		if ( strpos( $keyword, 'best' ) !== false || strpos( $keyword, 'tool' ) !== false ) { return 'commercial investigation'; }
		if ( strpos( $keyword, 'how' ) !== false || strpos( $keyword, 'guide' ) !== false ) { return 'informational'; }
		$score = (float) ( $context['overlap_score'] ?? 0 );
		return $score >= 0.60 ? 'comparison-led informational' : 'informational';
	}

	public function recommend_alternate_structure( array $context ): string {
		$score = (float) ( $context['overlap_score'] ?? 0 );
		if ( $score >= 0.70 ) { return 'point-of-view article with sections, examples and checklist'; }
		if ( $score >= 0.45 ) { return 'step-by-step guide with decision framework'; }
		return 'pillar-style guide with examples and FAQ';
	}

	protected function risk_level( float $score ): string {
		if ( $score >= 0.70 ) { return 'high'; }
		if ( $score >= 0.45 ) { return 'medium'; }
		return 'low';
	}
}
