<?php
/**
 * Native builder sync for Elementor and Divi.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Builder_Integrator {
	public function sync_generated_post( int $post_id, string $html, array $args = [] ): string {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return 'none';
		}

		$html = $this->normalize_html( $html );
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return 'none';
		}

		$mode = $this->resolve_builder_mode( $post, $args );
		update_post_meta( $post_id, '_cgm_builder_source_html', wp_kses_post( $html ) );
		update_post_meta( $post_id, '_contentgem_builder_mode', $mode );
		update_post_meta( $post_id, '_cgm_draft_text', wp_kses_post( $html ) );
		update_post_meta( $post_id, '_contentgem_draft_text', wp_kses_post( $html ) );

		if ( 'elementor' === $mode ) {
			$this->sync_elementor( $post, $html );
			return 'elementor';
		}
		if ( 'divi' === $mode ) {
			$this->sync_divi( $post, $html );
			return 'divi';
		}

		return 'none';
	}

	public function resolve_builder_mode( WP_Post $post, array $args = [] ): string {
		$requested = sanitize_key( (string) ( $args['builder_mode'] ?? $args['preferred_builder'] ?? 'auto' ) );
		if ( 'standard' === $requested ) {
			$requested = 'none';
		}
		if ( in_array( $requested, [ 'elementor', 'divi', 'none' ], true ) ) {
			return $this->builder_is_available( $requested ) ? $requested : ( 'none' === $requested ? 'none' : 'none' );
		}

		if ( get_post_meta( $post->ID, '_elementor_data', true ) && $this->is_elementor_available() ) {
			return 'elementor';
		}
		if ( get_post_meta( $post->ID, '_et_pb_use_builder', true ) && $this->is_divi_available() ) {
			return 'divi';
		}

		$preferred = $this->get_preferred_builder();
		if ( 'none' !== $preferred && $this->builder_is_available( $preferred ) ) {
			return $preferred;
		}

		return 'none';
	}

	public function get_preferred_builder(): string {
		$stored = sanitize_key( (string) get_option( 'contentgem_builder_preference', 'none' ) );
		if ( 'standard' === $stored ) {
			$stored = 'none';
		}
		return in_array( $stored, [ 'none', 'elementor', 'divi' ], true ) ? $stored : 'none';
	}

	public function is_elementor_available(): bool {
		return did_action( 'elementor/loaded' ) || class_exists( '\\Elementor\\Plugin' );
	}

	public function is_divi_available(): bool {
		return defined( 'ET_BUILDER_THEME' ) || defined( 'ET_BUILDER_PLUGIN_VERSION' ) || function_exists( 'et_pb_is_pagebuilder_used' );
	}

	private function builder_is_available( string $builder ): bool {
		if ( 'elementor' === $builder ) {
			return $this->is_elementor_available();
		}
		if ( 'divi' === $builder ) {
			return $this->is_divi_available();
		}
		return true;
	}

	private function sync_elementor( WP_Post $post, string $html ): void {
		$data = $this->build_elementor_document( $html );
		update_post_meta( $post->ID, '_elementor_data', wp_slash( wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
		update_post_meta( $post->ID, '_elementor_edit_mode', 'builder' );
		update_post_meta( $post->ID, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
		update_post_meta( $post->ID, '_elementor_page_settings', [] );
		delete_post_meta( $post->ID, '_et_pb_use_builder' );
	}

	private function sync_divi( WP_Post $post, string $html ): void {
		$shortcodes = $this->build_divi_layout( $html );
		update_post_meta( $post->ID, '_et_pb_use_builder', 'on' );
		update_post_meta( $post->ID, '_et_pb_old_content', wp_slash( $html ) );
		update_post_meta( $post->ID, '_et_pb_old_shortcodes', wp_slash( $shortcodes ) );
		delete_post_meta( $post->ID, '_elementor_data' );
		delete_post_meta( $post->ID, '_elementor_edit_mode' );
		wp_update_post( [
			'ID'           => (int) $post->ID,
			'post_content' => wp_slash( $shortcodes ),
		] );
	}

	private function build_elementor_document( string $html ): array {
		$widgets = [];
		$blocks = $this->extract_blocks( $html );
		if ( empty( $blocks ) ) {
			$blocks = [ [ 'tag' => 'div', 'html' => $html, 'text' => wp_strip_all_tags( $html ) ] ];
		}
		$index = 0;
		foreach ( $blocks as $block ) {
			$index++;
			$widgets[] = $this->map_block_to_elementor_widget( $block, $index );
		}
		return [
			[
				'id' => $this->make_id( 'sec' ),
				'elType' => 'section',
				'settings' => [
					'content_width' => 'boxed',
					'gap' => 'default',
				],
				'elements' => [
					[
						'id' => $this->make_id( 'col' ),
						'elType' => 'column',
						'isInner' => false,
						'settings' => [ '_column_size' => 100, '_inline_size' => null ],
						'elements' => $widgets,
					],
				],
				'isInner' => false,
			],
		];
	}

	private function map_block_to_elementor_widget( array $block, int $index ): array {
		$tag = strtolower( (string) ( $block['tag'] ?? 'div' ) );
		$html = (string) ( $block['html'] ?? '' );
		$text = (string) ( $block['text'] ?? wp_strip_all_tags( $html ) );
		$id = $this->make_id( 'el' . $index );

		if ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
			return [
				'id' => $id,
				'elType' => 'widget',
				'widgetType' => 'heading',
				'settings' => [
					'title' => $text,
					'header_size' => 'h' . $m[1],
				],
				'elements' => [],
			];
		}

		if ( 'img' === $tag ) {
			preg_match( '/src=["\']([^"\']+)["\']/i', $html, $src_match );
			$src = esc_url_raw( (string) ( $src_match[1] ?? '' ) );
			$attachment_id = $src ? attachment_url_to_postid( $src ) : 0;
			return [
				'id' => $id,
				'elType' => 'widget',
				'widgetType' => 'image',
				'settings' => [
					'image' => [
						'id' => $attachment_id,
						'url' => $src,
					],
					'image_size' => 'full',
				],
				'elements' => [],
			];
		}

		if ( 'hr' === $tag ) {
			return [
				'id' => $id,
				'elType' => 'widget',
				'widgetType' => 'divider',
				'settings' => [],
				'elements' => [],
			];
		}

		if ( 'a' === $tag && preg_match( '/href=["\']([^"\']+)["\']/i', $html, $href_match ) ) {
			return [
				'id' => $id,
				'elType' => 'widget',
				'widgetType' => 'button',
				'settings' => [
					'text' => $text,
					'link' => [ 'url' => esc_url_raw( (string) $href_match[1] ) ],
				],
				'elements' => [],
			];
		}

		return [
			'id' => $id,
			'elType' => 'widget',
			'widgetType' => 'text-editor',
			'settings' => [
				'editor' => $this->normalize_widget_html( $html, $tag ),
			],
			'elements' => [],
		];
	}

	private function build_divi_layout( string $html ): string {
		$modules = [];
		$blocks = $this->extract_blocks( $html );
		if ( empty( $blocks ) ) {
			$blocks = [ [ 'tag' => 'div', 'html' => $html, 'text' => wp_strip_all_tags( $html ) ] ];
		}
		foreach ( $blocks as $block ) {
			$modules[] = $this->map_block_to_divi_module( $block );
		}
		$builder_version = defined( 'ET_BUILDER_PLUGIN_VERSION' ) ? ET_BUILDER_PLUGIN_VERSION : '4.25.0';
		return sprintf(
			'[et_pb_section fb_built="1" _builder_version="%1$s" custom_padding="|||"][et_pb_row _builder_version="%1$s"][et_pb_column type="4_4" _builder_version="%1$s"]%2$s[/et_pb_column][/et_pb_row][/et_pb_section]',
			esc_attr( $builder_version ),
			implode( '', array_filter( $modules ) )
		);
	}

	private function map_block_to_divi_module( array $block ): string {
		$tag = strtolower( (string) ( $block['tag'] ?? 'div' ) );
		$html = (string) ( $block['html'] ?? '' );
		$text = (string) ( $block['text'] ?? wp_strip_all_tags( $html ) );
		$builder_version = defined( 'ET_BUILDER_PLUGIN_VERSION' ) ? ET_BUILDER_PLUGIN_VERSION : '4.25.0';

		if ( 'img' === $tag && preg_match( '/src=["\']([^"\']+)["\']/i', $html, $src_match ) ) {
			return sprintf(
				'[et_pb_image src="%1$s" alt="%2$s" title_text="%2$s" show_in_lightbox="off" admin_label="ContentGem Image" _builder_version="%3$s" /]',
				esc_url_raw( (string) $src_match[1] ),
				esc_attr( $text ),
				esc_attr( $builder_version )
			);
		}

		if ( 'a' === $tag && preg_match( '/href=["\']([^"\']+)["\']/i', $html, $href_match ) ) {
			return sprintf(
				'[et_pb_button button_text="%1$s" button_url="%2$s" button_alignment="left" admin_label="ContentGem Button" _builder_version="%3$s" /]',
				esc_attr( $text ),
				esc_url_raw( (string) $href_match[1] ),
				esc_attr( $builder_version )
			);
		}

		return sprintf(
			'[et_pb_text admin_label="ContentGem Block" _builder_version="%1$s" hover_enabled="0" sticky_enabled="0"]%2$s[/et_pb_text]',
			esc_attr( $builder_version ),
			$html
		);
	}

	private function extract_blocks( string $html ): array {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return [ [ 'tag' => 'div', 'html' => $html, 'text' => wp_strip_all_tags( $html ) ] ];
		}
		$doc = new DOMDocument( '1.0', 'UTF-8' );
		$wrapped = '<!DOCTYPE html><html><body><div id="cgm-root">' . $html . '</div></body></html>';
		libxml_use_internal_errors( true );
		$loaded = $doc->loadHTML( $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		if ( ! $loaded ) {
			return [ [ 'tag' => 'div', 'html' => $html, 'text' => wp_strip_all_tags( $html ) ] ];
		}
		$root = null;
		foreach ( $doc->getElementsByTagName( 'div' ) as $div ) {
			if ( 'cgm-root' === $div->getAttribute( 'id' ) ) {
				$root = $div;
				break;
			}
		}
		if ( ! $root ) {
			return [ [ 'tag' => 'div', 'html' => $html, 'text' => wp_strip_all_tags( $html ) ] ];
		}
		$blocks = [];
		foreach ( $root->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType ) {
				$text = trim( preg_replace( '/\s+/u', ' ', (string) $child->textContent ) );
				if ( '' !== $text ) {
					$blocks[] = [ 'tag' => 'p', 'html' => '<p>' . esc_html( $text ) . '</p>', 'text' => $text ];
				}
				continue;
			}
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}
			$tag = strtolower( (string) $child->nodeName );
			$block_html = trim( $doc->saveHTML( $child ) );
			if ( '' === $block_html ) {
				continue;
			}
			$blocks[] = [
				'tag' => $tag,
				'html' => $block_html,
				'text' => trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $block_html ) ) ),
			];
		}
		return $blocks;
	}

	private function normalize_widget_html( string $html, string $tag ): string {
		$html = trim( $html );
		if ( '' === $html ) {
			return '';
		}
		if ( in_array( $tag, [ 'p', 'ul', 'ol', 'blockquote', 'table', 'figure', 'details', 'div' ], true ) ) {
			return $html;
		}
		return '<div>' . $html . '</div>';
	}

	private function normalize_html( string $html ): string {
		$html = trim( (string) $html );
		$html = preg_replace( '/^```(?:html)?\s*/i', '', $html );
		$html = preg_replace( '/\s*```$/', '', (string) $html );
		return wp_kses_post( $html );
	}

	private function make_id( string $seed ): string {
		return substr( md5( $seed . '|' . wp_rand() . '|' . microtime( true ) ), 0, 8 );
	}
}
