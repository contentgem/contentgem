<?php
/**
 * Class CGM_Tone_Analyzer
 *
 * Analyseert de schrijfstijl van bestaande gepubliceerde posts en genereert
 * een tone-of-voice snapshot die gebruikt wordt bij draft generatie.
 *
 * De snapshot wordt opgeslagen in cgm_sites.tone_snapshot en bevat:
 *  - Formeel/informeel (gebruik van je/u/jullie)
 *  - Gemiddelde zinslengte
 *  - Gebruik van actieve/passieve zin
 *  - Toon (zakelijk, vriendelijk, inspirerend, etc.)
 *  - Typische openingszinnen
 *  - Gebruik van opsommingen, koppen, vragen
 *
 * @package Contentgem
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Tone_Analyzer {

	/** Aantal posts dat geanalyseerd wordt voor de snapshot. */
	private const SAMPLE_SIZE = 5;

	/** Maximum tekens per post die naar de AI gestuurd worden. */
	private const MAX_CHARS_PER_POST = 1500;

	private CGM_AI_Client $ai;

	public function __construct( CGM_AI_Client $ai ) {
		$this->ai = $ai;
	}

	/**
	 * Analyseert de tone of voice van de website en slaat de snapshot op.
	 *
	 * @param int $site_id  ID uit cgm_sites.
	 * @return string  De gegenereerde tone snapshot, of lege string bij fout.
	 */
	public function analyze_and_save( int $site_id ): string {
		$snapshot = $this->generate_snapshot();

		if ( '' === $snapshot ) {
			return '';
		}

		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'cgm_sites',
			[ 'tone_snapshot' => $snapshot ],
			[ 'id' => $site_id ],
			[ '%s' ],
			[ '%d' ]
		);

		return $snapshot;
	}

	/**
	 * Genereert een tone snapshot op basis van bestaande posts.
	 *
	 * @return string  JSON-string met tone kenmerken, of lege string bij fout.
	 */
	public function generate_snapshot(): string {
		$posts = $this->get_sample_posts();

		if ( empty( $posts ) ) {
			return '';
		}

		$excerpts = $this->build_excerpts( $posts );

		if ( '' === $excerpts ) {
			return '';
		}

		try {
			$prompt = $this->build_analysis_prompt( $excerpts );
			$result = $this->ai->chat(
				[ [ 'role' => 'user', 'content' => $prompt ] ],
				'You are an expert in linguistics and writing style analysis.',
				800
			);

			$raw      = $result['text'] ?? '';
			$snapshot = $this->parse_snapshot( $raw );

			return $snapshot;
		} catch ( \Exception $e ) {
			return '';
		}
	}

	/**
	 * Bouwt een system prompt op basis van de tone snapshot voor gebruik in draft generatie.
	 *
	 * @param string $snapshot  JSON tone snapshot.
	 * @return string  Instructies voor de AI om de schrijfstijl te matchen.
	 */
	public function build_tone_instructions( string $snapshot ): string {
		if ( '' === $snapshot ) {
			return '';
		}

		$data = json_decode( $snapshot, true );

		if ( ! is_array( $data ) ) {
			return "Match the existing writing style of this website: {$snapshot}";
		}

		$instructions = "TONE OF VOICE — match the existing writing style of this website exactly:\n";

		if ( ! empty( $data['formality'] ) ) {
			$instructions .= "- Formality: {$data['formality']}\n";
		}
		if ( ! empty( $data['tone'] ) ) {
			$instructions .= "- Tone: {$data['tone']}\n";
		}
		if ( ! empty( $data['sentence_length'] ) ) {
			$instructions .= "- Sentence length: {$data['sentence_length']}\n";
		}
		if ( ! empty( $data['person'] ) ) {
			$instructions .= "- Address reader as: {$data['person']}\n";
		}
		if ( ! empty( $data['structure'] ) ) {
			$instructions .= "- Content structure: {$data['structure']}\n";
		}
		if ( ! empty( $data['style_notes'] ) ) {
			$instructions .= "- Style notes: {$data['style_notes']}\n";
		}
		if ( ! empty( $data['language'] ) ) {
			$instructions .= "- Language: {$data['language']}\n";
		}

		$instructions .= "\nDo NOT change your writing style — stay true to this tone throughout the entire article.\n";

		return $instructions;
	}

	// ── Private helpers ───────────────────────────────────────────────────────

	/**
	 * Haalt de meest recente gepubliceerde posts op voor analyse.
	 *
	 * @return WP_Post[]
	 */
	private function get_sample_posts(): array {
		return get_posts( [
			'numberposts'            => self::SAMPLE_SIZE,
			'post_status'            => 'publish',
			'post_type'              => 'post',
			'orderby'                => 'date',
			'order'                  => 'DESC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		] );
	}

	/**
	 * Bouwt een tekstsamenvoeging van de post-excerpts.
	 *
	 * @param WP_Post[] $posts
	 * @return string
	 */
	private function build_excerpts( array $posts ): string {
		$parts = [];

		foreach ( $posts as $i => $post ) {
			$content = wp_strip_all_tags( $post->post_content );
			$content = preg_replace( '/\s+/', ' ', $content );
			$content = trim( mb_substr( $content, 0, self::MAX_CHARS_PER_POST ) );

			if ( '' === $content ) {
				continue;
			}

			$parts[] = "--- Article " . ( $i + 1 ) . ": {$post->post_title} ---\n{$content}";
		}

		return implode( "\n\n", $parts );
	}

	/**
	 * Bouwt de analyse-prompt.
	 *
	 * @param string $excerpts  Samengevoegde tekst van de posts.
	 * @return string
	 */
	private function build_analysis_prompt( string $excerpts ): string {
		return "Analyse the writing style of the following articles from a website. " .
			"Return ONLY a JSON object (no explanation, no markdown) with these exact keys:\n\n" .
			"{\n" .
			"  \"formality\": \"formal|semi-formal|informal\",\n" .
			"  \"tone\": \"brief description of the overall tone (e.g. friendly and direct, professional, inspirational)\",\n" .
			"  \"sentence_length\": \"short|medium|long|varied\",\n" .
			"  \"person\": \"how the reader is addressed (e.g. you, je, u, jij)\",\n" .
			"  \"structure\": \"how content is structured (e.g. uses many subheadings, lots of bullet points, long paragraphs)\",\n" .
			"  \"style_notes\": \"any other notable style characteristics in 1-2 sentences\",\n" .
			"  \"language\": \"the language of the articles (e.g. Dutch, English)\"\n" .
			"}\n\n" .
			"Articles to analyse:\n\n" .
			$excerpts;
	}

	/**
	 * Parseert de AI-response naar een JSON-string.
	 *
	 * @param string $raw  Ruwe AI-response.
	 * @return string  Geldige JSON-string of lege string bij fout.
	 */
	private function parse_snapshot( string $raw ): string {
		// Probeer directe decode
		$decoded = json_decode( $raw, true );
		if ( is_array( $decoded ) ) {
			return wp_json_encode( $decoded );
		}

		// Strip markdown code blocks
		$stripped = preg_replace( '/^```(?:json)?\s*/i', '', trim( $raw ) );
		$stripped = preg_replace( '/\s*```$/', '', trim( $stripped ?? '' ) );
		$decoded  = json_decode( $stripped, true );
		if ( is_array( $decoded ) ) {
			return wp_json_encode( $decoded );
		}

		// Extraheer JSON object
		$start = strpos( $raw, '{' );
		$end   = strrpos( $raw, '}' );
		if ( $start !== false && $end !== false && $end > $start ) {
			$decoded = json_decode( substr( $raw, $start, $end - $start + 1 ), true );
			if ( is_array( $decoded ) ) {
				return wp_json_encode( $decoded );
			}
		}

		// Fallback: sla de ruwe tekst op
		return '' !== trim( $raw ) ? trim( $raw ) : '';
	}
}
