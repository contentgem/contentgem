<?php
defined( 'ABSPATH' ) || exit;

class CGM_Prompt_Library {
	public function get_instructions( string $task, string $language = 'en' ): string {
		$base = $this->base_instructions( $language );
		$quality = $this->quality_rules( $task, $language );
		$task_rules = $this->task_rules( $task, $language );
		return trim( $base . "

" . $quality . ( $task_rules ? "

" . $task_rules : '' ) );
	}

	public function get_source_mode_appendix( bool $enabled, string $language = 'en' ): string {
		if ( ! $enabled ) {
			return '';
		}
		return 'nl' === $language
			? "Voeg waar mogelijk een compacte bronnenlijst toe met labels en relevante verwijzingen. Als er geen betrouwbare bronnen zijn, laat het bronnenveld leeg in plaats van te gokken."
			: "Include a compact source list when reliable sources are available. If reliable sources are not available, leave the sources field empty instead of guessing.";
	}

	private function base_instructions( string $language ): string {
		return 'nl' === $language
			? 'Je bent de Contentgem AI-assistent. Geef compacte, bruikbare en feitelijk voorzichtige output. Markeer aannames expliciet. Geef geen markdown code fences tenzij daar expliciet om wordt gevraagd.'
			: 'You are the Contentgem AI assistant. Produce compact, actionable and factually cautious output. Label assumptions explicitly. Do not use markdown code fences unless explicitly requested.';
	}

	private function quality_rules( string $task, string $language ): string {
		$rules = [
			'Use the configured language consistently.',
			'Prefer specific terminology over vague abstractions.',
			'Keep structure stable and machine-readable when a schema is expected.',
			'Do not invent settings, routes or classes that are not grounded in the provided context.',
		];
		if ( 'nl' === $language ) {
			$rules = [
				'Gebruik de ingestelde taal consequent.',
				'Gebruik specifieke terminologie in plaats van vage abstraheringen.',
				'Houd de structuur stabiel en machineleesbaar wanneer een schema verwacht wordt.',
				'Verzin geen settings, routes of classes die niet in de context zijn onderbouwd.',
			];
		}
		return implode( "
", array_map( static function ( $rule ) { return '- ' . $rule; }, $rules ) );
	}

	private function task_rules( string $task, string $language ): string {
		$map = [
			'title_suggestions' => 'Return concise SEO title suggestions with a matching focus keyword and one short rationale per item.',
			'semantic_keyword_suggestions' => 'Return only useful supporting semantic keywords. Avoid filler terms, stop words and duplicates.',
			'ai_assistant_research' => 'Return clean article-ready HTML only. Do not include code fences, raw SVG, figures, cards, legends or stacked label lists in the main article body.',
			'technical_build_plan' => 'Return a grounded technical plan that explicitly references relevant files, routes, classes or settings when they are present in the supplied context.',
		];
		if ( 'nl' === $language ) {
			$map = [
				'title_suggestions' => 'Geef compacte SEO-titels met een passend focus-keyword en één korte rationale per item.',
				'semantic_keyword_suggestions' => 'Geef alleen nuttige ondersteunende semantische keywords. Vermijd stopwoorden, opvulwoorden en duplicaten.',
				'ai_assistant_research' => 'Geef alleen schone artikelklare HTML terug. Voeg geen code fences, ruwe SVG, figures, kaarten, legends of gestapelde label-lijsten toe aan de artikelbody.',
				'technical_build_plan' => 'Geef een gegronde technische uitwerking die expliciet verwijst naar relevante bestanden, routes, classes of settings wanneer die in de context aanwezig zijn.',
			];
		}
		return $map[ $task ] ?? '';
	}
}
