<?php
/**
 * Premium-only admin paywall renderer.
 *
 * @package Contentgem
 */

defined( 'ABSPATH' ) || exit;

class CGM_Paywall {

	public static function render(): void {
		$upgrade_url = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '#';
		$account_url = function_exists( 'cgm_get_account_url' ) ? cgm_get_account_url() : '#';
		?>
		<div class="wrap cgm-paywall-wrap">
			<div class="cgm-paywall-shell">
				<div class="cgm-paywall-card">
					<div class="cgm-paywall-badge">Contentgem.ai</div>

					<h1 class="cgm-paywall-title"><?php esc_html_e( 'Unlock the full Contentgem workflow', 'contentgem' ); ?></h1>

					<p class="cgm-paywall-subtitle">
						<?php esc_html_e( 'Activate a paid plan to unlock advanced workflows like competitor analysis, saved reports, authority scoring, and unlimited drafting.', 'contentgem' ); ?>
					</p>

					<div class="cgm-paywall-grid">
						<div class="cgm-paywall-panel">
							<h2><?php esc_html_e( 'What you unlock', 'contentgem' ); ?></h2>
							<ul>
								<li><?php esc_html_e( 'Content gap analysis', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Bulk competitor analysis', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'AI draft generation', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Internal linking optimization', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Reports and advanced settings', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Premium support and updates', 'contentgem' ); ?></li>
							</ul>
						</div>

						<div class="cgm-paywall-panel">
							<h2><?php esc_html_e( 'Why activate now', 'contentgem' ); ?></h2>
							<ul>
								<li><?php esc_html_e( 'Turn your site into a structured topical authority engine', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Find missed traffic opportunities faster', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Generate publish-ready workflows from one dashboard', 'contentgem' ); ?></li>
								<li><?php esc_html_e( 'Keep billing, licensing, and updates managed inside WordPress', 'contentgem' ); ?></li>
							</ul>
						</div>
					</div>

					<div class="cgm-paywall-actions">
						<a href="<?php echo esc_url( $upgrade_url ); ?>" class="button button-primary button-hero">
							<?php esc_html_e( 'View plans', 'contentgem' ); ?>
						</a>

						<a href="<?php echo esc_url( $account_url ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Open account', 'contentgem' ); ?>
						</a>
					</div>

					<div class="cgm-paywall-note">
						<?php esc_html_e( 'Already purchased Contentgem? Open your account page and activate your license key there.', 'contentgem' ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
