<?php
/**
 * Persistent job storage for Contentgem.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Job_Repository {
	private string $table;
	private string $events_table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'cgm_jobs';
		$this->events_table = $wpdb->prefix . 'cgm_job_events';
	}

	public function create( array $job ): array {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$record = [
			'job_key'          => sanitize_key( (string) ( $job['job_key'] ?? wp_generate_uuid4() ) ),
			'site_id'          => isset( $job['site_id'] ) ? (int) $job['site_id'] : 0,
			'type'             => sanitize_key( (string) ( $job['type'] ?? 'generic' ) ),
			'status'           => $this->normalize_status( (string) ( $job['status'] ?? 'queued' ) ),
			'progress_current' => max( 0, (int) ( $job['progress_current'] ?? 0 ) ),
			'progress_total'   => max( 1, (int) ( $job['progress_total'] ?? 100 ) ),
			'step'             => sanitize_key( (string) ( $job['step'] ?? 'queued' ) ),
			'message'          => sanitize_text_field( (string) ( $job['message'] ?? '' ) ),
			'payload_json'     => wp_json_encode( $job['payload'] ?? [] ),
			'result_json'      => wp_json_encode( $job['result'] ?? [] ),
			'error_json'       => wp_json_encode( $job['error'] ?? [] ),
			'attempts'         => max( 0, (int) ( $job['attempts'] ?? 0 ) ),
			'max_attempts'     => max( 1, (int) ( $job['max_attempts'] ?? 1 ) ),
			'idempotency_key'  => sanitize_text_field( (string) ( $job['idempotency_key'] ?? '' ) ),
			'job_token'        => sanitize_text_field( (string) ( $job['job_token'] ?? '' ) ),
			'locked_at'        => null,
			'locked_by'        => '',
			'next_run_at'      => $job['next_run_at'] ?? $now,
			'created_at'       => $now,
			'updated_at'       => $now,
		];
		$wpdb->insert( $this->table, $record ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$id = (int) $wpdb->insert_id;
		$created = $this->get( $id );
		if ( $created ) {
			$this->mirror_legacy_option( $created );
			$this->add_event( $id, 'info', 'Job created', [ 'type' => $created['type'] ] );
			return $created;
		}
		throw new RuntimeException( 'Failed to create Contentgem job.' );
	}

	public function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d LIMIT 1", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		return is_array( $row ) ? $this->hydrate( $row ) : null;
	}

	public function get_by_key( string $job_key ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE job_key = %s LIMIT 1", sanitize_key( $job_key ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		return is_array( $row ) ? $this->hydrate( $row ) : null;
	}

	public function find_active_by_type( string $type, int $site_id = 0, string $idempotency_key = '' ): ?array {
		global $wpdb;
		$sql = "SELECT * FROM {$this->table} WHERE type = %s AND status IN ('queued','processing','finalizing')";
		$args = [ sanitize_key( $type ) ];
		if ( $site_id > 0 ) {
			$sql .= ' AND site_id = %d';
			$args[] = $site_id;
		}
		if ( '' !== $idempotency_key ) {
			$sql .= ' AND idempotency_key = %s';
			$args[] = sanitize_text_field( $idempotency_key );
		}
		$sql .= ' ORDER BY id DESC LIMIT 1';
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		return is_array( $row ) ? $this->hydrate( $row ) : null;
	}

	public function find_next_queued(): ?array {
		global $wpdb;
		$row = $wpdb->get_row( "SELECT * FROM {$this->table} WHERE status = 'queued' ORDER BY id ASC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return is_array( $row ) ? $this->hydrate( $row ) : null;
	}

	public function claim( int $id, string $locked_by ): bool {
		global $wpdb;
		$updated = $wpdb->update(
			$this->table,
			[
				'status' => 'processing',
				'locked_at' => current_time( 'mysql', true ),
				'locked_by' => sanitize_text_field( $locked_by ),
				'updated_at' => current_time( 'mysql', true ),
			],
			[ 'id' => $id, 'status' => 'queued' ],
			[ '%s', '%s', '%s', '%s' ],
			[ '%d', '%s' ]
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		if ( 1 === (int) $updated ) {
			$job = $this->get( $id );
			if ( $job ) {
				$this->mirror_legacy_option( $job );
			}
			return true;
		}
		return false;
	}

	public function update( int $id, array $changes ): ?array {
		global $wpdb;
		$data = [];
		$formats = [];
		$map = [
			'status' => '%s',
			'progress_current' => '%d',
			'progress_total' => '%d',
			'step' => '%s',
			'message' => '%s',
			'payload_json' => '%s',
			'result_json' => '%s',
			'error_json' => '%s',
			'attempts' => '%d',
			'max_attempts' => '%d',
			'idempotency_key' => '%s',
			'job_token' => '%s',
			'locked_at' => '%s',
			'locked_by' => '%s',
			'next_run_at' => '%s',
		];
		foreach ( $map as $key => $format ) {
			if ( ! array_key_exists( $key, $changes ) ) {
				continue;
			}
			$value = $changes[ $key ];
			if ( 'status' === $key ) {
				$value = $this->normalize_status( (string) $value );
			} elseif ( in_array( $key, [ 'payload_json', 'result_json', 'error_json' ], true ) && ! is_string( $value ) ) {
				$value = wp_json_encode( $value );
			} elseif ( in_array( $key, [ 'progress_current', 'progress_total', 'attempts', 'max_attempts' ], true ) ) {
				$value = (int) $value;
			} elseif ( in_array( $key, [ 'message', 'idempotency_key', 'job_token', 'locked_by' ], true ) ) {
				$value = sanitize_text_field( (string) $value );
			} elseif ( 'step' === $key ) {
				$value = sanitize_key( (string) $value );
			}
			$data[ $key ] = $value;
			$formats[] = $format;
		}
		$data['updated_at'] = current_time( 'mysql', true );
		$formats[] = '%s';
		if ( ! empty( $data ) ) {
			$wpdb->update( $this->table, $data, [ 'id' => $id ], $formats, [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		}
		$job = $this->get( $id );
		if ( $job ) {
			$this->mirror_legacy_option( $job );
		}
		return $job;
	}

	public function add_event( int $job_id, string $level, string $message, array $meta = [] ): void {
		global $wpdb;
		$wpdb->insert( $this->events_table, [
			'job_id' => $job_id,
			'level' => sanitize_key( $level ),
			'message' => sanitize_text_field( $message ),
			'meta_json' => wp_json_encode( $meta ),
			'created_at' => current_time( 'mysql', true ),
		], [ '%d', '%s', '%s', '%s', '%s' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	private function hydrate( array $row ): array {
		$payload = json_decode( (string) ( $row['payload_json'] ?? '{}' ), true );
		$result = json_decode( (string) ( $row['result_json'] ?? '{}' ), true );
		$error  = json_decode( (string) ( $row['error_json'] ?? '{}' ), true );
		return [
			'id' => (int) $row['id'],
			'job_key' => (string) $row['job_key'],
			'site_id' => (int) $row['site_id'],
			'type' => (string) $row['type'],
			'status' => $this->normalize_status( (string) $row['status'] ),
			'progress_current' => (int) $row['progress_current'],
			'progress_total' => max( 1, (int) $row['progress_total'] ),
			'progress_percentage' => (int) min( 100, max( 0, round( 100 * ( (int) $row['progress_current'] / max( 1, (int) $row['progress_total'] ) ) ) ) ),
			'step' => (string) $row['step'],
			'message' => (string) $row['message'],
			'payload' => is_array( $payload ) ? $payload : [],
			'result' => is_array( $result ) ? $result : [],
			'error' => is_array( $error ) ? $error : [],
			'attempts' => (int) $row['attempts'],
			'max_attempts' => (int) $row['max_attempts'],
			'idempotency_key' => (string) $row['idempotency_key'],
			'job_token' => (string) $row['job_token'],
			'locked_at' => (string) ( $row['locked_at'] ?? '' ),
			'locked_by' => (string) ( $row['locked_by'] ?? '' ),
			'next_run_at' => (string) ( $row['next_run_at'] ?? '' ),
			'created_at' => (string) ( $row['created_at'] ?? '' ),
			'updated_at' => (string) ( $row['updated_at'] ?? '' ),
		];
	}

	private function normalize_status( string $status ): string {
		$map = [
			'running' => 'processing',
			'done' => 'completed',
			'error' => 'failed',
			'stalled' => 'failed',
		];
		$status = sanitize_key( $status );
		return $map[ $status ] ?? ( in_array( $status, [ 'queued', 'processing', 'finalizing', 'completed', 'failed' ], true ) ? $status : 'queued' );
	}

	public function mirror_legacy_option( array $job ): void {
		$legacy = [
			'status' => CGM_Job_Service::to_legacy_status( (string) $job['status'] ),
			'progress' => (int) ( 'completed' === $job['status'] ? 100 : min( 99, (int) $job['progress_percentage'] ) ),
			'message' => (string) ( $job['message'] ?? '' ),
			'step' => (string) ( $job['step'] ?? '' ),
			'token' => (string) ( $job['job_token'] ?? '' ),
			'site_id' => (int) ( $job['site_id'] ?? 0 ),
			'payload' => $job['payload'] ?? [],
			'result' => $job['result'] ?? [],
			'error' => is_array( $job['error'] ?? null ) ? (string) ( $job['error']['message'] ?? '' ) : '',
			'updated' => time(),
			'started' => time(),
		];
		if ( ! empty( $job['result']['wp_post_id'] ) ) {
			$legacy['wp_post_id'] = (int) $job['result']['wp_post_id'];
		}
		update_option( 'cgm_job_' . $job['job_key'], $legacy, false );
	}
}
