<?php
/**
 * Diagnostic service for internal link reinsertion.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Reinsert_Diagnostic_Service {
	protected $scanner;
	protected $home_host;

	public function __construct( $scanner = null ) {
		$this->scanner = $scanner ?: new CGM_Link_Scanner();
		$this->home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	}

	public function detect_content_source( int $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return [ 'source' => 'unknown', 'supported' => false, 'reason' => 'Post not found', 'details' => [] ];
		}
		$details = [
			'has_blocks' => function_exists('has_blocks') ? has_blocks( $post->post_content ) : false,
			'post_content_length' => strlen( (string) $post->post_content ),
			'uses_elementor' => (bool) get_post_meta( $post_id, '_elementor_data', true ),
			'uses_elementor_edit' => (bool) get_post_meta( $post_id, '_elementor_edit_mode', true ),
			'uses_divi' => (bool) get_post_meta( $post_id, '_et_pb_use_builder', true ),
			'uses_beaver' => (bool) get_post_meta( $post_id, '_fl_builder_enabled', true ),
			'has_cgm_draft_text' => is_string( get_post_meta( $post_id, '_cgm_draft_text', true ) ) && '' !== trim( (string) get_post_meta( $post_id, '_cgm_draft_text', true ) ),
			'has_cgm_draft_svgs' => ! empty( get_post_meta( $post_id, '_cgm_draft_svgs', true ) ),
		];
		if ( ! empty( $details['has_cgm_draft_text'] ) ) {
			return [ 'source' => 'contentgem_draft', 'supported' => true, 'reason' => '', 'details' => $details ];
		}
		if ( $details['uses_elementor'] || $details['uses_elementor_edit'] || $details['uses_divi'] || $details['uses_beaver'] ) {
			return [ 'source' => 'builder', 'supported' => false, 'reason' => 'Builder content detected', 'details' => $details ];
		}
		if ( $details['has_blocks'] ) {
			return [ 'source' => 'gutenberg', 'supported' => true, 'reason' => '', 'details' => $details ];
		}
		if ( $details['post_content_length'] > 50 ) {
			return [ 'source' => 'classic', 'supported' => true, 'reason' => '', 'details' => $details ];
		}
		return [ 'source' => 'unknown', 'supported' => false, 'reason' => 'Empty or unsupported post_content', 'details' => $details ];
	}

	public function get_content_snapshot( int $post_id ): array {
		$post = get_post( $post_id );
		$content = $post instanceof WP_Post ? (string) $post->post_content : '';
		return [
			'post_id' => $post_id,
			'post_title' => $post instanceof WP_Post ? (string) $post->post_title : '',
			'post_content' => $content,
			'content_hash' => md5( $content ),
			'internal_links_all' => $this->extract_internal_links_all( $content ),
			'internal_links_body_only' => $this->extract_internal_links_body_only( $content ),
			'paragraph_count' => substr_count( strtolower( $content ), '<p' ),
		];
	}

	protected function get_mutable_content_payload( int $post_id ): array {
		$draft_text = get_post_meta( $post_id, '_cgm_draft_text', true );

		if ( is_string( $draft_text ) && '' !== trim( $draft_text ) ) {
			$svgs     = get_post_meta( $post_id, '_cgm_draft_svgs', true );
			$captions = get_post_meta( $post_id, '_cgm_draft_captions', true );
			$targets  = get_post_meta( $post_id, '_cgm_draft_svg_targets', true );

			return [
				'mode'     => 'draft_meta',
				'content'  => (string) $draft_text,
				'svgs'     => is_array( $svgs ) ? $svgs : [],
				'captions' => is_array( $captions ) ? $captions : [],
				'targets'  => is_array( $targets ) ? $targets : [],
			];
		}

		$post = get_post( $post_id );

		return [
			'mode'     => 'post_content',
			'content'  => $post instanceof WP_Post ? (string) $post->post_content : '',
			'svgs'     => [],
			'captions' => [],
			'targets'  => [],
		];
	}

	protected function persist_mutable_content( int $post_id, string $content, array $payload ) {
		$mode = (string) ( $payload['mode'] ?? 'post_content' );

		if ( 'draft_meta' === $mode ) {
			update_post_meta( $post_id, '_cgm_draft_text', $content );
			update_post_meta( $post_id, '_contentgem_draft_text', $content );

			$svgs     = is_array( $payload['svgs'] ?? null ) ? $payload['svgs'] : [];
			$captions = is_array( $payload['captions'] ?? null ) ? $payload['captions'] : [];
			$rendered = $content;

			if ( class_exists( 'CGM_Draft_SVG' ) && is_callable( [ 'CGM_Draft_SVG', 'render_draft_html' ] ) ) {
				$rendered = CGM_Draft_SVG::render_draft_html( $content, $svgs, $captions );
			}

			return wp_update_post(
				[
					'ID'           => $post_id,
					'post_content' => wp_slash( $rendered ),
				],
				true
			);
		}

		return wp_update_post(
			[
				'ID'           => $post_id,
				'post_content' => wp_slash( $content ),
			],
			true
		);
	}

	protected function count_words_from_html( string $content ): int {
		$text = (string) preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $content );
		$text = wp_strip_all_tags( html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		$text = trim( preg_replace( '/\s+/u', ' ', $text ) );
		if ( '' === $text ) {
			return 0;
		}
		$parts = preg_split( '/\s+/u', $text );
		return is_array( $parts ) ? count( array_filter( $parts, static function( $part ) {
			return '' !== trim( (string) $part );
		} ) ) : 0;
	}

	protected function get_adaptive_internal_link_goal( string $content ): int {
		$word_count      = $this->count_words_from_html( $content );
		$paragraph_count = max( 1, substr_count( strtolower( $content ), '<p' ) );

		$goal = 2;
		if ( $word_count >= 600 ) {
			$goal = 3;
		}
		if ( $word_count >= 900 ) {
			$goal = 4;
		}
		if ( $word_count >= 1200 ) {
			$goal = 5;
		}
		if ( $word_count >= 1600 ) {
			$goal = 6;
		}
		if ( $word_count >= 2000 ) {
			$goal = 8;
		}
		if ( $word_count >= 2600 ) {
			$goal = 10;
		}
		if ( $word_count >= 3400 ) {
			$goal = 12;
		}

		$paragraph_cap = max( 2, (int) floor( $paragraph_count * 0.8 ) );
		return max( 2, min( 12, min( $goal, $paragraph_cap ) ) );
	}

	protected function get_candidate_pool_limit( int $goal ): int {
		return max( 8, min( 24, $goal * 4 ) );
	}

	public function build_single_post_reinsert_plan( int $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return [ 'post_id' => $post_id, 'cluster' => '', 'targets' => [], 'remove_candidates' => [], 'add_candidates' => [], 'target_goal' => 0, 'word_count' => 0 ];
		}
		$payload     = $this->get_mutable_content_payload( $post_id );
		$base_content = (string) ( $payload['content'] ?? (string) $post->post_content );
		$target_goal = $this->get_adaptive_internal_link_goal( $base_content );
		$candidate_limit = $this->get_candidate_pool_limit( $target_goal );

		$cluster = '';
		try {
			$ref = new ReflectionMethod( $this->scanner, 'get_post_cluster' );
			$ref->setAccessible( true );
			$cluster = (string) $ref->invoke( $this->scanner, $post_id );
		} catch ( Throwable $e ) {}
		$pillar_map = get_option( 'contentgem_pillar_pages', [] );
		$forced_pillar_url = '';
		if ( is_array( $pillar_map ) && ! empty( $pillar_map[ $cluster ] ) ) {
			$forced_pillar_url = (string) get_permalink( (int) $pillar_map[ $cluster ] );
		}
		$suggestions = $this->scanner->get_link_suggestions( $post_id, $forced_pillar_url, false );
		$targets = [];
		foreach ( array_slice( (array) $suggestions, 0, $candidate_limit ) as $s ) {
			$url    = esc_url_raw( (string) ( $s['target_url'] ?? '' ) );
			$title  = (string) ( $s['target_title'] ?? '' );
			$anchor = trim( (string) ( $s['anchor_text'] ?? '' ) );
			// Skip targets without a concrete anchor phrase — the scanner emits an empty
			// anchor when no distinctive in-content phrase is available, which means we
			// should NOT fall back to the full title (that re-introduces cluster-name anchors).
			if ( '' === $url || '' === $title || mb_strlen( $anchor ) < 4 ) {
				continue;
			}
			$targets[] = [
				'target_id' => (int) ( $s['target_post_id'] ?? 0 ),
				'target_url' => $url,
				'target_title' => $title,
				'target_type' => ( false !== stripos( (string) ( $s['context_hint'] ?? '' ), 'pillar' ) ? 'pillar' : 'cluster' ),
				'anchor_candidates' => [ $anchor ],
				'reason' => (string) ( $s['context_hint'] ?? '' ),
			];
		}
		return [
			'post_id' => $post_id,
			'cluster' => $cluster,
			'targets' => $targets,
			'target_goal' => $target_goal,
			'word_count' => $this->count_words_from_html( $base_content ),
			'remove_candidates' => $this->extract_internal_links_body_only( (string) $post->post_content ),
			'add_candidates' => $targets,
		];
	}

	protected function insert_links_into_supported_content( string $content, array $targets, string $source_type, ?int $target_goal = null ): array {
		$inserted = [];
		if ( ! in_array( $source_type, [ 'classic', 'gutenberg', 'contentgem_draft' ], true ) ) {
			return [ 'content' => $content, 'inserted_urls' => [], 'write_method' => 'unsupported', 'target_goal' => 0 ];
		}
		$paragraph_pattern = '#<p\b[^>]*>.*?</p>#is';
		if ( ! preg_match_all( $paragraph_pattern, $content, $matches, PREG_OFFSET_CAPTURE ) || empty( $matches[0] ) ) {
			return [ 'content' => $content, 'inserted_urls' => [], 'write_method' => $source_type . '_no_paragraphs', 'target_goal' => 0 ];
		}

		$resolved_goal = null === $target_goal ? $this->get_adaptive_internal_link_goal( $content ) : max( 1, (int) $target_goal );
		$used_urls    = [];
		$used_anchors = [];
		foreach ( $targets as $target ) {
			if ( count( $inserted ) >= $resolved_goal ) {
				break;
			}
			$url    = esc_url_raw( (string) ( $target['target_url'] ?? '' ) );
			$title  = wp_strip_all_tags( (string) ( $target['target_title'] ?? '' ) );
			$anchor = trim( wp_strip_all_tags( (string) ( $target['anchor_candidates'][0] ?? '' ) ) );

			// Hard requirements: URL, title, usable anchor phrase of at least 4 chars.
			// Empty/too-short anchors mean the scanner could not find a natural in-content phrase,
			// so we DO NOT fall back to a template sentence — we just skip this target.
			if ( '' === $url || '' === $title || mb_strlen( $anchor ) < 4 ) {
				continue;
			}
			// Dedup by URL (same target) and by anchor text (avoid 4× "Topical Authority" in one post).
			$url_key    = untrailingslashit( $url );
			$anchor_key = mb_strtolower( $anchor );
			if ( isset( $used_urls[ $url_key ] ) || isset( $used_anchors[ $anchor_key ] ) ) {
				continue;
			}

			$link_tag        = '<a href="' . esc_url( $url ) . '" class="cgm-inline-link-inserted" data-cgm-reinsert="1">' . esc_html( $anchor ) . '</a>';
			$updated_content = $content;
			$matched_inline  = false;

			// Only strategy: find the anchor phrase verbatim inside a paragraph and wrap it.
			// If the phrase does not occur, the target is simply skipped — no template sentences.
			$candidate = preg_replace_callback(
				'/(<p\b[^>]*>(?:(?!<\/p>).)*?)(' . preg_quote( $anchor, '/' ) . ')((?:(?!<\/p>).)*?<\/p>)/is',
				static function ( $m ) use ( $link_tag, $anchor ) {
					// Do not double-wrap an already-linked phrase.
					if ( preg_match( '#<a\b[^>]*>[^<]*' . preg_quote( $anchor, '#' ) . '[^<]*<\/a>#i', $m[0] ) ) {
						return $m[0];
					}
					return $m[1] . $link_tag . $m[3];
				},
				$updated_content,
				1,
				$count
			);
			if ( $count > 0 && is_string( $candidate ) && $candidate !== $updated_content ) {
				$updated_content = $candidate;
				$matched_inline  = true;
			}

			if ( $matched_inline && $updated_content !== $content ) {
				$content                     = $updated_content;
				$used_urls[ $url_key ]       = true;
				$used_anchors[ $anchor_key ] = true;
				$inserted[]                  = $url;
			}
		}

		return [ 'content' => $content, 'inserted_urls' => $inserted, 'write_method' => $source_type . '_inline', 'target_goal' => $resolved_goal ];
	}

	public function estimate_insertable_targets_for_post( int $post_id, ?int $display_limit = 6 ): array {
		$source      = $this->detect_content_source( $post_id );
		$payload     = $this->get_mutable_content_payload( $post_id );
		$plan        = $this->build_single_post_reinsert_plan( $post_id );
		$targets     = (array) ( $plan['targets'] ?? [] );
		$target_goal = max( 1, (int) ( $plan['target_goal'] ?? $this->get_adaptive_internal_link_goal( (string) ( $payload['content'] ?? '' ) ) ) );

		if ( empty( $targets ) ) {
			return [
				'count'       => 0,
				'links'       => [],
				'target_goal' => $target_goal,
			];
		}

		$simulate = $this->insert_links_into_supported_content(
			(string) ( $payload['content'] ?? '' ),
			$targets,
			(string) $source['source'],
			$target_goal
		);

		$inserted_urls = array_map( 'esc_url_raw', (array) ( $simulate['inserted_urls'] ?? [] ) );
		$display_max   = null === $display_limit ? PHP_INT_MAX : max( 1, (int) $display_limit );

		$links = [];
		foreach ( $targets as $target ) {
			$url = esc_url_raw( (string) ( $target['target_url'] ?? '' ) );
			if ( in_array( $url, $inserted_urls, true ) ) {
				if ( count( $links ) < $display_max ) {
					$links[] = [
						'target_id' => (int) ( $target['target_id'] ?? 0 ),
						'title'     => (string) ( $target['target_title'] ?? '' ),
						'url'       => $url,
						'anchor'    => (string) ( $target['anchor_candidates'][0] ?? '' ),
						'reason'    => (string) ( $target['reason'] ?? '' ),
					];
				}
			}
		}

		return [
			'count'       => count( $inserted_urls ),
			'links'       => $links,
			'target_goal' => $target_goal,
		];
	}

	/**
	 * Strip legacy link-template cruft that earlier plugin versions injected into posts.
	 * Patterns handled (with or without wrapping <a> tags, case-insensitive):
	 *   - "See <phrase> for more detail."
	 *   - "For more detail, see <phrase>."
	 *   - "Also read: <phrase>." / "<em>Also read:</em> <phrase>." (colon required)
	 *   - "(<phrase>)" when it sits directly after a sentence boundary
	 * This is idempotent and safe to run on every reinsert pass. False positives on
	 * legitimate prose ("you can also read the docs", "the framework (TensorFlow) supports")
	 * are avoided by requiring highly specific template markers.
	 */
	public function cleanup_legacy_link_templates( string $content ): string {
		if ( '' === $content ) {
			return $content;
		}
		// A phrase is either a short <a>…</a> or a run of 1-6 words.
		$phrase = '(?:<a\b[^>]*>[^<]{1,80}</a>|[A-Za-z][A-Za-z0-9\'’\-]*(?:\s+[A-Za-z][A-Za-z0-9\'’\-]*){0,5})';

		$patterns = [
			// "See X for more detail." — template phrasing, highly specific.
			'#\s*\(?\s*See\s+' . $phrase . '\s+for\s+more\s+detail\s*\.?\s*\)?#i',
			// "For more detail, see X."
			'#\s*\(?\s*For\s+more\s+detail,\s+see\s+' . $phrase . '\s*\.?\s*\)?#i',
			// "Also read: X." — REQUIRES a colon after "read" so we don't match natural prose
			// like "you can also read the documentation".
			'#\s*(?:<em>\s*)?\*?\s*Also\s+read\s*:\s*\*?\s*(?:</em>\s*)?' . $phrase . '\s*\.?\s*#i',
			// "(X)" ONLY when it follows a sentence boundary (period, exclamation, question mark,
			// closing paragraph tag, or closing anchor). This preserves legitimate inline
			// parentheticals like "The framework (TensorFlow) supports many models."
			'#(?<=[.!?]|</p>|</a>)\s*\(\s*' . $phrase . '\s*\)(?=\s|[.,;:!?]|<|$)#i',
		];
		foreach ( $patterns as $pat ) {
			$prev = null;
			// Run repeatedly until no more matches (chains like "See X. See X. See X.").
			while ( $prev !== $content ) {
				$prev    = $content;
				$content = (string) preg_replace( $pat, ' ', $content );
			}
		}
		// Collapse leftover whitespace and orphan punctuation inside paragraphs.
		$content = (string) preg_replace( '#\s*\(\s*\)\s*#', '', $content );
		$content = (string) preg_replace( '#\s{2,}#', ' ', $content );
		$content = (string) preg_replace( '#\s+([.,;:!?])#', '$1', $content );
		return $content;
	}

	public function apply_single_post_reinsert( int $post_id ): array {
		$source = $this->detect_content_source( $post_id );
		if ( empty( $source['supported'] ) ) {
			return [ 'status' => 'skipped', 'post_id' => $post_id, 'source' => $source['source'], 'supported' => false, 'reason' => $source['reason'] ];
		}
		$before  = $this->get_content_snapshot( $post_id );
		$payload = $this->get_mutable_content_payload( $post_id );
		$plan    = $this->build_single_post_reinsert_plan( $post_id );
		$targets = (array) ( $plan['targets'] ?? [] );
		if ( empty( $targets ) ) {
			return [ 'status' => 'failed', 'post_id' => $post_id, 'source' => $source['source'], 'supported' => true, 'reason' => 'No targets found', 'before' => $before ];
		}
		$content = (string) ( $payload['content'] ?? '' );
		// Step A: Remove only inline body links (internal site links only), preserving text.
		$content = preg_replace_callback('#<p\b[^>]*>.*?</p>#is', function($m){
			$block = (string)$m[0];
			$pattern = "#<a\b[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>#is";
			$clean = preg_replace_callback($pattern, function($x){
				$url = (string)($x[1] ?? '');
				$host = wp_parse_url( $url, PHP_URL_HOST );
				$home = wp_parse_url( home_url(), PHP_URL_HOST );
				// Strip internal site links, keep text; leave external links alone
				if ( $host && $home && strtolower($host) === strtolower($home) ) {
					$text = (string)($x[2] ?? '');
					return '' !== trim($text) ? $text : '';
				}
				return $x[0];
			}, $block);
			// Clean up trailing spaces/punctuation left after link removal
			$clean = (string)preg_replace('#\s*\(\s*\)\s*#', '', $clean ?? $block);
			// Trim excess whitespace inside paragraph but preserve structure
			$clean = (string)preg_replace('#\s{2,}#', ' ', $clean);
			return is_string($clean) ? $clean : $block;
		}, $content);
		// Step B: Strip legacy template cruft ("See X for more detail.", "(X)", "Also read: X.")
		// left over from earlier plugin versions — these accumulate across runs.
		$content = $this->cleanup_legacy_link_templates( $content );

		$ins = $this->insert_links_into_supported_content( $content, $targets, (string) $source['source'], (int) ( $plan['target_goal'] ?? 0 ) );
		$new_content = (string) $ins['content'];
		$inserted_urls = (array) $ins['inserted_urls'];

		// If cleanup changed the content but no new links inserted, we still persist the cleanup
		// so junk is removed from the post even when no natural anchors were available.
		$original_content = (string) ( $payload['content'] ?? '' );
		if ( empty( $inserted_urls ) || $new_content === $content ) {
			if ( $content !== $original_content ) {
				$cleanup_result = $this->persist_mutable_content( $post_id, $content, $payload );
				if ( ! is_wp_error( $cleanup_result ) ) {
					$after_cleanup = $this->get_content_snapshot( $post_id );
					return [
						'status'     => 'partial',
						'post_id'    => $post_id,
						'source'     => $source['source'],
						'supported'  => true,
						'db_changed' => true,
						'db_links_found'     => 0,
						'render_links_found' => 0,
						'write_method'       => 'cleanup_only',
						'links_inserted'     => 0,
						'links_removed'      => max( 0, count( (array) $before['internal_links_body_only'] ) - count( (array) $after_cleanup['internal_links_body_only'] ) ),
						'reason'     => 'Legacy template cruft cleaned; no natural anchors found for new links',
						'before'     => $before,
						'after'      => $after_cleanup,
					];
				}
			}
			return [ 'status' => 'failed', 'post_id' => $post_id, 'source' => $source['source'], 'supported' => true, 'reason' => 'No visible body links inserted', 'before' => $before ];
		}
		$result = $this->persist_mutable_content( $post_id, $new_content, $payload );
		if ( is_wp_error( $result ) ) {
			return [ 'status' => 'failed', 'post_id' => $post_id, 'source' => $source['source'], 'supported' => true, 'reason' => $result->get_error_message(), 'before' => $before ];
		}
		$after = $this->get_content_snapshot( $post_id );
		$frontend = $this->fetch_frontend_snapshot( $post_id );
		$db_found = 0;
		foreach ( $inserted_urls as $u ) {
			if ( false !== stripos( (string) $after['post_content'], esc_url_raw( $u ) ) ) $db_found++;
		}
		$render_found = 0;
		foreach ( $inserted_urls as $u ) {
			if ( false !== stripos( (string) ( $frontend['html'] ?? '' ), esc_url_raw( $u ) ) ) $render_found++;
		}
		$status = ( $db_found > 0 && $render_found > 0 ) ? 'success' : ( $db_found > 0 ? 'partial' : 'failed' );
		$result = [
			'status' => $status,
			'post_id' => $post_id,
			'source' => $source['source'],
			'supported' => true,
			'db_changed' => ( $before['content_hash'] !== $after['content_hash'] ),
			'db_links_found' => $db_found,
			'render_links_found' => $render_found,
			'write_method' => (string) $ins['write_method'],
			'links_inserted' => $db_found,
			'links_removed' => max( 0, count( (array) $before['internal_links_body_only'] ) - count( (array) $after['internal_links_body_only'] ) ),
			'reason' => $status === 'success' ? '' : 'Inserted links not fully visible in frontend render',
			'before' => $before,
			'after' => $after,
			'frontend' => $frontend,
		];
		$this->store_diagnostic_log( $post_id, $result );
		return $result;
	}

	public function fetch_frontend_snapshot( int $post_id ): array {
		$url = get_permalink( $post_id );
		if ( ! $url ) {
			return [ 'url' => '', 'status_code' => 0, 'html' => '', 'error' => 'Could not get post permalink', 'internal_links_found' => [], 'body_links_found' => [] ];
		}
		// Add bypass cache parameter to ensure fresh content
		$fetch_url = add_query_arg( '_cgm_diag', time(), $url );
		$response = wp_remote_get( $fetch_url, [
			'timeout' => 10,
			'redirection' => 2,
			'user-agent' => 'ContentGem-Diagnostic/1.0 (+http://contentgem.ai)',
		] );
		if ( is_wp_error( $response ) ) {
			return [
				'url' => $url,
				'status_code' => 0,
				'html' => '',
				'error' => 'Fetch error: ' . $response->get_error_message(),
				'internal_links_found' => [],
				'body_links_found' => []
			];
		}
		$http_code = (int) wp_remote_retrieve_response_code( $response );
		if ( $http_code < 200 || $http_code >= 400 ) {
			return [
				'url' => $url,
				'status_code' => $http_code,
				'html' => '',
				'error' => 'HTTP ' . $http_code,
				'internal_links_found' => [],
				'body_links_found' => []
			];
		}
		$html = (string) wp_remote_retrieve_body( $response );
		if ( empty( $html ) ) {
			return [
				'url' => $url,
				'status_code' => $http_code,
				'html' => '',
				'error' => 'Empty response body',
				'internal_links_found' => [],
				'body_links_found' => []
			];
		}
		return [
			'url' => $url,
			'status_code' => $http_code,
			'html' => $html,
			'internal_links_found' => $this->extract_internal_links_all( $html ),
			'body_links_found' => $this->extract_internal_links_body_only( $html ),
		];
	}

	public function extract_internal_links_all( string $html ): array {
		preg_match_all('#href=["\']([^"\'#]+)["\']#i', $html, $m);
		$urls = array_values( array_unique( array_filter( array_map( 'esc_url_raw', (array) ($m[1] ?? []) ) ) ) );
		return $urls;
	}

	public function extract_internal_links_body_only( string $html ): array {
		if ( '' === $html || ! class_exists( 'DOMDocument' ) ) return [];
		libxml_use_internal_errors( true );
		$dom = new DOMDocument();
		$dom->loadHTML('<?xml encoding="utf-8" ?>' . '<div id="cgm-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
		$xpath = new DOMXPath( $dom );
		$query = "//p[not(ancestor::aside) and not(ancestor::footer) and not(contains(@class,'cgm-related-links')) and not(contains(@class,'cgm-inline-link-sentence'))]//a[@href] | //li[not(ancestor::aside) and not(ancestor::footer)]//a[@href]";
		$nodes = $xpath->query( $query );
		$urls = [];
		if ( $nodes ) {
			foreach ( $nodes as $n ) {
				$href = esc_url_raw( (string) $n->getAttribute('href') );
				if ( $href ) $urls[] = $href;
			}
		}
		libxml_clear_errors();
		return array_values( array_unique( $urls ) );
	}

	public function store_diagnostic_log( int $post_id, array $result ): void {
		update_post_meta( $post_id, '_cgm_reinsert_diag_last', $result );
		$existing = get_option( 'cgm_reinsert_last_diagnostics', [] );
		if ( ! is_array( $existing ) ) $existing = [];
		$existing[ $post_id ] = [ 'time' => time(), 'result' => $result ];
		update_option( 'cgm_reinsert_last_diagnostics', $existing, false );
	}
}
