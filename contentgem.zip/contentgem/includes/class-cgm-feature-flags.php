<?php
/**
 * Feature flags and settings accessors for Contentgem AI behavior.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Feature_Flags {
	public function show_source_list(): bool {
		return (bool) get_option( 'cgm_show_source_list', false );
	}

	public function token_optimization_enabled(): bool {
		return (bool) get_option( 'cgm_enable_token_optimization', true );
	}

	public function full_source_grounding_enabled(): bool {
		return (bool) get_option( 'cgm_enable_full_source_grounding', false );
	}


	public function fact_check_enabled(): bool {
		return (bool) get_option( 'cgm_enable_fact_check', false );
	}

	public function batch_enabled(): bool {
		return (bool) get_option( 'cgm_openai_enable_batch', false );
	}

	public function flex_enabled(): bool {
		return (bool) get_option( 'cgm_openai_enable_flex', false );
	}

	public function show_token_stats(): bool {
		return (bool) get_option( 'cgm_openai_show_token_stats', false );
	}

	public function default_model(): string {
		$model = sanitize_text_field( (string) get_option( 'cgm_openai_default_model', 'gpt-5.4-mini' ) );
		return '' !== $model ? $model : 'gpt-5.4-mini';
	}

	public function reasoning_profile(): string {
		$profile = sanitize_key( (string) get_option( 'cgm_openai_reasoning_profile', 'balanced' ) );
		return in_array( $profile, [ 'minimal', 'balanced', 'deep' ], true ) ? $profile : 'balanced';
	}

	public function should_ground_task( string $task_name ): bool {
		if ( ! $this->full_source_grounding_enabled() ) {
			return false;
		}
		$allowed = [
			'technical_build_plan',
			'ai_assistant_research',
			'site_structure_recommendation',
			'cannibalization_semantic_check',
			'bug_triage',
			'patch_plan',
		];
		return in_array( $task_name, $allowed, true );
	}
}
