<?php
/**
 * Job orchestration for Contentgem.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Job_Service {
	private CGM_Job_Repository $repository;

	public function __construct( ?CGM_Job_Repository $repository = null ) {
		$this->repository = $repository ?: new CGM_Job_Repository();
	}

	public function start_job( string $type, array $payload = [], array $args = [] ): array {
		$site_id = isset( $args['site_id'] ) ? (int) $args['site_id'] : (int) ( $payload['site_id'] ?? 0 );
		$idempotency_key = (string) ( $args['idempotency_key'] ?? $this->generate_idempotency_key( $type, $payload, $site_id ) );
		$active = $this->repository->find_active_by_type( $type, $site_id, $idempotency_key );
		if ( $active ) {
			$active['existing'] = true;
			return $active;
		}
		$job = $this->repository->create( [
			'job_key' => 'cgm_' . sanitize_key( $type ) . '_' . wp_generate_uuid4(),
			'site_id' => $site_id,
			'type' => $type,
			'status' => 'queued',
			'progress_current' => 1,
			'progress_total' => 100,
			'step' => 'queued',
			'message' => (string) ( $args['message'] ?? 'Queued...' ),
			'payload' => $payload,
			'result' => [],
			'error' => [],
			'attempts' => 0,
			'max_attempts' => max( 1, (int) ( $args['max_attempts'] ?? 1 ) ),
			'idempotency_key' => $idempotency_key,
			'job_token' => wp_generate_password( 32, false ),
		] );
		$job['existing'] = false;
		return $job;
	}

	public function get_job_by_key( string $job_key ): ?array {
		return $this->repository->get_by_key( $job_key );
	}

	public function get_job( int $id ): ?array {
		return $this->repository->get( $id );
	}

	public function advance( string $job_key, string $status, int $progress_current, string $message, string $step = '', array $result = null, array $error = null ): ?array {
		$job = $this->get_job_by_key( $job_key );
		if ( ! $job ) {
			return null;
		}
		$changes = [
			'status' => $status,
			'progress_current' => $progress_current,
			'step' => $step !== '' ? $step : $job['step'],
			'message' => $message,
		];
		if ( null !== $result ) {
			$changes['result_json'] = $result;
		}
		if ( null !== $error ) {
			$changes['error_json'] = $error;
		}
		$updated = $this->repository->update( (int) $job['id'], $changes );
		if ( $updated ) {
			$this->repository->add_event( (int) $updated['id'], 'info', $message, [ 'step' => $updated['step'], 'status' => $updated['status'] ] );
		}
		return $updated;
	}

	public function fail( string $job_key, string $message, array $error = [] ): ?array {
		$job = $this->get_job_by_key( $job_key );
		if ( ! $job ) {
			return null;
		}
		$error['message'] = $message;
		$this->repository->add_event( (int) $job['id'], 'error', $message, $error );
		return $this->repository->update( (int) $job['id'], [
			'status' => 'failed',
			'progress_current' => min( 99, (int) $job['progress_current'] ),
			'step' => 'failed',
			'message' => $message,
			'error_json' => $error,
			'locked_at' => null,
			'locked_by' => '',
		] );
	}

	public function complete( string $job_key, string $message, array $result = [] ): ?array {
		$job = $this->get_job_by_key( $job_key );
		if ( ! $job ) {
			return null;
		}
		$this->repository->add_event( (int) $job['id'], 'info', $message, $result );
		return $this->repository->update( (int) $job['id'], [
			'status' => 'completed',
			'progress_current' => 100,
			'step' => 'completed',
			'message' => $message,
			'result_json' => $result,
			'locked_at' => null,
			'locked_by' => '',
		] );
	}

	public function retry_job( string $job_key ): ?array {
		$job = $this->get_job_by_key( $job_key );
		if ( ! $job || 'failed' !== $job['status'] ) {
			return null;
		}
		$attempts = (int) $job['attempts'] + 1;
		$updated = $this->repository->update( (int) $job['id'], [
			'status' => 'queued',
			'progress_current' => 1,
			'step' => 'queued',
			'message' => 'Retry queued...',
			'attempts' => $attempts,
			'error_json' => [],
		] );
		if ( $updated ) {
			$this->schedule_processing();
		}
		return $updated;
	}

	public function schedule_processing(): void {
		if ( ! wp_next_scheduled( 'cgm_process_jobs' ) ) {
			wp_schedule_single_event( time(), 'cgm_process_jobs' );
		}
		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	public function generate_idempotency_key( string $type, array $payload, int $site_id = 0 ): string {
		return md5( wp_json_encode( [ 'type' => sanitize_key( $type ), 'site_id' => $site_id, 'payload' => $payload ] ) );
	}

	public static function to_legacy_status( string $status ): string {
		$map = [
			'processing' => 'running',
			'finalizing' => 'running',
			'completed' => 'done',
			'failed' => 'error',
		];
		return $map[ $status ] ?? $status;
	}

	public function normalize_for_response( array $job ): array {
		return [
			'id' => (int) $job['id'],
			'job_id' => (string) $job['job_key'],
			'type' => (string) $job['type'],
			'status' => (string) $job['status'],
			'legacy_status' => self::to_legacy_status( (string) $job['status'] ),
			'progress' => [
				'current' => (int) $job['progress_current'],
				'total' => (int) $job['progress_total'],
				'percentage' => (int) $job['progress_percentage'],
			],
			'step' => (string) $job['step'],
			'message' => (string) $job['message'],
			'result' => $job['result'] ?? [],
			'error' => $job['error'] ?? [],
			'updated_at' => (string) $job['updated_at'],
		];
	}
}
