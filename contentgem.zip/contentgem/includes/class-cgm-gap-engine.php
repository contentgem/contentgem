<?php
/**
 * Context-driven gap engine for plugin-backed analysis.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Gap_Engine {
	private const MIN_GAPS_PER_CLUSTER = 5;
	private const MIN_GAPS_WITH_PILLAR = 7;
	private const MAX_SCORED_GAPS_PER_CLUSTER = 10;
	private CGM_Language_Service $language_service;
	private CGM_Title_Quality_Service $title_quality_service;

	public function __construct( ?CGM_Language_Service $language_service = null, ?CGM_Title_Quality_Service $title_quality_service = null ) {
		$this->language_service = $language_service ?: new CGM_Language_Service();
		$this->title_quality_service = $title_quality_service ?: new CGM_Title_Quality_Service( $this->language_service );
	}

	public function build_gap_context( array $context ): array {
		$clusters = $this->sanitize_string_list( $context['clusters'] ?? [] );
		$competitors = $this->sanitize_string_list( $context['competitors'] ?? [] );
		$gsc_queries = $this->sanitize_string_list( $context['gsc_queries'] ?? [] );
		$language = $this->normalize_language_code( (string) ( $context['language_code'] ?? $context['language'] ?? 'en' ) );
		$cluster_keywords = [];
		foreach ( (array) ( $context['cluster_keywords'] ?? [] ) as $cluster => $keywords ) {
			$cluster = sanitize_text_field( (string) $cluster );
			$cluster_keywords[ $cluster ] = $this->sanitize_string_list( is_array( $keywords ) ? $keywords : [] );
		}
		$semantic_keywords = $this->sanitize_string_list( $context['semantic_keywords'] ?? [] );
		$pillar_pages = is_array( $context['pillar_pages'] ?? null ) ? $context['pillar_pages'] : [];
		$pillar_cluster_keys = [];
		foreach ( $pillar_pages as $cluster_name => $raw_value ) {
			$key = $this->normalize_cluster_key( (string) $cluster_name );
			if ( '' !== $key ) {
				$pillar_cluster_keys[ $key ] = true;
			}
		}

		return [
			'language' => $language,
			'niche' => sanitize_text_field( (string) ( $context['niche'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $context['description'] ?? '' ) ),
			'clusters' => $clusters,
			'cluster_keywords' => $cluster_keywords,
			'semantic_keywords' => $semantic_keywords,
			'pillar_pages' => $pillar_pages,
			'pillar_cluster_keys' => $pillar_cluster_keys,
			'competitors' => $competitors,
			'gsc_queries' => $gsc_queries,
			'existing_titles' => $this->sanitize_string_list( $context['existing_titles'] ?? [] ),
			'strict_keyword_match' => ! empty( $context['strict_keyword_match'] ),
		];
	}

	public function extract_seed_queries( array $context, string $cluster ): array {
		$cluster = sanitize_text_field( $cluster );
		$cluster_words = $this->token_set( $cluster );
		$cluster_keywords = $this->sanitize_string_list( $context['cluster_keywords'][ $cluster ] ?? [] );
		$queries = [];

		foreach ( (array) $context['gsc_queries'] as $query ) {
			if ( $this->shares_tokens( $query, $cluster_words ) ) {
				$queries[] = $this->normalize_seed_query( $query );
			}
		}
		foreach ( $cluster_keywords as $keyword ) {
			$queries[] = $this->normalize_seed_query( $keyword );
		}
		foreach ( (array) ( $context['semantic_keywords'] ?? [] ) as $keyword ) {
			if ( $this->shares_tokens( $keyword, $cluster_words ) ) {
				$queries[] = $this->normalize_seed_query( $keyword );
			}
		}

		$queries[] = $this->normalize_seed_query( $cluster );
		$queries = array_values( array_unique( array_filter( $queries ) ) );
		$filtered = [];

		foreach ( $queries as $query ) {
			if ( preg_match( '/\b\d{3,}\b/u', $query ) ) {
				continue;
			}
			if ( str_word_count( preg_replace( '/[^\p{L}\p{N}\s]+/u', ' ', $query ) ) < 2 ) {
				continue;
			}
			$filtered[] = $query;
		}

		return array_slice( array_values( array_unique( $filtered ) ), 0, 8 );
	}

	public function expand_seed_queries_by_intent( array $seeds, array $context ): array {
		$language = $context['language'] ?? 'en';
		$expanded = [];

		foreach ( $seeds as $seed ) {
			$topic = $this->humanize_phrase( $seed );
			$meta = $this->classify_keyword( $topic, $language );
			$primary_intent = $this->infer_effective_intent( $topic, 'informational', $language, $meta );
			$expanded[] = [
				'query' => $topic,
				'intent' => $primary_intent,
				'priority' => $this->base_priority_for_intent( $primary_intent ),
			];

			foreach ( $this->secondary_intents_for_meta( $meta, $primary_intent ) as $secondary_intent ) {
				$expanded[] = [
					'query' => $topic,
					'intent' => $secondary_intent,
					'priority' => $this->base_priority_for_intent( $secondary_intent ) - 3,
				];
			}
		}

		$seen = [];
		$out = [];
		foreach ( $expanded as $row ) {
			$key = strtolower( (string) $row['query'] . '|' . (string) $row['intent'] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[] = $row;
		}

		return array_slice( $out, 0, 16 );
	}

	public function generate_title_candidates( array $expanded_queries, array $context, string $cluster ): array {
		$language = $context['language'] ?? 'en';
		$cluster_h = $this->humanize_phrase( $cluster );
		$titles = [];

		foreach ( $expanded_queries as $row ) {
			$query = $this->humanize_phrase( (string) ( $row['query'] ?? '' ) );
			$input_intent = (string) ( $row['intent'] ?? 'informational' );
			$topic = $this->extract_core_topic( $query, $cluster_h, $language );
			$meta = $this->classify_keyword( $topic, $language );
			$intent = $this->infer_effective_intent( $topic, $input_intent, $language, $meta );
			$angles = $this->derive_semantic_angles( $topic, $intent, $meta, $language );
			$seed_bonus = (float) ( $row['priority'] ?? 80 );

			foreach ( $angles as $angle ) {
				foreach ( $this->build_titles_for_angle( $topic, $cluster_h, $intent, $angle, $language, $meta ) as $candidate ) {
					$generated = $this->normalize_title_candidate( $candidate, $topic, $language );
					$generated = $this->enrich_title_with_cluster_context( $generated, $topic, $cluster_h, $language, $angle );
					if ( '' === $generated ) {
						continue;
					}
					if ( ! $this->language_service->validate_output_language( $generated, $language ) ) {
						continue;
					}
					$titles[] = [
						'title' => $generated,
						'intent' => $intent,
						'priority' => $seed_bonus + $this->priority_bonus_for_angle( $angle, $intent, $meta ),
						'primary_keyword' => $this->normalize_seed_query( $topic ),
						'family' => $this->title_family_signature( $generated, $language, $cluster_h ),
					];
				}
			}
		}

		return $titles;
	}

	public function filter_low_quality_titles( array $titles, array $context, string $cluster ): array {
		$language = $context['language'] ?? 'en';
		$existing = array_map( 'strtolower', (array) ( $context['existing_titles'] ?? [] ) );
		$strict = ! empty( $context['strict_keyword_match'] );
		$strict_terms = $strict ? $this->collect_strict_match_terms( $context, $cluster ) : [];
		$out = [];
		$seen = [];
		$seen_openings = [];
		$seen_families = [];

		foreach ( $titles as $row ) {
			$title = sanitize_text_field( (string) ( $row['title'] ?? '' ) );
			if ( '' === $title ) {
				continue;
			}
			if ( in_array( strtolower( $title ), $existing, true ) ) {
				continue;
			}
			if ( ! $this->title_quality_service->is_valid_title( $title, $language, $cluster ) ) {
				continue;
			}
			if ( $strict && ! $this->title_matches_strict_terms( $title, $strict_terms ) ) {
				continue;
			}
			if ( preg_match( '/^\d+\b/u', $title ) ) {
				continue;
			}
			if ( preg_match( '/\b(?:actually add value|really means and when it matters|for beginners: where to start)\b/i', $title ) ) {
				continue;
			}
			$key = strtolower( $title );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$opening = $this->opening_signature( $title, $language );
			if ( isset( $seen_openings[ $opening ] ) && $seen_openings[ $opening ] >= 1 ) {
				continue;
			}
			$family = (string) ( $row['family'] ?? $this->title_family_signature( $title, $language, $cluster ) );
			if ( isset( $seen_families[ $family ] ) && $seen_families[ $family ] >= 1 ) {
				continue;
			}
			if ( $this->is_semantic_duplicate( $title, array_keys( $seen ) ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$seen_openings[ $opening ] = (int) ( $seen_openings[ $opening ] ?? 0 ) + 1;
			$seen_families[ $family ] = (int) ( $seen_families[ $family ] ?? 0 ) + 1;
			$out[] = $row;
		}

		return array_slice( $out, 0, 8 );
	}

	/**
	 * v4.7 — Strict keyword match helpers.
	 *
	 * Collect all the surface forms a title could legitimately match against
	 * for a given cluster: the cluster name itself, every cluster_keyword,
	 * and (if available) semantic_keywords. We keep simple stem variants so
	 * "cannibalization" matches "cannibalize" and "linking" matches "link".
	 */
	private function collect_strict_match_terms( array $context, string $cluster ): array {
		$terms = [];
		$terms[] = $cluster;
		$terms = array_merge( $terms, (array) ( $context['cluster_keywords'][ $cluster ] ?? [] ) );
		// Semantic keywords can apply across clusters — include them as a soft net.
		$terms = array_merge( $terms, (array) ( $context['semantic_keywords'] ?? [] ) );
		$out = [];
		foreach ( $terms as $term ) {
			$term = trim( (string) $term );
			if ( '' === $term ) { continue; }
			$lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $term ) : strtolower( $term );
			$out[] = $lc;
			// Also add each individual word from multi-word terms (>= 4 chars).
			$words = preg_split( '/\s+/u', $lc, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
			foreach ( $words as $w ) {
				if ( strlen( $w ) >= 4 ) { $out[] = $w; }
			}
		}
		return array_values( array_unique( $out ) );
	}

	private function title_matches_strict_terms( string $title, array $terms ): bool {
		if ( empty( $terms ) ) { return true; }
		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title ) : strtolower( $title );
		foreach ( $terms as $term ) {
			if ( '' === $term ) { continue; }
			// Direct substring match handles multi-word phrases.
			if ( false !== strpos( $title_lc, $term ) ) { return true; }
			// Stem-tolerant single-word match: trim common suffixes.
			$stem = preg_replace( '/(ization|ations|ation|izing|izes|ized|ings|ing|ers|er|ed|es|s)$/u', '', $term );
			if ( $stem && $stem !== $term && strlen( $stem ) >= 4 && false !== strpos( $title_lc, $stem ) ) {
				return true;
			}
		}
		return false;
	}

	public function score_gap_candidates( array $candidates, array $context, string $cluster ): array {
		$keywords = $this->sanitize_string_list( $context['cluster_keywords'][ $cluster ] ?? [] );
		$queries = $this->sanitize_string_list( $context['gsc_queries'] ?? [] );
		$competitors = (array) ( $context['competitors'] ?? [] );
		$has_pillar = $this->cluster_has_pillar_page( $context, $cluster );
		$scored = [];

		foreach ( $candidates as $row ) {
			$title = (string) ( $row['title'] ?? '' );
			$score = (float) ( $row['priority'] ?? 75 );
			if ( $this->contains_any( $title, $keywords ) ) { $score += 10; }
			if ( $this->contains_any( $title, $queries ) ) { $score += 12; }
			if ( ! empty( $competitors ) ) { $score += 6; }
			if ( false !== stripos( $title, 'guide' ) || false !== stripos( $title, 'gids' ) ) { $score -= 1; }
			if ( false !== stripos( $title, 'best' ) || false !== stripos( $title, 'beste' ) || false !== stripos( $title, 'vs' ) ) { $score += 1; }
			if ( $has_pillar ) {
				if ( preg_match( '/\b(?:complete guide|gids|beginners|fundamentals|basics|what is|wat is|complete overview|volledige gids)\b/i', $title ) ) { $score -= 10; }
				if ( preg_match( '/\b(?:checklist|workflow|mistakes|fouten|template|examples|voorbeelden|implementation|implementatie|audit|tools|comparison|vergelijking|use cases|praktijk|best practices)\b/i', $title ) ) { $score += 8; }
				$score += 4;
			}
			$row['priority'] = min( 99.0, round( $score, 2 ) );
			$row['reason'] = $this->build_reason( $row, $context, $cluster );
			$scored[] = $row;
		}

		$existing_scored_keys = [];
		foreach ( $scored as $row ) {
			$key = strtolower( (string) ( $row['title'] ?? '' ) );
			if ( '' !== $key ) {
				$existing_scored_keys[ $key ] = true;
			}
		}
		foreach ( $this->build_cluster_explainer_titles( $cluster, $context['language'] ?? 'en', $has_pillar ) as $blueprint ) {
			$title = sanitize_text_field( (string) ( $blueprint['title'] ?? '' ) );
			$key = strtolower( $title );
			if ( '' === $title || isset( $existing_scored_keys[ $key ] ) ) {
				continue;
			}
			$scored[] = [
				'title' => $title,
				'intent' => (string) ( $blueprint['intent'] ?? 'informational' ),
				'priority' => (float) ( $blueprint['priority'] ?? 84.0 ),
				'primary_keyword' => $this->normalize_seed_query( $cluster ),
				'family' => (string) ( $blueprint['family'] ?? $this->title_family_signature( $title, (string) ( $context['language'] ?? 'en' ), $cluster ) ),
				'reason' => $this->build_reason( [ 'title' => $title, 'intent' => (string) ( $blueprint['intent'] ?? 'informational' ) ], $context, $cluster ),
			];
			$existing_scored_keys[ $key ] = true;
		}

		usort( $scored, static function( $a, $b ) { return ( $b['priority'] <=> $a['priority'] ); } );
		$scored = $this->ensure_minimum_cluster_coverage( $scored, $context, $cluster );
		return array_slice( $scored, 0, self::MAX_SCORED_GAPS_PER_CLUSTER );
	}

	private function build_reason( array $row, array $context, string $cluster ): string {
		$language = $context['language'] ?? 'en';
		$has_competitors = ! empty( $context['competitors'] );
		$has_gsc = ! empty( $context['gsc_queries'] );
		$cluster_h = $this->humanize_phrase( $cluster );
		if ( 'nl' === $language ) {
			if ( $has_competitors && $has_gsc ) {
				return 'Gebaseerd op concurrentoverlap, zoekvraagdata en ontbrekende subonderwerpen binnen het cluster ' . $cluster_h . '.';
			}
			if ( $has_competitors ) {
				return 'Gebaseerd op concurrentcontext en ontbrekende invalshoeken binnen het cluster ' . $cluster_h . '.';
			}
			if ( $has_gsc ) {
				return 'Gebaseerd op zoekvraagdata en ontbrekende clusterdekking binnen ' . $cluster_h . '.';
			}
			return 'Gebaseerd op je clusterstructuur, semantische keywords en ontbrekende invalshoeken binnen ' . $cluster_h . '.';
		}
		if ( $has_competitors && $has_gsc ) {
			return 'Based on competitor overlap, query data and missing subtopics inside the ' . $cluster_h . ' cluster.';
		}
		if ( $has_competitors ) {
			return 'Based on competitor context and missing coverage angles inside the ' . $cluster_h . ' cluster.';
		}
		if ( $has_gsc ) {
			return 'Based on search query data and missing coverage inside the ' . $cluster_h . ' cluster.';
		}
		return 'Based on your cluster structure, semantic keywords and missing topic coverage inside the ' . $cluster_h . ' cluster.';
	}

	private function classify_keyword( string $keyword, string $language ): array {
		$keyword_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $keyword ) : strtolower( $keyword );
		$is_beginner = (bool) preg_match( '/\b(?:beginner|beginners|starter|starters|first time|first-time|nieuw|nieuwkomer|nieuwkomers|voor beginners)\b/iu', $keyword_lc );
		$is_product = (bool) preg_match( '/\b(?:shoe|shoes|watch|gear|equipment|vest|sock|socks|app|apps|tool|tools|platform|software|schoen|schoenen|horloge|uitrusting|materiaal|accessoires)\b/iu', $keyword_lc );
		$is_problem = (bool) preg_match( '/\b(?:injury|injuries|pain|mistake|mistakes|problem|problems|recovery|prevent|prevention|error|errors|blessure|blessures|pijn|fout|fouten|herstel|voorkomen)\b/iu', $keyword_lc );
		$is_process = (bool) preg_match( '/\b(?:plan|schedule|training|routine|program|programme|preparation|strategy|workflow|checklist|roadmap|schema|voorbereiding|stappenplan|aanpak|strategie)\b/iu', $keyword_lc );
		$is_comparison = (bool) preg_match( '/\b(?:vs|versus|best|top|compare|comparison|review|reviews|vergelijk|vergelijken|beste|top)\b/iu', $keyword_lc );
		$is_question = (bool) preg_match( '/\b(?:how|what|when|why|which|hoe|wat|wanneer|waarom|welke)\b/iu', $keyword_lc );

		return [
			'is_beginner' => $is_beginner,
			'is_product' => $is_product,
			'is_problem' => $is_problem,
			'is_process' => $is_process,
			'is_comparison' => $is_comparison,
			'is_question' => $is_question,
		];
	}

	private function infer_effective_intent( string $topic, string $intent, string $language, ?array $meta = null ): string {
		$intent = in_array( $intent, [ 'informational', 'commercial', 'navigational' ], true ) ? $intent : 'informational';
		$meta = $meta ?: $this->classify_keyword( $topic, $language );
		if ( $meta['is_comparison'] || $meta['is_product'] ) {
			return 'commercial';
		}
		if ( $meta['is_problem'] || $meta['is_process'] ) {
			return 'informational';
		}
		return $intent;
	}

	private function secondary_intents_for_meta( array $meta, string $primary_intent ): array {
		$out = [];
		if ( 'commercial' === $primary_intent ) {
			$out[] = 'informational';
		}
		if ( $meta['is_process'] && 'informational' === $primary_intent ) {
			$out[] = 'commercial';
		}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	private function base_priority_for_intent( string $intent ): float {
		switch ( $intent ) {
			case 'commercial':
				return 88.0;
			case 'navigational':
				return 82.0;
			default:
				return 84.0;
		}
	}

	private function derive_semantic_angles( string $topic, string $intent, array $meta, string $language ): array {
		$angles = [];

		if ( $meta['is_problem'] ) {
			$angles = array_merge( $angles, [ 'prevention', 'causes', 'mistakes', 'recovery', 'signals' ] );
		}
		if ( $meta['is_product'] ) {
			$angles = array_merge( $angles, [ 'selection', 'features', 'comparison', 'alternatives' ] );
		}
		if ( $meta['is_process'] ) {
			$angles = array_merge( $angles, [ 'starting', 'planning', 'improvement', 'checklist', 'framework' ] );
		}
		if ( $meta['is_beginner'] ) {
			$angles[] = 'beginner_basics';
		}
		if ( 'commercial' === $intent ) {
			$angles = array_merge( $angles, [ 'comparison', 'selection', 'alternatives' ] );
		} else {
			$angles = array_merge( $angles, [ 'basics', 'guide', 'questions', 'examples', 'timing' ] );
		}
		if ( empty( $angles ) ) {
			$angles = [ 'basics', 'guide', 'questions', 'examples' ];
		}

		$angles = array_values( array_unique( $angles ) );
		$priority = [
			'prevention' => 1,
			'selection' => 2,
			'comparison' => 3,
			'planning' => 4,
			'causes' => 5,
			'guide' => 6,
			'basics' => 7,
			'questions' => 8,
			'recovery' => 9,
			'mistakes' => 10,
			'starting' => 11,
			'improvement' => 12,
			'features' => 13,
			'beginner_basics' => 14,
		];
		usort( $angles, static function ( $a, $b ) use ( $priority ) {
			return ( $priority[ $a ] ?? 99 ) <=> ( $priority[ $b ] ?? 99 );
		} );

		return array_slice( $angles, 0, 7 );
	}

	private function build_titles_for_angle( string $topic, string $cluster, string $intent, string $angle, string $language, array $meta ): array {
		$topic = $this->clean_topic_for_title( $topic, $language );
		$topic_h = $this->humanize_phrase( $topic );

		if ( 'nl' === $language ) {
			switch ( $angle ) {
				case 'prevention':
					return [
						'Hoe voorkom je problemen rond ' . $topic_h . '?',
						'Praktische manieren om fouten rond ' . $topic_h . ' te voorkomen',
						'Wat helpt echt om risico\'s rond ' . $topic_h . ' te beperken?',
					];
				case 'causes':
					return [
						'Wat veroorzaakt knelpunten rond ' . $topic_h . '?',
						'De belangrijkste oorzaken achter zwakke ' . $topic_h . ' uitgelegd',
						'Waarom ' . $topic_h . ' vaak minder sterk is dan gedacht',
					];
				case 'recovery':
					return [
						'Hoe herstel en verbeter je ' . $topic_h . ' na een zwakke uitvoering?',
						'Welke acties helpen om ' . $topic_h . ' sneller te herstellen?',
						'Wat werkt in de praktijk om ' . $topic_h . ' weer op niveau te krijgen?',
					];
				case 'mistakes':
					return [
						'Veelgemaakte fouten bij ' . $topic_h . ' en hoe je ze voorkomt',
						'Wat veel teams verkeerd doen bij ' . $topic_h,
						'Waar gaat ' . $topic_h . ' in de praktijk vaak mis?',
					];
				case 'selection':
					return [
						'Hoe kies je de juiste aanpak voor ' . $topic_h . '?',
						'Waar let je echt op bij keuzes rond ' . $topic_h . '?',
						'Welke optie past het best bij jouw ' . $topic_h . '?',
					];
				case 'features':
					return [
						'Welke onderdelen van ' . $topic_h . ' maken het grootste verschil?',
						'Welke kenmerken van ' . $topic_h . ' moet je eerst beoordelen?',
						'Wat telt echt mee als je ' . $topic_h . ' verbetert?',
					];
				case 'comparison':
					return [
						'Hoe vergelijk je opties binnen ' . $topic_h . ' zonder verkeerde keuze?',
						'Welke aanpakken voor ' . $topic_h . ' leveren het meeste op?',
						$topic_h . ' vergelijken: waar let je als eerste op?',
					];
				case 'planning':
					return [
						'Hoe bouw je een sterk plan rond ' . $topic_h . '?',
						'Welke stappen horen in een goed plan voor ' . $topic_h . '?',
						'Een praktische structuur om ' . $topic_h . ' beter te organiseren',
					];
				case 'starting':
					return [
						'Waar begin je als je ' . $topic_h . ' wilt verbeteren?',
						'De eerste stappen voor sterkere ' . $topic_h,
						'Hoe start je slim met ' . $topic_h . '?',
					];
				case 'improvement':
					return [
						'Hoe verbeter je je aanpak van ' . $topic_h . '?',
						'Wat maakt ' . $topic_h . ' direct effectiever?',
						'Hoe haal je structureel meer resultaat uit ' . $topic_h . '?',
					];
				case 'beginner_basics':
					return [
						'De basis van ' . $topic_h . ' helder uitgelegd',
						'Wat moet je eerst begrijpen over ' . $topic_h . '?',
						'Een toegankelijke introductie tot ' . $topic_h,
					];
				case 'framework':
					return [
						'Een helder framework voor ' . $topic_h,
						'Hoe zet je ' . $topic_h . ' om in een vaste werkwijze?',
						'Welke structuur maakt ' . $topic_h . ' schaalbaar?',
					];
				case 'checklist':
					return [
						'Een praktische checklist voor sterkere ' . $topic_h,
						'Wat moet je afvinken om ' . $topic_h . ' op orde te krijgen?',
						'De checklist die ' . $topic_h . ' consistenter maakt',
					];
				case 'examples':
					return [
						'Praktische voorbeelden van ' . $topic_h,
						'Hoe ziet sterke ' . $topic_h . ' eruit in de praktijk?',
						'Concrete voorbeelden die ' . $topic_h . ' tastbaar maken',
					];
				case 'signals':
					return [
						'Welke signalen tonen aan dat ' . $topic_h . ' aandacht nodig heeft?',
						'Zo herken je zwakke plekken in ' . $topic_h . ' vroegtijdig',
						'Vroege signalen dat ' . $topic_h . ' je resultaten afremt',
					];
				case 'timing':
					return [
						'Wanneer heeft ' . $topic_h . ' de meeste impact?',
						'Op welk moment moet je prioriteit geven aan ' . $topic_h . '?',
						'Wanneer is het slim om eerst aan ' . $topic_h . ' te werken?',
					];
				case 'alternatives':
					return [
						'Welke alternatieven zijn er voor ' . $topic_h . '?',
						'Wanneer is een andere aanpak dan ' . $topic_h . ' slimmer?',
						'Welke alternatieven binnen ' . $topic_h . ' zijn het overwegen waard?',
					];
				case 'questions':
					return [
						'Vragen die zwakke plekken in ' . $topic_h . ' zichtbaar maken',
						'Welke vragen helpen je ' . $topic_h . ' sneller te verbeteren?',
						'Wat moet je eerst helder hebben voordat je ' . $topic_h . ' opschaalt?',
					];
				case 'guide':
					return [
						'Hoe maak je van ' . $topic_h . ' een herhaalbare werkwijze?',
						'Praktische manieren om ' . $topic_h . ' te versterken',
						'Hoe ' . $topic_h . ' betere contentprestaties ondersteunt',
					];
				case 'basics':
				default:
					return [
						'Wat ' . $topic_h . ' in de praktijk echt betekent',
						'De fundamenten voor sterkere ' . $topic_h,
						'Waarom ' . $topic_h . ' belangrijker is dan veel mensen denken',
					];
			}
		}

		switch ( $angle ) {
			case 'prevention':
				return [
					'How Do You Prevent Problems Around ' . $topic_h . '?',
					'Practical Ways to Reduce Risk Around ' . $topic_h,
					'What Actually Helps You Avoid Weak ' . $topic_h . '?',
				];
			case 'causes':
				return [
					'What Causes Weak Performance in ' . $topic_h . '?',
					'The Main Reasons ' . $topic_h . ' Breaks Down',
					'Why ' . $topic_h . ' Underperforms More Often Than Expected',
				];
			case 'recovery':
				return [
					'How Do You Recover and Improve ' . $topic_h . ' After Weak Execution?',
					'What Actions Help Restore Stronger ' . $topic_h . '?',
					'What Works in Practice to Improve ' . $topic_h . ' Quickly?',
				];
			case 'mistakes':
				return [
					'Common Mistakes Around ' . $topic_h . ' and How to Avoid Them',
					'What Most Teams Get Wrong About ' . $topic_h,
					'Where ' . $topic_h . ' Usually Breaks Down in Practice',
				];
			case 'selection':
				return [
					'How Do You Choose the Right Approach for ' . $topic_h . '?',
					'What Should You Evaluate First in ' . $topic_h . '?',
					'Which Option Fits Your ' . $topic_h . ' Goals Best?',
				];
			case 'features':
				return [
					'Which Elements of ' . $topic_h . ' Matter Most?',
					'Which ' . $topic_h . ' Features Should You Assess First?',
					'What Actually Makes ' . $topic_h . ' Stronger?',
				];
			case 'comparison':
				return [
					'How to Compare Options in ' . $topic_h . ' Without Choosing Poorly',
					'Which ' . $topic_h . ' Approaches Deliver the Strongest Results?',
					$topic_h . ' Compared: What Should You Look at First?',
				];
			case 'planning':
				return [
					'How to Build a Strong Plan for ' . $topic_h,
					'Which Steps Belong in a Good ' . $topic_h . ' Plan?',
					'A Practical Structure for Improving ' . $topic_h,
				];
			case 'starting':
				return [
					'Where Should You Start with ' . $topic_h . '?',
					'The First Steps to Improve ' . $topic_h,
					'How to Start Improving ' . $topic_h . ' the Smart Way',
				];
			case 'improvement':
				return [
					'How to Improve Your Approach to ' . $topic_h,
					'What Makes ' . $topic_h . ' More Effective Right Away?',
					'How to Get Better Results from ' . $topic_h . ' Consistently',
				];
			case 'beginner_basics':
				return [
					'The Basics of ' . $topic_h . ', Explained Clearly',
					'What Should You Understand First About ' . $topic_h . '?',
					'A Beginner-Friendly Introduction to ' . $topic_h,
				];
			case 'framework':
				return [
					'A Clear Framework for ' . $topic_h,
					'How to Turn ' . $topic_h . ' Into a Repeatable Process',
					'Which Structure Makes ' . $topic_h . ' Easier to Scale?',
				];
			case 'checklist':
				return [
					'A Practical Checklist for Stronger ' . $topic_h,
					'What Should You Check First to Improve ' . $topic_h . '?',
					'The Checklist That Makes ' . $topic_h . ' More Consistent',
				];
			case 'examples':
				return [
					'Practical Examples of ' . $topic_h,
					'What Does Strong ' . $topic_h . ' Look Like in Practice?',
					'Real Examples That Make ' . $topic_h . ' Easier to Apply',
				];
			case 'signals':
				return [
					'Which Signs Show That ' . $topic_h . ' Needs Attention?',
					'How to Spot Weak ' . $topic_h . ' Early',
					'Early Signals That ' . $topic_h . ' Is Holding Back Results',
				];
			case 'timing':
				return [
					'When Does ' . $topic_h . ' Matter Most?',
					'At What Stage Should You Prioritize ' . $topic_h . '?',
					'When Should ' . $topic_h . ' Come First in Your Plan?',
				];
			case 'alternatives':
				return [
					'What Are the Best Alternatives to ' . $topic_h . '?',
					'When Does an Alternative to ' . $topic_h . ' Make More Sense?',
					'Which Alternatives Inside ' . $topic_h . ' Are Worth Considering?',
				];
			case 'questions':
				return [
					'Questions That Reveal Weak Spots in ' . $topic_h,
					'Which Questions Help You Improve ' . $topic_h . ' Faster?',
					'What Should You Clarify Before You Scale ' . $topic_h . '?',
				];
			case 'guide':
				return [
					'How to Turn ' . $topic_h . ' into a Repeatable Workflow',
					'Practical Ways to Strengthen ' . $topic_h,
					'How ' . $topic_h . ' Supports Better Content Performance',
				];
			case 'basics':
			default:
				return [
					'What ' . $topic_h . ' Really Means in Practice',
					'The Fundamentals You Need for Stronger ' . $topic_h,
					'Why ' . $topic_h . ' Matters More Than It Seems',
				];
		}
	}

	private function priority_bonus_for_angle( string $angle, string $intent, array $meta ): float {
		$bonus = [
			'prevention' => 7.0,
			'selection' => 7.0,
			'comparison' => 6.0,
			'planning' => 5.0,
			'framework' => 5.0,
			'guide' => 1.5,
			'basics' => 3.0,
			'questions' => 2.0,
			'examples' => 3.0,
			'features' => 4.0,
			'checklist' => 4.0,
			'signals' => 3.0,
			'timing' => 2.0,
			'alternatives' => 4.0,
			'beginner_basics' => 4.0,
		];
		return $bonus[ $angle ] ?? 1.0;
	}

	private function normalize_title_candidate( string $title, string $topic, string $language ): string {
		$title = $this->title_quality_service->normalize_title( $title, $language );
		$title = preg_replace( '/\bfor Beginners: Where to Start\b/i', 'for Beginners', $title );
		$title = preg_replace( '/\b(?:Actually Add Value|Really Means and When It Matters)\b/i', '', $title );
		$title = preg_replace( '/\b(beginner|beginners)\b.*\bfor Beginners\b/i', 'for Beginners', $title );
		$title = preg_replace( '/\b('. preg_quote( $this->humanize_phrase( $topic ), '/' ) .')\s+\1\b/ui', '$1', $title );
		$title = preg_replace( '/\s+/', ' ', trim( (string) $title ) );
		return sanitize_text_field( (string) $title );
	}

	private function title_mentions_cluster( string $title, string $cluster ): bool {
		$title_tokens = $this->token_set( $title );
		$cluster_tokens = $this->token_set( $cluster );
		if ( empty( $title_tokens ) || empty( $cluster_tokens ) ) {
			return false;
		}
		$matches = count( array_intersect_key( $title_tokens, $cluster_tokens ) );
		$threshold = max( 1, min( 2, count( $cluster_tokens ) ) );
		return $matches >= $threshold;
	}

	private function enrich_title_with_cluster_context( string $title, string $topic, string $cluster, string $language, string $angle = '' ): string {
		$title = sanitize_text_field( trim( $title ) );
		$cluster_h = $this->humanize_phrase( $cluster );
		$topic_h = $this->humanize_phrase( $topic );
		if ( '' === $title || '' === $cluster_h ) {
			return $title;
		}
		if ( $this->title_mentions_cluster( $title, $cluster_h ) ) {
			return $title;
		}
		if ( strtolower( $topic_h ) !== strtolower( $cluster_h ) && '' !== $topic_h && false !== stripos( $title, $topic_h ) ) {
			$replacement = 'nl' === $language
				? $topic_h . ' binnen ' . $cluster_h
				: $topic_h . ' within ' . $cluster_h;
			$title = preg_replace( '/' . preg_quote( $topic_h, '/' ) . '/iu', $replacement, $title, 1 );
		}
		if ( $this->title_mentions_cluster( $title, $cluster_h ) ) {
			return sanitize_text_field( trim( preg_replace( '/\s+/', ' ', (string) $title ) ) );
		}
		if ( 'nl' === $language ) {
			$suffixes = [
				'questions' => ' binnen ' . $cluster_h,
				'guide' => ' voor sterkere ' . $cluster_h,
				'basics' => ' binnen ' . $cluster_h,
				'comparison' => ' voor ' . $cluster_h,
				'examples' => ' in een ' . $cluster_h . '-strategie',
				'checklist' => ' voor ' . $cluster_h,
				'default' => ' voor ' . $cluster_h,
			];
		} else {
			$suffixes = [
				'questions' => ' within ' . $cluster_h,
				'guide' => ' for stronger ' . $cluster_h,
				'basics' => ' within ' . $cluster_h,
				'comparison' => ' for ' . $cluster_h,
				'examples' => ' in a ' . $cluster_h . ' strategy',
				'checklist' => ' for ' . $cluster_h,
				'default' => ' for ' . $cluster_h,
			];
		}
		$suffix = $suffixes[ $angle ] ?? $suffixes['default'];
		$title .= $suffix;
		$title = preg_replace( '/\s+/', ' ', trim( (string) $title ) );
		return sanitize_text_field( (string) $title );
	}

	private function clean_topic_for_title( string $topic, string $language ): string {
		$topic = wp_strip_all_tags( $topic );
		$topic = preg_replace( '/\b(?:how to|what is|what are|guide|explained|mistakes|comparison|best|where to start|for beginners|hoe|wat is|gids|uitleg|fouten|vergelijk|beste|waar begin je|voor beginners)\b/iu', ' ', $topic );
		$topic = preg_replace( '/\s+/', ' ', trim( (string) $topic ) );
		return '' !== $topic ? $topic : 'topic';
	}

	private function extract_core_topic( string $query, string $cluster, string $language ): string {
		$topic = $this->clean_topic_for_title( $query, $language );
		return '' !== $topic ? $topic : $cluster;
	}

	private function opening_signature( string $title, string $language ): string {
		$words = preg_split( '/\s+/u', strtolower( trim( $title ) ) ) ?: [];
		return implode( ' ', array_slice( $words, 0, 3 ) );
	}


	private function is_generic_opening( string $opening, string $language ): bool {
		$generic = 'nl' === $language
			? [ 'wat is', 'hoe voorkom', 'hoe kies', 'de basis', 'een praktische', 'een complete', 'de belangrijkste' ]
			: [ 'what is', 'how to', 'how do', 'a practical', 'a complete', 'the core', 'the most' ];
		return in_array( trim( strtolower( $opening ) ), $generic, true );
	}

	private function title_family_signature( string $title, string $language, string $cluster ): string {
		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title ) : strtolower( $title );
		$patterns = [
			'question' => $language === 'nl' ? '/^(hoe|wat|waar|waarom|wanneer|welke)\b/u' : '/^(how|what|where|why|when|which)\b/u',
			'comparison' => '/\b(vs|compare|comparison|compared|vergelijk|vergeleken|beste)\b/iu',
			'guide' => $language === 'nl' ? '/\b(gids|handleiding|uitleg|basisprincipes)\b/u' : '/\b(guide|explained|principles|introduction)\b/u',
			'problem' => $language === 'nl' ? '/\b(fouten|voorkom|oorzaken|herstel)\b/u' : '/\b(mistakes|avoid|causes|recovery|prevent)\b/u',
			'choice' => $language === 'nl' ? '/\b(kies|kiezen|past|eigenschappen)\b/u' : '/\b(choose|choosing|fits|features)\b/u',
		];
		foreach ( $patterns as $family => $regex ) {
			if ( preg_match( $regex, $title_lc ) ) {
				return $family;
			}
		}
		return $this->opening_signature( $title, $language );
	}

	private function is_semantic_duplicate( string $title, array $existing_titles ): bool {
		$title_tokens = array_keys( $this->token_set( $title ) );
		$title_lc = strtolower( $title );
		foreach ( $existing_titles as $existing ) {
			$existing_lc = strtolower( (string) $existing );
			similar_text( $title_lc, $existing_lc, $percent );
			if ( $percent >= 64 ) {
				return true;
			}
			$existing_tokens = array_keys( $this->token_set( (string) $existing ) );
			$union = array_unique( array_merge( $title_tokens, $existing_tokens ) );
			if ( empty( $union ) ) {
				continue;
			}
			$intersection = array_intersect( $title_tokens, $existing_tokens );
			$jaccard = count( $intersection ) / count( $union );
			if ( $jaccard >= 0.6 ) {
				return true;
			}
		}
		return false;
	}

	private function normalize_seed_query( string $query ): string {
		$query = wp_strip_all_tags( $query );
		$query = preg_replace( '/\b\d{3,}\b/u', '', $query );
		$query = preg_replace( '/[^\p{L}\p{N}\s\-]+/u', ' ', $query );
		$query = preg_replace( '/\s+/', ' ', trim( (string) $query ) );
		return sanitize_text_field( strtolower( $query ) );
	}

	private function token_set( string $text ): array {
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', strtolower( $text ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		$out = [];
		foreach ( $tokens as $token ) {
			if ( strlen( $token ) >= 4 ) {
				$out[ $token ] = true;
			}
		}
		return $out;
	}

	private function shares_tokens( string $text, array $token_set ): bool {
		if ( empty( $token_set ) ) {
			return false;
		}
		$tokens = $this->token_set( $text );
		return count( array_intersect_key( $tokens, $token_set ) ) > 0;
	}

	private function humanize_phrase( string $phrase ): string {
		$phrase = trim( preg_replace( '/[\-_]+/', ' ', sanitize_text_field( $phrase ) ) );
		$phrase = preg_replace( '/\s+/', ' ', (string) $phrase );
		$words = preg_split( '/\s+/', strtolower( (string) $phrase ) ) ?: [];
		$acronyms = [ 'seo', 'ai', 'serp', 'gsc', 'faq', 'etf', 'ipo', 'nlp' ];
		$out = [];
		foreach ( $words as $word ) {
			if ( in_array( $word, $acronyms, true ) ) {
				$out[] = strtoupper( $word );
			} else {
				$out[] = function_exists( 'mb_convert_case' ) ? mb_convert_case( $word, MB_CASE_TITLE, 'UTF-8' ) : ucwords( $word );
			}
		}
		return trim( implode( ' ', $out ) );
	}

	private function sanitize_string_list( $values ): array {
		$values = is_array( $values ) ? $values : [];
		$out = [];
		foreach ( $values as $value ) {
			$value = sanitize_text_field( (string) $value );
			if ( '' !== $value ) {
				$out[] = $value;
			}
		}
		return array_values( array_unique( $out ) );
	}

	private function normalize_language_code( string $language ): string {
		$language = strtolower( trim( $language ) );
		return 'nl' === $language ? 'nl' : 'en';
	}

	private function contains_any( string $text, array $needles ): bool {
		$text_lc = strtolower( $text );
		foreach ( $needles as $needle ) {
			$needle = strtolower( sanitize_text_field( (string) $needle ) );
			if ( '' !== $needle && false !== strpos( $text_lc, $needle ) ) {
				return true;
			}
		}
		return false;
	}


	private function build_cluster_explainer_titles( string $cluster, string $language, bool $has_pillar ): array {
		$cluster_h = $this->humanize_phrase( $cluster );
		if ( 'nl' === $language ) {
			$bank = [
				[ 'title' => 'Wat ' . $cluster_h . ' precies omvat en waarom het belangrijk is', 'intent' => 'informational', 'priority' => 94.0, 'family' => 'basics' ],
				[ 'title' => 'Hoe bouw je een herhaalbare werkwijze voor ' . $cluster_h . '?', 'intent' => 'informational', 'priority' => 93.0, 'family' => 'framework' ],
				[ 'title' => 'Hoe meet je ' . $cluster_h . ' zonder te gokken?', 'intent' => 'informational', 'priority' => 92.0, 'family' => 'measurement' ],
				[ 'title' => 'Veelgemaakte fouten bij ' . $cluster_h . ' die resultaten verzwakken', 'intent' => 'informational', 'priority' => 91.0, 'family' => 'problem' ],
				[ 'title' => 'Praktische voorbeelden van ' . $cluster_h . ' die je direct kunt toepassen', 'intent' => 'informational', 'priority' => 90.0, 'family' => 'examples' ],
				[ 'title' => 'Hoe ' . $cluster_h . ' past binnen je bredere contentstrategie', 'intent' => 'informational', 'priority' => 89.0, 'family' => 'strategy' ],
				[ 'title' => 'Welke tools helpen je ' . $cluster_h . ' efficiënter uit te voeren?', 'intent' => 'commercial', 'priority' => 88.0, 'family' => 'tools' ],
				[ 'title' => 'Welke subonderwerpen versterken ' . $cluster_h . ' het meest?', 'intent' => 'informational', 'priority' => 87.0, 'family' => 'supporting' ],
				[ 'title' => 'Een praktische checklist om ' . $cluster_h . ' structureel te verbeteren', 'intent' => 'informational', 'priority' => 86.0, 'family' => 'checklist' ],
				[ 'title' => 'Wat maakt ' . $cluster_h . ' schaalbaar zonder kwaliteitsverlies?', 'intent' => 'informational', 'priority' => 85.0, 'family' => 'advanced' ],
			];
			if ( $has_pillar ) {
				array_unshift( $bank, [ 'title' => 'Hoe ' . $cluster_h . ' je pillar page en supporting content versterkt', 'intent' => 'informational', 'priority' => 95.0, 'family' => 'pillar_support' ] );
			}
		} else {
			$bank = [
				[ 'title' => 'What ' . $cluster_h . ' Actually Covers and Why It Matters', 'intent' => 'informational', 'priority' => 94.0, 'family' => 'basics' ],
				[ 'title' => 'How to Build a Repeatable Workflow for ' . $cluster_h, 'intent' => 'informational', 'priority' => 93.0, 'family' => 'framework' ],
				[ 'title' => 'How Do You Measure ' . $cluster_h . ' Without Guesswork?', 'intent' => 'informational', 'priority' => 92.0, 'family' => 'measurement' ],
				[ 'title' => 'Common ' . $cluster_h . ' Mistakes That Weaken Results', 'intent' => 'informational', 'priority' => 91.0, 'family' => 'problem' ],
				[ 'title' => 'Practical ' . $cluster_h . ' Examples You Can Apply Right Away', 'intent' => 'informational', 'priority' => 90.0, 'family' => 'examples' ],
				[ 'title' => 'How ' . $cluster_h . ' Fits Into a Wider Content Strategy', 'intent' => 'informational', 'priority' => 89.0, 'family' => 'strategy' ],
				[ 'title' => 'Which Tools Help You Execute ' . $cluster_h . ' More Efficiently?', 'intent' => 'commercial', 'priority' => 88.0, 'family' => 'tools' ],
				[ 'title' => 'Which Supporting Subtopics Strengthen ' . $cluster_h . ' the Most?', 'intent' => 'informational', 'priority' => 87.0, 'family' => 'supporting' ],
				[ 'title' => 'A Practical Checklist to Improve ' . $cluster_h . ' Consistently', 'intent' => 'informational', 'priority' => 86.0, 'family' => 'checklist' ],
				[ 'title' => 'What Makes ' . $cluster_h . ' Scalable Without Losing Quality?', 'intent' => 'informational', 'priority' => 85.0, 'family' => 'advanced' ],
			];
			if ( $has_pillar ) {
				array_unshift( $bank, [ 'title' => 'How ' . $cluster_h . ' Strengthens Your Pillar Page and Supporting Content', 'intent' => 'informational', 'priority' => 95.0, 'family' => 'pillar_support' ] );
			}
		}

		$rotation = abs( (int) crc32( strtolower( $cluster_h ) ) );
		$offset = 0 === count( $bank ) ? 0 : $rotation % count( $bank );
		$ordered = array_merge( array_slice( $bank, $offset ), array_slice( $bank, 0, $offset ) );
		$target = $has_pillar ? 7 : 6;
		return array_slice( $ordered, 0, $target );
	}

	private function normalize_cluster_key( string $cluster ): string {
		$cluster = sanitize_text_field( $cluster );
		if ( '' === $cluster ) { return ''; }
		$key = sanitize_title( $cluster );
		return '' !== $key ? $key : md5( strtolower( $cluster ) );
	}

	private function cluster_has_pillar_page( array $context, string $cluster ): bool {
		$key = $this->normalize_cluster_key( $cluster );
		return ! empty( $context['pillar_cluster_keys'][ $key ] );
	}

	private function ensure_minimum_cluster_coverage( array $scored, array $context, string $cluster ): array {
		$has_pillar = $this->cluster_has_pillar_page( $context, $cluster );
		$target_min = $has_pillar ? self::MIN_GAPS_WITH_PILLAR : self::MIN_GAPS_PER_CLUSTER;
		if ( count( $scored ) >= $target_min ) { return $scored; }
		$language = $context['language'] ?? 'en';
		$existing_titles = array_map( static fn( $row ) => strtolower( (string) ( $row['title'] ?? '' ) ), $scored );
		foreach ( $this->build_support_gap_fallback_titles( $cluster, $language, $has_pillar ) as $title ) {
			$clean = sanitize_text_field( $title );
			if ( '' === $clean || in_array( strtolower( $clean ), $existing_titles, true ) ) { continue; }
			$scored[] = [ 'title' => $clean, 'intent' => 'informational', 'priority' => $has_pillar ? 86.0 : 78.0, 'primary_keyword' => $this->normalize_seed_query( $cluster ), 'family' => $this->title_family_signature( $clean, $language, $cluster ), 'reason' => $has_pillar ? ( 'nl' === $language ? 'Aanvullende supporting content rond een bestaand pillar-cluster.' : 'Supporting content generated to strengthen an existing pillar cluster.' ) : ( 'nl' === $language ? 'Aanvullende clusterdekking voor een ondervertegenwoordigd onderwerp.' : 'Additional cluster coverage for an underrepresented topic.' ) ];
			$existing_titles[] = strtolower( $clean );
			if ( count( $scored ) >= $target_min ) { break; }
		}
		usort( $scored, static function( $a, $b ) { return ( $b['priority'] <=> $a['priority'] ); } );
		return $scored;
	}

	private function build_support_gap_fallback_titles( string $cluster, string $language, bool $has_pillar ): array {
		$topic = $this->humanize_phrase( $cluster );
		if ( 'nl' === $language ) {
			$base = [ "Veelgemaakte fouten bij {$topic}", "{$topic}: checklist voor implementatie", "Praktische voorbeelden van {$topic}", "Hoe je {$topic} meet en verbetert", "Beste tools voor {$topic}", "{$topic} in de praktijk: stappenplan" ];
			if ( $has_pillar ) array_unshift( $base, "Hoe {$topic} samenwerkt met je pillar page", "Interne linkstructuur rond {$topic}", "Ondersteunende content voor {$topic} opbouwen" );
			return $base;
		}
		$base = [ "Common {$topic} mistakes to avoid", "{$topic} implementation checklist", "Practical {$topic} examples", "How to measure and improve {$topic}", "Best tools for {$topic}", "{$topic} workflow and execution plan" ];
		if ( $has_pillar ) array_unshift( $base, "How {$topic} supports your pillar page", "Internal linking around {$topic}", "Supporting content ideas for {$topic}" );
		return $base;
	}

}
