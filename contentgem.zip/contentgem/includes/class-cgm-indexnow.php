<?php
/**
 * Class CGM_IndexNow
 *
 * Automatically pings IndexNow-compatible search engines (Bing, Yandex)
 * when WordPress posts are published or updated.
 *
 * Protocol: https://www.indexnow.org/documentation
 *
 * @package Contentgem
 * @since   1.5.0
 */
defined( 'ABSPATH' ) || exit;

class CGM_IndexNow {

	const OPTION_API_KEY    = 'contentgem_indexnow_key';
	const OPTION_LAST_PING  = 'contentgem_indexnow_last_ping';
	const OPTION_PING_LOG   = 'contentgem_indexnow_log';
	const LOG_MAX_ENTRIES   = 20;

	// IndexNow endpoints — Bing is the primary, others pick up via protocol
	const ENDPOINT = 'https://api.indexnow.org/indexnow';

	/**
	 * Register WordPress hooks.
	 */
	public static function register_hooks(): void {
		// Fire on publish and update
		add_action( 'publish_post',       [ __CLASS__, 'on_publish' ], 10, 2 );
		add_action( 'post_updated',       [ __CLASS__, 'on_updated' ], 10, 3 );

		// Serve the key verification file
		add_action( 'init',               [ __CLASS__, 'maybe_serve_key_file' ] );

		// Generate key on plugin activation if not set
		add_action( 'admin_init',         [ __CLASS__, 'maybe_generate_key' ] );
	}

	/**
	 * Generate an API key if one does not exist yet.
	 */
	public static function maybe_generate_key(): void {
		if ( '' !== get_option( self::OPTION_API_KEY, '' ) ) {
			return;
		}

		$key = self::generate_key();
		update_option( self::OPTION_API_KEY, $key );
	}

	/**
	 * Returns the public site base URL used by IndexNow.
	 *
	 * home_url() is the correct public location for verification files and
	 * submitted URLs. site_url() can point to /wp or another internal path on
	 * installations that separate the public site from WordPress core.
	 */
	private static function public_base_url(): string {
		return rtrim( home_url( '/' ), '/' );
	}

	/**
	 * Returns the full public verification file URL for the current key.
	 */
	private static function key_location( ?string $key = null ): string {
		$key = null === $key ? (string) get_option( self::OPTION_API_KEY, '' ) : (string) $key;
		if ( '' === $key ) {
			return '';
		}

		return self::public_base_url() . '/' . rawurlencode( $key ) . '.txt';
	}

	/**
	 * Generate a 32-character hex key (valid for IndexNow).
	 */
	private static function generate_key(): string {
		return bin2hex( random_bytes( 16 ) ); // 32 hex chars
	}

	/**
	 * Serve /{key}.txt at the site root — required by IndexNow protocol.
	 * The file must return the key as plain text with status 200.
	 */
	public static function maybe_serve_key_file(): void {
		$key = (string) get_option( self::OPTION_API_KEY, '' );
		if ( empty( $key ) ) {
			return;
		}

		$request_uri   = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$request_path  = trim( (string) wp_parse_url( $request_uri, PHP_URL_PATH ), '/' );
		$expected_path = trim( (string) wp_parse_url( self::key_location( $key ), PHP_URL_PATH ), '/' );

		if ( '' !== $request_path && $request_path === $expected_path ) {
			header( 'Content-Type: text/plain; charset=UTF-8' );
			header( 'Cache-Control: no-cache, no-store, must-revalidate' );
			header( 'Pragma: no-cache' );
			header( 'X-Robots-Tag: noindex, nofollow', true );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $key;
			exit;
		}
	}

	/**
	 * Fires when a post transitions to 'publish' for the first time.
	 */
	public static function on_publish( int $post_id, WP_Post $post ): void {
		if ( ! self::should_ping( $post ) ) return;
		self::ping( get_permalink( $post_id ) );
	}

	/**
	 * Fires on any post update. Only pings if the post is already published.
	 */
	public static function on_updated( int $post_id, WP_Post $post_after, WP_Post $post_before ): void {
		if ( $post_after->post_status !== 'publish' ) return;
		if ( ! self::should_ping( $post_after ) ) return;
		// Only ping if content or title actually changed
		if ( $post_after->post_content === $post_before->post_content &&
		     $post_after->post_title   === $post_before->post_title ) return;
		self::ping( get_permalink( $post_id ) );
	}

	/**
	 * Check if a post should be pinged.
	 */
	private static function should_ping( WP_Post $post ): bool {
		// Only public post types
		if ( ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) return false;
		// Skip auto-drafts, revisions, etc.
		if ( wp_is_post_revision( $post->ID ) || wp_is_post_autosave( $post->ID ) ) return false;
		return true;
	}

	/**
	 * Send a single URL ping to IndexNow.
	 *
	 * @param  string $url The public URL to ping.
	 * @return bool        True on success (HTTP 200/202), false otherwise.
	 */
	public static function ping( string $url ): bool {
		$key      = (string) get_option( self::OPTION_API_KEY, '' );
		$site_url = self::public_base_url();

		if ( empty( $key ) ) {
			self::log_entry( $url, false, 'No API key set' );
			return false;
		}

		$body = [
			'host'        => (string) wp_parse_url( $site_url, PHP_URL_HOST ),
			'key'         => $key,
			'keyLocation' => self::key_location( $key ),
			'urlList'     => [ $url ],
		];

		$response = wp_remote_post( self::ENDPOINT, [
			'timeout' => 10,
			'headers' => [
				'Content-Type' => 'application/json; charset=utf-8',
				'User-Agent'   => 'ContentGem/' . CONTENTGEM_VERSION,
			],
			'body' => wp_json_encode( $body ),
		] );

		if ( is_wp_error( $response ) ) {
			self::log_entry( $url, false, $response->get_error_message() );
			return false;
		}

		$code    = wp_remote_retrieve_response_code( $response );
		$success = in_array( (int) $code, [ 200, 202 ], true );
		$message = $success ? 'OK' : 'HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response );

		self::log_entry( $url, $success, $message );

		if ( $success ) {
			update_option( self::OPTION_LAST_PING, [
				'url'  => $url,
				'time' => gmdate( 'c' ),
			] );
		}

		return $success;
	}

	/**
	 * Append an entry to the ping log (capped at LOG_MAX_ENTRIES).
	 */
	private static function log_entry( string $url, bool $success, string $message ): void {
		$log   = (array) get_option( self::OPTION_PING_LOG, [] );
		$log[] = [
			'url'     => $url,
			'success' => $success,
			'message' => $message,
			'time'    => gmdate( 'c' ),
		];
		// Keep only the most recent entries
		if ( count( $log ) > self::LOG_MAX_ENTRIES ) {
			$log = array_slice( $log, -self::LOG_MAX_ENTRIES );
		}
		update_option( self::OPTION_PING_LOG, $log );
	}

	/**
	 * Get current status for display in Settings.
	 */
	public static function get_status(): array {
		$key       = (string) get_option( self::OPTION_API_KEY, '' );
		$last_ping = (array)  get_option( self::OPTION_LAST_PING, [] );
		$log       = (array)  get_option( self::OPTION_PING_LOG, [] );

		return [
			'active'            => ! empty( $key ),
			'key'               => $key ? substr( $key, 0, 8 ) . '…' : '', // partial for display
			'key_url'           => self::key_location( $key ),
			'last_ping_url'     => $last_ping['url']  ?? '',
			'last_ping_time'    => $last_ping['time'] ?? '',
			'recent_log'        => array_reverse( array_slice( $log, -5 ) ), // last 5, newest first
			'public_base_url'   => self::public_base_url(),
			'verification_path' => ! empty( $key ) ? '/' . $key . '.txt' : '',
		];
	}

	/**
	 * Manually ping a URL — called from REST API.
	 */
	public static function manual_ping( string $url ): bool {
		return self::ping( $url );
	}

	/**
	 * Regenerate the API key.
	 */
	public static function regenerate_key(): string {
		$key = self::generate_key();
		update_option( self::OPTION_API_KEY, $key );
		return $key;
	}
}
