<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Graph_Repository {
	private function table_nodes(): string { global $wpdb; return $wpdb->prefix . 'cgm_content_nodes'; }
	private function table_edges(): string { global $wpdb; return $wpdb->prefix . 'cgm_content_edges'; }
	public function create_node( array $data ): int { global $wpdb; $wpdb->insert( $this->table_nodes(), $data ); return (int) $wpdb->insert_id; }
	public function update_node( int $node_id, array $data ): bool { global $wpdb; return false !== $wpdb->update( $this->table_nodes(), $data, [ 'id' => $node_id ] ); }
	public function find_node( string $node_type, string $slug ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_nodes()} WHERE node_type = %s AND slug = %s LIMIT 1", $node_type, $slug ), ARRAY_A ); return is_array( $row ) ? $row : null; }
	public function get_node( int $node_id ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_nodes()} WHERE id = %d LIMIT 1", $node_id ), ARRAY_A ); return is_array( $row ) ? $row : null; }
	public function create_edge( array $data ): int { global $wpdb; $wpdb->insert( $this->table_edges(), $data ); return (int) $wpdb->insert_id; }
	public function delete_edges_for_node( int $node_id ): bool { global $wpdb; $wpdb->query( $wpdb->prepare( "DELETE FROM {$this->table_edges()} WHERE from_node_id = %d OR to_node_id = %d", $node_id, $node_id ) ); return true; }
	public function get_edges_from( int $node_id, ?string $edge_type = null ): array { global $wpdb; if ( $edge_type ) { return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_edges()} WHERE from_node_id = %d AND edge_type = %s", $node_id, $edge_type ), ARRAY_A ); } return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_edges()} WHERE from_node_id = %d", $node_id ), ARRAY_A ); }
	public function get_edges_to( int $node_id, ?string $edge_type = null ): array { global $wpdb; if ( $edge_type ) { return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_edges()} WHERE to_node_id = %d AND edge_type = %s", $node_id, $edge_type ), ARRAY_A ); } return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_edges()} WHERE to_node_id = %d", $node_id ), ARRAY_A ); }
	public function get_graph_for_cluster( int $cluster_id ): array { $cluster = $this->find_node( 'cluster', 'cluster-' . $cluster_id ); return [ 'cluster' => $cluster, 'edges' => $cluster ? $this->get_edges_from( (int) $cluster['id'] ) : [] ]; }
}
