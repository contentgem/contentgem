<?php
defined( 'ABSPATH' ) || exit;

class CGM_Task_Registry {
	public function get( string $task_name ): array {
		$tasks = $this->all();
		return $tasks[ $task_name ] ?? $tasks['ai_assistant_research'];
	}

	public function all(): array {
		return [
			'title_suggestions' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'minimal',
				'max_output_tokens' => 320,
				'schema' => 'title_suggestions_v1',
				'supports_sources' => false,
				'supports_grounding' => false,
				'optimization_profile' => 'compact_json',
			],
			'semantic_keyword_suggestions' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'minimal',
				'max_output_tokens' => 240,
				'schema' => 'semantic_keyword_suggestions_v1',
				'supports_sources' => false,
				'supports_grounding' => false,
				'optimization_profile' => 'compact_json',
			],
			'content_gap_analysis' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'low',
				'max_output_tokens' => 900,
				'schema' => 'content_gap_analysis_v1',
				'supports_sources' => true,
				'supports_grounding' => false,
				'optimization_profile' => 'compact_json',
			],
			'competitor_cluster_summary' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'low',
				'max_output_tokens' => 1200,
				'schema' => 'competitor_cluster_summary_v1',
				'supports_sources' => true,
				'supports_grounding' => false,
				'optimization_profile' => 'compact_json',
			],
			'site_structure_recommendation' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'low',
				'max_output_tokens' => 1000,
				'schema' => 'site_structure_recommendation_v1',
				'supports_sources' => true,
				'supports_grounding' => true,
				'optimization_profile' => 'compact_json',
			],
			'cannibalization_semantic_check' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'low',
				'max_output_tokens' => 1000,
				'schema' => 'cannibalization_semantic_check_v1',
				'supports_sources' => true,
				'supports_grounding' => true,
				'optimization_profile' => 'compact_json',
			],
			'ai_assistant_research' => [
				'model' => 'gpt-5.4-mini',
				'reasoning_effort' => 'low',
				'max_output_tokens' => 4200,
				'schema' => '',
				'supports_sources' => true,
				'supports_grounding' => true,
				'optimization_profile' => 'article_html',
			],
			'technical_build_plan' => [
				'model' => 'gpt-5.4',
				'reasoning_effort' => 'medium',
				'max_output_tokens' => 3600,
				'schema' => '',
				'supports_sources' => true,
				'supports_grounding' => true,
				'optimization_profile' => 'grounded_markdown',
			],
		];
	}
}
