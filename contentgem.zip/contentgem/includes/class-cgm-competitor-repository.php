<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Competitor_Repository {
	public function get_latest_for_keyword( string $keyword ): array { $row = ( new CGM_SERP_Repository() )->get_latest_snapshot( $keyword ); return is_array( $row ) ? (array) json_decode( (string) $row['snapshot_json'], true ) : []; }
}
