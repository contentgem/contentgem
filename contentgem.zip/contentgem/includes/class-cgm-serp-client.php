<?php
/**
 * SERP Client
 *
 * Provides competitor URL discovery. Direct scraping of search engines
 * violates their Terms of Service, so this class returns an empty result set
 * by default. Integrate a permitted SERP API (e.g. SerpApi, DataForSEO) by
 * implementing the fetch() method below and storing the API key in settings.
 *
 * @package Contentgem
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CGM_SERP_Client {

	/**
	 * Retrieve top URLs for a query using a configured SERP API.
	 *
	 * @param string $query Search query.
	 * @param array  $args  Optional arguments.
	 * @return array{ query: string, results: array }
	 */
	public function search( string $query, array $args = [] ): array {
		// No permitted SERP API configured — return empty results.
		// To enable: add your SERP API key in Contentgem > Settings and
		// implement the API call here using wp_remote_get() / wp_remote_post().
		return array(
			'query'   => $query,
			'results' => array(),
			'notice'  => __( 'Configure a SERP API key in Contentgem settings to enable competitor URL discovery.', 'contentgem' ),
		);
	}
}
