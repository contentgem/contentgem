<?php
/**
 * Contentgem fact-check assistance layer.
 *
 * This is a lightweight, model-assisted verification pass that reduces unsupported
 * claims in generated output without removing existing Contentgem functionality.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Fact_Checker {
	public function enabled(): bool {
		return (bool) get_option( 'cgm_enable_fact_check', false );
	}

	public function build_instruction_appendix( string $language = '' ): string {
		$language = '' !== trim( $language ) ? trim( $language ) : 'the requested language';
		return "FACT-CHECK MODE:
"
			. "- Write only in {$language}.
"
			. "- Prefer verifiable, stable facts over speculation.
"
			. "- Remove claims you cannot support from the provided context.
"
			. "- When certainty is limited, soften wording and state limits clearly.
"
			. "- Do not invent studies, statistics, dates, quotes, products, regulations or source names.
"
			. "- Keep the output clean and reader-facing. Do not mention this fact-check instruction block.
";
	}

	public function revise_article_html( CGM_Claude_Client $client, string $html, array $context = [] ): array {
		$html = trim( (string) $html );
		if ( '' === $html ) {
			return [ 'html' => '', 'summary' => '', 'tokens_used' => 0 ];
		}

		$topic = sanitize_text_field( (string) ( $context['topic'] ?? $context['suggested_title'] ?? '' ) );
		$primary_keyword = sanitize_text_field( (string) ( $context['primary_keyword'] ?? $topic ) );
		$language = sanitize_text_field( (string) ( $context['language'] ?? 'English' ) );
		$summary = '';

		$prompt = sprintf(
			"Review the following HTML article and fact-check it conservatively.\n\n"
			. "Topic: %s\n"
			. "Primary keyword: %s\n"
			. "Language: %s\n\n"
			. "Requirements:\n"
			. "- Preserve the same structure, tone and SEO intent where possible\n"
			. "- Remove or soften unsupported factual claims\n"
			. "- Do not invent citations, source names, percentages, dates or statistics\n"
			. "- Keep useful practical advice when it does not depend on unsupported specifics\n"
			. "- Return ONLY the final full HTML article\n\n"
			. "ARTICLE HTML:\n%s",
			$topic,
			$primary_keyword,
			$language,
			$html
		);

		$result = $client->chat(
			[ [ 'role' => 'user', 'content' => $prompt ] ],
			$this->build_instruction_appendix( $language ),
			12000
		);

		$revised = trim( (string) ( $result['text'] ?? '' ) );
		if ( '' === $revised ) {
			$revised = $html;
		}

		return [
			'html'       => $revised,
			'summary'    => $summary,
			'tokens_used'=> (int) ( $result['tokens_used'] ?? 0 ),
		];
	}
}
