<?php
/**
 * Class CGM_Link_Scanner
 *
 * Scans published posts for broken internal links and suggests replacements.
 *
 * @package Contentgem
 * @since   1.0.0
 */
defined( 'ABSPATH' ) || exit;

class CGM_Link_Scanner {

	/**
	 * Scan all published posts for broken internal links.
	 */
	public function scan_broken_internal_links(): array {
		$posts    = get_posts( [
			'numberposts' => -1,
			'post_status' => 'publish',
			'post_type'   => 'post',
		] );
		$site_url     = rtrim( get_site_url(), '/' );
		$broken_links = [];

		foreach ( $posts as $post ) {
			error_log( '[ContentGem scanner] Scanning post: ' . $post->ID . ' | ' . $post->post_title );

			preg_match_all(
				'/<a[^>]+href=["\']([^"\'#]+)["\'][^>]*>(.*?)<\/a>/is',
				$post->post_content,
				$matches,
				PREG_SET_ORDER
			);

			error_log( '[ContentGem scanner] Found ' . count( $matches ) . ' links' );

			foreach ( $matches as $match ) {
				$url    = trim( $match[1] );
				$anchor = strip_tags( $match[2] );

				if ( str_starts_with( $url, 'http' ) && ! str_starts_with( $url, $site_url ) ) {
					continue;
				}
				if ( preg_match( '/^(mailto:|tel:|#|javascript:)/i', $url ) ) {
					continue;
				}
				if ( empty( trim( $anchor ) ) ) {
					continue;
				}

				$full_url = str_starts_with( $url, 'http' ) ? $url : $site_url . '/' . ltrim( $url, '/' );
				$response = wp_remote_head( $full_url, [ 'timeout' => 5, 'redirection' => 0 ] );

				if ( is_wp_error( $response ) ) {
					$broken_links[] = $this->build_broken_link_entry( $post, $url, $anchor );
					continue;
				}

				$code = wp_remote_retrieve_response_code( $response );
				if ( $code >= 400 ) {
					$broken_links[] = $this->build_broken_link_entry( $post, $url, $anchor );
				}
			}
		}

		return $broken_links;
	}

	private function build_broken_link_entry( WP_Post $post, string $url, string $anchor ): array {
		$entry = [
			'source_post_id' => $post->ID,
			'source_title'   => $post->post_title,
			'broken_url'     => $url,
			'anchor_text'    => $anchor,
		];

		$replacement = $this->find_replacement( $anchor, $url, $post->ID );
		if ( $replacement ) {
			$entry['suggestion'] = $replacement;
		}

		return $entry;
	}

	private function find_replacement( string $anchor, string $url, int $source_post_id ): ?array {
		$slug = basename( rtrim( $url, '/' ) );

		$by_slug = get_posts( [
			'name'        => $slug,
			'post_status' => 'publish',
			'post_type'   => 'post',
			'numberposts' => 1,
		] );

		if ( ! empty( $by_slug ) ) {
			$p = $by_slug[0];
			return [
				'title' => $p->post_title,
				'url'   => get_permalink( $p->ID ),
				'score' => 100,
			];
		}

		$by_title = get_posts( [
			's'           => $anchor,
			'post_status' => 'publish',
			'post_type'   => 'post',
			'numberposts' => 1,
			'exclude'     => [ $source_post_id ],
		] );

		if ( ! empty( $by_title ) ) {
			$p = $by_title[0];
			return [
				'title' => $p->post_title,
				'url'   => get_permalink( $p->ID ),
				'score' => 80,
			];
		}

		return null;
	}

	public function fix_link( int $source_post_id, string $broken_url, string $new_url, string $new_title = '' ): bool {
		$post = get_post( $source_post_id );
		if ( ! $post ) {
			return false;
		}

		$content = $post->post_content;

		if ( empty( $new_url ) ) {
			$content = preg_replace(
				'/<a[^>]+href=["\']' . preg_quote( $broken_url, '/' ) . '["\'][^>]*>(.*?)<\/a>/is',
				'$1',
				$content
			);
		} else {
			$content = str_replace(
				[ 'href="' . $broken_url . '"', "href='" . $broken_url . "'" ],
				[ 'href="' . $new_url . '"',    "href='" . $new_url . "'" ],
				$content
			);
		}

		$result = wp_update_post( [
			'ID'           => $source_post_id,
			'post_content' => $content,
		] );

		return ! is_wp_error( $result ) && $result > 0;
	}

	public function remove_link( int $source_post_id, string $broken_url, string $anchor_text ): bool {
		return $this->fix_link( $source_post_id, $broken_url, '' );
	}

	/**
	 * Get internal link suggestions for a post using layered semantic scoring.
	 *
	 * Scoring layers (additive):
	 *  Layer 1 — Same cluster          : +40 pts  (strongest signal)
	 *  Layer 2 — Cluster keywords      : +5 pts per matching keyword (max +25)
	 *  Layer 3 — GSC query overlap     : +3 pts per shared query (max +15)
	 *  Layer 4 — TF-IDF word overlap   : +1 pt per significant shared word (max +10)
	 *  Layer 5 — Already linked        : −999 (exclude)
	 *
	 * Minimum score to appear: 5 pts.
	 * Returns top 10 results sorted by score descending.
	 */
    /**
     * Get internal link suggestions for a post using layered semantic scoring.
     *
     * @param int    $post_id            Source post ID.
     * @param string $forced_pillar_url  Optional forced pillar URL.
     * @param bool   $allow_unpublished   When true, allow suggestions for unpublished posts (draft, pending, future, private). Defaults to false.
     *
     * @return array  Suggestions array.
     */
    public function get_link_suggestions( int $post_id, string $forced_pillar_url = '', bool $allow_unpublished = false ): array {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return [];
        }
        // By default only process published posts; when $allow_unpublished is true, skip only trashed or auto-draft posts.
        if ( ! $allow_unpublished ) {
            if ( $post->post_status !== 'publish' ) {
                return [];
            }
        } else {
            if ( in_array( $post->post_status, [ 'trash', 'auto-draft' ], true ) ) {
                return [];
            }
        }

		// ── Prepare source post data ────────────────────────────────────
		$source_content_lc = mb_strtolower( wp_strip_all_tags( $post->post_content ) );
		$source_words      = $this->extract_significant_words( $source_content_lc );

		// ── Find which cluster the source post belongs to ───────────────
		$source_cluster = $this->get_post_cluster( $post_id );

		// ── Load cluster keywords from settings ─────────────────────────
		$cluster_keywords = $this->get_cluster_keywords();

		// ── Load GSC queries for source post ────────────────────────────
		$source_gsc_queries = $this->get_gsc_queries_for_post( $post_id );

		// ── Already-linked URLs in source post ──────────────────────────
		preg_match_all( '/href=["\']([^"\'#]+)["\']/', $post->post_content, $link_matches );
		$existing_links = array_map( 'trailingslashit', $link_matches[1] ?? [] );

		// ── Get all candidate posts ──────────────────────────────────────
		$all_posts = get_posts( [
			'numberposts' => -1,
			'post_status' => 'publish',
			'post_type'   => [ 'post', 'page' ],
			'exclude'     => [ $post_id ],
		] );

		$suggestions = [];

		foreach ( $all_posts as $candidate ) {
			$permalink        = get_permalink( $candidate->ID );
			$permalink_slash  = trailingslashit( $permalink );
			$score            = 0;
			$score_reasons    = [];

			// Layer 5 — skip already linked
			if ( in_array( $permalink_slash, $existing_links, true ) ) {
				continue;
			}

			$site_structure = $this->get_site_structure();
		$site_structure_targets = [];
		foreach ( [ 'homepage', 'about_page' ] as $single_key ) {
			$entry = (array) ( $site_structure[ $single_key ] ?? [] );
			if ( ! empty( $entry['page_id'] ) ) {
				$site_structure_targets[ (int) $entry['page_id'] ] = [ 'type' => $single_key ];
			}
		}
		foreach ( [ 'service_pages', 'case_studies' ] as $list_key ) {
			foreach ( (array) ( $site_structure[ $list_key ] ?? [] ) as $entry ) {
				if ( ! empty( $entry['page_id'] ) ) {
					$site_structure_targets[ (int) $entry['page_id'] ] = [ 'type' => $list_key ];
				}
			}
		}
		foreach ( (array) ( $site_structure['nodes'] ?? [] ) as $entry ) {
			if ( ! empty( $entry['page_id'] ) ) {
				$site_structure_targets[ (int) $entry['page_id'] ] = [ 'type' => (string) ( $entry['type'] ?? 'custom' ) ];
			}
		}

		// ── Layer 0: Is pillar page (+25) ──────────────────────────────────────
			// Pillar pages always score highest — they are the hub of the cluster.
			// Also check against forced_pillar_url from the request.
			$is_pillar = (bool) get_post_meta( $candidate->ID, '_cgm_is_pillar', true );
			if ( $is_pillar ) {
				$score           += 25;
				$score_reasons[]  = 'Pillar page';
			}
			if ( isset( $site_structure_targets[ (int) $candidate->ID ] ) ) {
				$type = (string) ( $site_structure_targets[ (int) $candidate->ID ]['type'] ?? 'site structure' );
				$score += 'service_pages' === $type ? 22 : ( 'homepage' === $type ? 18 : ( 'case_studies' === $type ? 14 : 12 ) );
				$score_reasons[] = 'Site structure target: ' . str_replace( '_', ' ', $type );
			}

			// ── Layer 1: Same cluster (+40) ──────────────────────────────────────────────────────────────────────────────
			$candidate_cluster = $this->get_post_cluster( $candidate->ID );
			if (
				$source_cluster &&
				$candidate_cluster &&
				$source_cluster === $candidate_cluster
			) {
				$score           += 40;
				$score_reasons[]  = 'Same cluster: ' . $source_cluster;
			}

			// ── Layer 2: Cluster keyword match (+5 each, max +25) ────────
			$keyword_score   = 0;
			$matched_keywords = [];
			if ( $source_cluster && ! empty( $cluster_keywords[ $source_cluster ] ) ) {
				$content_lc = mb_strtolower( wp_strip_all_tags( $candidate->post_content ) . ' ' . $candidate->post_title );
				foreach ( $cluster_keywords[ $source_cluster ] as $kw ) {
					if ( mb_strlen( $kw ) > 2 && str_contains( $content_lc, mb_strtolower( $kw ) ) ) {
						$keyword_score    += 5;
						$matched_keywords[] = $kw;
						if ( $keyword_score >= 25 ) break;
					}
				}
			}
			if ( $keyword_score > 0 ) {
				$score           += $keyword_score;
				$score_reasons[]  = 'Cluster keywords: ' . implode( ', ', array_slice( $matched_keywords, 0, 3 ) );
			}

			// ── Layer 3: GSC query overlap (+3 each, max +15) ────────────
			$gsc_score = 0;
			if ( ! empty( $source_gsc_queries ) ) {
				$candidate_gsc  = $this->get_gsc_queries_for_post( $candidate->ID );
				$shared_queries = array_intersect( $source_gsc_queries, $candidate_gsc );
				$gsc_score      = min( count( $shared_queries ) * 3, 15 );
				if ( $gsc_score > 0 ) {
					$score           += $gsc_score;
					$score_reasons[]  = 'Shared GSC queries: ' . count( $shared_queries );
				}
			}

			// ── Layer 3b: GSC position boost ────────────────────────────────────
			// +10 if candidate ranks pos 5-15 (near-win: most valuable to link to)
			// +5  if candidate ranks pos 1-4  (already winning, still good)
			$candidate_position = $this->get_gsc_position_for_post( $candidate->ID );
			if ( $candidate_position >= 5.0 && $candidate_position <= 15.0 ) {
				$score           += 10;
				$score_reasons[]  = 'GSC pos: ' . round( $candidate_position, 1 ) . ' (near-win)';
			} elseif ( $candidate_position > 0.0 && $candidate_position < 5.0 ) {
				$score           += 5;
				$score_reasons[]  = 'GSC pos: ' . round( $candidate_position, 1 ) . ' (top 5)';
			}

			// ── Layer 4: TF-IDF word overlap (+1 each, max +10) ──────────
			$candidate_content_lc = mb_strtolower( wp_strip_all_tags( $candidate->post_content ) );
			$candidate_words      = $this->extract_significant_words( $candidate_content_lc );
			$shared_words         = array_intersect( $source_words, $candidate_words );
			$word_score           = min( count( $shared_words ), 10 );
			if ( $word_score > 0 ) {
				$score           += $word_score;
				$score_reasons[]  = 'Shared terms: ' . $word_score;
			}

			// ── Minimum threshold ─────────────────────────────────────────
			if ( $score < 3 ) {
				continue;
			}

			// ── Best anchor text ──────────────────────────────────────────
			$best_anchor = $this->find_best_anchor( $source_content_lc, $candidate, $matched_keywords, $source_cluster );

			// Skip targets that have no natural in-content anchor — we do not want to
			// insert links with generic cluster-name anchors or template sentences.
			if ( '' === $best_anchor ) {
				continue;
			}

			$suggestions[] = [
				'source_post_id' => $post_id,
				'target_post_id' => $candidate->ID,
				'target_title'   => $candidate->post_title,
				'target_url'     => $permalink,
				'anchor_text'    => $best_anchor,
				'match_score'    => $score,
				'context_hint'   => implode( ' · ', $score_reasons ),
			];
		}

		usort( $suggestions, fn( $a, $b ) => $b['match_score'] - $a['match_score'] );

		return array_slice( $suggestions, 0, 10 );
	}

	// ── Helper: get cluster for a post ─────────────────────────────────
	private function get_post_cluster( int $post_id ): string {
		foreach ( [ '_cgm_cluster', '_contentgem_cluster', 'contentgem_cluster' ] as $meta_key ) {
			$cluster = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
			if ( '' !== $cluster ) {
				return $cluster;
			}
		}

		$raw_clusters = get_option( 'contentgem_clusters', [] );
		if ( is_array( $raw_clusters ) ) {
			$saved_clusters = $raw_clusters;
		} elseif ( is_string( $raw_clusters ) ) {
			$decoded = json_decode( $raw_clusters, true );
			if ( is_array( $decoded ) ) {
				$saved_clusters = $decoded;
			} else {
				$saved_clusters = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw_clusters ) ) );
			}
		} else {
			$saved_clusters = [];
		}
		$saved_clusters = array_values( array_filter( array_map( static function( $value ) { return trim( (string) $value ); }, $saved_clusters ) ) );

		$categories = wp_get_post_categories( $post_id, [ 'fields' => 'names' ] );
		foreach ( (array) $categories as $cat_name ) {
			$cat_name_lc = mb_strtolower( trim( (string) $cat_name ) );
			foreach ( $saved_clusters as $cluster_name ) {
				if ( $cat_name_lc === mb_strtolower( trim( (string) $cluster_name ) ) ) {
					return (string) $cluster_name;
				}
			}
		}

		$tags = wp_get_post_tags( $post_id, [ 'fields' => 'names' ] );
		foreach ( (array) $tags as $tag_name ) {
			$tag_name_lc = mb_strtolower( trim( (string) $tag_name ) );
			foreach ( $saved_clusters as $cluster_name ) {
				if ( $tag_name_lc === mb_strtolower( trim( (string) $cluster_name ) ) ) {
					return (string) $cluster_name;
				}
			}
		}

		$post = get_post( $post_id );
		if ( $post instanceof WP_Post ) {
			$title_lc = mb_strtolower( trim( (string) $post->post_title ) );
			foreach ( $saved_clusters as $cluster_name ) {
				$cluster_lc = mb_strtolower( trim( (string) $cluster_name ) );
				if ( '' !== $cluster_lc && false !== strpos( $title_lc, $cluster_lc ) ) {
					return (string) $cluster_name;
				}
			}
		}

		return '';
	}

	// ── Helper: load cluster keywords from settings ─────────────────────
	private function get_cluster_keywords(): array {
		// cgm_cluster_keywords is saved as [ 'cluster_name' => ['kw1','kw2',...], ... ]
		$keywords = get_option( 'cgm_cluster_keywords', [] );
		if ( is_array( $keywords ) ) {
			return $keywords;
		}
		return [];
	}

	// ── Helper: get GSC queries that a post ranks for ───────────────────
	private function get_gsc_queries_for_post( int $post_id ): array {
		// Stored during GSC sync as serialized array of query strings
		$queries = get_post_meta( $post_id, '_cgm_gsc_queries', true );
		if ( is_array( $queries ) ) {
			return array_map( 'mb_strtolower', $queries );
		}
		return [];
	}

	// ── Helper: extract significant words for TF-IDF layer ─────────────
	private function extract_significant_words( string $text_lc ): array {
		$stopwords = [
			'de','het','een','van','voor','met','en','of','in','op','aan','the','and',
			'for','with','how','hoe','wat','why','naar','als','dat','die','zijn','bij',
			'door','over','this','that','wordt','worden','heeft','hebben','your','you',
			'its','maar','ook','nog','wel','niet','meer','zeer','heel','was','have',
			'been','will','they','them','their','from','also','when','than','then',
			'what','which','about','after','before','other','into','more','some',
		];

		preg_match_all( '/\b[a-z\x{00C0}-\x{024F}]{4,}\b/u', $text_lc, $m );
		$words = $m[0] ?? [];

		// Count frequencies
		$freq = array_count_values( $words );

		// Remove stopwords and very rare words (freq < 2) — keep only meaningful terms
		$significant = [];
		foreach ( $freq as $word => $count ) {
			if ( ! in_array( $word, $stopwords, true ) && $count >= 2 ) {
				$significant[] = $word;
			}
		}

		return $significant;
	}

	// ── Helper: get average GSC position for a post ────────────────────
	private function get_gsc_position_for_post( int $post_id ): float {
		$position = get_post_meta( $post_id, '_cgm_gsc_position', true );
		if ( $position !== '' && $position !== false ) {
			return (float) $position;
		}
		$page_data = get_option( 'cgm_gsc_page_positions', [] );
		if ( is_array( $page_data ) ) {
			$permalink = get_permalink( $post_id );
			if ( $permalink && isset( $page_data[ $permalink ] ) ) {
				return (float) $page_data[ $permalink ];
			}
		}
		return 0.0;
	}

	// ── Helper: find best anchor text for a suggestion ──────────────────
	//
	// Returns the best natural anchor phrase that already occurs in the source content.
	// Returns an EMPTY STRING when no distinctive phrase is found — this signals the caller
	// to skip the target rather than insert a generic cluster-name anchor.
	//
	// Cluster names (e.g. "Topical authority") are explicitly excluded from results because
	// every post in a cluster shares them, so using one produces identical, SEO-hostile
	// anchors across every internal link in the cluster.
	private function find_best_anchor( string $source_content_lc, WP_Post $candidate, array $cluster_keywords, string $source_cluster = '' ): string {
		$full_title_lc   = mb_strtolower( $candidate->post_title );
		$source_cluster_lc = mb_strtolower( trim( $source_cluster ) );

		// Build a banned-phrase set: the cluster name itself plus each of its individual words
		// if the cluster name is a 2-word label (so "Topical authority" bans "topical authority",
		// but NOT the single words "topical" or "authority" unless they equal the full cluster).
		$banned_phrases = [];
		if ( '' !== $source_cluster_lc ) {
			$banned_phrases[ $source_cluster_lc ] = true;
		}

		$is_banned = static function ( string $phrase_lc ) use ( $banned_phrases ): bool {
			$phrase_lc = trim( $phrase_lc );
			if ( '' === $phrase_lc ) {
				return true;
			}
			return isset( $banned_phrases[ $phrase_lc ] );
		};

		// Priority 1: full title appears verbatim in source content AND is not the cluster name.
		if ( str_contains( $source_content_lc, $full_title_lc ) && ! $is_banned( $full_title_lc ) ) {
			return $candidate->post_title;
		}

		// Priority 2: a multi-word cluster keyword (≥ 2 words, ≥ 12 chars) that is
		// (a) present in source content AND (b) not equal to the cluster name itself.
		// This prevents "topical authority" (the cluster label) being returned just because
		// it appears in the content.
		foreach ( $cluster_keywords as $kw ) {
			$kw_lc    = mb_strtolower( trim( $kw ) );
			$kw_words = preg_split( '/\s+/u', $kw_lc ) ?: [];
			if (
				count( $kw_words ) >= 2
				&& mb_strlen( $kw_lc ) >= 12
				&& str_contains( $source_content_lc, $kw_lc )
				&& ! $is_banned( $kw_lc )
			) {
				return ucwords( $kw );
			}
		}

		// Priority 3: longest multi-word phrase from the candidate's title (3→2 words)
		// that (a) occurs in source content AND (b) is not the cluster name.
		// This is what produces distinctive anchors like "Knowledge Graph Relevance" or
		// "Entity Coverage" instead of the generic cluster label.
		$title_words = preg_split( '/\s+/u', $full_title_lc ) ?: [];
		for ( $window = min( 4, count( $title_words ) ); $window >= 2; $window-- ) {
			for ( $i = 0; $i <= count( $title_words ) - $window; $i++ ) {
				$phrase = implode( ' ', array_slice( $title_words, $i, $window ) );
				if (
					mb_strlen( $phrase ) > 8
					&& str_contains( $source_content_lc, $phrase )
					&& ! $is_banned( $phrase )
				) {
					return ucwords( $phrase );
				}
			}
		}

		// Priority 4: longest distinctive single word from the title (> 5 chars) found in
		// source content — but ONLY words that are NOT part of the cluster name. This means
		// for a post titled "How Entity Coverage Improves Your Topical Authority" in cluster
		// "Topical authority", we'll pick "coverage" or "improves", never "topical" or "authority".
		$cluster_word_set = [];
		foreach ( preg_split( '/[\s\-]+/u', $source_cluster_lc ) ?: [] as $cw ) {
			$cw = trim( $cw );
			if ( '' !== $cw ) {
				$cluster_word_set[ $cw ] = true;
			}
		}
		$single_words = preg_split( '/[\s\-]+/u', $full_title_lc ) ?: [];
		usort( $single_words, static fn( $a, $b ) => mb_strlen( $b ) - mb_strlen( $a ) );
		foreach ( $single_words as $word ) {
			$word = trim( $word );
			if (
				mb_strlen( $word ) > 5
				&& ! isset( $cluster_word_set[ $word ] )
				&& str_contains( $source_content_lc, $word )
			) {
				return ucfirst( $word );
			}
		}

		// No distinctive anchor found — signal caller to skip this target.
		return '';
	}


    private function get_site_structure(): array {
        $saved = get_option( 'contentgem_site_structure', [] );
        return is_array( $saved ) ? $saved : [];
    }
}
