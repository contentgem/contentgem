<?php
/**
 * Executes queued jobs.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Job_Runner {
	public static function process_next(): void {
		$repo = new CGM_Job_Repository();
		$service = new CGM_Job_Service( $repo );
		$job = $repo->find_next_queued();
		if ( ! $job ) {
			return;
		}
		if ( ! $repo->claim( (int) $job['id'], 'cron:' . get_current_blog_id() ) ) {
			return;
		}
		$job = $repo->get( (int) $job['id'] );
		if ( ! $job ) {
			return;
		}
		$api = new CGM_Rest_Api();
		$draft_service = new CGM_Draft_Service( $api );
		global $wpdb;
		try {
			switch ( $job['type'] ) {
				case 'analyze_site':
					$payload = $job['payload'];
					$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/analyze-run' );
					$request->set_header( 'content-type', 'application/json' );
					$request->set_body( wp_json_encode( [ 'job_id' => $job['job_key'], 'token' => $job['job_token'] ] ) );
					$api->post_analyse_run( $request );
					break;
				case 'scan_broken_links':
					$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/broken-links/scan/run' );
					$request->set_header( 'content-type', 'application/json' );
					$request->set_body( wp_json_encode( [ 'job_id' => $job['job_key'], 'token' => $job['job_token'] ] ) );
					$api->post_scan_links_run( $request );
					break;
				case 'assistant_draft':
					$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/assistant/draft-run' );
					$request->set_header( 'content-type', 'application/json' );
					$request->set_body( wp_json_encode( [ 'job_id' => $job['job_key'], 'token' => $job['job_token'] ] ) );
					$api->post_assistant_draft_run( $request );
					break;
				case 'generate_draft':
					$gap_id = (int) ( $job['payload']['gap_id'] ?? 0 );
					$service->advance( $job['job_key'], 'processing', 10, 'Generating draft...', 'generating_draft' );
					$post_id = $draft_service->create_from_gap( $gap_id, static function( $chunk ) {} );
					$service->advance( $job['job_key'], 'finalizing', 95, 'Saving draft...', 'saving_draft', [ 'wp_post_id' => $post_id ] );
					$service->complete( $job['job_key'], 'Draft created.', [ 'wp_post_id' => $post_id ] );
					break;
				default:
					$service->fail( $job['job_key'], 'Unsupported job type.', [ 'type' => $job['type'] ] );
			}
		} catch ( Throwable $e ) {
			$service->fail( $job['job_key'], $e->getMessage(), [ 'exception' => get_class( $e ) ] );
		}
		if ( $repo->find_next_queued() ) {
			$service->schedule_processing();
		}
	}
}
