<?php
/**
 * Unified draft generation service.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Draft_Service {
	private CGM_Rest_Api $api;

	public function __construct( CGM_Rest_Api $api ) {
		$this->api = $api;
	}

	public function create_from_gap( int $gap_id, callable $on_chunk ): int {
		$creator = new CGM_Draft_Creator(
			new CGM_Claude_Client( $this->api->get_api_key() ),
			new CGM_Token_Manager( get_current_user_id() )
		);
		return $creator->create( $gap_id, $on_chunk );
	}

	public function create_assistant_draft( array $payload ): array {
		global $wpdb;
		$gap_id = (int) ( $payload['gap_id'] ?? 0 );
		$custom_topic = sanitize_text_field( (string) ( $payload['custom_topic'] ?? '' ) );
		$focus_keyword = sanitize_text_field( (string) ( $payload['focus_keyword'] ?? '' ) );
		$cluster = sanitize_text_field( (string) ( $payload['cluster'] ?? '' ) );
		$word_count = max( 1200, (int) ( $payload['word_count'] ?? 1500 ) );
		$additional_instructions = sanitize_textarea_field( (string) ( $payload['additional_instructions'] ?? '' ) );
		$content_type = in_array( sanitize_key( (string) ( $payload['content_type'] ?? 'post' ) ), [ 'post', 'page' ], true ) ? sanitize_key( (string) ( $payload['content_type'] ?? 'post' ) ) : 'post';
		$topic = '';
		$site_id = 0;

		if ( $gap_id > 0 ) {
			$gap = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_gaps WHERE id = %d", $gap_id ) );
			if ( $gap ) {
				$topic = (string) $gap->suggested_title;
				$site_id = (int) $gap->site_id;
				$cluster = $cluster ?: (string) ( $gap->cluster_name ?? '' );
				$focus_keyword = $focus_keyword ?: (string) ( $gap->cluster_name ?? $gap->suggested_title );
			}
		}
		$topic = $topic ?: $custom_topic;
		if ( '' === trim( $topic ) ) {
			throw new RuntimeException( 'Topic is required.' );
		}

		$site = $site_id > 0 ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_sites WHERE id = %d", $site_id ) ) : null;
		$tone = (string) get_option( 'contentgem_tone_of_voice', '' );
		if ( '' === $tone && ! empty( $site->tone_snapshot ) ) {
			$tone_analyzer = new CGM_Tone_Analyzer( CGM_AI_Client::from_settings() );
			$tone = $tone_analyzer->build_tone_instructions( (string) $site->tone_snapshot );
		}

		$forced_language = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		$forced_language = str_replace( '_', '-', $forced_language );
		if ( 'auto' !== $forced_language && preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $forced_language ) ) {
			$parts = explode( '-', $forced_language );
			$language_label = $this->language_label_from_code( sanitize_key( $parts[0] ) );
		} else {
			$sample = trim( implode( ' ', array_filter( [ $topic, $focus_keyword, $cluster ] ) ) );
			$detected = ( class_exists( 'CGM_NLP_Engine' ) ? ( new CGM_NLP_Engine() )->detect_language( $sample ) : 'en' );
			$language_label = $this->language_label_from_code( $detected );
		}

		$prompt_payload = [
			'topic' => $topic,
			'focus_keyword' => $focus_keyword ?: $topic,
			'cluster' => $cluster,
			'word_count' => $word_count,
			'additional_instructions' => $additional_instructions,
			'tone' => $tone,
			'language' => $language_label,
			'lsi_keywords' => $this->derive_lsi_keywords( $topic, $cluster ),
			'internal_links' => $this->get_internal_links_for_cluster( $cluster ),
			'pillar_pages' => $this->get_cluster_pillar_pages( $cluster ),
		];

		$client = new CGM_Claude_Client( $this->api->get_api_key() );
		$result = $client->generate_long_form_article( $prompt_payload );
		$html = trim( (string) ( $result['html'] ?? '' ) );
		$html = preg_replace( '/^```(?:html)?\s*/i', '', $html );
		$html = preg_replace( '/\s*```$/', '', (string) $html );
		$html = $this->convert_faq_section_to_accordion( (string) $html );
		$title = function_exists( 'contentgem_clean_ai_title_output' ) ? contentgem_clean_ai_title_output( (string) ( $result['title'] ?? $topic ) ) : sanitize_text_field( (string) ( $result['title'] ?? $topic ) );
		$meta_desc = sanitize_text_field( (string) ( $result['meta_description'] ?? '' ) );
		$current_words = (int) str_word_count( wp_strip_all_tags( $html ) );
		$attempts = 0;
		while ( $attempts < 4 && $current_words < (int) floor( $word_count * 0.9 ) ) {
			$attempts++;
			$expanded = $client->expand_article( $html, [
				'suggested_title'    => $title,
				'primary_keyword'    => $focus_keyword ?: $topic,
				'word_count'         => $word_count,
				'current_word_count' => $current_words,
				'language'           => $language_label,
			] );
			$expanded_html = trim( (string) ( $expanded['html'] ?? '' ) );
			$expanded_html = preg_replace( '/^```(?:html)?\s*/i', '', $expanded_html );
			$expanded_html = preg_replace( '/\s*```$/', '', (string) $expanded_html );
			$new_words = (int) str_word_count( wp_strip_all_tags( $expanded_html ) );
			if ( '' === trim( wp_strip_all_tags( $expanded_html ) ) || $new_words <= $current_words ) {
				break;
			}
			$html = $expanded_html;
			$current_words = $new_words;
		}
		if ( '' !== trim( wp_strip_all_tags( $html ) ) && ! preg_match( '/[.!?]["\')\]]*\s*$/u', trim( wp_strip_all_tags( $html ) ) ) ) {
			$html .= '\n\n<h2>' . ( 'Nederlands' === $language_label ? 'Conclusie' : 'Conclusion' ) . '</h2><p>' . esc_html__( 'Final takeaway.', 'contentgem' ) . '.</p>';
		}
		$post_id = wp_insert_post( [
			'post_title' => $title,
			'post_content' => wp_kses_post( contentgem_clean_ai_article_output( $html, false ) ),
			'post_status' => 'draft',
			'post_type' => $content_type,
		], true );
		if ( is_wp_error( $post_id ) ) {
			throw new RuntimeException( $post_id->get_error_message() );
		}
		if ( '' !== $meta_desc ) {
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
			update_post_meta( $post_id, 'rank_math_description', $meta_desc );
		}
		update_post_meta( $post_id, '_contentgem_assistant_generated', '1' );
		$this->assign_cluster_metadata( (int) $post_id, (string) $cluster, array_filter( [ $focus_keyword, $topic ] ), (string) $title, (string) $html );
		$builder_integrator = new CGM_Builder_Integrator();
		$builder_mode = $builder_integrator->sync_generated_post(
			(int) $post_id,
			(string) $html,
			[
				'post_type'    => $content_type,
				'builder_mode' => sanitize_key( (string) ( $payload['builder_mode'] ?? 'auto' ) ),
			]
		);
		return [
			'wp_post_id' => (int) $post_id,
			'title' => $title,
			'meta_description' => $meta_desc,
			'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
			'builder_mode' => $builder_mode,
		];
	}



	public function assign_cluster_metadata( int $post_id, string $cluster, array $keywords = [], string $title = '', string $content = '' ): void {
		$cluster = trim( sanitize_text_field( $cluster ) );
		if ( $post_id <= 0 || '' === $cluster ) {
			return;
		}
		update_post_meta( $post_id, '_cgm_cluster', $cluster );
		if ( ! empty( $keywords ) ) {
			$primary_keyword = sanitize_text_field( (string) reset( $keywords ) );
			if ( '' !== $primary_keyword ) {
				update_post_meta( $post_id, '_cgm_primary_keyword', $primary_keyword );
				update_post_meta( $post_id, '_contentgem_focus_keyword', $primary_keyword );
			}
		}
		$category_id = $this->get_or_create_cluster_category_id( $cluster );
		if ( $category_id > 0 ) {
			wp_set_post_categories( $post_id, [ $category_id ], false );
		}
		$tag_names = $this->generate_cluster_tags( $cluster, $keywords, $title, $content );
		if ( ! empty( $tag_names ) ) {
			wp_set_post_terms( $post_id, $tag_names, 'post_tag', false );
		}
	}

	private function get_or_create_cluster_category_id( string $cluster ): int {
		$existing = get_term_by( 'name', $cluster, 'category' );
		if ( $existing && ! is_wp_error( $existing ) ) {
			return (int) $existing->term_id;
		}
		$created = wp_insert_term( $cluster, 'category' );
		if ( is_wp_error( $created ) ) {
			return 0;
		}
		return (int) ( $created['term_id'] ?? 0 );
	}

	private function generate_cluster_tags( string $cluster, array $keywords = [], string $title = '', string $content = '' ): array {
		$raw = [];
		$raw[] = $cluster;
		foreach ( $keywords as $keyword ) {
			if ( is_string( $keyword ) && '' !== trim( $keyword ) ) {
				$raw[] = $keyword;
			}
		}
		foreach ( preg_split( '/[,|]/', (string) $title ) as $piece ) {
			$piece = trim( wp_strip_all_tags( (string) $piece ) );
			if ( mb_strlen( $piece ) >= 4 && mb_strlen( $piece ) <= 40 ) {
				$raw[] = $piece;
			}
		}
		preg_match_all( '/[\p{L}\p{N}-]{4,}/u', mb_strtolower( wp_strip_all_tags( $content ) ), $m );
		$stop = [ 'this','that','with','from','have','your','voor','deze','deze','over','naar','from','into','worden','content','guide','build' ];
		$freq = array_count_values( $m[0] ?? [] );
		arsort( $freq );
		foreach ( array_keys( array_slice( $freq, 0, 8, true ) ) as $word ) {
			if ( ! in_array( $word, $stop, true ) ) {
				$raw[] = $word;
			}
		}
		$tags = [];
		foreach ( $raw as $value ) {
			$value = trim( preg_replace( '/\s+/', ' ', sanitize_text_field( (string) $value ) ) );
			if ( mb_strlen( $value ) < 3 || mb_strlen( $value ) > 40 ) {
				continue;
			}
			$key = mb_strtolower( $value );
			$tags[ $key ] = $value;
			if ( count( $tags ) >= 8 ) {
				break;
			}
		}
		return array_values( $tags );
	}

	private function derive_lsi_keywords( string $topic, string $cluster ): array {
		$pieces = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $topic . ' ' . $cluster ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		$pieces = array_filter( array_map( 'sanitize_text_field', $pieces ), static function( $word ) {
			return mb_strlen( $word ) > 2;
		} );
		return array_values( array_slice( array_unique( $pieces ), 0, 12 ) );
	}

	private function get_internal_links_for_cluster( string $cluster ): array {
		global $wpdb;
		if ( '' === $cluster ) {
			return [];
		}
		$topic = $wpdb->get_row( $wpdb->prepare( "SELECT post_ids FROM {$wpdb->prefix}cgm_topics WHERE cluster_name = %s ORDER BY coverage_score DESC LIMIT 1", $cluster ) );
		if ( ! $topic ) {
			return [];
		}
		$post_ids = json_decode( (string) $topic->post_ids, true );
		if ( ! is_array( $post_ids ) ) {
			return [];
		}
		$links = [];
		foreach ( array_slice( array_map( 'absint', $post_ids ), 0, 5 ) as $pid ) {
			$url = get_permalink( $pid );
			$title = get_the_title( $pid );
			if ( $url && $title ) {
				$links[] = [ 'title' => $title, 'url' => $url ];
			}
		}
		return $links;
	}

	private function get_cluster_pillar_pages( string $cluster ): array {
		$map = (array) get_option( 'contentgem_pillar_pages', [] );
		if ( '' === $cluster || empty( $map[ $cluster ] ) ) {
			return [];
		}
		$raw = $map[ $cluster ];
		$pid = is_array( $raw ) ? (int) ( $raw[0] ?? 0 ) : (int) $raw;
		$url = get_permalink( $pid );
		$title = get_the_title( $pid );
		return ( $url && $title ) ? [ [ 'title' => $title, 'url' => $url ] ] : [];
	}



	private function convert_faq_section_to_accordion( string $html ): string {
		if ( '' === trim( $html ) ) {
			return $html;
		}
		$pattern = '/(<h2[^>]*>\s*(?:Veelgestelde vragen|Frequently asked questions|FAQ)\s*<\/h2>)(.*?)(?=(<h2[^>]*>)|\z)/isu';
		return (string) preg_replace_callback( $pattern, static function( $m ) {
			$heading = (string) ( $m[1] ?? '' );
			$body = (string) ( $m[2] ?? '' );
			if ( preg_match( '/<details/i', $body ) ) {
				return $heading . $body;
			}
			if ( ! preg_match_all( '/<h3[^>]*>(.*?)<\/h3>\s*<p[^>]*>(.*?)<\/p>/isu', $body, $pairs, PREG_SET_ORDER ) ) {
				return $heading . $body;
			}
			$items = [];
			foreach ( $pairs as $pair ) {
				$q = trim( wp_strip_all_tags( (string) $pair[1] ) );
				$a = trim( (string) $pair[2] );
				if ( '' === $q || '' === trim( wp_strip_all_tags( $a ) ) ) {
					continue;
				}
				$items[] = '<details class="cgm-faq-item"><summary>' . esc_html( $q ) . '</summary><div class="cgm-faq-answer"><p>' . $a . '</p></div></details>';
			}
			return $items ? $heading . implode( "
", $items ) : $heading . $body;
		}, $html );
	}

	private function language_label_from_code( string $code ): string {
		$labels = [ 'nl' => 'Nederlands', 'en' => 'English', 'de' => 'Deutsch', 'fr' => 'Français', 'es' => 'Español', 'it' => 'Italiano', 'pt' => 'Português' ];
		return $labels[ strtolower( $code ) ] ?? strtoupper( strtolower( $code ) );
	}
}
