<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CGM_Differentiation_REST_Controller {
	protected CGM_Intelligence_Kernel $kernel;

	public function __construct( CGM_Intelligence_Kernel $kernel ) {
		$this->kernel = $kernel;
	}

	public function register_routes(): void {
		register_rest_route( CONTENTGEM_REST_NS, '/differentiation/analyze', [
			'methods' => 'POST',
			'callback' => [ $this, 'analyze' ],
			'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
		] );
	}

	public function analyze( WP_REST_Request $request ) {
		$params = is_array( $request->get_json_params() ) ? $request->get_json_params() : [];
		$title = sanitize_text_field( (string) ( $params['title'] ?? '' ) );
		$keyword = sanitize_text_field( (string) ( $params['keyword'] ?? '' ) );
		$brief = sanitize_textarea_field( (string) ( $params['brief'] ?? '' ) );
		$cluster_id = isset( $params['cluster_id'] ) ? (int) $params['cluster_id'] : 0;

		if ( '' === $title && '' === $keyword && '' === $brief ) {
			return new WP_Error( 'invalid_input', 'Provide a title, keyword or brief.', [ 'status' => 400 ] );
		}

		$data = $this->kernel->differentiation_service()->analyze_gap_against_existing_content( [
			'title' => $title,
			'keyword' => $keyword,
			'brief' => $brief,
			'cluster_id' => $cluster_id,
		] );

		return rest_ensure_response( [ 'success' => true, 'data' => $data ] );
	}
}
