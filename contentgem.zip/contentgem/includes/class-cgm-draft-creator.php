<?php
/**
 * Class CGM_Draft_Creator
 *
 * Haalt een gap op, bouwt context, genereert een volledig artikel via
 * CGM_Claude_Client en slaat het op als WordPress-concept.
 *
 * Flow:
 *  1. Laad gap, topic en site-rij uit de database.
 *  2. Bouw pillar pages en interne links uit cgm_topics.
 *  3. Haal h2_structure op via CGM_Claude_Client::suggest().
 *  4. Controleer token-budget (4 000 tokens).
 *  5. Genereer het artikel via CGM_Claude_Client::generate_draft() (streaming).
 *  6. Maak het WordPress-concept aan.
 *  7. Voer een kwaliteitscheck uit.
 *  8. Sla het resultaat op in cgm_drafts en update de gap-status.
 *  9. Schrijf tokens af.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Draft_Creator {

	private CGM_Claude_Client  $claude;
	private CGM_Token_Manager  $tokens;

	/** Geschat token-gebruik voor één draft-generatie. */
	private const DRAFT_TOKEN_ESTIMATE = 4000;

	/** Maximum pillar-pages en interne links meegestuurd naar Claude. */
	private const MAX_PILLAR_PAGES  = 5;
	private const MAX_INTERNAL_LINKS = 5;

	public function __construct( CGM_Claude_Client $claude, CGM_Token_Manager $tokens ) {
		$this->claude = $claude;
		$this->tokens = $tokens;
	}

	/**
	 * Maakt een WordPress-concept aan op basis van een gap.
	 *
	 * @param int      $gap_id   Rij-ID in cgm_gaps.
	 * @param callable $on_chunk fn(string $chunk): void — SSE-callback voor streaming.
	 * @return int WordPress post-ID van het aangemaakte concept.
	 * @throws \RuntimeException Bij ontbrekende data, onvoldoende budget of API-fouten.
	 */
	public function create( int $gap_id, callable $on_chunk ): int {
		global $wpdb;

		// ── 1. Laad gap ───────────────────────────────────────────────────────

		$gap = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_gaps WHERE id = %d",
				$gap_id
			)
		);

		if ( ! $gap ) {
			throw new \RuntimeException( sprintf( __( 'Gap #%d not found in cgm_gaps.', 'contentgem' ), $gap_id ) );
		}

		// ── 2. Laad topic ─────────────────────────────────────────────────────

		$topic = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_topics WHERE id = %d",
				(int) $gap->topic_id
			)
		);

		if ( ! $topic ) {
			$topic = $this->resolve_topic_for_gap( $gap );
		}

		if ( ! $topic ) {
			throw new \RuntimeException( sprintf( __( 'Topic #%d not found in cgm_topics.', 'contentgem' ), $gap->topic_id ) );
		}

		// ── 3. Laad site ──────────────────────────────────────────────────────

		$site = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_sites WHERE id = %d",
				(int) $topic->site_id
			)
		);

		if ( ! $site ) {
			throw new \RuntimeException( sprintf( __( 'Site for topic #%d not found in cgm_sites.', 'contentgem' ), $gap->topic_id ) );
		}

		// ── 4. Bouw pillar pages uit cgm_topics ───────────────────────────────

		$pillar_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT cluster_name, post_ids
				 FROM {$wpdb->prefix}cgm_topics
				 WHERE site_id = %d
				 ORDER BY coverage_score DESC
				 LIMIT %d",
				(int) $topic->site_id,
				self::MAX_PILLAR_PAGES
			)
		);

		$pillar_pages = [];
		foreach ( $pillar_rows as $row ) {
			$pids = json_decode( $row->post_ids ?? '[]', true );

			if ( ! is_array( $pids ) || empty( $pids ) ) {
				continue;
			}

			$post = get_post( (int) $pids[0] );

			if ( $post instanceof WP_Post ) {
				$pillar_pages[] = [
					'title' => $post->post_title,
					'url'   => get_permalink( $post->ID ),
				];
			}
		}

		// ── 5. Bouw basiscontext ──────────────────────────────────────────────

		$cluster_name = sanitize_text_field( (string) ( $topic->cluster_name ?? '' ) );
		$primary_keyword = $cluster_name ?: (string) $gap->suggested_title;
		$language_sample = implode( ' ', array_filter( [
			$primary_keyword,
			(string) $gap->suggested_title,
			(string) ( $site->niche_label ?? '' ),
			implode( ' ', (array) ( get_option( 'cgm_cluster_keywords', [] )[ $cluster_name ] ?? [] ) ),
		] ) );
		$forced_language = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		$forced_language = str_replace( '_', '-', $forced_language );
		if ( 'auto' !== $forced_language && preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $forced_language ) ) {
			$parts = explode( '-', $forced_language );
			$language_code = sanitize_key( $parts[0] );
		} else {
			$language_code = ( new CGM_NLP_Engine() )->detect_language( $language_sample );
		}
		$context = [
			'niche_label'   => $site->niche_label ?? '',
			'pillar_pages'  => $pillar_pages,
			'tone_snapshot' => $site->tone_snapshot ?? '',
			'tone_instructions' => ( ! empty( $site->tone_snapshot ) ? ( new CGM_Tone_Analyzer( CGM_AI_Client::from_settings() ) )->build_tone_instructions( (string) $site->tone_snapshot ) : '' ),
			'language'      => $this->language_label_from_code( $language_code ?: 'en' ),
			'gap_topic'     => $gap->suggested_title,
			'search_intent' => $gap->search_intent,
			'cluster_name'  => $cluster_name,
			'primary_keyword' => $primary_keyword,
			'competitor_insights' => $this->get_competitor_insights_for_cluster( $cluster_name ),
			'lsi_keywords'  => array_values( array_unique( array_filter( array_map( 'sanitize_text_field', array_merge( preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( (string) $gap->suggested_title ), -1, PREG_SPLIT_NO_EMPTY ) ?: [], json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true )[ $topic->cluster_name ?? '' ] ?? [] ) ) ) ) ),
		];

		// ── 6. Haal structuursuggestie op (h2_structure, woordtelling) ────────

		$suggestion     = $this->claude->suggest( $context );
		$suggest_tokens = (int) ( $suggestion['tokens_used'] ?? 0 );

		// ── 7. Controleer token-budget ────────────────────────────────────────

		if ( ! $this->tokens->is_budget_available( self::DRAFT_TOKEN_ESTIMATE ) ) {
			throw new \RuntimeException( __( 'Insufficient token budget for draft generation.', 'contentgem' ) );
		}

		// ── 8. Bouw interne links uit de topic-posts ──────────────────────────

		$topic_post_ids = json_decode( $topic->post_ids ?? '[]', true );
		$internal_links = [];

		if ( is_array( $topic_post_ids ) ) {
			foreach ( array_slice( $topic_post_ids, 0, self::MAX_INTERNAL_LINKS ) as $pid ) {
				$post = get_post( (int) $pid );

				if ( $post instanceof WP_Post ) {
					$internal_links[] = [
						'title' => $post->post_title,
						'url'   => get_permalink( $post->ID ),
					];
				}
			}
		}

		// ── 9. Breid context uit voor draft-generatie ─────────────────────────

		$context['suggested_title'] = $suggestion['title'] ?? $gap->suggested_title;
		$context['h2_structure']    = $suggestion['h2_structure'] ?? [];
		$suggested_words = (int) ( $suggestion['estimated_word_count'] ?? 0 );
		$context['word_count']      = max( 1400, $suggested_words, $this->extract_competitor_target_words( (string) $context['competitor_insights'] ) );
		$context['internal_links']  = $internal_links;

		// ── 10. Genereer artikel (streaming) ──────────────────────────────────

		$result           = $this->claude->generate_draft( $context, $on_chunk );
		$html             = ltrim( preg_replace( '/<h1[^>]*>.*?<\/h1>/is', '', $result['html'] ?? '', 1 ) );
		$html             = preg_replace( '/\n{3,}/', "\n\n", $html );
		$meta_from_claude = $result['meta'] ?? '';
		$draft_tokens     = (int) ( $result['tokens_used'] ?? 0 );
		$total_tokens = $suggest_tokens + $draft_tokens;
		$current_words = (int) str_word_count( wp_strip_all_tags( $html ) );
		$attempts = 0;
		while ( $attempts < 4 && $current_words < (int) floor( (int) $context['word_count'] * 0.9 ) ) {
			$attempts++;
			$expanded = $this->claude->expand_article( $html, [
				'suggested_title'    => $context['suggested_title'] ?? $gap->suggested_title,
				'primary_keyword'    => $context['primary_keyword'] ?? $gap->suggested_title,
				'word_count'         => $context['word_count'] ?? 1500,
				'current_word_count' => $current_words,
				'language'           => $context['language'] ?? '',
			] );
			$expanded_html = ltrim( preg_replace( '/<h1[^>]*>.*?<\/h1>/is', '', $expanded['html'] ?? '', 1 ) );
			$expanded_html = preg_replace( '/\n{3,}/', "\n\n", (string) $expanded_html );
			$new_words = (int) str_word_count( wp_strip_all_tags( $expanded_html ) );
			if ( '' === trim( wp_strip_all_tags( $expanded_html ) ) || $new_words <= $current_words ) {
				break;
			}
			$html = $expanded_html;
			$current_words = $new_words;
			$total_tokens += (int) ( $expanded['tokens_used'] ?? 0 );
		}

		// ── 11. Maak WordPress-concept aan ────────────────────────────────────

		$html = $this->convert_faq_section_to_accordion( (string) $html );
		$clean_title = function_exists( 'contentgem_clean_ai_title_output' ) ? contentgem_clean_ai_title_output( (string) $context['suggested_title'] ) : sanitize_text_field( strip_tags( (string) $context['suggested_title'] ) );
		$slug        = sanitize_title( $clean_title );

		$wp_post_id = wp_insert_post(
			[
				'post_title'   => sanitize_text_field( $clean_title ),
				'post_content' => wp_kses_post( contentgem_clean_ai_article_output( $html, false ) ),
				'post_status'  => 'draft',
				'post_type'    => 'post',
				'post_name'    => $slug,
			],
			true
		);

		if ( is_wp_error( $wp_post_id ) ) {
			throw new \RuntimeException(
				__( 'wp_insert_post failed: ', 'contentgem' ) . $wp_post_id->get_error_message()
			);
		}

		// Koppel gap_id als post-meta voor fallback-identificatie in get_drafts().
		update_post_meta( $wp_post_id, '_contentgem_gap_id', $gap_id );

		// ── 11b. SEO-meta: title, description, open graph ────────────────────

		// SEO title: max 60 tekens, geen afgebroken woord.
		$seo_title = function_exists( 'contentgem_clean_ai_title_output' ) ? contentgem_clean_ai_title_output( (string) $context['suggested_title'] ) : sanitize_text_field( (string) $context['suggested_title'] );
		if ( mb_strlen( $seo_title ) > 60 ) {
			$seo_title  = mb_substr( $seo_title, 0, 60 );
			$last_space = mb_strrpos( $seo_title, ' ' );
			if ( false !== $last_space ) {
				$seo_title = mb_substr( $seo_title, 0, $last_space );
			}
		}
		update_post_meta( $wp_post_id, '_yoast_wpseo_title', $seo_title );
		update_post_meta( $wp_post_id, 'rank_math_title', $seo_title );
		update_post_meta( $wp_post_id, '_aioseo_title', $seo_title );

		// Meta description: valideer Claude-versie, val terug op eerste alinea van content.
		$gap_words       = preg_split( '/\s+/u', mb_strtolower( sanitize_text_field( $gap->suggested_title ) ), -1, PREG_SPLIT_NO_EMPTY );
		$primary_keyword = $gap_words[0] ?? '';
		$meta_clean      = wp_strip_all_tags( $meta_from_claude );
		$meta_len        = mb_strlen( $meta_clean );
		$has_keyword     = '' !== $primary_keyword && str_contains( mb_strtolower( $meta_clean ), $primary_keyword );

		if ( $meta_len < 120 || $meta_len > 160 || ! $has_keyword ) {
			$first_para = strip_tags( substr( $html, 0, 500 ) );
			$meta_clean = substr( $first_para, 0, 155 );
			$last_space = strrpos( $meta_clean, ' ' );
			if ( false !== $last_space ) {
				$meta_clean = substr( $meta_clean, 0, $last_space );
			}
		}

		update_post_meta( $wp_post_id, '_yoast_wpseo_metadesc', $meta_clean );
		update_post_meta( $wp_post_id, 'rank_math_description', $meta_clean );
		update_post_meta( $wp_post_id, '_aioseo_description', $meta_clean );
		update_post_meta( $wp_post_id, '_yoast_wpseo_og_description', $meta_clean );
		update_post_meta( $wp_post_id, 'rank_math_facebook_description', $meta_clean );

		// ── 11c. Koppel aan WordPress-categorie en -tag ───────────────────────

		$cluster_terms = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_name  = $topic->cluster_name ?? '';

		if ( is_array( $cluster_terms ) && isset( $cluster_terms[ $cluster_name ] ) ) {
			$term_data = $cluster_terms[ $cluster_name ];

			if ( ! empty( $term_data['category_id'] ) ) {
				wp_set_post_categories( $wp_post_id, [ (int) $term_data['category_id'] ] );
			}

			if ( ! empty( $term_data['tag_id'] ) ) {
				wp_set_post_tags( $wp_post_id, [ $cluster_name ] );
			}
		}

		$this->cgm_assign_cluster_metadata( (int) $wp_post_id, (string) $cluster_name, array_filter( [ (string) $cluster_name, (string) ( $context['primary_keyword'] ?? '' ) ] ), (string) $clean_title, (string) $html );

		// ── 11d. Stel SEO-vriendelijke slug in (geen stopwoorden, max 60 tekens) ─

		$stopwords  = [ 'de', 'het', 'een', 'van', 'voor', 'met', 'bij', 'op', 'in', 'en', 'of', 'als', 'te', 'naar', 'is', 'zijn', 'over', 'door', 'uit', 'aan', 'om' ];
		$slug_words = preg_split( '/\s+/u', mb_strtolower( $context['suggested_title'] ), -1, PREG_SPLIT_NO_EMPTY );
		$slug_words = array_filter( $slug_words, static fn( $w ) => ! in_array( $w, $stopwords, true ) );
		$slug       = sanitize_title( implode( ' ', $slug_words ) );

		if ( mb_strlen( $slug ) > 60 ) {
			$slug      = mb_substr( $slug, 0, 60 );
			$last_dash = mb_strrpos( $slug, '-' );
			if ( false !== $last_dash ) {
				$slug = mb_substr( $slug, 0, $last_dash );
			}
		}

		wp_update_post( [
			'ID'        => $wp_post_id,
			'post_name' => $slug,
		] );

		// ── 11e. Fix ?p=ID links naar echte permalinks ────────────────────────

		$fixed_content = get_post_field( 'post_content', $wp_post_id );
		$fixed_content = preg_replace_callback(
			'/href=["\']([^"\']*\?p=(\d+))["\']/',
			function ( $matches ) {
				$linked_post_id = intval( $matches[2] );
				$permalink      = get_permalink( $linked_post_id );
				if ( $permalink ) {
					return 'href="' . esc_url( $permalink ) . '"';
				}
				return $matches[0];
			},
			$fixed_content
		);
		wp_update_post( [
			'ID'           => $wp_post_id,
			'post_content' => $fixed_content,
		] );

		// ── 11f. Builder sync voor native page builders ───────────────────────
		$builder_integrator = new CGM_Builder_Integrator();
		$builder_mode = $builder_integrator->sync_generated_post(
			(int) $wp_post_id,
			(string) $fixed_content,
			[
				'post_type'    => 'post',
				'builder_mode' => 'auto',
			]
		);
		update_post_meta( $wp_post_id, '_contentgem_builder_mode', $builder_mode );

		// ── 11g. Automatische interne links tijdens draft-creatie overslaan ──
		// Deze stap veroorzaakte merkbare vertraging nadat de AI-output al gereed was.
		// Interne links kunnen later nog via de optimizer/linkscanner worden toegevoegd.


		// ── 12. Sla op in cgm_drafts ─────────────────────────────────────────

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'cgm_drafts',
			[
				'gap_id'       => $gap_id,
				'wp_post_id'   => $wp_post_id,
				'tokens_spent' => $total_tokens,
			],
			[ '%d', '%d', '%d' ]
		);

		if ( false === $inserted ) {
			// Niet fataal — post is al aangemaakt, ga door.
		}

		// ── 14. Update gap-status naar in_progress ────────────────────────────

		$wpdb->update(
			$wpdb->prefix . 'cgm_gaps',
			[ 'status' => 'in_progress' ],
			[ 'id'     => $gap_id ],
			[ '%s' ],
			[ '%d' ]
		);

		// ── 15. Schrijf tokens af ─────────────────────────────────────────────

		$this->tokens->deduct( $total_tokens );

		// ── 16. Vuur WordPress-hook ───────────────────────────────────────────

		do_action( 'contentgem/draft_created', $wp_post_id, $gap_id );

		return $wp_post_id;
	}




	private function resolve_topic_for_gap( object $gap ) {
		global $wpdb;

		$site_id = 0;
		if ( isset( $gap->site_id ) ) {
			$site_id = (int) $gap->site_id;
		}
		if ( $site_id <= 0 ) {
			$site_id = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT site_id FROM {$wpdb->prefix}cgm_topics WHERE id = %d LIMIT 1", (int) $gap->topic_id )
			);
		}
		if ( $site_id <= 0 ) {
			$site_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}cgm_sites WHERE blog_id = %d LIMIT 1", get_current_blog_id() ) );
		}

		$cluster = $this->infer_cluster_name_for_gap_title( (string) ( $gap->suggested_title ?? '' ) );
		if ( '' === $cluster ) {
			return null;
		}

		$topic = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name = %s ORDER BY id ASC LIMIT 1",
				$site_id,
				$cluster
			)
		);

		if ( $topic ) {
			$wpdb->update(
				$wpdb->prefix . 'cgm_gaps',
				[ 'topic_id' => (int) $topic->id ],
				[ 'id' => (int) $gap->id ],
				[ '%d' ],
				[ '%d' ]
			);
		}

		return $topic;
	}

	private function infer_cluster_name_for_gap_title( string $title ): string {
		$title_lc = mb_strtolower( wp_strip_all_tags( $title ) );
		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$clusters = is_array( $clusters ) ? $clusters : [];
		$cluster_keywords = get_option( 'cgm_cluster_keywords', [] );
		$cluster_keywords = is_array( $cluster_keywords ) ? $cluster_keywords : [];

		$best_cluster = '';
		$best_score   = 0;
		foreach ( $clusters as $cluster ) {
			$cluster = sanitize_text_field( (string) $cluster );
			if ( '' === $cluster ) {
				continue;
			}
			$score = 0;
			$cluster_lc = mb_strtolower( $cluster );
			foreach ( preg_split( '/[^\p{L}\p{N}]+/u', $cluster_lc, -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $token ) {
				if ( mb_strlen( $token ) >= 4 && false !== mb_strpos( $title_lc, $token ) ) {
					$score += 3;
				}
			}
			foreach ( (array) ( $cluster_keywords[ $cluster ] ?? [] ) as $kw ) {
				$kw = mb_strtolower( sanitize_text_field( (string) $kw ) );
				if ( '' !== $kw && false !== mb_strpos( $title_lc, $kw ) ) {
					$score += 4;
				}
			}
			if ( $score > $best_score ) {
				$best_score = $score;
				$best_cluster = $cluster;
			}
		}
		return $best_score > 0 ? $best_cluster : '';
	}

	private function get_competitor_insights_for_cluster( string $cluster_name ): string {
		if ( '' === trim( $cluster_name ) ) {
			return '';
		}
		$cache_key = 'contentgem_comp_cache_' . md5( $cluster_name );
		$cached    = get_option( $cache_key, null );
		if ( ! is_array( $cached ) ) {
			return '';
		}
		$lines = [];
		if ( ! empty( $cached['avg_words'] ) ) {
			$lines[] = '- Target word count: ~' . (int) $cached['avg_words'] . ' words (competitor average)';
		}
		if ( ! empty( $cached['common_h2s'] ) && is_array( $cached['common_h2s'] ) ) {
			$lines[] = '- Topics covered by competitors: ' . implode( ', ', array_slice( $cached['common_h2s'], 0, 8 ) );
		}
		$elements = [];
		if ( ! empty( $cached['pct_faq'] ) && $cached['pct_faq'] >= 0.5 ) {
			$elements[] = 'FAQ section';
		}
		if ( ! empty( $cached['pct_table'] ) && $cached['pct_table'] >= 0.5 ) {
			$elements[] = 'comparison table';
		}
		if ( ! empty( $elements ) ) {
			$lines[] = '- Elements used by majority of competitors: ' . implode( ', ', $elements );
		}
		return implode( "
", $lines );
	}

	private function extract_competitor_target_words( string $insights ): int {
		if ( preg_match( '/Target word count:\s*~?(\d+)/i', $insights, $m ) ) {
			return max( 0, (int) $m[1] );
		}
		return 0;
	}


	private function language_label_from_code( string $code ): string {
		$labels = [ 'nl' => 'Dutch', 'en' => 'English', 'de' => 'German', 'fr' => 'French', 'es' => 'Spanish', 'it' => 'Italian', 'pt' => 'Portuguese' ];
		return $labels[ strtolower( $code ) ] ?? strtoupper( strtolower( $code ) );
	}

	private function cgm_assign_cluster_metadata( int $post_id, string $cluster, array $keywords = [], string $title = '', string $content = '' ): void {
		$cluster = trim( sanitize_text_field( $cluster ) );
		if ( $post_id <= 0 || '' === $cluster ) { return; }
		update_post_meta( $post_id, '_cgm_cluster', $cluster );
		if ( ! empty( $keywords ) ) {
			$primary_keyword = sanitize_text_field( (string) reset( $keywords ) );
			if ( '' !== $primary_keyword ) {
				update_post_meta( $post_id, '_cgm_primary_keyword', $primary_keyword );
				update_post_meta( $post_id, '_contentgem_focus_keyword', $primary_keyword );
			}
		}
		$term = get_term_by( 'name', $cluster, 'category' );
		if ( ! $term || is_wp_error( $term ) ) {
			$created = wp_insert_term( $cluster, 'category' );
			if ( ! is_wp_error( $created ) ) { $term = get_term( (int) ( $created['term_id'] ?? 0 ), 'category' ); }
		}
		if ( $term && ! is_wp_error( $term ) ) {
			wp_set_post_categories( $post_id, [ (int) $term->term_id ], false );
		}
		$tags = array_values( array_unique( array_filter( array_map( static function( $v ) { return sanitize_text_field( trim( (string) $v ) ); }, array_merge( [ $cluster ], $keywords ) ) ) ) );
		if ( ! empty( $tags ) ) {
			wp_set_post_terms( $post_id, array_slice( $tags, 0, 8 ), 'post_tag', false );
		}
	}



	private function convert_faq_section_to_accordion( string $html ): string {
		if ( '' === trim( $html ) ) {
			return $html;
		}
		$pattern = '/(<h2[^>]*>\s*(?:Veelgestelde vragen|Frequently asked questions|FAQ)\s*<\/h2>)(.*?)(?=(<h2[^>]*>)|\z)/isu';
		return (string) preg_replace_callback( $pattern, static function( $m ) {
			$heading = (string) ( $m[1] ?? '' );
			$body = (string) ( $m[2] ?? '' );
			if ( preg_match( '/<details/i', $body ) ) {
				return $heading . $body;
			}
			if ( ! preg_match_all( '/<h3[^>]*>(.*?)<\/h3>\s*<p[^>]*>(.*?)<\/p>/isu', $body, $pairs, PREG_SET_ORDER ) ) {
				return $heading . $body;
			}
			$items = [];
			foreach ( $pairs as $pair ) {
				$q = trim( wp_strip_all_tags( (string) $pair[1] ) );
				$a = trim( (string) $pair[2] );
				if ( '' === $q || '' === trim( wp_strip_all_tags( $a ) ) ) {
					continue;
				}
				$items[] = '<details class="cgm-faq-item"><summary>' . esc_html( $q ) . '</summary><div class="cgm-faq-answer"><p>' . $a . '</p></div></details>';
			}
			return $items ? $heading . implode( "
", $items ) : $heading . $body;
		}, $html );
	}

}
