<?php
defined( 'ABSPATH' ) || exit;

class CGM_Token_Optimizer {
	private CGM_Feature_Flags $flags;

	public function __construct( ?CGM_Feature_Flags $flags = null ) {
		$this->flags = $flags ?: new CGM_Feature_Flags();
	}

	public function optimize_task_config( array $task, array $context = [] ): array {
		if ( ! $this->flags->token_optimization_enabled() ) {
			$task['model'] = $task['model'] ?? $this->flags->default_model();
			return $task;
		}
		$task['model'] = $this->select_model( (string) ( $task['schema'] ?? '' ), $task, $context );
		$task['max_output_tokens'] = $this->select_output_limit( $task, $context );
		$task['reasoning_effort'] = $this->select_reasoning_effort( $task, $context );
		$task['service_tier'] = $this->select_service_tier( $task );
		$task['prompt_cache_key'] = $this->build_cache_key( $task, $context );
		$task['prompt_cache_retention'] = '24h';
		return $task;
	}

	private function select_model( string $task_name, array $task, array $context ): string {
		$profile = (string) ( $task['optimization_profile'] ?? '' );
		if ( 'article_html' === $profile ) {
			return $this->flags->default_model();
		}
		if ( false !== strpos( $task_name, 'semantic' ) || false !== strpos( $profile, 'compact' ) ) {
			return 'gpt-5.4-mini';
		}
		return $task['model'] ?? $this->flags->default_model();
	}

	private function select_output_limit( array $task, array $context ): int {
		$limit = (int) ( $task['max_output_tokens'] ?? 1200 );
		if ( ! empty( $context['short_mode'] ) ) {
			$limit = (int) max( 180, floor( $limit * 0.6 ) );
		}
		return $limit;
	}

	private function select_reasoning_effort( array $task, array $context ): string {
		$profile = $this->flags->reasoning_profile();
		if ( 'minimal' === $profile ) {
			return 'minimal';
		}
		if ( 'deep' === $profile ) {
			return 'medium';
		}
		$effort = (string) ( $task['reasoning_effort'] ?? 'low' );
		return in_array( $effort, [ 'minimal', 'low', 'medium', 'high' ], true ) ? $effort : 'low';
	}

	private function select_service_tier( array $task ): string {
		if ( ! empty( $task['supports_flex'] ) && $this->flags->flex_enabled() ) {
			return 'flex';
		}
		return 'auto';
	}

	private function build_cache_key( array $task, array $context ): string {
		$signature = [
			(string) ( $task['model'] ?? '' ),
			(string) ( $task['schema'] ?? '' ),
			(string) ( $task['optimization_profile'] ?? '' ),
			(array) ( $context['cache_hints'] ?? [] ),
		];
		return 'cgm_' . md5( wp_json_encode( $signature ) );
	}
}
