<?php
defined( 'ABSPATH' ) || exit;

class CGM_Codebase_Indexer {
	private CGM_Code_Symbol_Registry $symbols;
	private CGM_Codebase_Summarizer $summarizer;

	public function __construct() {
		$this->symbols = new CGM_Code_Symbol_Registry();
		$this->summarizer = new CGM_Codebase_Summarizer();
	}

	public function build_index(): array {
		$root = CONTENTGEM_DIR;
		$files = [];
		$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $iterator as $file ) {
			/** @var SplFileInfo $file */
			if ( ! $file->isFile() ) continue;
			$path = $file->getPathname();
			$relative = ltrim( str_replace( $root, '', $path ), '/\\' );
			if ( preg_match( '#^(vendor/(?!autoload\.php)|node_modules/|\.git/|assets/js/dist/|logs/)#', $relative ) ) continue;
			$ext = strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) );
			if ( ! in_array( $ext, [ 'php', 'js', 'ts', 'tsx', 'css', 'md', 'json' ], true ) ) continue;
			$contents = @file_get_contents( $path );
			if ( false === $contents ) continue;
			$record = [
				'path' => $relative,
				'type' => $this->detect_type( $relative, $ext ),
				'size' => (int) $file->getSize(),
				'modified' => gmdate( 'c', (int) $file->getMTime() ),
				'hash' => md5( $contents ),
				'symbols' => $this->symbols->extract_symbols( $relative, $contents ),
			];
			$record['summary'] = $this->summarizer->summarize( $record );
			$files[] = $record;
		}
		$index = [
			'version' => '1.0.0',
			'built_at' => gmdate( 'c' ),
			'root' => 'contentgem',
			'file_count' => count( $files ),
			'files' => $files,
		];
		update_option( 'cgm_codebase_index', $index, false );
		update_option( 'cgm_codebase_index_last_built', $index['built_at'], false );
		update_option( 'cgm_codebase_index_version', $index['version'], false );
		return $index;
	}

	public function get_index(): array {
		$index = get_option( 'cgm_codebase_index', [] );
		return is_array( $index ) ? $index : [];
	}

	private function detect_type( string $relative, string $ext ): string {
		if ( 'php' === $ext ) {
			if ( false !== strpos( $relative, 'admin/' ) ) return 'php_admin';
			if ( false !== strpos( $relative, 'includes/' ) ) return 'php_backend';
		}
		if ( in_array( $ext, [ 'js', 'ts', 'tsx' ], true ) ) return 'frontend';
		if ( 'css' === $ext ) return 'style';
		if ( 'md' === $ext ) return 'docs';
		return $ext ?: 'unknown';
	}
}
