<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Competitor_Service {
	protected CGM_SERP_Client $serp_client; protected CGM_SERP_Repository $serp_repo; protected CGM_Content_Parser $content_parser; protected CGM_Entity_Extractor $entity_extractor; protected CGM_Post_Repository $post_repo; protected CGM_Cluster_Repository $cluster_repo;
	public function __construct( CGM_SERP_Client $serp_client, CGM_SERP_Repository $serp_repo, CGM_Content_Parser $content_parser, CGM_Entity_Extractor $entity_extractor, CGM_Post_Repository $post_repo, CGM_Cluster_Repository $cluster_repo ) { $this->serp_client = $serp_client; $this->serp_repo = $serp_repo; $this->content_parser = $content_parser; $this->entity_extractor = $entity_extractor; $this->post_repo = $post_repo; $this->cluster_repo = $cluster_repo; }
	public function analyze_keyword( string $keyword, array $args = [] ): array {
		$snapshot = $this->fetch_serp_snapshot( $keyword, $args );
		$structure = $this->extract_competitor_structure( $snapshot );
		$own = $this->compare_against_own_content( $keyword, (int) ( $args['cluster_id'] ?? 0 ) );
		return [ 'keyword' => $keyword, 'snapshot' => $snapshot, 'structure' => $structure, 'comparison' => $own, 'outline' => $this->generate_superior_outline( $keyword, $structure ) ];
	}
	public function fetch_serp_snapshot( string $keyword, array $args = [] ): array {
		$locale = sanitize_text_field( (string) ( $args['locale'] ?? 'en' ) );
		$device = sanitize_text_field( (string) ( $args['device'] ?? 'desktop' ) );
		$cached = $this->serp_repo->get_latest_snapshot( $keyword, $locale, $device );
		if ( $cached ) { $cached['results'] = json_decode( (string) $cached['snapshot_json'], true ); return $cached; }
		$results = $this->serp_client->search( $keyword, $args );
		$this->serp_repo->create_snapshot( [ 'keyword_node_id' => null, 'query' => $keyword, 'locale' => $locale, 'device_type' => $device, 'snapshot_json' => wp_json_encode( $results ), 'created_at' => current_time( 'mysql', true ) ] );
		return [ 'query' => $keyword, 'locale' => $locale, 'device_type' => $device, 'results' => $results['results'] ?? [] ];
	}
	public function extract_competitor_structure( array $snapshot ): array {
		$out = [];
		$results = $snapshot['results'] ?? [];
		foreach ( array_slice( $results, 0, 5 ) as $item ) {
			$url = esc_url_raw( (string) ( $item['url'] ?? '' ) ); if ( ! $url ) { continue; }
			$response = wp_remote_get( $url, [ 'timeout' => 10, 'user-agent' => 'Mozilla/5.0 ContentGem/4.2' ] );
			if ( is_wp_error( $response ) ) { continue; }
			$html = (string) wp_remote_retrieve_body( $response );
			$text = $this->content_parser->extract_plain_text( $html );
			$out[] = [ 'url' => $url, 'title' => sanitize_text_field( (string) ( $item['title'] ?? '' ) ), 'headings' => $this->content_parser->extract_headings( $html ), 'entities' => $this->entity_extractor->extract_entities_from_text( mb_substr( $text, 0, 5000 ) ), 'word_count' => $this->content_parser->extract_word_count( $html ) ];
		}
		return $out;
	}
	public function compare_against_own_content( string $keyword, int $cluster_id = 0 ): array {
		$posts = $cluster_id > 0 ? $this->post_repo->get_posts_by_cluster( $cluster_id ) : $this->post_repo->get_published_posts();
		$matches = [];
		foreach ( $posts as $post ) { $haystack = strtolower( (string) $post->post_title . ' ' . wp_strip_all_tags( (string) $post->post_content ) ); if ( false !== strpos( $haystack, strtolower( $keyword ) ) ) { $matches[] = [ 'post_id' => (int) $post->ID, 'title' => (string) $post->post_title, 'url' => get_permalink( $post->ID ) ?: '' ]; } }
		return [ 'matching_posts' => $matches, 'coverage_count' => count( $matches ) ];
	}
	public function generate_superior_outline( string $keyword, array $competitor_data ): array {
		$entity_pool = []; $heading_pool = [];
		foreach ( $competitor_data as $row ) { foreach ( (array) ( $row['headings'] ?? [] ) as $h ) { $heading_pool[] = (string) ( $h['text'] ?? '' ); } $entity_pool = array_merge( $entity_pool, (array) ( $row['entities'] ?? [] ) ); }
		$entity_pool = array_values( array_unique( array_filter( $entity_pool ) ) );
		$outline = [ 'title' => 'Complete guide to ' . $keyword, 'sections' => [ 'What is ' . $keyword . '?', 'How ' . $keyword . ' works', 'Best practices for ' . $keyword, 'Common mistakes', 'Tools and examples', 'Action plan' ], 'recommended_entities' => array_slice( $entity_pool, 0, 12 ), 'reference_headings' => array_slice( array_values( array_unique( array_filter( $heading_pool ) ) ), 0, 12 ) ];
		return $outline;
	}
}
