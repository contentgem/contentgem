<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Content_Parser {
	public function extract_plain_text( string $html ): string { return trim( wp_strip_all_tags( $html, true ) ); }
	public function extract_headings( string $html ): array { preg_match_all( '/<h([1-6])[^>]*>(.*?)<\/h\1>/is', $html, $matches, PREG_SET_ORDER ); $headings = []; foreach ( $matches as $m ) { $headings[] = [ 'level' => (int) $m[1], 'text' => trim( wp_strip_all_tags( $m[2] ) ) ]; } return $headings; }
	public function extract_links( string $html ): array { preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER ); $links = []; foreach ( $matches as $m ) { $links[] = [ 'href' => esc_url_raw( $m[1] ), 'anchor' => trim( wp_strip_all_tags( $m[2] ) ) ]; } return $links; }
	public function extract_anchor_map( string $html ): array { $map = []; foreach ( $this->extract_links( $html ) as $link ) { $map[ $link['href'] ][] = $link['anchor']; } return $map; }
	public function extract_word_count( string $html ): int { return str_word_count( $this->extract_plain_text( $html ) ); }
}
