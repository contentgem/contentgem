<?php
defined( 'ABSPATH' ) || exit;

class CGM_OpenAI_Client {
	private const RESPONSES_API_URL = 'https://api.openai.com/v1/responses';
	private const CHAT_API_URL = 'https://api.openai.com/v1/chat/completions';
	private string $api_key;
	private CGM_Response_Parser $parser;
	private CGM_Analytics $analytics;

	public function __construct( string $api_key ) {
		$this->api_key = $api_key;
		$this->parser = new CGM_Response_Parser();
		$this->analytics = new CGM_Analytics();
	}

	public function create_response( string $task_name, array $task_config, array $payload ): array {
		$body = $this->build_responses_payload( $task_config, $payload );
		$response = wp_remote_post( self::RESPONSES_API_URL, [
			'timeout' => 120,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type' => 'application/json',
			],
			'body' => wp_json_encode( $body ),
		] );
		if ( is_wp_error( $response ) ) {
			return $this->fallback_chat( $task_name, $task_config, $payload, $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || ! is_array( $decoded ) ) {
			return $this->fallback_chat( $task_name, $task_config, $payload, is_array( $decoded ) ? (string) ( $decoded['error']['message'] ?? 'OpenAI Responses API error' ) : 'OpenAI Responses API error' );
		}
		$normalized = $this->normalize_responses_output( $decoded, $task_name );
		$this->analytics->log_request( $task_name, [
			'model' => $normalized['meta']['model'] ?? ( $task_config['model'] ?? '' ),
			'usage' => $normalized['usage'],
			'service_tier' => $task_config['service_tier'] ?? '',
			'grounded' => ! empty( $payload['grounded_context'] ),
		] );
		return $normalized;
	}

	private function build_responses_payload( array $task_config, array $payload ): array {
		$input = [];
		$instructions = (string) ( $payload['instructions'] ?? '' );
		if ( '' !== $instructions ) {
			$input[] = [ 'role' => 'developer', 'content' => [ [ 'type' => 'input_text', 'text' => $instructions ] ] ];
		}
		foreach ( (array) ( $payload['messages'] ?? [] ) as $message ) {
			$role = in_array( $message['role'] ?? '', [ 'user', 'assistant', 'developer', 'system' ], true ) ? $message['role'] : 'user';
			$text = (string) ( $message['content'] ?? '' );
			if ( '' === trim( $text ) ) continue;
			if ( 'system' === $role ) $role = 'developer';
			$input[] = [ 'role' => $role, 'content' => [ [ 'type' => 'input_text', 'text' => $text ] ] ];
		}
		if ( ! empty( $payload['grounded_context'] ) && is_array( $payload['grounded_context'] ) ) {
			$ground = wp_json_encode( $payload['grounded_context'] );
			$input[] = [ 'role' => 'developer', 'content' => [ [ 'type' => 'input_text', 'text' => 'Grounded codebase context: ' . $ground ] ] ];
		}
		$body = [
			'model' => (string) ( $task_config['model'] ?? 'gpt-5.4-mini' ),
			'input' => $input,
			'max_output_tokens' => (int) ( $task_config['max_output_tokens'] ?? 1200 ),
			'service_tier' => (string) ( $task_config['service_tier'] ?? 'auto' ),
			'prompt_cache_key' => (string) ( $task_config['prompt_cache_key'] ?? '' ),
			'prompt_cache_retention' => (string) ( $task_config['prompt_cache_retention'] ?? '24h' ),
		];
		if ( ! empty( $task_config['reasoning_effort'] ) ) {
			$body['reasoning'] = [ 'effort' => $task_config['reasoning_effort'] ];
		}
		if ( ! empty( $task_config['schema_payload'] ) ) {
			$body['text'] = [ 'format' => $task_config['schema_payload'] ];
		}
		return $body;
	}

	private function normalize_responses_output( array $decoded, string $task_name ): array {
		$output_text = '';
		$output_json = [];
		foreach ( (array) ( $decoded['output'] ?? [] ) as $item ) {
			foreach ( (array) ( $item['content'] ?? [] ) as $content ) {
				$type = (string) ( $content['type'] ?? '' );
				if ( 'output_text' === $type ) {
					$output_text .= (string) ( $content['text'] ?? '' );
				} elseif ( 'output_json' === $type && isset( $content['json'] ) && is_array( $content['json'] ) ) {
					$output_json = $content['json'];
				}
			}
		}
		if ( empty( $output_json ) && '' !== trim( $output_text ) ) {
			$decoded_json = json_decode( trim( $output_text ), true );
			if ( is_array( $decoded_json ) ) {
				$output_json = $decoded_json;
			}
		}
		$normalized = $this->parser->parse( [
			'output_text' => $output_text,
			'output_json' => $output_json,
			'usage' => $this->extract_usage( $decoded ),
			'model' => (string) ( $decoded['model'] ?? '' ),
			'request_id' => (string) ( $decoded['id'] ?? '' ),
		], $task_name );
		return $normalized;
	}

	public function extract_usage( array $decoded ): array {
		$usage = (array) ( $decoded['usage'] ?? [] );
		$input_tokens = (int) ( $usage['input_tokens'] ?? $usage['prompt_tokens'] ?? 0 );
		$output_tokens = (int) ( $usage['output_tokens'] ?? $usage['completion_tokens'] ?? 0 );
		return [
			'input_tokens' => $input_tokens,
			'output_tokens' => $output_tokens,
			'total_tokens' => (int) ( $usage['total_tokens'] ?? ( $input_tokens + $output_tokens ) ),
			'cached_tokens' => (int) ( $usage['input_tokens_details']['cached_tokens'] ?? 0 ),
			'reasoning_tokens' => (int) ( $usage['output_tokens_details']['reasoning_tokens'] ?? 0 ),
		];
	}

	private function fallback_chat( string $task_name, array $task_config, array $payload, string $reason ): array {
		$messages = [];
		if ( ! empty( $payload['instructions'] ) ) {
			$messages[] = [ 'role' => 'developer', 'content' => (string) $payload['instructions'] ];
		}
		foreach ( (array) ( $payload['messages'] ?? [] ) as $message ) {
			$messages[] = [
				'role' => in_array( $message['role'] ?? '', [ 'user', 'assistant', 'developer' ], true ) ? $message['role'] : 'user',
				'content' => (string) ( $message['content'] ?? '' ),
			];
		}
		if ( ! empty( $payload['grounded_context'] ) ) {
			$messages[] = [ 'role' => 'developer', 'content' => 'Grounded codebase context: ' . wp_json_encode( $payload['grounded_context'] ) ];
		}
		$body = [
			'model' => (string) ( $task_config['model'] ?? 'gpt-5.4-mini' ),
			'messages' => $messages,
			'max_completion_tokens' => (int) ( $task_config['max_output_tokens'] ?? 1200 ),
			'service_tier' => (string) ( $task_config['service_tier'] ?? 'auto' ),
		];
		if ( ! empty( $task_config['schema_payload'] ) ) {
			$body['response_format'] = $task_config['schema_payload'];
		}
		$response = wp_remote_post( self::CHAT_API_URL, [
			'timeout' => 120,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type' => 'application/json',
			],
			'body' => wp_json_encode( $body ),
		] );
		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( 'OpenAI error: ' . $reason . ' | ' . $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || ! is_array( $decoded ) ) {
			throw new RuntimeException( 'OpenAI error: ' . $reason );
		}
		$content = (string) ( $decoded['choices'][0]['message']['content'] ?? '' );
		$decoded_json = json_decode( trim( $content ), true );
		$normalized = $this->parser->parse( [
			'output_text' => $content,
			'output_json' => is_array( $decoded_json ) ? $decoded_json : [],
			'usage' => [
				'input_tokens' => (int) ( $decoded['usage']['prompt_tokens'] ?? 0 ),
				'output_tokens' => (int) ( $decoded['usage']['completion_tokens'] ?? 0 ),
				'total_tokens' => (int) ( $decoded['usage']['total_tokens'] ?? 0 ),
			],
			'model' => (string) ( $decoded['model'] ?? '' ),
			'request_id' => (string) ( $decoded['id'] ?? '' ),
		], $task_name );
		$this->analytics->log_request( $task_name, [
			'model' => $normalized['meta']['model'] ?? '',
			'usage' => $normalized['usage'],
			'service_tier' => $task_config['service_tier'] ?? '',
			'grounded' => ! empty( $payload['grounded_context'] ),
		] );
		return $normalized;
	}
}
