<?php
/**
 * Contentgem plan resolution helpers.
 *
 * Canonical tiers used throughout the plugin:
 *   - free       → Freemium default (max 4 clusters, AI Assistant + Content Gaps)
 *   - growth     → Paid "Pro" tier in marketing copy (unlimited clusters, all features)
 *   - unlimited  → Paid "Agency" tier in marketing copy (Growth features + multi-site)
 *
 * Freemius plan slugs ("free", "growth", "unlimited") and legacy aliases
 * ("starter", "pro", "agency") are all mapped here so that existing
 * customer licenses continue to resolve correctly.
 *
 * @package Contentgem
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolve the active plan slug for the current install.
 *
 * @return string One of: free, growth, unlimited.
 */
function cgm_get_plan(): string {
	// Developer override, only in debug builds.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$dev_plan = get_user_meta( get_current_user_id(), 'contentgem_tier', true );
		if ( in_array( $dev_plan, [ 'free', 'growth', 'unlimited' ], true ) ) {
			return $dev_plan;
		}
	}

	if ( ! function_exists( 'contentgem_fs' ) ) {
		return 'free';
	}

	try {
		$fs = contentgem_fs();
		if ( ! is_object( $fs ) ) {
			return 'free';
		}

		// === GATE 1: must actually be entitled to a paid tier ===
		//
		// Freemius's `is_plan('growth', true)` reports the *nominal* plan
		// configured on the product, NOT whether this install is paying for
		// it. A user who installed the plugin without a license can still
		// have `is_plan('growth') === true` if "growth" is the default plan
		// in the Freemius product configuration. We therefore require an
		// explicit entitlement signal — paying license, active trial, or
		// non-null license object — before we even look at the plan slug.
		//
		// If none of those is present, the user is Free, full stop.
		$has_entitlement = false;

		if ( method_exists( $fs, 'is_paying' ) && $fs->is_paying() ) {
			$has_entitlement = true;
		}
		if ( ! $has_entitlement && method_exists( $fs, 'is_trial' ) && $fs->is_trial() ) {
			$has_entitlement = true;
		}
		if ( ! $has_entitlement && method_exists( $fs, '_get_license' ) ) {
			try {
				$license = $fs->_get_license();
				if ( $license && is_object( $license ) && ! empty( $license->id ) ) {
					$has_entitlement = true;
				}
			} catch ( \Throwable $e ) {
				// Ignore — fall through to no-entitlement.
			}
		}

		// Belt-and-braces: explicit free-plan flag from Freemius wins.
		if ( method_exists( $fs, 'is_free_plan' ) && $fs->is_free_plan() ) {
			// Even if a stale `is_plan('growth')` would say otherwise,
			// is_free_plan() is the authoritative current-state flag.
			if ( ! $has_entitlement ) {
				return 'free';
			}
		}

		if ( ! $has_entitlement ) {
			return 'free';
		}

		// === GATE 2: entitled — now decide WHICH paid tier ===
		//
		// We prefer concrete signals (license plan_id) over slug checks,
		// because Freemius slug data can lag behind license activations.

		// Layer A: license plan_id is the strongest signal we have.
		if ( method_exists( $fs, '_get_license' ) ) {
			try {
				$license = $fs->_get_license();
				if ( $license && is_object( $license ) && isset( $license->plan_id ) ) {
					$plan_id = (int) $license->plan_id;
					if ( 45563 === $plan_id ) {
						return 'unlimited';
					}
					if ( in_array( $plan_id, [ 45313, 45557 ], true ) ) {
						return 'growth';
					}
				}
			} catch ( \Throwable $e ) {
				// Continue to slug-based fallback.
			}
		}

		// Layer B: explicit plan slug membership. Match highest tier first.
		if ( method_exists( $fs, 'is_plan' ) ) {
			if ( $fs->is_plan( 'unlimited', true ) || $fs->is_plan( 'agency', true ) ) {
				return 'unlimited';
			}
			if ( $fs->is_plan( 'growth', true )
				|| $fs->is_plan( 'pro', true )
				|| $fs->is_plan( 'starter', true ) ) {
				return 'growth';
			}
		}

		// Layer C: plan name string matching as a final fallback.
		if ( method_exists( $fs, 'get_plan_name' ) ) {
			$name = strtolower( (string) $fs->get_plan_name() );
			if ( false !== strpos( $name, 'unlimited' ) || false !== strpos( $name, 'agency' ) ) {
				return 'unlimited';
			}
			if ( false !== strpos( $name, 'growth' )
				|| false !== strpos( $name, 'pro' )
				|| false !== strpos( $name, 'starter' ) ) {
				return 'growth';
			}
		}

		// Entitled but no tier match — default a paying user to growth.
		return 'growth';

	} catch ( \Throwable $e ) {
		// Fall through to safe default.
	}

	return 'free';
}

/**
 * Human-readable plan label for UI surfaces.
 */
function cgm_get_plan_label(): string {
	switch ( cgm_get_plan() ) {
		case 'unlimited':
			return 'Unlimited';
		case 'growth':
			return 'Growth';
		case 'free':
		default:
			return 'Free';
	}
}
