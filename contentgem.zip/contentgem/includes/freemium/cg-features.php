<?php
/**
 * Contentgem feature gating map.
 *
 * Free tier (per product decision):
 *   - basic_dashboard   → Dashboard view, cluster table, coverage.
 *   - basic_clusters    → Create/edit up to 4 clusters (see cg-limits).
 *   - basic_settings    → Profile, AI provider, tone, keywords.
 *   - ai_assistant      → Full AI Assistant (title, meta, draft).
 *   - content_gaps      → Content Gap discovery & listing.
 *
 * Draft generation itself is unlimited on every tier (no feature flag).
 *
 * Growth tier (paid "Pro" in marketing): all Free features plus
 *   - competitor_analysis
 *   - internal_linking_automation
 *   - gsc_integration
 *   - optimizer
 *   - semantic_differentiation
 *   - saved_reports
 *   - authority_dashboard
 *   - bulk_analysis
 *   - priority_ui
 *   - indexation_monitor
 *
 * Unlimited tier (paid "Agency"): everything.
 *
 * @package Contentgem
 */

defined( 'ABSPATH' ) || exit;

/**
 * Returns whether the active plan has a given feature.
 */
function cgm_has_feature( string $feature ): bool {
	$plan = cgm_get_plan();

	$free_features = [
		'basic_dashboard',
		'basic_clusters',
		'basic_settings',
		'ai_assistant',
		'content_gaps',
	];

	$growth_features = array_merge( $free_features, [
		'competitor_analysis',
		'internal_linking_automation',
		'gsc_integration',
		'optimizer',
		'semantic_differentiation',
		'saved_reports',
		'authority_dashboard',
		'bulk_analysis',
		'priority_ui',
		'indexation_monitor',
	] );

	$features = [
		'free'      => $free_features,
		'growth'    => $growth_features,
		'unlimited' => [ 'all' ],
	];

	if ( ! isset( $features[ $plan ] ) ) {
		return false;
	}

	return in_array( 'all', $features[ $plan ], true )
		|| in_array( $feature, $features[ $plan ], true );
}

/**
 * Returns the flat list of features available on the active plan.
 * Useful for the React SPA to decide what to render/disable.
 *
 * @return string[]
 */
function cgm_get_active_features(): array {
	$all = [
		'basic_dashboard',
		'basic_clusters',
		'basic_settings',
		'ai_assistant',
		'content_gaps',
		'competitor_analysis',
		'internal_linking_automation',
		'gsc_integration',
		'optimizer',
		'semantic_differentiation',
		'saved_reports',
		'authority_dashboard',
		'bulk_analysis',
		'priority_ui',
		'indexation_monitor',
	];

	return array_values( array_filter( $all, 'cgm_has_feature' ) );
}
