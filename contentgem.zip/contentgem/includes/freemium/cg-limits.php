<?php
/**
 * Contentgem plan limits.
 *
 * Numeric limits per tier. A value of -1 means "unlimited".
 *
 * Tiers:
 *   - free       → 4 clusters, limited draft generation, full AI Assistant
 *                  + Content Gaps generation.
 *   - growth     → Unlimited clusters and drafts, competitor/reports caps.
 *   - unlimited  → All limits lifted, multi-site entitlement.
 *
 * @package Contentgem
 */

defined( 'ABSPATH' ) || exit;

/**
 * Returns the resolved limits for the active plan.
 *
 * @return array<string,int>
 */
function cgm_get_limits(): array {
	$plan = cgm_get_plan();

	$limits = [
		'free' => [
			'clusters'      => 4,
			'content_gaps'  => -1,  // Unlimited gap generation for Free.
			'competitors'   => 0,
			'saved_reports' => 0,
			'drafts'        => -1,  // Unlimited draft generation for Free.
			'sites'         => 1,
		],
		'growth' => [
			'clusters'      => -1,
			'content_gaps'  => -1,
			'competitors'   => 20,
			'saved_reports' => -1,
			'drafts'        => -1,
			'sites'         => 1,
		],
		'unlimited' => [
			'clusters'      => -1,
			'content_gaps'  => -1,
			'competitors'   => -1,
			'saved_reports' => -1,
			'drafts'        => -1,
			'sites'         => -1,
		],
	];

	return $limits[ $plan ] ?? $limits['free'];
}

/**
 * Shortcut for a single limit.
 *
 * @param string $key Limit key (clusters, drafts, competitors, ...).
 * @return int Limit value. -1 means unlimited.
 */
function cgm_get_limit( string $key ): int {
	$limits = cgm_get_limits();
	if ( ! isset( $limits[ $key ] ) ) {
		return 0;
	}
	return (int) $limits[ $key ];
}

/**
 * Whether the current user is allowed to add another cluster.
 *
 * @param int $current_count How many clusters the user already has.
 * @return bool
 */
function cgm_can_add_cluster( int $current_count ): bool {
	$limit = cgm_get_limit( 'clusters' );
	if ( $limit < 0 ) {
		return true; // Unlimited.
	}
	return $current_count < $limit;
}

/**
 * Human-readable cluster limit label for the UI.
 */
function cgm_get_cluster_limit_label(): string {
	$limit = cgm_get_limit( 'clusters' );
	if ( $limit < 0 ) {
		return 'unlimited';
	}
	return (string) $limit;
}
