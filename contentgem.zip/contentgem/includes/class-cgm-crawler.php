<?php
/**
 * Class CGM_Crawler
 *
 * Scant alle gepubliceerde posts en pagina's via WP_Query.
 * Verwerkt in batches van 100 via WP Cron.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Crawler {

	private int $site_id;
	private int $batch_size;

	public function __construct( int $site_id, int $batch_size = 100 ) {
		$this->site_id    = $site_id;
		$this->batch_size = apply_filters( 'contentgem/batch_size', $batch_size );
	}

	/**
	 * Start de analyse via WP Cron (async).
	 */
	public function run(): void {
		global $wpdb;

		// Markeer als bezig
		$wpdb->update(
			$wpdb->prefix . 'cgm_sites',
			[ 'analysis_status' => 'running' ],
			[ 'id' => $this->site_id ],
			[ '%s' ],
			[ '%d' ]
		);

		$offset = 0;
		do {
			$posts = $this->get_posts_batch( $offset );
			$offset += $this->batch_size;
		} while ( count( $posts ) === $this->batch_size );

		// Markeer als klaar
		$wpdb->update(
			$wpdb->prefix . 'cgm_sites',
			[ 'analysis_status' => 'done' ],
			[ 'id' => $this->site_id ],
			[ '%s' ],
			[ '%d' ]
		);

		do_action( 'contentgem/analysis_complete', $this->site_id );
	}

	/**
	 * Retourneert analysevoortgang als percentage.
	 */
	public function get_progress(): int {
		return 0;
	}

	/**
	 * Haalt een batch posts op.
	 *
	 * @param int $offset
	 * @return \WP_Post[]
	 */
	public function get_posts_batch( int $offset ): array {
		return get_posts( [
			'post_type'              => [ 'post', 'page' ],
			'post_status'            => 'publish',
			'posts_per_page'         => $this->batch_size,
			'offset'                 => $offset,
			'orderby'                => 'ID',
			'order'                  => 'ASC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'suppress_filters'       => true,
		] );
	}
}
