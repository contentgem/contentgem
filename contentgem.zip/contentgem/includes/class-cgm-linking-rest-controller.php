<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CGM_Linking_REST_Controller {
	protected CGM_Intelligence_Kernel $kernel;

	public function __construct( CGM_Intelligence_Kernel $kernel ) {
		$this->kernel = $kernel;
	}

	public function register_routes(): void {
		register_rest_route( CONTENTGEM_REST_NS, '/linking/suggest', [
			'methods' => 'POST',
			'callback' => [ $this, 'suggest' ],
			'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
		] );

		register_rest_route( CONTENTGEM_REST_NS, '/linking/orphans', [
			'methods' => 'GET',
			'callback' => [ $this, 'orphans' ],
			'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
		] );

		register_rest_route( CONTENTGEM_REST_NS, '/linking/insert', [
			'methods' => 'POST',
			'callback' => [ $this, 'insert' ],
			'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
		] );
	}

	public function suggest( WP_REST_Request $request ) {
		$params = is_array( $request->get_json_params() ) ? $request->get_json_params() : [];
		$content = (string) ( $params['content'] ?? '' );
		$limit = isset( $params['limit'] ) ? max( 1, min( 12, (int) $params['limit'] ) ) : 5;

		if ( '' === trim( $content ) ) {
			return new WP_Error( 'no_content', 'Content required.', [ 'status' => 400 ] );
		}

		$data = $this->kernel->linking_service()->suggest_links( $content, $limit );
		return rest_ensure_response( [ 'success' => true, 'data' => $data ] );
	}

	public function orphans( WP_REST_Request $request ) {
		$data = $this->kernel->linking_service()->detect_orphan_pages();
		return rest_ensure_response( [ 'success' => true, 'data' => $data ] );
	}

	public function insert( WP_REST_Request $request ) {
		$params = is_array( $request->get_json_params() ) ? $request->get_json_params() : [];
		$post_id = (int) ( $params['post_id'] ?? 0 );
		$suggestions = is_array( $params['suggestions'] ?? null ) ? $params['suggestions'] : [];

		if ( $post_id <= 0 || empty( $suggestions ) ) {
			return new WP_Error( 'invalid_request', 'Post ID and suggestions are required.', [ 'status' => 400 ] );
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'invalid_post', 'Post not found.', [ 'status' => 404 ] );
		}

		$updated = $this->kernel->linking_service()->insert_links_into_content( (string) $post->post_content, $suggestions );
		wp_update_post( [
			'ID' => $post_id,
			'post_content' => $updated,
		] );

		return rest_ensure_response( [ 'success' => true, 'data' => [ 'post_id' => $post_id ] ] );
	}
}
