<?php
defined( 'ABSPATH' ) || exit;

class CGM_Codebase_Grounder {
	private CGM_Codebase_Indexer $indexer;

	public function __construct( ?CGM_Codebase_Indexer $indexer = null ) {
		$this->indexer = $indexer ?: new CGM_Codebase_Indexer();
	}

	public function get_context_for_task( string $task, array $hints = [] ): array {
		$index = $this->indexer->get_index();
		if ( empty( $index['files'] ) ) {
			$index = $this->indexer->build_index();
		}
		$ranked = $this->rank_files_for_task( $task, (array) ( $index['files'] ?? [] ), $hints );
		$max_files = (int) get_option( 'cgm_codebase_grounding_max_files', 8 );
		$files = array_slice( $ranked, 0, max( 1, $max_files ) );
		return $this->build_grounded_context_bundle( $files );
	}

	public function rank_files_for_task( string $task, array $files, array $hints = [] ): array {
		$keywords = $this->task_keywords( $task, $hints );
		foreach ( $files as &$file ) {
			$score = 0;
			$haystack = strtolower( (string) $file['path'] . ' ' . wp_json_encode( $file['symbols'] ?? [] ) . ' ' . wp_json_encode( $file['summary'] ?? [] ) );
			foreach ( $keywords as $keyword ) {
				if ( false !== strpos( $haystack, strtolower( $keyword ) ) ) {
					$score += 10;
				}
			}
			$file['_score'] = $score;
		}
		unset( $file );
		usort( $files, static function( array $a, array $b ): int {
			return (int) ( $b['_score'] ?? 0 ) <=> (int) ( $a['_score'] ?? 0 );
		} );
		return $files;
	}

	public function build_grounded_context_bundle( array $files ): array {
		$bundle = [ 'files' => [], 'sources' => [] ];
		$max_chars = (int) get_option( 'cgm_codebase_grounding_max_chars', 12000 );
		$used = 0;
		foreach ( $files as $file ) {
			$summary = is_array( $file['summary'] ?? null ) ? (string) ( $file['summary']['summary'] ?? '' ) : '';
			$chunk = sprintf( "%s
Type: %s
Summary: %s", $file['path'], $file['type'], $summary );
			if ( $used + strlen( $chunk ) > $max_chars ) {
				break;
			}
			$used += strlen( $chunk );
			$bundle['files'][] = [
				'path' => $file['path'],
				'type' => $file['type'],
				'summary' => $summary,
				'symbols' => $file['symbols'] ?? [],
			];
			$bundle['sources'][] = [ 'label' => $file['path'], 'type' => 'code_file' ];
		}
		return $bundle;
	}

	private function task_keywords( string $task, array $hints ): array {
		$map = [
			'technical_build_plan' => [ 'settings', 'rest', 'admin', 'contentgem.php', 'ai', 'task', 'schema', 'openai' ],
			'ai_assistant_research' => [ 'assistant', 'draft', 'settings', 'ai', 'prompt', 'svg' ],
			'site_structure_recommendation' => [ 'site-structure', 'structure', 'page', 'settings' ],
			'cannibalization_semantic_check' => [ 'cannibalization', 'cluster', 'site_structure', 'page' ],
		];
		$keywords = $map[ $task ] ?? [ $task ];
		foreach ( $hints as $hint ) {
			if ( is_string( $hint ) && '' !== trim( $hint ) ) $keywords[] = $hint;
		}
		return array_values( array_unique( $keywords ) );
	}
}
