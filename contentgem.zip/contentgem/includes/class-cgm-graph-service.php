<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Graph_Service {
	protected CGM_Graph_Repository $graph_repo; protected CGM_Entity_Extractor $entity_extractor; protected CGM_Post_Repository $post_repo; protected CGM_Cluster_Repository $cluster_repo; protected CGM_Keyword_Repository $keyword_repo; protected CGM_Content_Parser $content_parser;
	public function __construct( CGM_Graph_Repository $graph_repo, CGM_Entity_Extractor $entity_extractor, CGM_Post_Repository $post_repo, CGM_Cluster_Repository $cluster_repo, CGM_Keyword_Repository $keyword_repo, CGM_Content_Parser $content_parser ) { $this->graph_repo = $graph_repo; $this->entity_extractor = $entity_extractor; $this->post_repo = $post_repo; $this->cluster_repo = $cluster_repo; $this->keyword_repo = $keyword_repo; $this->content_parser = $content_parser; }
	public function rebuild_graph_for_post( int $post_id ): void {
		$post = $this->post_repo->get_post( $post_id ); if ( ! $post ) { return; }
		$post_slug = 'post-' . $post_id;
		$post_node = $this->graph_repo->find_node( 'post', $post_slug );
		$node_id = $post_node ? (int) $post_node['id'] : $this->graph_repo->create_node( [ 'node_type' => 'post', 'wp_object_id' => $post_id, 'slug' => $post_slug, 'title' => sanitize_text_field( (string) $post->post_title ), 'status' => $post->post_status, 'meta_json' => wp_json_encode( [ 'url' => get_permalink( $post_id ) ?: '' ] ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ] );
		if ( $post_node ) { $this->graph_repo->update_node( $node_id, [ 'title' => sanitize_text_field( (string) $post->post_title ), 'status' => $post->post_status, 'meta_json' => wp_json_encode( [ 'url' => get_permalink( $post_id ) ?: '' ] ), 'updated_at' => current_time( 'mysql', true ) ] ); }
		$this->graph_repo->delete_edges_for_node( $node_id );
		$entities = $this->entity_extractor->extract_entities_from_post( $post_id );
		foreach ( $entities as $entity ) { $slug = sanitize_title( $entity ); $entity_node = $this->graph_repo->find_node( 'entity', $slug ); $entity_id = $entity_node ? (int) $entity_node['id'] : $this->graph_repo->create_node( [ 'node_type' => 'entity', 'slug' => $slug, 'title' => $entity, 'status' => 'active', 'meta_json' => wp_json_encode( [] ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ] ); $this->graph_repo->create_edge( [ 'from_node_id' => $node_id, 'to_node_id' => $entity_id, 'edge_type' => 'covers_entity', 'weight' => 1.0, 'meta_json' => wp_json_encode( [] ), 'created_at' => current_time( 'mysql', true ) ] ); }
		$clusters = $this->cluster_repo->get_all_clusters();
		foreach ( $clusters as $cluster ) {
			$post_ids = json_decode( (string) ( $cluster['post_ids'] ?? '[]' ), true );
			$post_ids = array_map( 'intval', is_array( $post_ids ) ? $post_ids : [] );
			if ( in_array( $post_id, $post_ids, true ) ) {
				$cluster_slug = 'cluster-' . (int) $cluster['id'];
				$cluster_node = $this->graph_repo->find_node( 'cluster', $cluster_slug );
				$cluster_node_id = $cluster_node ? (int) $cluster_node['id'] : $this->graph_repo->create_node( [ 'node_type' => 'cluster', 'slug' => $cluster_slug, 'title' => sanitize_text_field( (string) $cluster['cluster_name'] ), 'status' => 'active', 'meta_json' => wp_json_encode( [ 'cluster_id' => (int) $cluster['id'] ] ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ] );
				$this->graph_repo->create_edge( [ 'from_node_id' => $node_id, 'to_node_id' => $cluster_node_id, 'edge_type' => 'belongs_to_cluster', 'weight' => 1.0, 'meta_json' => wp_json_encode( [] ), 'created_at' => current_time( 'mysql', true ) ] );
			}
		}
	}
	public function rebuild_graph_for_cluster( int $cluster_id ): void { foreach ( $this->post_repo->get_posts_by_cluster( $cluster_id ) as $post ) { $this->rebuild_graph_for_post( (int) $post->ID ); } }
	public function get_cluster_graph( int $cluster_id ): array { return $this->graph_repo->get_graph_for_cluster( $cluster_id ); }
}
