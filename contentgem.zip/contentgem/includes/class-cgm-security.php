<?php
/**
 * Central security helpers for Contentgem.
 *
 * @package Contentgem
 */

defined( 'ABSPATH' ) || exit;

final class CGM_Security {
	public static function require_rest_nonce( WP_REST_Request $request ) {
		$method = strtoupper( (string) $request->get_method() );
		if ( in_array( $method, [ 'GET', 'HEAD', 'OPTIONS' ], true ) ) {
			return true;
		}

		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( empty( $nonce ) ) {
			$nonce = $request->get_param( '_wpnonce' );
		}
		$nonce = is_string( $nonce ) ? sanitize_text_field( wp_unslash( $nonce ) ) : '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error( 'rest_forbidden_nonce', __( 'Invalid or missing REST nonce.', 'contentgem' ), [ 'status' => 403 ] );
		}

		return true;
	}

	public static function require_capability( string $capability ) {
		if ( ! current_user_can( $capability ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}

		return true;
	}

	public static function validate_async_job_request( WP_REST_Request $request, array $allowed_types = [] ) {
		$body   = $request->get_json_params();
		$job_id = sanitize_text_field( (string) ( $body['job_id'] ?? $request->get_param( 'job_id' ) ?? '' ) );
		$token  = sanitize_text_field( (string) ( $body['token'] ?? $request->get_param( 'token' ) ?? '' ) );

		if ( '' === $job_id || '' === $token ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid async job token.', 'contentgem' ), [ 'status' => 403 ] );
		}

		$repo = new CGM_Job_Repository();
		$job  = $repo->get_by_key( $job_id );
		if ( is_array( $job ) && ! empty( $job ) ) {
			$stored_token = (string) ( $job['job_token'] ?? '' );
			if ( '' === $stored_token || ! hash_equals( $stored_token, $token ) ) {
				return new WP_Error( 'rest_forbidden', __( 'Invalid async job token.', 'contentgem' ), [ 'status' => 403 ] );
			}
			if ( ! empty( $allowed_types ) ) {
				$job_type = (string) ( $job['job_type'] ?? '' );
				if ( ! in_array( $job_type, $allowed_types, true ) ) {
					return new WP_Error( 'rest_forbidden', __( 'Invalid async job scope.', 'contentgem' ), [ 'status' => 403 ] );
				}
			}
			return [ 'job_id' => $job_id, 'job' => $job, 'source' => 'repository' ];
		}

		$legacy = get_option( 'cgm_job_' . $job_id, null );
		if ( ! is_array( $legacy ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid async job token.', 'contentgem' ), [ 'status' => 403 ] );
		}
		$stored_token = (string) ( $legacy['token'] ?? '' );
		if ( '' === $stored_token || ! hash_equals( $stored_token, $token ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid async job token.', 'contentgem' ), [ 'status' => 403 ] );
		}
		if ( ! empty( $allowed_types ) ) {
			$legacy_type = sanitize_key( (string) ( $legacy['type'] ?? '' ) );
			if ( '' !== $legacy_type && ! in_array( $legacy_type, $allowed_types, true ) ) {
				return new WP_Error( 'rest_forbidden', __( 'Invalid async job scope.', 'contentgem' ), [ 'status' => 403 ] );
			}
		}
		return [ 'job_id' => $job_id, 'job' => $legacy, 'source' => 'legacy' ];
	}

	public static function sanitize_gsc_property( $value ): string {
		$value = is_scalar( $value ) ? trim( sanitize_text_field( wp_unslash( (string) $value ) ) ) : '';
		if ( '' === $value ) {
			return '';
		}
		if ( 0 === strpos( $value, 'sc-domain:' ) ) {
			$host = substr( $value, strlen( 'sc-domain:' ) );
			$host = strtolower( preg_replace( '/[^a-z0-9.-]/i', '', (string) $host ) );
			return '' !== $host ? 'sc-domain:' . $host : '';
		}
		$url = esc_url_raw( $value, [ 'http', 'https' ] );
		if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
			return '';
		}
		return $url;
	}

	public static function sanitize_term_name( $value ): string {
		$value = sanitize_text_field( wp_unslash( (string) $value ) );
		return trim( preg_replace( '/\s+/u', ' ', $value ) );
	}
}
