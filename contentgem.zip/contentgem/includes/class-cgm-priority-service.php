<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Priority_Service {
	protected CGM_Authority_Service $authority_service; protected CGM_SERP_Repository $serp_repo; protected CGM_Competitor_Repository $competitor_repo;
	public function __construct( CGM_Authority_Service $authority_service, CGM_SERP_Repository $serp_repo, CGM_Competitor_Repository $competitor_repo ) { $this->authority_service = $authority_service; $this->serp_repo = $serp_repo; $this->competitor_repo = $competitor_repo; }
	public function rank_gap_opportunities( int $cluster_id, array $items ): array { usort( $items, function( $a, $b ) { return ( $b['impact_score'] ?? 0 ) <=> ( $a['impact_score'] ?? 0 ); } ); return $items; }
	public function calculate_impact_score( array $item ): float { return round( (float) ( $item['gap_weight'] ?? 1 ) * 25 + (float) ( $item['competitor_weight'] ?? 1 ) * 20 + (float) ( $item['coverage_weight'] ?? 1 ) * 15, 2 ); }
	public function get_priority_articles( int $cluster_id, int $limit = 5 ): array { $authority = $this->authority_service->calculate_cluster_authority( $cluster_id ); $items = []; foreach ( (array) $authority['missing_topics'] as $topic ) { $items[] = [ 'keyword' => $topic, 'impact_score' => $this->calculate_impact_score( [ 'gap_weight' => 2, 'competitor_weight' => 1.2, 'coverage_weight' => 1.5 ] ) ]; } return array_slice( $this->rank_gap_opportunities( $cluster_id, $items ), 0, $limit ); }
}
