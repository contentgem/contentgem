<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Link_Suggestion_Repository {
	private function table(): string { global $wpdb; return $wpdb->prefix . 'cgm_link_suggestions'; }
	public function create_suggestion( array $data ): int { global $wpdb; $data = array_merge( [ 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ], $data ); $wpdb->insert( $this->table(), $data ); return (int) $wpdb->insert_id; }
	public function get_suggestions_for_post( int $post_id ): array { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE source_post_id = %d ORDER BY confidence DESC", $post_id ), ARRAY_A ); }
	public function update_suggestion( int $suggestion_id, array $data ): bool { global $wpdb; $data['updated_at'] = current_time( 'mysql', true ); return false !== $wpdb->update( $this->table(), $data, [ 'id' => $suggestion_id ] ); }
	public function get_pending_suggestions(): array { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE status = %s ORDER BY id DESC", 'suggested' ), ARRAY_A ); }
}
