<?php
/**
 * Contentgem draft SVG parsing, sanitization, storage and rendering.
 */

defined( 'ABSPATH' ) || exit;

class CGM_Draft_SVG {
	public static function register_hooks(): void {
		add_filter( 'the_content', [ __CLASS__, 'filter_the_content' ], 9 );
		add_action( 'add_meta_boxes', [ __CLASS__, 'register_meta_box' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_editor_assets' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend_assets' ] );
	}

	public static function register_meta_box(): void {
		add_meta_box(
			'contentgem-draft-visuals',
			__( 'Contentgem Draft Visuals', 'contentgem' ),
			[ __CLASS__, 'render_meta_box' ],
			[ 'post', 'page' ],
			'normal',
			'default'
		);
	}

	public static function enqueue_editor_assets( string $hook ): void {
		if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
			return;
		}
		$path = CONTENTGEM_DIR . 'assets/css/admin.css';
		if ( file_exists( $path ) ) {
			wp_register_style( 'contentgem-draft-visuals', CONTENTGEM_URL . 'assets/css/admin.css', [], (string) filemtime( $path ) );
			wp_enqueue_style( 'contentgem-draft-visuals' );
		}
	}

	public static function enqueue_frontend_assets(): void {
		$path = CONTENTGEM_DIR . 'assets/css/admin.css';
		if ( file_exists( $path ) ) {
			wp_register_style( 'contentgem-draft-visuals', CONTENTGEM_URL . 'assets/css/admin.css', [], (string) filemtime( $path ) );
			wp_enqueue_style( 'contentgem-draft-visuals' );
		}
	}

	public static function render_meta_box( WP_Post $post ): void {
		$svgs = get_post_meta( $post->ID, '_cgm_draft_svgs', true );
		if ( ! is_array( $svgs ) || empty( $svgs ) ) {
			echo '<p>' . esc_html__( 'No Contentgem SVG visuals are stored for this draft yet.', 'contentgem' ) . '</p>';
			return;
		}
		$rendered = self::render_draft( (int) $post->ID );
		echo '<div class="cgm-draft-visual-preview">' . self::sanitize_rendered_html( $rendered ) . '</div>';
	}

	public static function filter_the_content( string $content ): string {
		if ( is_admin() ) {
			return $content;
		}

		$post_id = get_the_ID();
		if ( ! $post_id ) {
			return $content;
		}

		$text = get_post_meta( $post_id, '_cgm_draft_text', true );
		if ( ! is_string( $text ) || '' === trim( $text ) ) {
			return $content;
		}

		$rendered = self::render_draft( (int) $post_id );
		if ( '' === trim( $rendered ) ) {
			return $content;
		}

		// Fail-open safeguard:
		// if post_content already contains freshly inserted CGM reinsert links,
		// never overwrite it with stale draft render output.
		if (
			false !== strpos( $content, 'data-cgm-reinsert="1"' ) &&
			false === strpos( $rendered, 'data-cgm-reinsert="1"' )
		) {
			return $content;
		}

		return $rendered;
	}

	public static function parse_draft_response( string $response ): array {
		$svgs      = [];
		$captions  = [];
		$targets   = [];
		$draft_text = $response;

		preg_match_all(
			'/(?:<!--\s*cgm-insert-after:\s*(.*?)\s*-->)?\s*(<svg[\s\S]*?<\/svg>)\s*(?:<cgm-svg-caption>([\s\S]*?)<\/cgm-svg-caption>)?/i',
			$response,
			$matches,
			PREG_SET_ORDER
		);

		foreach ( $matches as $index => $match ) {
			$full    = (string) ( $match[0] ?? '' );
			$target  = sanitize_text_field( trim( (string) ( $match[1] ?? '' ) ) );
			$svg     = (string) ( $match[2] ?? '' );
			$caption = sanitize_text_field( trim( wp_strip_all_tags( (string) ( $match[3] ?? '' ) ) ) );
			if ( '' === trim( $svg ) ) {
				continue;
			}
			$svgs[]      = $svg;
			$captions[]  = $caption;
			$targets[]   = $target;
			$draft_text  = str_replace( $full, '<!-- cgm-svg-' . ( count( $svgs ) - 1 ) . ' -->', $draft_text );
		}

		return [
			'draft_text' => trim( $draft_text ),
			'svgs'       => $svgs,
			'captions'   => $captions,
			'targets'    => $targets,
		];
	}

	public static function sanitize_svg( string $svg ): string {
		$allowed = self::allowed_svg_html();
		$clean = wp_kses( $svg, $allowed );
		$clean = preg_replace( '/<\/?(?:script|foreignObject)\b[^>]*>/i', '', (string) $clean );
		$clean = preg_replace( "/\\son[a-z]+\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)/i", '', (string) $clean );
		$clean = preg_replace( "/\\s(?:href|xlink:href)\\s*=\\s*(\"https?:[^\"]*\"|'https?:[^']*'|https?:[^\\s>]+)/i", '', (string) $clean );
		return is_string( $clean ) ? trim( $clean ) : '';
	}

	private static function is_meaningful_svg( string $svg ): bool {
		$svg = trim( $svg );
		if ( '' === $svg || false === stripos( $svg, '<svg' ) ) {
			return false;
		}

		$shape_count = preg_match_all( '/<(?:circle|ellipse|rect|line|path|polyline|polygon)\b/i', $svg, $m );
		$text_count  = preg_match_all( '/<text\b/i', $svg, $t );
		$char_count  = mb_strlen( trim( wp_strip_all_tags( $svg ) ) );

		if ( $shape_count < 3 ) {
			return false;
		}

		if ( $shape_count <= 3 && $text_count >= 5 ) {
			return false;
		}

		if ( $char_count > 280 && $shape_count <= 4 ) {
			return false;
		}

		$text_plain  = mb_strtolower( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $svg ) ) ) );
		if ( preg_match( '/(?:pillar topic|topic coverage assessment|covered opportunity gap|sample internal link audit|cluster subtopic [a-z]|gap topic)/iu', $text_plain ) ) {
			return false;
		}
		return true;
	}

	public static function allowed_svg_html(): array {
		$common = [
			'class' => true,
			'id' => true,
			'fill' => true,
			'stroke' => true,
			'stroke-width' => true,
			'stroke-linecap' => true,
			'stroke-linejoin' => true,
			'opacity' => true,
			'transform' => true,
			'style' => true,
			'width' => true,
			'height' => true,
			'x' => true,
			'y' => true,
			'x1' => true,
			'x2' => true,
			'y1' => true,
			'y2' => true,
			'cx' => true,
			'cy' => true,
			'r' => true,
			'rx' => true,
			'ry' => true,
			'd' => true,
			'points' => true,
			'viewbox' => true,
			'viewBox' => true,
			'xmlns' => true,
			'font-family' => true,
			'font-size' => true,
			'font-weight' => true,
			'text-anchor' => true,
			'dominant-baseline' => true,
		];
		return [
			'svg' => $common,
			'g' => $common,
			'rect' => $common,
			'circle' => $common,
			'ellipse' => $common,
			'line' => $common,
			'path' => $common,
			'polyline' => $common,
			'polygon' => $common,
			'text' => $common,
			'tspan' => $common,
			'figure' => [ 'class' => true ],
			'figcaption' => [ 'class' => true ],
			'h1' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'h5' => [], 'h6' => [],
			'p' => [ 'class' => true ],
			'ul' => [ 'class' => true ],
			'ol' => [ 'class' => true ],
			'li' => [ 'class' => true ],
			'blockquote' => [ 'class' => true ],
			'table' => [ 'class' => true ],
			'thead' => [], 'tbody' => [], 'tr' => [], 'th' => [ 'colspan' => true, 'rowspan' => true ], 'td' => [ 'colspan' => true, 'rowspan' => true ],
			'a' => [ 'href' => true, 'target' => true, 'rel' => true ],
			'strong' => [], 'em' => [], 'br' => [], 'code' => [], 'pre' => [],
		];
	}

	public static function store_for_post( int $post_id, string $api_response, string $fallback_text = '' ): array {
		$parsed = self::parse_draft_response( $api_response );
		$svgs = [];
		foreach ( (array) ( $parsed['svgs'] ?? [] ) as $svg ) {
			$clean = self::sanitize_svg( (string) $svg );
			if ( '' !== $clean && self::is_meaningful_svg( $clean ) ) {
				$svgs[] = $clean;
			}
		}
		$captions = array_values( array_slice( array_map( 'sanitize_text_field', (array) ( $parsed['captions'] ?? [] ) ), 0, count( $svgs ) ) );
		$targets  = array_values( array_slice( array_map( 'sanitize_text_field', (array) ( $parsed['targets'] ?? [] ) ), 0, count( $svgs ) ) );
		$text     = trim( (string) ( $parsed['draft_text'] ?? '' ) );
		if ( '' === $text ) {
			$text = trim( $fallback_text );
		}
		if ( '' === $text ) {
			$text = trim( preg_replace( '/(<figure[\s\S]*?<\/figure>)|(<svg[\s\S]*?<\/svg>)|(<figcaption[\s\S]*?<\/figcaption>)|(<cgm-svg-caption>[\s\S]*?<\/cgm-svg-caption>)/i', '', $api_response ) );
		}
		$text = contentgem_clean_ai_article_output( $text, false );
		if ( ! empty( $svgs ) ) {
			$text = self::inject_placeholders_by_target( $text, $targets, count( $svgs ) );
		}
		update_post_meta( $post_id, '_cgm_draft_text', $text );
		update_post_meta( $post_id, '_cgm_draft_svgs', $svgs );
		update_post_meta( $post_id, '_cgm_draft_captions', $captions );
		update_post_meta( $post_id, '_cgm_draft_svg_targets', $targets );
		update_post_meta( $post_id, '_cgm_raw_response', $api_response );
		update_post_meta( $post_id, '_contentgem_cluster_svg', $svgs[0] ?? '' );
		update_post_meta( $post_id, '_contentgem_draft_text', $text );
		$rendered = ! empty( $svgs ) ? self::render_draft_html( $text, $svgs, $captions ) : wp_kses_post( $text );
		wp_update_post( [ 'ID' => $post_id, 'post_content' => $rendered ] );
		return [ 'draft_text' => $text, 'svgs' => $svgs, 'captions' => $captions, 'rendered' => $rendered ];
	}

	private static function inject_placeholders_by_target( string $text, array $targets, int $count ): string {
		for ( $i = 0; $i < $count; $i++ ) {
			$placeholder = '<!-- cgm-svg-' . $i . ' -->';
			if ( false !== strpos( $text, $placeholder ) ) {
				continue;
			}
			$target = trim( (string) ( $targets[ $i ] ?? '' ) );
			if ( '' !== $target ) {
				$pattern = '/(<h[23][^>]*>\s*' . preg_quote( $target, '/' ) . '\s*<\/h[23]>)/iu';
				$updated = preg_replace( $pattern, '$1\n' . $placeholder, $text, 1, $replaced );
				if ( ! empty( $replaced ) ) {
					$text = (string) $updated;
					continue;
				}
			}
			if ( preg_match( '/(<p[^>]*>.*?<\/p>)/is', $text, $m ) ) {
				$text = preg_replace( '/(<p[^>]*>.*?<\/p>)/is', '$1\n' . $placeholder, $text, 1 );
			} else {
				$text .= "\n\n" . $placeholder;
			}
		}
		return $text;
	}

	public static function render_draft( int $post_id ): string {
		$text = (string) get_post_meta( $post_id, '_cgm_draft_text', true );
		$svgs = get_post_meta( $post_id, '_cgm_draft_svgs', true );
		$captions = get_post_meta( $post_id, '_cgm_draft_captions', true );
		return self::render_draft_html( $text, is_array( $svgs ) ? $svgs : [], is_array( $captions ) ? $captions : [] );
	}

	public static function render_draft_html( string $text, array $svgs, array $captions ): string {
		$text = contentgem_clean_ai_article_output( $text, false );
		$rendered = preg_replace_callback(
			'/<!-- cgm-svg-(\d+) -->/',
			static function( array $matches ) use ( $svgs, $captions ): string {
				$i = (int) $matches[1];
				$svg = (string) ( $svgs[ $i ] ?? '' );
				if ( '' === $svg ) {
					return '';
				}
				$caption = '';
				if ( ! empty( $captions[ $i ] ) ) {
					$caption = '<figcaption>' . esc_html( (string) $captions[ $i ] ) . '</figcaption>';
				}
				return '<figure class="cgm-draft-svg">' . $svg . $caption . '</figure>';
			},
			$text
		);
		$rendered = preg_replace( '/<(p|div|span|li|blockquote)[^>]*>\s*(?:n|nn)\s*<\/\1>/iu', '', (string) $rendered );
		$rendered = preg_replace( '/(^|>)\s*(?:n|nn)\s*(?=<|$)/iu', '$1', (string) $rendered );
		return self::sanitize_rendered_html( (string) $rendered );
	}

	public static function sanitize_rendered_html( string $html ): string {
		return wp_kses( $html, self::allowed_svg_html() );
	}
}




if ( ! function_exists( 'contentgem_clean_ai_title_output' ) ) {
	function contentgem_clean_ai_title_output( string $title ): string {
		$title = html_entity_decode( (string) $title, ENT_QUOTES | ENT_HTML5 );
		$title = str_replace( [ "
", "
" ], "
", $title );
		$title = trim( wp_strip_all_tags( $title ) );
		$title = preg_replace( '/^```(?:html)?\s*/i', '', (string) $title );
		$title = preg_replace( '/\s*```$/', '', (string) $title );
		$title = preg_replace( '/^(?:n|nn)\s*[:\-–—]?\s*/iu', '', (string) $title );
		$title = preg_replace( '/^(?:html|```html)\s*/iu', '', (string) $title );
		$title = preg_replace( '/\s+/u', ' ', (string) $title );
		return trim( sanitize_text_field( (string) $title ) );
	}
}

if ( ! function_exists( 'contentgem_clean_ai_article_output' ) ) {
	function contentgem_clean_ai_article_output( string $content, bool $allow_svg = false ): string {
		$content = str_replace( [ "\r\n", "\r" ], "\n", $content );
		$content = trim( $content );
		$content = preg_replace( '/^```(?:html)?\s*/i', '', $content );
		$content = preg_replace( '/\s*```$/', '', (string) $content );
		$content = preg_replace( '/(?:^|\n)\s*(?:n|nn)?\s*`{1,3}\s*(?:html)?\s*(?=\n|$)/i', "\n", (string) $content );
		$content = preg_replace( '/`{1,3}\s*html\b/i', ' ', (string) $content );

		$content = preg_replace( '/^\s*(?:<p>\s*)?(?:n|nn)(?:\s*<\/p>)?\s*/iu', '', (string) $content );
		$content = preg_replace( '/<(p|div|span|li|blockquote)[^>]*>\s*(?:n|nn)\s*<\/\1>/iu', '', (string) $content );
		$content = preg_replace( '/(^|>)\s*(?:n|nn)\s*(?=<h[1-6]\b|<p\b|<div\b|<ul\b|<ol\b|<table\b|<blockquote\b|$)/iu', '$1', (string) $content );

		$content = preg_replace( '/<figcaption[\s\S]*?<\/figcaption>/i', '', (string) $content );
		$content = preg_replace( '/<figure[^>]*>[\s\S]*?<\/figure>/i', '', (string) $content );
		$content = preg_replace( '/<cgm-svg-caption>[\s\S]*?<\/cgm-svg-caption>/i', '', (string) $content );
		if ( ! $allow_svg ) {
			$content = preg_replace( '/<svg[\s\S]*?<\/svg>/i', '', (string) $content );
		}
		$content = preg_replace( '/<!--\s*cgm-svg-\d+\s*-->/i', '', (string) $content );
		$content = preg_replace( '/<!--\s*cgm-insert-after:.*?-->/is', '', (string) $content );

		$plain = html_entity_decode( wp_strip_all_tags( (string) $content ), ENT_QUOTES | ENT_HTML5 );
		$lines = preg_split( '/\n+/', $plain ) ?: [];
		$lines = array_values( array_filter( array_map( static function( $line ) {
			return trim( preg_replace( '/\s+/u', ' ', (string) $line ) );
		}, $lines ), static function( $line ) { return '' !== $line; } ) );

		$suffix = [];
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) {
			$line = $lines[ $i ];
			$is_percent = (bool) preg_match( '/^\d{1,3}%$/', $line );
			$is_short   = (bool) preg_match( '/^[\p{L}\p{N}][\p{L}\p{N}\s&+\-≤≥]{0,38}$/u', $line );
			$is_visual  = (bool) preg_match( '/\b(?:diagram|architecture|coverage|cluster|semantic|topical|audit|legend|pillar|entity|knowledge graph|schema|internal linking|anchor text|click depth|orphan pages|topic coverage|subtopic|supporting|gap topic|covered|opportunity|gap)\b/iu', $line );
			if ( $is_percent || $is_visual || $is_short ) {
				array_unshift( $suffix, $line );
				continue;
			}
			break;
		}

		if ( count( $suffix ) >= 3 ) {
			$content = preg_replace(
				'/(?:<(?:p|li|div|span|figcaption)[^>]*>\s*)?(?:(?:pillar page|supporting|gap topic|covered|opportunity|anchor text variety|click depth|orphan pages fixed|topic coverage assessment|entity coverage|cluster depth|internal linking|schema markup|knowledge graph)|\d{1,3}%|[A-Z][A-Za-z\s&+\-≤≥]{0,38})(?:\s*<\/(?:p|li|div|span|figcaption)>)?\s*$/iu',
				'',
				(string) $content
			);
		}

		$content = preg_replace( '/(^|>)\s*(?:n|nn)\s*(?=<|$)/iu', '$1', (string) $content );
		$content = preg_replace( '/(?:<p>\s*<\/p>\s*){1,}/i', '', (string) $content );
		$content = preg_replace( '/\n{3,}/', "\n\n", (string) $content );
		return trim( (string) $content );
	}
}

if ( ! function_exists( 'contentgem_parse_draft_response' ) ) {
	function contentgem_parse_draft_response( string $response ): array {
		return CGM_Draft_SVG::parse_draft_response( $response );
	}
}

if ( ! function_exists( 'contentgem_render_draft' ) ) {
	function contentgem_render_draft( int $post_id ): string {
		return CGM_Draft_SVG::render_draft( $post_id );
	}
}
