<?php
/**
 * Class CGM_Token_Manager
 *
 * Beheert het Claude API token-budget per gebruiker.
 *
 * Wanneer de gebruiker een eigen Anthropic API key heeft ingesteld,
 * worden er GEEN limieten afgedwongen — tokens worden alleen geteld
 * voor statistische doeleinden.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Token_Manager {

/**
	 * Token-limieten per tier — geen limieten, alleen tracking voor statistieken.
	 * Onderscheid tussen plannen zit in aantal websites (starter = 1, agency = unlimited).
	 */
	private const TIER_LIMITS = [
		'free'      => PHP_INT_MAX,
		'starter'   => PHP_INT_MAX,
		'growth'    => PHP_INT_MAX,
		'unlimited' => PHP_INT_MAX,
	];

	private int $user_id;

	public function __construct( int $user_id ) {
		$this->user_id = $user_id;
	}

	/**
	 * Controleert of er voldoende budget beschikbaar is.
	 *
	 * Wanneer de gebruiker een eigen API key heeft: altijd true.
	 * Zonder eigen key: vergelijk met tier-limiet.
	 *
	 * @param int $estimated_tokens Geschatte tokens die nodig zijn.
	 */
	public function is_budget_available( int $estimated_tokens = 1000 ): bool {
		return true; // Geen token limieten — onderscheid zit in aantal websites per plan.
	}

	/**
	 * Schrijft tokens af voor statistische tracking.
	 * Gooit geen exception wanneer de gebruiker een eigen API key heeft.
	 *
	 * @param int $tokens Aantal verbruikte tokens.
	 * @throws \RuntimeException Als budget overschreden wordt (alleen zonder eigen API key).
	 */
	public function deduct( int $tokens ): void {
		global $wpdb;

		if ( ! $this->has_own_api_key() && ! $this->is_budget_available( $tokens ) ) {
			throw new \RuntimeException( __( 'Token budget exceeded.', 'contentgem' ) );
		}

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}cgm_token_usage
				 SET tokens_used = tokens_used + %d
				 WHERE user_id = %d",
				$tokens,
				$this->user_id
			)
		);

		if ( ! $this->has_own_api_key() ) {
			$this->send_alert_if_needed();
		}
	}

	/**
	 * Retourneert het huidige saldo.
	 *
	 * @return array{used: int, limit: int, remaining: int, percent_used: float,
	 *               reset_date: string, tier: string, has_own_api_key: bool,
	 *               estimated_drafts_remaining: int}
	 */
	public function get_balance(): array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_token_usage WHERE user_id = %d",
				$this->user_id
			)
		);

		if ( ! $row ) {
			$this->ensure_record();
			return $this->get_balance();
		}

		// Controleer of reset nodig is.
		if ( $row->reset_date <= current_time( 'Y-m-d' ) ) {
			$this->reset();
			return $this->get_balance();
		}

		$has_own_key = $this->has_own_api_key();
		$used        = (int) $row->tokens_used;
		$limit       = (int) $row->tokens_limit;
		$remaining   = PHP_INT_MAX;

		return [
			'used'                       => $used,
			'limit'                      => $limit,
			'remaining'                  => $remaining,
			'percent_used'               => ( ! $has_own_key && $limit > 0 ) ? round( ( $used / $limit ) * 100, 1 ) : 0,
			'reset_date'                 => $row->reset_date,
			'tier'                       => $this->get_tier(),
			'has_own_api_key'            => $has_own_key,
			'estimated_drafts_remaining' => function_exists( 'cgm_get_free_articles_remaining' ) ? cgm_get_free_articles_remaining( $this->user_id ) : 9999,
		];
	}

	/**
	 * Geeft de tier van de huidige gebruiker terug op basis van Freemius.
	 */
	public function get_tier(): string {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$dev_tier = get_user_meta( $this->user_id, 'contentgem_tier', true );
			if ( in_array( $dev_tier, [ 'starter', 'growth', 'unlimited' ], true ) ) {
				return $dev_tier;
			}
		}

		return $this->get_tier_from_freemius();
	}

	/**
	 * Controleert of de gebruiker een eigen Anthropic API key heeft ingesteld.
	 */
	public function has_own_api_key(): bool {
		return ! empty( get_option( 'contentgem_api_key', '' ) );
	}

	/**
	 * Reset het token-budget (aangeroepen door Freemius webhook).
	 */
	public function reset(): void {
		global $wpdb;

		$tier  = $this->get_tier_from_freemius();
		$limit = self::TIER_LIMITS[ $tier ] ?? self::TIER_LIMITS['free'];

		$wpdb->update(
			$wpdb->prefix . 'cgm_token_usage',
			[
				'tokens_used'  => 0,
				'tokens_limit' => $limit,
				'tier'         => $tier,
				'reset_date'   => gmdate( 'Y-m-d', strtotime( '+1 month' ) ),
			],
			[ 'user_id' => $this->user_id ],
			[ '%d', '%d', '%s', '%s' ],
			[ '%d' ]
		);
	}

	/**
	 * Verstuurt alert-e-mail bij 75% en 90% verbruik (alleen zonder eigen API key).
	 */
	public function send_alert_if_needed(): void {
		$balance   = $this->get_balance();
		$pct       = $balance['percent_used'];
		$user_data = get_userdata( $this->user_id );
		$email     = ( $user_data instanceof \WP_User ) ? $user_data->user_email : '';

		foreach ( [ 90, 75 ] as $threshold ) {
			$key = "cgm_alert_{$threshold}_{$this->user_id}";
			if ( $pct >= $threshold && ! get_transient( $key ) ) {
				wp_mail(
					$email,
					sprintf( __( 'ContentGem: %d%% of token budget used', 'contentgem' ), $threshold ),
					sprintf(
						__( 'You have used %d%% of your monthly AI budget. Remaining: %d tokens.', 'contentgem' ),
						$threshold,
						$balance['remaining']
					)
				);
				set_transient( $key, 1, 3 * DAY_IN_SECONDS );
				break;
			}
		}
	}

	/**
	 * Bepaalt de tier van de huidige gebruiker via Freemius of fallback.
	 */
	private function get_user_tier(): string {
		return $this->get_tier_from_freemius();
	}

	/**
	 * Detecteert het Freemius-plan en vertaalt dit naar een tier-string.
	 */

private function get_tier_from_freemius(): string {
	if ( function_exists( 'cgm_get_plan' ) ) {
		$plan = cgm_get_plan();
		if ( in_array( $plan, [ 'free', 'starter', 'growth', 'unlimited' ], true ) ) {
			return $plan;
		}
	}

	// Fallback: lees uit user meta (handig tijdens ontwikkeling).
	$tier = get_user_meta( $this->user_id, 'contentgem_tier', true );
	return in_array( $tier, [ 'free', 'starter', 'growth', 'unlimited' ], true ) ? $tier : 'free';
}

	/**
	 * Maakt een nieuw token-record aan als dat nog niet bestaat.
	 */
	private function ensure_record(): void {
		global $wpdb;

		$tier  = $this->get_user_tier();
		$limit = self::TIER_LIMITS[ $tier ] ?? self::TIER_LIMITS['free'];

		$wpdb->insert(
			$wpdb->prefix . 'cgm_token_usage',
			[
				'user_id'      => $this->user_id,
				'tier'         => $tier,
				'tokens_used'  => 0,
				'tokens_limit' => $limit,
				'reset_date'   => gmdate( 'Y-m-d', strtotime( '+1 month' ) ),
			],
			[ '%d', '%s', '%d', '%d', '%s' ]
		);
	}
}
