<?php
defined( 'ABSPATH' ) || exit;

class CGM_Response_Parser {
	public function parse( array $response, string $task_name = '' ): array {
		$content = '';
		$structured = [];
		if ( isset( $response['output_json'] ) && is_array( $response['output_json'] ) ) {
			$structured = $response['output_json'];
		}
		if ( isset( $response['output_text'] ) ) {
			$content = (string) $response['output_text'];
		} elseif ( isset( $response['text'] ) ) {
			$content = (string) $response['text'];
		}
		$sources = [];
		if ( isset( $structured['sources'] ) && is_array( $structured['sources'] ) ) {
			$sources = ( new CGM_Source_Manager() )->normalize_sources( $structured['sources'] );
			unset( $structured['sources'] );
		}
		return [
			'success' => true,
			'data' => $structured,
			'content' => $content,
			'sources' => $sources,
			'usage' => isset( $response['usage'] ) && is_array( $response['usage'] ) ? $response['usage'] : [],
			'meta' => [
				'model' => (string) ( $response['model'] ?? '' ),
				'task' => $task_name,
				'request_id' => (string) ( $response['request_id'] ?? '' ),
			],
		];
	}
}
