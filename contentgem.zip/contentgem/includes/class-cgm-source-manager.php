<?php
defined( 'ABSPATH' ) || exit;

class CGM_Source_Manager {
	public function normalize_sources( array $sources ): array {
		$normalized = [];
		foreach ( $sources as $source ) {
			if ( ! is_array( $source ) ) {
				continue;
			}
			$label = sanitize_text_field( (string) ( $source['label'] ?? '' ) );
			$url = esc_url_raw( (string) ( $source['url'] ?? '' ) );
			$type = sanitize_key( (string) ( $source['type'] ?? 'reference' ) );
			if ( '' === $label ) {
				continue;
			}
			$normalized[] = [
				'label' => $label,
				'url' => $url,
				'type' => $type ?: 'reference',
			];
		}
		return $this->dedupe_sources( $normalized );
	}

	public function dedupe_sources( array $sources ): array {
		$out = [];
		$seen = [];
		foreach ( $sources as $source ) {
			$key = strtolower( trim( (string) ( $source['label'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $source['url'] ?? '' ) ) );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[] = $source;
		}
		return $out;
	}
}
