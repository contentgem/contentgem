<?php
defined( 'ABSPATH' ) || exit;

class CGM_Code_Symbol_Registry {
	public function extract_symbols( string $path, string $contents ): array {
		$classes = [];
		$functions = [];
		$routes = [];
		$options = [];
		$hooks = [];
		if ( preg_match_all( '/class\s+([A-Za-z_][A-Za-z0-9_]*)/', $contents, $matches ) ) {
			$classes = array_values( array_unique( $matches[1] ) );
		}
		if ( preg_match_all( '/function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/', $contents, $matches ) ) {
			$functions = array_values( array_unique( $matches[1] ) );
		}
		if ( preg_match_all( "/register_rest_route\\s*\\([^,]+,\\s*['\"]([^'\"]+)['\"]/", $contents, $matches ) ) {
			$routes = array_values( array_unique( $matches[1] ) );
		}
		if ( preg_match_all( "/(?:get_option|update_option|delete_option|register_setting)\\s*\\(\\s*['\"]([^'\"]+)['\"]/", $contents, $matches ) ) {
			$options = array_values( array_unique( $matches[1] ) );
		}
		if ( preg_match_all( "/(?:do_action|apply_filters|add_action|add_filter)\\s*\\(\\s*['\"]([^'\"]+)['\"]/", $contents, $matches ) ) {
			$hooks = array_values( array_unique( $matches[1] ) );
		}
		return [
			'classes' => $classes,
			'functions' => $functions,
			'rest_routes' => $routes,
			'options' => $options,
			'hooks' => $hooks,
		];
	}
}
