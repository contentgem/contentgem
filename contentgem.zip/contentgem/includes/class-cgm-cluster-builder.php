<?php
/**
 * Class CGM_Cluster_Builder
 *
 * Groepeert alle gepubliceerde posts in semantische clusters op basis van
 * keywords van CGM_NLP_Engine, berekent een coverage_score per cluster
 * en slaat de resultaten op in de {prefix}cgm_topics tabel.
 *
 * Clustering-algoritme (zonder externe ML):
 *  1. Extract keywords per post via CGM_NLP_Engine.
 *  2. Bouw een inverteerde index: keyword → [post_ids].
 *  3. Keywords die in ≥2 posts voorkomen worden cluster-seeds (gesorteerd
 *     op documentfrequentie, meest voorkomende eerst).
 *  4. Wijs elke post toe aan het cluster waarmee hij de meeste keyword-
 *     overlap heeft. Ongeplaatste posts vormen een eigen singleton-cluster.
 *
 * Clusternaam:
 *  - Afgeleid uit post-titels (niet keywords) via woordfrequentie.
 *  - Meest voorkomend zelfstandig naamwoord in de titels, max 2 woorden.
 *  - Clusters met dezelfde naam worden samengevoegd.
 *
 * Coverage-score (0.0 – 1.0):
 *  - Diepte (60 %): log10-schaal op post-count; verzadigt bij DEPTH_SATURATION (10).
 *  - Breedte (40 %): unieke cluster-keywords / BREADTH_TARGET (20).
 *  - Singletons (1 post) krijgen altijd maximaal 0.20.
 *  - Lege clusters (0 posts) krijgen altijd 0.0.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Cluster_Builder {

	/** Minimum keyword-overlap om een losstaande post aan een bestaand cluster te koppelen. */
	private const MIN_OVERLAP = 2;

	/** Aantal posts per batch bij het ophalen van content. */
	private const BATCH_SIZE = 100;

	/** Streefaantal unieke keywords voor een volledig gedekte cluster-breedte. */
	private const BREADTH_TARGET = 20;

	/** Postaantal waarbij de dieptescore verzadigt (log10-schaal). */
	private const DEPTH_SATURATION = 10;

	/**
	 * Woorden die nooit als clusternaam (of onderdeel ervan) mogen dienen.
	 * Bevat zowel grammaticale stopwoorden als inhoudelijk te generieke termen.
	 */
	private const STOPWORDS = [
		// Grammaticale stopwoorden (NL).
		'de', 'het', 'een', 'van', 'voor', 'met', 'bij', 'op', 'in', 'als',
		'dat', 'die', 'wat', 'hoe', 'is', 'zijn', 'heeft', 'naar', 'te', 'en', 'of',
		'aan', 'om', 'door', 'over', 'uit', 'ook', 'nog', 'maar', 'dan', 'zo',
		'meer', 'al', 'wel', 'niet', 'geen', 'er', 'je', 'ze', 'we', 'hij', 'dit',
		// Inhoudelijk te generieke termen die geen topic-cluster vormen.
		'gratis', 'betaalde', 'beste', 'tips', 'kosten', 'tools', 'voordelen', 'nadelen',
	];

	/** Woorden die als zelfstandige (één-woord) clusternaam nooit geldig zijn. */
	private const INVALID_CLUSTER_NAMES = [
		'gratis', 'betaalde', 'beste', 'tips', 'kosten', 'tools', 'voordelen', 'nadelen',
	];

	private int            $site_id;
	private CGM_NLP_Engine $nlp;

	/** Handmatig gedefinieerde clusters uit contentgem_clusters option. Leeg = automatisch. */
	private array $manual_clusters;

	/**
	 * @param int                $site_id Site-ID uit cgm_sites.
	 * @param CGM_NLP_Engine|null $nlp    Optionele dependency-injection voor tests.
	 */
	public function __construct( int $site_id, ?CGM_NLP_Engine $nlp = null ) {
		$this->site_id = $site_id;
		$this->nlp     = $nlp ?? new CGM_NLP_Engine();

		$decoded               = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$this->manual_clusters = is_array( $decoded )
			? array_values( array_filter( $decoded, static fn( $c ) => is_string( $c ) && '' !== trim( $c ) ) )
			: [];
	}

	// ── Publieke API ──────────────────────────────────────────────────────────

	/**
	 * Voert de volledige cluster-analyse uit en slaat de resultaten op.
	 *
	 * @return int Aantal opgeslagen clusters.
	 */
	public function build(): int {
		$posts      = $this->get_all_posts();
		$is_manual  = ! empty( $this->manual_clusters );

		// Zonder posts én zonder handmatige clusters is er niets te doen.
		if ( empty( $posts ) && ! $is_manual ) {
			return 0;
		}

		$clusters = $is_manual
			? $this->build_manual_clusters( $posts )
			: $this->cluster_posts( $posts );

		$this->save_clusters( $clusters, $is_manual );

		return count( $clusters );
	}

	/**
	 * Groepeert een reeks posts in semantische clusters.
	 *
	 * @param  \WP_Post[] $posts
	 * @return array<int, array{name: string, post_ids: int[], keywords: string[]}>
	 */
	public function cluster_posts( array $posts ): array {
		// Bouw een post_id → title map voor naamafleiding.
		$post_titles = [];
		foreach ( $posts as $post ) {
			$post_titles[ $post->ID ] = $post->post_title;
		}

		// ── Stap 1: extraheer keywords per post ──────────────────────────────
		$post_keywords = [];
		foreach ( $posts as $post ) {
			$kws = $this->nlp->extract_keywords( $post );
			if ( ! empty( $kws ) ) {
				$post_keywords[ $post->ID ] = array_map( 'strtolower', $kws );
			}
		}

		if ( empty( $post_keywords ) ) {
			return [];
		}

		// ── Stap 2: inverteerde index keyword → post-ids ──────────────────
		$keyword_posts = [];
		foreach ( $post_keywords as $post_id => $keywords ) {
			foreach ( $keywords as $kw ) {
				$kw = trim( $kw );
				if ( $kw !== '' ) {
					$keyword_posts[ $kw ][] = (int) $post_id;
				}
			}
		}

		// Sorteer op documentfrequentie (meest voorkomende keyword eerst).
		uasort( $keyword_posts, static fn( $a, $b ) => count( $b ) - count( $a ) );

		// ── Stap 3: seed-clusters bouwen ──────────────────────────────────
		$clusters = [];
		$assigned = []; // post_id → cluster-index

		foreach ( $keyword_posts as $seed_kw => $seed_post_ids ) {
			// Alleen keywords die in ≥2 posts voorkomen zijn cluster-seeds.
			if ( count( $seed_post_ids ) < 2 ) {
				continue;
			}

			$unassigned = array_filter(
				$seed_post_ids,
				static fn( $id ) => ! isset( $assigned[ $id ] )
			);

			if ( empty( $unassigned ) ) {
				continue;
			}

			$idx              = count( $clusters );
			$clusters[ $idx ] = [
				'seed'     => $seed_kw,
				'post_ids' => [],
				'keywords' => [],
			];

			foreach ( $seed_post_ids as $post_id ) {
				if ( isset( $assigned[ $post_id ] ) ) {
					continue;
				}
				$assigned[ $post_id ]             = $idx;
				$clusters[ $idx ]['post_ids'][]   = $post_id;
				$clusters[ $idx ]['keywords']     = array_merge(
					$clusters[ $idx ]['keywords'],
					$post_keywords[ $post_id ] ?? []
				);
			}

			// Verwijder lege seed-clusters (kan door race in de loop).
			if ( empty( $clusters[ $idx ]['post_ids'] ) ) {
				unset( $clusters[ $idx ] );
			}
		}

		// ── Stap 4: resterende posts toewijzen of als singleton opslaan ───
		foreach ( $post_keywords as $post_id => $keywords ) {
			if ( isset( $assigned[ $post_id ] ) ) {
				continue;
			}

			$best = $this->find_best_cluster( $keywords, $clusters );

			if ( $best !== null ) {
				$clusters[ $best ]['post_ids'][] = $post_id;
				$clusters[ $best ]['keywords']   = array_merge(
					$clusters[ $best ]['keywords'],
					$keywords
				);
				$assigned[ $post_id ] = $best;
			} else {
				// Singleton-cluster voor geïsoleerde post.
				$idx              = count( $clusters );
				$clusters[ $idx ] = [
					'seed'     => $keywords[0] ?? 'general',
					'post_ids' => [ (int) $post_id ],
					'keywords' => $keywords,
				];
			}
		}

		// ── Stap 5: namen afleiden uit post-titels ────────────────────────
		// ── Stap 6: dedupliceren – clusters met dezelfde naam samenvoegen ─
		$named = [];
		foreach ( $clusters as $cluster ) {
			if ( empty( $cluster['post_ids'] ) ) {
				continue;
			}

			$name = $this->derive_cluster_name(
				$cluster['post_ids'],
				$post_titles,
				$cluster['seed']
			);

			if ( isset( $named[ $name ] ) ) {
				// Zelfde naam → samenvoegen.
				$named[ $name ]['post_ids'] = array_values( array_unique(
					array_merge( $named[ $name ]['post_ids'], $cluster['post_ids'] )
				) );
				$named[ $name ]['keywords'] = array_values( array_unique(
					array_merge( $named[ $name ]['keywords'], $cluster['keywords'] )
				) );
			} else {
				$named[ $name ] = [
					'name'     => $name,
					'post_ids' => array_values( array_unique( $cluster['post_ids'] ) ),
					'keywords' => array_values( array_unique( $cluster['keywords'] ) ),
				];
			}
		}

		return array_values( $named );
	}

	/**
	 * Berekent de coverage_score (0.0 – 1.0) voor één cluster.
	 *
	 * Diepte (60 %): logaritmische schaal op het aantal posts; verzadigt bij DEPTH_SATURATION.
	 * Breedte (40 %): unieke keywords / BREADTH_TARGET (streefwaarde 20 keywords = 100 %).
	 * Singletons (1 post) krijgen altijd maximaal 0.20.
	 * Lege clusters (0 posts) krijgen altijd 0.0.
	 *
	 * @param int[]    $post_ids Post-IDs in het cluster.
	 * @param string[] $keywords Alle unieke keywords van het cluster.
	 * @return float
	 */
	private function calculate_coverage_score( array $post_ids, array $keywords ): float {
		$post_count = count( $post_ids );

		if ( $post_count === 0 ) {
			return 0.0;
		}

		// Diepte (60 %): logaritmische schaal, verzadigt bij DEPTH_SATURATION posts.
		$depth = min(
			0.60,
			log10( max( 1, $post_count ) + 1 ) / log10( self::DEPTH_SATURATION + 1 ) * 0.60
		);

		// Breedte (40 %): unieke keywords t.o.v. BREADTH_TARGET.
		$unique_keywords = count( array_unique( $keywords ) );
		$breadth         = min( 0.40, ( $unique_keywords / self::BREADTH_TARGET ) * 0.40 );

		$score = $depth + $breadth;

		// Singletons krijgen maximaal 0.20.
		if ( $post_count === 1 ) {
			$score = min( 0.20, $score );
		}

		return round( min( 1.0, $score ), 2 );
	}

	/**
	 * Extraheert unieke keywords voor een reeks post-IDs via de NLP-engine.
	 *
	 * @param int[] $post_ids
	 * @return string[]
	 */
	private function extract_cluster_keywords( array $post_ids ): array {
		if ( empty( $post_ids ) ) {
			return [];
		}

		$posts = get_posts( [
			'post__in'         => $post_ids,
			'post_type'        => [ 'post', 'page' ],
			'post_status'      => 'publish',
			'posts_per_page'   => count( $post_ids ),
			'orderby'          => 'post__in',
			'suppress_filters' => true,
			'lang'             => '',
		] );

		$keywords = [];
		foreach ( $posts as $post ) {
			$kws      = $this->nlp->extract_keywords( $post );
			$keywords = array_merge( $keywords, array_map( 'strtolower', $kws ) );
		}

		return array_values( array_unique( $keywords ) );
	}

	/**
	 * Verwijdert alle bestaande clusters voor de site en slaat de nieuwe op.
	 *
	 * @param array<int, array{name: string, post_ids: int[], keywords: string[]}> $clusters
	 * @param bool $is_manual true = handmatige clusters — sla relevantiecheck over.
	 */
	public function save_clusters( array $clusters, bool $is_manual = false ): void {
		global $wpdb;

		$table = $wpdb->prefix . 'cgm_topics';

		// Bij handmatige clusters: verwijder eerst alle automatisch gegenereerde clusters
		// die NIET in de handmatige lijst staan (veiligheidsnet voor eerder opgeslagen data).
		if ( $is_manual && ! empty( $this->manual_clusters ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $this->manual_clusters ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE site_id = %d AND cluster_name NOT IN ({$placeholders})",
					array_merge( [ $this->site_id ], $this->manual_clusters )
				)
			);
		}

		// Verwijder alle bestaande clusters voor deze site vóór nieuwe opslag.
		$wpdb->delete(
			$table,
			[ 'site_id' => $this->site_id ],
			[ '%d' ]
		);

		foreach ( $clusters as $cluster ) {
			// Handmatige clusters worden altijd opgeslagen — geen relevantiecheck.
			if ( ! $is_manual && ! $this->is_relevant_cluster( $cluster['name'] ) ) {
				continue;
			}

			$score = $this->calculate_coverage_score(
				$cluster['post_ids'],
				$cluster['keywords']
			);

			$wpdb->insert(
				$table,
				[
					'site_id'        => $this->site_id,
					'cluster_name'   => sanitize_text_field( $cluster['name'] ),
					'coverage_score' => $score,
					'post_ids'       => wp_json_encode( $cluster['post_ids'] ),
					'post_count'     => count( $cluster['post_ids'] ),
				],
				[ '%d', '%s', '%f', '%s', '%d' ]
			);
		}

		do_action( 'contentgem/clusters_saved', $this->site_id, count( $clusters ) );
	}

	/**
	 * Wijst een nieuw gepubliceerde post toe aan het meest passende cluster
	 * en herberekent de coverage-score van dat cluster.
	 *
	 * @param int $post_id ID van de zojuist gepubliceerde post.
	 */
	public function assign_new_post_to_clusters( int $post_id ): void {
		global $wpdb;

		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$clusters = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d",
				$this->site_id
			)
		);

		if ( empty( $clusters ) ) {
			return;
		}

		$keywords = array_map( 'strtolower', $this->nlp->extract_keywords( $post ) );

		$best_cluster = null;
		$best_overlap = 0;

		foreach ( $clusters as $cluster ) {
			$cluster_words = preg_split( '/\s+/', strtolower( $cluster->cluster_name ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
			$overlap       = count( array_intersect( $keywords, $cluster_words ) );

			if ( $overlap > $best_overlap ) {
				$best_overlap = $overlap;
				$best_cluster = $cluster;
			}
		}

		if ( ! $best_cluster || $best_overlap === 0 ) {
			return;
		}

		$post_ids   = json_decode( $best_cluster->post_ids ?? '[]', true );
		$post_ids[] = $post_id;
		$post_ids   = array_values( array_unique( $post_ids ) );

		$cluster_keywords = $this->extract_cluster_keywords( $post_ids );
		$new_score        = $this->calculate_coverage_score( $post_ids, $cluster_keywords );

		$wpdb->update(
			$wpdb->prefix . 'cgm_topics',
			[
				'post_ids'       => wp_json_encode( $post_ids ),
				'post_count'     => count( $post_ids ),
				'coverage_score' => $new_score,
			],
			[ 'id' => $best_cluster->id ],
			[ '%s', '%d', '%f' ],
			[ '%d' ]
		);
	}

	// ── Private helpers ───────────────────────────────────────────────────────

	/**
	 * Bouwt clusters op basis van handmatig gedefinieerde clusternamen.
	 *
	 * Algoritme:
	 *  1. Bouw een tekst-map per post: title + eerste 500 tekens content.
	 *  2. Extraheer keywords per post via NLP.
	 *  3. Bereken per post een score per cluster:
	 *     score = (gevonden clusternaam-keywords in post-tekst / totaal clusternaam-keywords) × 100
	 *  4. Wijs post toe aan elk cluster met score ≥ 20 %, maximaal 3 clusters (hoogste score eerst).
	 *
	 * @param  \WP_Post[] $posts
	 * @return array<int, array{name: string, post_ids: int[], keywords: string[]}>
	 */
	private function build_manual_clusters( array $posts ): array {
		// ── Stap 1: keywords per post ──────────────────────────────────────
		$post_keywords = [];
		foreach ( $posts as $post ) {
			$kws = $this->nlp->extract_keywords( $post );
			if ( ! empty( $kws ) ) {
				$post_keywords[ $post->ID ] = array_map( 'strtolower', $kws );
			}
		}

		// Bouw post_id → zoektekst map (title + eerste 500 tekens content).
		$post_texts = [];
		foreach ( $posts as $post ) {
			$content              = wp_strip_all_tags( $post->post_content );
			$post_texts[ $post->ID ] = mb_strtolower(
				$post->post_title . ' ' . mb_substr( $content, 0, 500 )
			);
		}

		// ── Stap 2: initialiseer clusters vanuit handmatige namen ──────────
		$clusters = [];
		foreach ( $this->manual_clusters as $name ) {
			$clusters[ $name ] = [
				'name'     => $name,
				'post_ids' => [],
				'keywords' => [],
			];
		}

		// ── Stap 3: wijs elke post aan ≤ 3 clusters toe (score ≥ 20 %) ────
		foreach ( $posts as $post ) {
			$post_id   = $post->ID;
			$post_text = $post_texts[ $post_id ] ?? '';
			$keywords  = $post_keywords[ $post_id ] ?? [];

			$scores = [];

			foreach ( $clusters as $name => $cluster ) {
				// Splits clusternaam op spaties voor keyword matching.
				$name_words = preg_split( '/\s+/', mb_strtolower( $name ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
				if ( empty( $name_words ) ) {
					continue;
				}

				// Tel hoeveel clusternaam-woorden in de post title/content voorkomen.
				$found = 0;
				foreach ( $name_words as $word ) {
					if ( mb_strpos( $post_text, $word ) !== false ) {
						$found++;
					}
				}

				$score = ( $found / count( $name_words ) ) * 100;

				if ( $score >= 20 ) {
					$scores[ $name ] = $score;
				}
			}

			if ( empty( $scores ) ) {
				continue;
			}

			// Sorteer op score (hoogste eerst) en neem maximaal 3 clusters.
			arsort( $scores );
			$top_clusters = array_slice( array_keys( $scores ), 0, 3 );

			foreach ( $top_clusters as $cluster_name ) {
				$clusters[ $cluster_name ]['post_ids'][] = $post_id;
				$clusters[ $cluster_name ]['keywords']   = array_merge(
					$clusters[ $cluster_name ]['keywords'],
					$keywords
				);
			}
		}

		// ── Stap 4: normaliseer naar geïndexeerde array ────────────────────
		$result = [];
		foreach ( $clusters as $cluster ) {
			$result[] = [
				'name'     => $cluster['name'],
				'post_ids' => array_values( array_unique( $cluster['post_ids'] ) ),
				'keywords' => array_values( array_unique( $cluster['keywords'] ) ),
			];
		}

		return $result;
	}

	/**
	 * Bepaalt of een clusternaam relevant genoeg is om op te slaan.
	 *
	 * Retourneert false als:
	 *  - De naam een generiek woord bevat (sample, page, uncategorized, hello world, test).
	 *  - De naam minder dan 3 tekens heeft.
	 *  - De naam uitsluitend uit stopwoorden/verboden termen bestaat.
	 *  - De naam exact één woord is dat op de INVALID_CLUSTER_NAMES-lijst staat.
	 *  - Er een niche is ingesteld én de clusternaam geen enkel woord deelt met die niche.
	 *
	 * @param  string $cluster_name
	 * @return bool
	 */
	private function is_relevant_cluster( string $cluster_name ): bool {
		$lower = mb_strtolower( $cluster_name );

		// Generieke blacklist.
		foreach ( [ 'sample', 'page', 'uncategorized', 'hello world', 'test' ] as $word ) {
			if ( str_contains( $lower, $word ) ) {
				return false;
			}
		}

		// Naam moet minimaal 3 tekens bevatten.
		if ( mb_strlen( trim( $cluster_name ) ) < 3 ) {
			return false;
		}

		$words = preg_split( '/\s+/', $lower, -1, PREG_SPLIT_NO_EMPTY ) ?: [];

		// Naam mag niet uitsluitend uit stopwoorden/verboden termen bestaan.
		$has_valid_word = false;
		foreach ( $words as $word ) {
			if ( ! in_array( $word, self::STOPWORDS, true ) ) {
				$has_valid_word = true;
				break;
			}
		}
		if ( ! $has_valid_word ) {
			return false;
		}

		// Naam mag niet exact één van de ongeldige enkelvoudige namen zijn.
		if ( count( $words ) === 1 && in_array( $words[0], self::INVALID_CLUSTER_NAMES, true ) ) {
			return false;
		}

		// Niche-filter: als niche ingesteld is, moet de naam minstens één woord delen.
		$niche = trim( (string) get_option( 'contentgem_niche', '' ) );
		if ( '' !== $niche ) {
			$niche_words   = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $niche ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
			$cluster_words = preg_split( '/[^\p{L}\p{N}]+/u', $lower, -1, PREG_SPLIT_NO_EMPTY ) ?: [];

			if ( empty( array_intersect( $cluster_words, $niche_words ) ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Geeft het aantal gepubliceerde posts terug (zonder alle content te laden).
	 */
	private function get_published_post_count(): int {
		$counts = wp_count_posts( 'post' );
		return (int) ( $counts->publish ?? 0 );
	}

	/**
	 * Haalt alle gepubliceerde posts en pagina's op in batches van BATCH_SIZE.
	 *
	 * @return \WP_Post[]
	 */
	private function get_all_posts(): array {
		$all    = [];
		$offset = 0;

		do {
			$batch = get_posts( [
				'post_type'        => [ 'post', 'page' ],
				'post_status'      => 'publish',
				'posts_per_page'   => self::BATCH_SIZE,
				'offset'           => $offset,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
				'lang'             => '',
			] );

			$all     = array_merge( $all, $batch );
			$offset += self::BATCH_SIZE;
		} while ( count( $batch ) === self::BATCH_SIZE );

		return $all;
	}

	/**
	 * Zoekt het cluster met de hoogste keyword-overlap voor de gegeven keywords.
	 * Retourneert de cluster-index, of null als de overlap onder MIN_OVERLAP ligt.
	 *
	 * @param  string[]                                                              $keywords
	 * @param  array<int, array{seed: string, post_ids: int[], keywords: string[]}> $clusters
	 * @return int|null
	 */
	private function find_best_cluster( array $keywords, array $clusters ): ?int {
		$best_idx     = null;
		$best_overlap = 0;

		foreach ( $clusters as $idx => $cluster ) {
			$overlap = count(
				array_intersect( $keywords, array_map( 'strtolower', $cluster['keywords'] ) )
			);

			if ( $overlap > $best_overlap ) {
				$best_overlap = $overlap;
				$best_idx     = $idx;
			}
		}

		return $best_overlap >= self::MIN_OVERLAP ? $best_idx : null;
	}

	/**
	 * Leidt een leesbare clusternaam af uit de titels van de posts in het cluster.
	 *
	 * Telt woorden in post-titels, filtert stopwoorden en kiest het meest
	 * voorkomende zelfstandig naamwoord als naam (enkelvoud, max 2 woorden).
	 *
	 * Voorbeelden:
	 *  - Posts "Hardloopschoenen kiezen", "Hardloopschoenen kopen" → "Hardloopschoenen"
	 *  - Posts "Trainingsschema 5km", "Marathonschema hardlopen"  → "Trainingsschema"
	 *
	 * @param int[]    $post_ids    Post-IDs in dit cluster.
	 * @param string[] $post_titles Map van post_id → post_title.
	 * @param string   $seed        Fallback-seed keyword als er geen titels zijn.
	 * @return string
	 */
	private function derive_cluster_name( array $post_ids, array $post_titles, string $seed ): string {
		// Verzamel titels voor de posts in dit cluster.
		$titles = [];
		foreach ( $post_ids as $id ) {
			if ( isset( $post_titles[ $id ] ) && '' !== trim( $post_titles[ $id ] ) ) {
				$titles[] = $post_titles[ $id ];
			}
		}

		$word_freq = [];

		if ( ! empty( $titles ) ) {
			foreach ( $titles as $title ) {
				$parts = preg_split( '/\s+/', mb_strtolower( trim( $title ) ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
				foreach ( $parts as $word ) {
					$word = preg_replace( '/[^\p{L}\p{N}]/u', '', $word );
					if ( $word === '' || mb_strlen( $word ) < 3 ) {
						continue;
					}
					if ( in_array( $word, self::STOPWORDS, true ) ) {
						continue;
					}
					$word_freq[ $word ] = ( $word_freq[ $word ] ?? 0 ) + 1;
				}
			}
		}

		if ( empty( $word_freq ) ) {
			// Geen betekenisvolle woorden in titels — gebruik seed als fallback.
			$clean = preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', mb_strtolower( $seed ) );
			return ucwords( trim( $clean ) );
		}

		arsort( $word_freq );

		// Neem het meest voorkomende woord als clusternaam (max 2 woorden).
		$top_words = array_slice( array_keys( $word_freq ), 0, 1 );

		return ucwords( implode( ' ', $top_words ) );
	}
}
