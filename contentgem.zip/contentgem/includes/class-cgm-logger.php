<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Logger {
	public function info( string $message, array $context = [] ): void { if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) { error_log( '[ContentGem] ' . $message . ' ' . wp_json_encode( $context ) ); } }
	public function warning( string $message, array $context = [] ): void { $this->info( 'WARNING: ' . $message, $context ); }
	public function error( string $message, array $context = [] ): void { $this->info( 'ERROR: ' . $message, $context ); }
}
