<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Linking Service
 *
 * v4.5 — Natural anchor texts and balanced placement.
 *
 * Anchor strategy: prefer an n-gram (2-4 words) from the TARGET post title
 * that actually appears in the draft, in lowercase, in original order.
 * Fall back to a clean fragment of the target title with stopwords removed
 * but word order preserved. Never use Title Case — that's the AI tell.
 *
 * Placement strategy: split the draft into N segments and score each
 * target against each segment, so suggestions get spread across the post
 * instead of clustering at the top.
 */
class CGM_Linking_Service {
	protected CGM_Post_Repository $post_repo;
	protected CGM_Content_Parser $parser;

	const SEGMENTS = 5;
	const STOPWORDS = [
		'the','and','for','that','this','with','from','you','your','are','was','were',
		'has','have','had','but','not','can','will','what','when','where','why','how',
		'who','which','whom','whose','about','into','onto','over','under','than','then',
		'them','they','their','there','here','some','any','all','one','two','also','very',
		'just','more','most','such','only','own','same','too','our','its','out','off',
		'per','via','vs','versus','etc','i.e','e.g','to','of','in','on','as','at','by',
		'is','it','an','a','or','if','be','do','no','so','up',
	];

	public function __construct( CGM_Post_Repository $post_repo, CGM_Content_Parser $parser ) {
		$this->post_repo = $post_repo;
		$this->parser = $parser;
	}

	public function suggest_links( string $content, int $limit = 5 ): array {
		$posts = $this->post_repo->get_all_content_posts( [ 'post_status' => [ 'publish' ] ] );
		$plain = $this->parser->extract_plain_text( $content );
		$plain_lc = strtolower( $plain );

		// Split into roughly equal segments for balanced placement.
		$segments = $this->segment_text( $plain, self::SEGMENTS );
		$segments_lc = array_map( 'strtolower', $segments );

		$draft_tokens = $this->tokenize( $plain_lc );
		$out = [];

		foreach ( $posts as $p ) {
			if ( ! $p instanceof WP_Post ) { continue; }
			$title = trim( (string) $p->post_title );
			if ( '' === $title ) { continue; }

			$title_lc = strtolower( $title );
			// Skip if the draft already contains the full title — likely already linked or redundant.
			if ( false !== strpos( $plain_lc, $title_lc ) ) { continue; }

			$post_tokens = $this->tokenize( $title_lc );
			$content_tokens = array_values( array_unique( array_diff( $post_tokens, self::STOPWORDS ) ) );
			if ( empty( $content_tokens ) ) { continue; }

			// Token-overlap score across the WHOLE draft (not just the first 1200 chars).
			$overlap = array_intersect( $draft_tokens, $content_tokens );
			$token_score = count( $overlap ) / max( 1, count( $content_tokens ) );

			// Per-segment scoring — find which segment this target best fits.
			$best_segment = 0;
			$best_segment_score = 0.0;
			foreach ( $segments_lc as $i => $seg ) {
				if ( '' === $seg ) { continue; }
				$seg_tokens = $this->tokenize( $seg );
				$seg_overlap = array_intersect( $seg_tokens, $content_tokens );
				$seg_score = count( $seg_overlap ) / max( 1, count( $content_tokens ) );
				if ( $seg_score > $best_segment_score ) {
					$best_segment_score = $seg_score;
					$best_segment = $i;
				}
			}

			$score = min( 1.0, ( $token_score * 0.6 ) + ( $best_segment_score * 0.4 ) );
			if ( $score < 0.18 ) { continue; }

			$anchor = $this->generate_anchor_text( $title, $plain_lc );
			if ( '' === $anchor ) { continue; }

			$out[] = [
				'post_id'        => (int) $p->ID,
				'title'          => $title,
				'url'            => get_permalink( $p->ID ),
				'score'          => round( $score * 100, 1 ),
				'anchor_text'    => $anchor,
				'placement_hint' => sprintf( 'Section %d of %d', $best_segment + 1, self::SEGMENTS ),
				'segment'        => $best_segment,
			];
		}

		usort( $out, static function( $a, $b ) {
			return (float) $b['score'] <=> (float) $a['score'];
		} );

		// Spread across segments — prefer not to stack multiple suggestions in the same segment
		// unless we run out of options.
		$out = $this->spread_across_segments( $out, $limit );

		return array_slice( $out, 0, $limit );
	}

	public function detect_orphan_pages(): array {
		$posts = $this->post_repo->get_all_content_posts( [ 'post_status' => [ 'publish' ] ] );
		$out = [];
		foreach ( $posts as $p ) {
			if ( ! $p instanceof WP_Post ) { continue; }
			$content = (string) $p->post_content;
			$links = $this->parser->extract_links( $content );
			if ( empty( $links ) ) {
				$out[] = [
					'post_id'  => (int) $p->ID,
					'title'    => (string) $p->post_title,
					'edit_url' => get_edit_post_link( $p->ID, '' ),
				];
			}
		}
		return array_slice( $out, 0, 20 );
	}

	/**
	 * Insert <a> tags into content for each suggestion.
	 *
	 * Improvements over v4.4:
	 *   - Skips anchors already inside an <a> tag.
	 *   - Skips duplicate URLs (one link per target).
	 *   - Inserts in the SEGMENT the suggestion was scored for, so links spread.
	 */
	public function insert_links_into_content( string $content, array $suggestions ): string {
		$updated = $content;
		$used_urls = [];

		// Detect URLs already linked in the draft so we don't double-link.
		if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $updated, $m ) ) {
			foreach ( $m[1] as $u ) { $used_urls[ $u ] = true; }
		}

		foreach ( $suggestions as $item ) {
			$anchor = trim( (string) ( $item['anchor_text'] ?? '' ) );
			$url = esc_url_raw( (string) ( $item['url'] ?? '' ) );
			$segment = isset( $item['segment'] ) ? (int) $item['segment'] : -1;
			if ( '' === $anchor || '' === $url ) { continue; }
			if ( isset( $used_urls[ $url ] ) ) { continue; }

			$next = $this->insert_anchor_in_segment( $updated, $anchor, $url, $segment );
			if ( null !== $next && $next !== $updated ) {
				$updated = $next;
				$used_urls[ $url ] = true;
			}
		}
		return $updated;
	}

	/**
	 * Insert a single anchor → url, preferring the given segment of the draft.
	 * Returns the updated content, or null if the anchor could not be placed.
	 */
	protected function insert_anchor_in_segment( string $content, string $anchor, string $url, int $segment ): ?string {
		// Build a regex that matches the anchor as a whole word, case-insensitive,
		// but NOT inside an existing <a>...</a> tag.
		$quoted = preg_quote( $anchor, '/' );
		$pattern = '/(?<![>\w])(' . $quoted . ')(?![\w<])/i';

		$matches = [];
		if ( ! preg_match_all( $pattern, $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			return null;
		}
		if ( empty( $matches[0] ) ) { return null; }

		// Filter out matches inside <a>...</a> tags.
		$valid = [];
		foreach ( $matches[0] as $hit ) {
			$offset = (int) $hit[1];
			if ( $this->is_inside_anchor_tag( $content, $offset ) ) { continue; }
			$valid[] = $hit;
		}
		if ( empty( $valid ) ) { return null; }

		// Pick the match closest to the target segment's character range.
		$len = strlen( $content );
		$seg_count = max( 1, self::SEGMENTS );
		$target_offset = $segment >= 0
			? (int) ( $len * ( ( $segment + 0.5 ) / $seg_count ) )
			: (int) ( $len * 0.5 );

		$chosen = $valid[0];
		$best_dist = PHP_INT_MAX;
		foreach ( $valid as $hit ) {
			$dist = abs( ( (int) $hit[1] ) - $target_offset );
			if ( $dist < $best_dist ) {
				$best_dist = $dist;
				$chosen = $hit;
			}
		}

		$matched_text = (string) $chosen[0];
		$offset = (int) $chosen[1];
		$replacement = '<a href="' . esc_url( $url ) . '">' . $matched_text . '</a>';

		return substr( $content, 0, $offset ) . $replacement . substr( $content, $offset + strlen( $matched_text ) );
	}

	protected function is_inside_anchor_tag( string $content, int $offset ): bool {
		$before = substr( $content, 0, $offset );
		$last_open = strripos( $before, '<a ' );
		$last_open_alt = strripos( $before, '<a>' );
		$last_open = max( $last_open === false ? -1 : $last_open, $last_open_alt === false ? -1 : $last_open_alt );
		if ( $last_open < 0 ) { return false; }
		$last_close = strripos( $before, '</a>' );
		return $last_close < $last_open;
	}

	protected function segment_text( string $text, int $n ): array {
		$text = trim( $text );
		if ( '' === $text ) { return array_fill( 0, $n, '' ); }
		$len = strlen( $text );
		$size = (int) ceil( $len / max( 1, $n ) );
		$out = [];
		for ( $i = 0; $i < $n; $i++ ) {
			$out[] = substr( $text, $i * $size, $size );
		}
		return $out;
	}

	protected function spread_across_segments( array $items, int $limit ): array {
		if ( count( $items ) <= $limit ) { return $items; }
		$by_segment = [];
		foreach ( $items as $it ) {
			$seg = isset( $it['segment'] ) ? (int) $it['segment'] : 0;
			$by_segment[ $seg ][] = $it;
		}
		$picked = [];
		$round = 0;
		while ( count( $picked ) < $limit && $round < 20 ) {
			$progressed = false;
			for ( $s = 0; $s < self::SEGMENTS; $s++ ) {
				if ( ! empty( $by_segment[ $s ][ $round ] ) ) {
					$picked[] = $by_segment[ $s ][ $round ];
					$progressed = true;
					if ( count( $picked ) >= $limit ) { break; }
				}
			}
			if ( ! $progressed ) { break; }
			$round++;
		}
		// If we still have room, top up with leftovers in score order.
		if ( count( $picked ) < $limit ) {
			$ids = array_flip( array_map( static fn( $i ) => $i['post_id'] ?? 0, $picked ) );
			foreach ( $items as $it ) {
				if ( count( $picked ) >= $limit ) { break; }
				$pid = (int) ( $it['post_id'] ?? 0 );
				if ( isset( $ids[ $pid ] ) ) { continue; }
				$picked[] = $it;
				$ids[ $pid ] = true;
			}
		}
		return $picked;
	}

	protected function tokenize( string $text ): array {
		$text = strtolower( preg_replace( '/[^a-z0-9\s-]+/i', ' ', $text ) );
		$tokens = preg_split( '/\s+/', $text );
		$tokens = array_filter( array_map( 'trim', $tokens ), static function( $t ) {
			return strlen( $t ) >= 3;
		} );
		return array_values( array_unique( $tokens ) );
	}

	/**
	 * Pick a natural anchor for a target title.
	 *
	 * 1. Try n-grams (4 → 2 words) from the title that ALREADY appear in the draft.
	 *    These are real anchors a human would write, in original lowercase.
	 * 2. Fall back to the title minus stopwords, original word order, lowercase.
	 * 3. Last resort: the bare title.
	 */
	protected function generate_anchor_text( string $title, string $plain_lc ): string {
		$clean = strtolower( preg_replace( '/[^a-z0-9\s-]+/i', ' ', $title ) );
		$words = preg_split( '/\s+/', trim( $clean ) );
		$words = array_values( array_filter( $words, static fn( $w ) => '' !== $w ) );
		if ( empty( $words ) ) { return $title; }

		// Try descending n-gram sizes for in-draft matches.
		for ( $n = min( 5, count( $words ) ); $n >= 2; $n-- ) {
			for ( $i = 0; $i + $n <= count( $words ); $i++ ) {
				$ngram = implode( ' ', array_slice( $words, $i, $n ) );
				// Skip n-grams that are mostly stopwords.
				$ngram_words = explode( ' ', $ngram );
				$content_words = array_diff( $ngram_words, self::STOPWORDS );
				if ( count( $content_words ) < 2 ) { continue; }
				if ( false !== strpos( $plain_lc, $ngram ) ) {
					return $ngram;
				}
			}
		}

		// Fallback: title with stopwords stripped, original order, lowercase.
		$kept = array_values( array_filter( $words, static function( $w ) {
			return ! in_array( $w, self::STOPWORDS, true );
		} ) );
		if ( count( $kept ) >= 2 ) {
			return implode( ' ', array_slice( $kept, 0, 5 ) );
		}

		return strtolower( $title );
	}
}
