<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Cluster_Repository {
	public function get_all_clusters(): array {
		global $wpdb;
		$site_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}cgm_sites WHERE blog_id = %d LIMIT 1", get_current_blog_id() ) );
		if ( $site_id <= 0 ) {
			return [];
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d ORDER BY cluster_name ASC", $site_id ), ARRAY_A );
	}

	public function get_cluster( int $cluster_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_topics WHERE id = %d LIMIT 1", $cluster_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	public function get_cluster_keywords( int $cluster_id ): array {
		$cluster = $this->get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return [];
		}

		$keywords = [];
		$raw      = json_decode( (string) ( $cluster['keywords_json'] ?? '[]' ), true );
		if ( is_array( $raw ) ) {
			$keywords = array_merge( $keywords, $raw );
		}

		$cluster_name = sanitize_text_field( (string) ( $cluster['cluster_name'] ?? '' ) );
		$keyword_map  = get_option( 'cgm_cluster_keywords', [] );
		$keyword_map  = is_array( $keyword_map ) ? $keyword_map : [];
		if ( $cluster_name !== '' && ! empty( $keyword_map[ $cluster_name ] ) && is_array( $keyword_map[ $cluster_name ] ) ) {
			$keywords = array_merge( $keywords, $keyword_map[ $cluster_name ] );
		}

		if ( empty( $keywords ) && $cluster_name !== '' ) {
			$keywords = preg_split( '/\s*,\s*|\s+/', strtolower( $cluster_name ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		}

		$keywords = array_values( array_unique( array_filter( array_map( static function( $keyword ) {
			return sanitize_text_field( (string) $keyword );
		}, $keywords ) ) ) );

		return $keywords;
	}

	public function get_cluster_pillar( int $cluster_id ): ?array {
		$cluster = $this->get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return null;
		}
		$pillar_id = (int) ( $cluster['pillar_post_id'] ?? 0 );
		if ( $pillar_id <= 0 ) {
			return null;
		}
		return [
			'post_id' => $pillar_id,
			'title'   => get_the_title( $pillar_id ),
			'url'     => get_permalink( $pillar_id ) ?: '',
		];
	}

	public function get_cluster_posts( int $cluster_id ): array {
		return ( new CGM_Post_Repository() )->get_posts_by_cluster( $cluster_id );
	}
}
