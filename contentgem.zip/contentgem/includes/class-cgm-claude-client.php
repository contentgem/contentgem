<?php
/**
 * Class CGM_Claude_Client
 *
 * AI client wrapper — ondersteunt zowel Anthropic Claude als OpenAI.
 * Gebruikt intern CGM_AI_Client voor provider-agnostische API calls.
 * De klassenaam blijft CGM_Claude_Client voor backwards compatibiliteit.
 */

defined( 'ABSPATH' ) || exit;

class CGM_Claude_Client {

	private CGM_AI_Client $ai;

	public function __construct( string $api_key ) {
		$provider = get_option( 'contentgem_ai_provider', 'claude' );
		$this->ai = new CGM_AI_Client( $provider, $api_key );
	}

	public function chat( array $messages, string $system_prompt = '', int $max_tokens = 1200 ): array {
		$result = $this->ai->chat( $messages, $system_prompt, $max_tokens );
		return [
			'text'        => (string) ( $result['text'] ?? '' ),
			'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
		];
	}

	public function suggest( array $context ): array {
		$result = $this->chat(
			[ [ 'role' => 'user', 'content' => $this->build_suggest_prompt( $context ) ] ],
			$this->build_system_prompt( $context ),
			900
		);
		$parsed = $this->parse_json_response( $result['text'] );
		return array_merge( $parsed, [ 'tokens_used' => $result['tokens_used'] ] );
	}

	public function generate_draft( array $context, callable $on_chunk ): array {
		return $this->generate_chunked_article( $context, $on_chunk );
	}



	public function generate_inline_draft_visuals( array $context, string $article_html ): array {
		$language = $this->infer_language_label( $context );
		$topic = (string) ( $context['topic'] ?? $context['suggested_title'] ?? $context['primary_keyword'] ?? '' );
		$subtopics = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $context['h2_structure'] ?? [] ) ) ) );
		if ( empty( $subtopics ) && preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $article_html, $matches ) ) {
			$subtopics = array_values( array_slice( array_map( static function( string $heading ): string {
				return sanitize_text_field( wp_strip_all_tags( $heading ) );
			}, (array) $matches[1] ), 0, 6 ) );
		}
		$gaps = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $context['gap_topics'] ?? [] ) ) ) );
		$system = 'You are the Contentgem AI assistant. Generate inline SVG visuals for a WordPress content draft. Return only raw SVG blocks and caption tags. Never use markdown fences. Never output loose labels, bullet lists, metrics, legends or explanatory text outside the SVG and <cgm-svg-caption> tags.';
		$template = <<<'PROMPT'
Create up to 2 inline SVG visuals for this article.

Language: %s
Main topic: %s
Subtopics: %s
Gap topics: %s

Return format for each visual exactly like this and nothing else:
<!-- cgm-insert-after: Exact H2 heading -->
<svg width="100%%" viewBox="0 0 600 300" class="cgm-inline-svg cgm-draft-svg__graphic" xmlns="http://www.w3.org/2000/svg">...</svg>
<cgm-svg-caption>One-sentence caption.</cgm-svg-caption>

Strict rules:
- Output only complete SVG blocks plus matching <cgm-svg-caption> tags. No paragraphs, no headings, no bullet points, no legend text outside the SVG, no metrics list, no analysis text.
- If you cannot produce a valid SVG for this article, return an empty string.
- Use only CSS custom properties like var(--cgm-hub-fill), var(--cgm-node-fill), var(--cgm-gap-fill), var(--cgm-line), var(--cgm-node-text), var(--cgm-gap-text), var(--cgm-bar-covered), var(--cgm-bar-gap), var(--cgm-bar-missing), var(--cgm-text-muted).
- At most one cluster hub-and-spoke diagram and at most one horizontal gap coverage diagram.
- No scripts, no external fonts, no gradients, no filters.
- Keep labels inside the viewBox.
- Keep spoke labels to max 3 words.
- Use captions in the same language as the article.

Reject these invalid outputs:
- plain word lists such as "Pillar Page", "Core Web Vitals", "Structured Data"
- standalone percentages like "85%%"
- legend rows like "Covered / Opportunity / Gap"
- prose outside the SVG markup

Existing article HTML for context:
%s
PROMPT;
		$prompt = sprintf(
			$template,
			$language,
			$topic,
			implode( ', ', array_slice( $subtopics, 0, 6 ) ) ?: 'none',
			implode( ', ', array_slice( $gaps, 0, 6 ) ) ?: 'none',
			mb_substr( $article_html, 0, 12000 )
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 2800 );
		return [ 'text' => (string) ( $result['text'] ?? '' ), 'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ) ];
	}

	public function generate_long_form_article( array $context ): array {
		$result = $this->generate_chunked_article( $context, static function( string $chunk ): void {} );
		$html   = (string) ( $result['html'] ?? '' );
		$title  = sanitize_text_field( (string) ( $context['topic'] ?? $context['suggested_title'] ?? '' ) );
		if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/is', $html, $m ) ) {
			$title = sanitize_text_field( wp_strip_all_tags( $m[1] ) );
		}
		$meta_description = sanitize_text_field( (string) ( $result['meta_description'] ?? '' ) );
		if ( '' === $meta_description ) {
			$meta = $this->generate_meta_description( $title, wp_strip_all_tags( mb_substr( $html, 0, 600 ) ) );
			$meta_description = (string) ( $meta['meta_description'] ?? '' );
			$result['tokens_used'] = (int) ( $result['tokens_used'] ?? 0 ) + (int) ( $meta['tokens_used'] ?? 0 );
		}
		return [
			'html'             => $html,
			'title'            => $title,
			'meta_description' => $meta_description,
			'tokens_used'      => (int) ( $result['tokens_used'] ?? 0 ),
		];
	}

	private function generate_chunked_article( array $context, callable $on_chunk ): array {
		$normalized = [
			'suggested_title'         => $context['topic'] ?? $context['suggested_title'] ?? '',
			'primary_keyword'         => $context['focus_keyword'] ?? $context['primary_keyword'] ?? ( $context['topic'] ?? '' ),
			'cluster_name'            => $context['cluster'] ?? $context['cluster_name'] ?? '',
			'word_count'              => max( 1400, (int) ( $context['word_count'] ?? 1600 ) ),
			'language'                => $context['language'] ?? '',
			'additional_instructions' => $context['additional_instructions'] ?? '',
			'tone_instructions'       => $context['tone'] ?? $context['tone_instructions'] ?? '',
			'lsi_keywords'            => $context['lsi_keywords'] ?? [],
			'internal_links'          => $context['internal_links'] ?? [],
			'pillar_pages'            => $context['pillar_pages'] ?? [],
			'competitor_insights'     => $context['competitor_insights'] ?? '',
			'gsc_queries'             => $context['gsc_queries'] ?? [],
			'search_intent'           => $context['search_intent'] ?? 'informational',
			'niche_label'             => $context['niche_label'] ?? 'general',
		];
		$system  = $this->build_system_prompt( $normalized );
		$outline = $this->build_article_outline( $normalized, $system );
		$title   = sanitize_text_field( (string) ( $outline['title'] ?? $normalized['suggested_title'] ) );
		$faq     = array_values( array_slice( array_filter( array_map( 'sanitize_text_field', (array) ( $outline['faq_questions'] ?? [] ) ) ), 0, 4 ) );
		$sections = array_values( array_filter( (array) ( $outline['sections'] ?? [] ), static function( $section ) {
			return is_array( $section ) && ! empty( $section['heading'] );
		} ) );
		if ( empty( $sections ) ) {
			$sections = [];
			foreach ( array_slice( (array) ( $normalized['h2_structure'] ?? [] ), 0, 6 ) as $heading ) {
				$sections[] = [ 'heading' => sanitize_text_field( (string) $heading ), 'brief' => '', 'target_words' => 220 ];
			}
		}
		if ( empty( $sections ) ) {
			$sections = [
				[ 'heading' => 'Core principles', 'brief' => '', 'target_words' => 260 ],
				[ 'heading' => 'Practical applications', 'brief' => '', 'target_words' => 260 ],
				[ 'heading' => 'Common mistakes', 'brief' => '', 'target_words' => 220 ],
				[ 'heading' => 'How to apply this', 'brief' => '', 'target_words' => 240 ],
			];
		}
		$meta = $this->generate_meta_description( $title, (string) $normalized['primary_keyword'] );
		$tokens = (int) ( $meta['tokens_used'] ?? 0 );
		$html = '<!-- meta: ' . esc_html( (string) ( $meta['meta_description'] ?? '' ) ) . ' -->\n';
		$html .= '<h1>' . esc_html( $title ) . '</h1>\n';
		$intro = $this->generate_article_intro( $normalized, $system, $title, $sections );
		$tokens += (int) ( $intro['tokens_used'] ?? 0 );
		if ( ! empty( $intro['html'] ) ) {
			$html .= trim( (string) $intro['html'] ) . "\n";
			$on_chunk( (string) $intro['html'] );
		}
		$section_count = count( $sections );
		foreach ( $sections as $index => $section ) {
			$piece = $this->generate_article_section( $normalized, $system, $title, $section, $index + 1, $section_count );
			$tokens += (int) ( $piece['tokens_used'] ?? 0 );
			$chunk = trim( (string) ( $piece['html'] ?? '' ) );
			if ( '' !== $chunk ) {
				$html .= $chunk . "\n";
				$on_chunk( $chunk );
			}
		}
		$closing = $this->generate_forced_closing_block( $normalized, $system, $title, $faq );
		$tokens += (int) ( $closing['tokens_used'] ?? 0 );
		if ( ! empty( $closing['html'] ) ) {
			$html .= trim( (string) $closing['html'] ) . "\n";
			$on_chunk( (string) $closing['html'] );
		}
		return [
			'html' => trim( $html ),
			'meta_description' => (string) ( $meta['meta_description'] ?? '' ),
			'tokens_used' => $tokens,
		];
	}

	public function suggest_clusters( string $niche, string $description ): array {
		$forced = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		if ( in_array( $forced, [ 'nl', 'en' ], true ) ) {
			$lang = $forced;
		} else {
			$lang = class_exists( 'CGM_NLP_Engine' ) ? ( new CGM_NLP_Engine() )->detect_language( trim( $niche . ' ' . $description ) ) : 'nl';
		}
		$lang_label = 'en' === $lang ? 'English' : 'Dutch';
		$prompt = sprintf(
			"Generate up to 12 content clusters for a website about %s. %s\n\n" .
			"IMPORTANT: Write the cluster names in %s and keep the language consistent with the niche/keywords. Do not switch language because of anglicisms or unclear terms.\n" .
			"Return ONLY a JSON array with cluster names, each 1-3 words, specific and relevant.\n" .
			"Example: [\"Running for beginners\", \"Running shoes\", \"Training schedule\"]",
			$niche,
			$description,
			$lang_label
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 300 );
		return [ 'clusters' => $this->parse_clusters_response( $result['text'] ), 'tokens_used' => $result['tokens_used'] ];
	}

	public function suggest_gap_titles( string $cluster, array $existing_titles, string $niche ): array {
		$existing = implode( ', ', array_slice( $existing_titles, 0, 10 ) );
		$forced = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		if ( in_array( $forced, [ 'nl', 'en' ], true ) ) {
			$lang = $forced;
		} else {
			$lang = class_exists( 'CGM_NLP_Engine' ) ? ( new CGM_NLP_Engine() )->detect_language( trim( $cluster . ' ' . $niche . ' ' . implode( ' ', $existing_titles ) ) ) : 'nl';
		}
		$lang_label = 'en' === $lang ? 'English' : 'Dutch';
		$prompt   = sprintf(
			"Generate 5 unique, human article titles for a website about %s for the cluster '%s'.\n" .
			"Existing articles: %s.\n" .
			"IMPORTANT LANGUAGE RULE: write every title in %s. Do not switch language because of anglicisms or unclear terms.\n" .
			"Rules: no templates, no years, no 'complete guide', no 'step-by-step', no 'everything you need to know'.\n" .
			"Return ONLY a JSON array: [\"title1\", \"title2\", ...]",
			$niche,
			$cluster,
			'' !== $existing ? $existing : 'none',
			$lang_label
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 300 );
		return $this->parse_clusters_response( $result['text'] );
	}

	public function suggest_cluster_keywords( string $prompt ): array {
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 1200 );
		return [ 'text' => $result['text'] ?? '', 'tokens_used' => $result['tokens_used'] ?? 0 ];
	}

	public function quality_check( string $html, array $context ): int {
		$prompt = sprintf(
			"Assess the quality of the HTML below on a scale of 0-100.\n\n" .
			"Criteria (25 points each):\n" .
			"1. At least 2 internal links present\n" .
			"2. Meta description present and <= 155 characters\n" .
			"3. Search intent \"%s\" covered (keyword in H1 + intro)\n" .
			"4. No title-similarity >85%% with: %s\n\n" .
			"HTML: %s\n\n" .
			"Return ONLY an integer 0-100.",
			$context['search_intent'] ?? 'informational',
			implode( ', ', $context['existing_titles'] ?? [] ),
			substr( $html, 0, 3000 )
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 100 );
		$score  = (int) trim( $result['text'] );
		return max( 0, min( 100, $score ) );
	}

	public function chat_stream( array $messages, string $system_prompt, callable $on_chunk ): array {
		$result = $this->ai->chat_stream( $messages, $system_prompt, $on_chunk );
		return [
			'text'        => (string) ( $result['text'] ?? '' ),
			'meta'        => (string) ( $result['meta'] ?? '' ),
			'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
		];
	}

	public function generate_meta_description( string $title, string $content_excerpt ): array {
		$prompt = sprintf(
			"Write a meta description of 120-155 characters for an article with the title: \"%s\"\n\n" .
			"Start of content:\n%s\n\n" .
			"Rules:\n- Exactly 120-155 characters\n- Start with the main keyword\n- Compelling to click without clickbait\n\n" .
			"Return ONLY the meta description, without quotes or explanation.",
			$title,
			$content_excerpt
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 200 );
		$raw    = trim( $result['text'] );
		if ( mb_strlen( $raw ) > 155 ) {
			$raw = mb_substr( $raw, 0, 155 );
		}
		return [ 'meta_description' => $raw, 'tokens_used' => $result['tokens_used'] ];
	}

	public function optimize_title( string $title, string $focus_keyword ): array {
		$keyword_hint = '' !== $focus_keyword ? " Focus keyword: \"{$focus_keyword}\"." : '';
		$prompt = sprintf(
			"Generate 5 SEO-optimised alternatives for the title: \"%s\".%s\n\n" .
			"Rules:\n- Maximum 65 characters per title\n- Include the focus keyword where possible\n- Compelling to click without clickbait\n" .
			"- No 'Ultimate guide', 'Everything you need to know', 'Complete guide'\n\n" .
			"Return ONLY a JSON array: [\"title1\", \"title2\", ...]",
			$title,
			$keyword_hint
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 400 );
		return [ 'titles' => $this->parse_clusters_response( $result['text'] ), 'tokens_used' => $result['tokens_used'] ];
	}

	public function generate_excerpt( string $content ): array {
		$content_snippet = mb_substr( wp_strip_all_tags( $content ), 0, 2000 );
		$prompt = "Write an excerpt of 2-3 sentences for the following content:\n\n" .
			$content_snippet . "\n\nRules:\n- Exactly 2 to 3 sentences\n- Summarising and compelling to read\n- No spoilers of the conclusion\n\n" .
			"Return ONLY the excerpt, without quotes or extra explanation.";
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 200 );
		return [ 'excerpt' => trim( $result['text'] ), 'tokens_used' => $result['tokens_used'] ];
	}

	public function generate_article( string $system_prompt, string $user_prompt ): array {
		$combined_length = strlen( $system_prompt ) + strlen( $user_prompt );
		$requested_tokens = 6400;
		if ( $combined_length > 20000 ) {
			$requested_tokens = 5200;
		} elseif ( $combined_length > 12000 ) {
			$requested_tokens = 5800;
		}
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $user_prompt ] ], $system_prompt, $requested_tokens );
		return [ 'html' => $result['text'], 'tokens_used' => $result['tokens_used'] ];
	}

	public function expand_article( string $html, array $context ): array {
		$target   = max( 1200, (int) ( $context['word_count'] ?? 1500 ) );
		$current  = max( 0, (int) ( $context['current_word_count'] ?? str_word_count( wp_strip_all_tags( $html ) ) ) );
		$primary  = (string) ( $context['primary_keyword'] ?? $context['suggested_title'] ?? '' );
		$title    = (string) ( $context['suggested_title'] ?? $primary );
		$needed   = max( 500, $target - $current );
		$language = $this->infer_language_label( $context );
		$prompt = sprintf(
			"Expand the following HTML article so it reaches approximately %d words total. It currently has about %d words, so add roughly %d new words of genuinely new substance.\n\n" .
			"Requirements:\n- Write ONLY in %s\n- Keep the same topic and SEO focus keyword: %s\n- Preserve the existing useful content, but make every major section materially deeper\n- Add new H2 and H3 sections, examples, comparisons, decision criteria, practical scenarios and detailed FAQ answers\n- Return ONLY the final full HTML article starting directly with <h1>%s</h1> and ending with HTML, not markdown\n\nARTICLE HTML:\n%s",
			$target,
			$current,
			$needed,
			$language,
			$primary,
			$title,
			$html
		);
		$result = $this->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], '', 24000 );
		return [ 'html' => $result['text'] ?? '', 'tokens_used' => $result['tokens_used'] ?? 0 ];
	}

	private function build_system_prompt( array $context ): string {
		$niche    = $context['niche_label'] ?? 'general';
		$pillars  = '';
		$language = $this->infer_language_label( $context );
		foreach ( $context['pillar_pages'] ?? [] as $page ) {
			$pillars .= "- {$page['title']} ({$page['url']})\n";
		}
		$current_year = (int) date( 'Y' );
		$prompt  = "You are a content editor writing articles for a blog about {$niche}.\n\n";
		$prompt .= "IMPORTANT LANGUAGE RULE:\n- Write ONLY in {$language}.\n- The article language must follow the language of the keyword and topic.\n- Do not switch languages because of anglicisms, brand names or unclear terms.\n- Keep brand names and common loanwords natural, but keep the full article in {$language}.\n\n";
		$tone = $context['tone_instructions'] ?? '';
		if ( '' === $tone ) {
			$tone = (string) get_option( 'contentgem_tone_of_voice', '' );
		}
		if ( '' !== $tone ) {
			$prompt .= "TONE OF VOICE INSTRUCTIONS (follow these strictly):\n{$tone}\n\n";
		}
		$prompt .= "IMPORTANT: Never use specific years in article titles unless it is the current year. The current year is {$current_year}. If a year is needed, only use {$current_year}.\n\n";
		$prompt .= "FORBIDDEN in titles and headings:\n- 'Complete Guide', 'Step-by-Step', 'Everything You Need to Know', 'Ultimate Guide'\n- Years other than {$current_year}\n- 'For Beginners' as the only differentiator\n\n";
		$prompt .= "Write as if you are writing for a reader who genuinely wants to understand this topic.\n";
		$prompt .= "FORBIDDEN OPENING PHRASES AND CLICHÉS:\n- Never begin with phrases like 'In the dynamic world of', 'In today's world', 'In the current world', 'In de dynamische wereld van', 'In de wereld van vandaag', 'In de huidige wereld', or similar generic AI-like introductions.\n- Start with a concrete fact, observation, definition, practical scenario, or direct answer instead.\n\n";
		$prompt .= "INTERNAL LINKS - IMPORTANT: When adding internal links, never use ?p=ID URL format. Only use clean permalink URLs like /slug-name/ or full URLs.\n";
		$prompt .= "OUTPUT SAFETY RULES:\n- Never use markdown fences, code fences, backticks or prefixed tokens such as html, ```html or n```html.\n- Never output stray single-letter fragments such as n or nn before headings or paragraphs.\n- Return article HTML only. No commentary before the first tag and nothing after the conclusion.\n\n";
		if ( '' !== $pillars ) {
			$prompt .= "\nPILLAR PAGES (include 2-3 internal links with keyword-rich anchor text):\n{$pillars}";
		}
		$fact_checker = new CGM_Fact_Checker();
		if ( $fact_checker->enabled() ) {
			$prompt .= "\n" . $fact_checker->build_instruction_appendix( $language );
		}
		return $prompt;
	}

	private function build_suggest_prompt( array $context ): string {
		$semantic = implode( ', ', $context['lsi_keywords'] ?? [] );
		$gsc      = implode( ', ', $context['gsc_queries'] ?? [] );
		$language = $this->infer_language_label( $context );
		return sprintf(
			"Generate a content suggestion for gap: \"%s\"\n\nLanguage: %s\nIMPORTANT: The suggestion must be entirely in %s. Do not default to English.\n\nContext:\n- Search intent: %s\n- Semantic keywords to cover: %s\n- Google Search Console queries (if relevant): %s\n\nReturn ONLY valid JSON (no explanation, no markdown blocks):\n{\n  \"title\": \"SEO title max 65 characters\",\n  \"search_intent\": \"informational|commercial|navigational\",\n  \"h2_structure\": [\"H2 1\", \"H2 2\", \"H2 3\"],\n  \"recommended_internal_links\": [post_id_1, post_id_2],\n  \"estimated_word_count\": 1600,\n  \"meta_description\": \"max 155 characters\"\n}",
			$context['gap_topic'] ?? '',
			$language,
			$language,
			$context['search_intent'] ?? 'informational',
			$semantic ?: 'derive relevant semantic coverage',
			$gsc ?: 'none'
		);
	}

	private function build_draft_prompt( array $context ): string {
		$links = '';
		foreach ( $context['internal_links'] ?? [] as $link ) {
			$links .= "- {$link['title']} -> {$link['url']}\n";
		}
		$primary_keyword = $context['primary_keyword'] ?? $context['suggested_title'] ?? '';
		$lsi_keywords    = implode( ', ', $context['lsi_keywords'] ?? [] );
		$word_count      = max( 1200, (int) ( $context['word_count'] ?? 1600 ) );
		$h2_list         = implode( ', ', $context['h2_structure'] ?? [] );
		$language        = $this->infer_language_label( $context );
		$additional_instructions = trim( (string) ( $context['additional_instructions'] ?? '' ) );
		$gsc_queries = implode( ', ', $context['gsc_queries'] ?? [] );
		$competitor_block = ! empty( $context['competitor_insights'] )
			? "\n\nCOMPETITOR INSIGHTS (use as reference, not to copy, and ensure the article covers these themes at least as well):\n" . $context['competitor_insights']
			: "\n\nCOMPETITOR INSIGHTS: No competitor data available. Use best-practice SEO coverage and create comprehensive topical depth.";
		$faq_heading = $this->localized_heading( 'faq', $language );
		$conclusion_heading = $this->localized_heading( 'conclusion', $language );
		return sprintf(
			"Write a complete SEO article for the primary keyword: \"%s\"\n\nLANGUAGE REQUIREMENT:\n- Write ONLY in %s\n- Do not switch to another language because of anglicisms, borrowed terms or ambiguous words\n- Keep the article language aligned with the keyword language\n\nOUTPUT FORMAT - follow this exactly:\nLine 1: <!-- meta: [your meta description] -->\nThen directly the HTML of the article. No explanation, no markdown, no JSON.\n\nMETA DESCRIPTION (line 1):\n- Maximum 155 characters\n- The primary keyword appears in the first 10 words\n\nHTML STRUCTURE:\n- Start with <h1>%s</h1>\n- H2 headings: %s\n- The primary keyword appears in the first 100 words of the body text\n- Target approximately %d words total and stay above 90%% of that target where possible (excluding HTML tags)\n- Add real depth: examples, comparisons, scenarios, decision criteria, and practical takeaways\n- Do NOT include SVG, charts, diagrams, cards, figures, captions, legend blocks, label stacks, metric summaries or related-term lists in the article HTML\n- Do NOT append loose labels, percentages, coverage summaries, topic maps or visual descriptions after the conclusion\n- End the article cleanly after the conclusion section\n\nSEARCH INTENT: %s\n\nLSI / SEMANTIC KEYWORDS (optional supporting terms; use only where naturally relevant):\n%s\n\nGOOGLE SEARCH CONSOLE QUERIES TO REFLECT WHERE RELEVANT:\n%s\n\nINTERNAL LINKS (required: include 2-3 with keyword-rich anchor text):\n%s\nCONTENT REQUIREMENTS:\n- Address the reader impersonally or as \"you\"\n- Use concrete scenarios and examples\n- Add facts or statistics with source attribution where appropriate\n- Add a comparison or table where relevant (<table>)\n- Add at least 1 step-by-step list (<ol>)\n- Include all major subtopics competitors cover, but explain them more clearly and more deeply\n- Additional instructions: %s\n\nREQUIRED CLOSING SECTIONS (in this order):\n1. <h2>%s</h2> with exactly 4 sub-questions as <h3>, each followed by a <p> of 50-100 words\n2. <h2>%s</h2> with a summarising paragraph and a clear call-to-action%s",
			$primary_keyword,
			$language,
			$context['suggested_title'] ?? '',
			$h2_list,
			$word_count,
			$context['search_intent'] ?? 'informational',
			$lsi_keywords ?: '(not provided - derive relevant LSI terms yourself)',
			$gsc_queries ?: '(none available)',
			$links,
			$additional_instructions ?: 'none',
			$faq_heading,
			$conclusion_heading,
			$competitor_block
		);
	}


	private function build_article_outline( array $context, string $system ): array {
		$h2_seed = implode( ', ', array_filter( array_map( 'sanitize_text_field', (array) ( $context['h2_structure'] ?? [] ) ) ) );
		$prompt = sprintf(
			"Create a concise JSON article outline for the topic \"%s\".\nReturn ONLY JSON with this shape: {\"title\":string,\"sections\":[{\"heading\":string,\"brief\":string,\"target_words\":integer}],\"faq_questions\":[string,string,string,string]}.\nRules: 4-6 sections, each section materially different, use the requested language, no markdown, no explanation. Existing H2 ideas: %s",
			(string) ( $context['suggested_title'] ?? '' ),
			$h2_seed ?: 'none'
		);
		try {
			$result = $this->chat_with_retry( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 900 );
			$parsed = $this->parse_json_response( (string) ( $result['text'] ?? '' ) );
			if ( is_array( $parsed ) ) {
				return $parsed;
			}
		} catch ( \Throwable $e ) {
		}
		return [ 'title' => (string) ( $context['suggested_title'] ?? '' ), 'sections' => [], 'faq_questions' => [] ];
	}

	private function generate_article_intro( array $context, string $system, string $title, array $sections ): array {
		$headings = implode( ', ', array_map( static function( array $section ) { return (string) ( $section['heading'] ?? '' ); }, $sections ) );
		$prompt = sprintf(
			"Write only the opening body HTML for an SEO article titled \"%s\".\nRequirements: no <h1>, no meta comment, 180-260 words, 2-3 paragraphs, the primary keyword \"%s\" appears in the first 80 words, preview these upcoming sections naturally: %s. Return ONLY HTML paragraphs. Never use markdown fences, backticks or the token html.",
			$title,
			(string) ( $context['primary_keyword'] ?? '' ),
			$headings ?: 'core sections'
		);
		$result = $this->chat_with_retry( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 1200 );
		return [ 'html' => trim( (string) ( $result['text'] ?? '' ) ), 'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ) ];
	}

	private function generate_article_section( array $context, string $system, string $title, array $section, int $position, int $total ): array {
		$heading = sanitize_text_field( (string) ( $section['heading'] ?? '' ) );
		$brief   = sanitize_text_field( (string) ( $section['brief'] ?? '' ) );
		$target_words = max( 180, min( 420, (int) ( $section['target_words'] ?? 240 ) ) );
		$prompt = sprintf(
			"Write only one complete article section in HTML for the article \"%s\".\nSection heading: %s\nSection brief: %s\nTarget length: about %d words.\nRequirements: start with <h2>%s</h2>, then substantive paragraphs. Add <h3> subheadings where useful. Use examples, comparisons, concrete detail, and naturally reflect these support terms where relevant: %s. If useful, include a short list or table. Do not write FAQ or conclusion. Return ONLY this section HTML. Never use markdown fences, backticks or standalone tokens like html, n, or nn.",
			$title,
			$heading,
			$brief ?: 'Expand this section with practical, useful detail.',
			$target_words,
			$heading,
			implode( ', ', array_slice( (array) ( $context['lsi_keywords'] ?? [] ), 0, 8 ) )
		);
		$result = $this->chat_with_retry( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 1800 );
		$html = trim( (string) ( $result['text'] ?? '' ) );
		if ( '' !== $html && ! preg_match( '/<h2[^>]*>/i', $html ) ) {
			$html = '<h2>' . esc_html( $heading ) . '</h2>' . $html;
		}
		return [ 'html' => $html, 'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ) ];
	}

	private function generate_forced_closing_block( array $context, string $system, string $title, array $faq ): array {
		$language = $this->infer_language_label( $context );
		$faq_heading = $this->localized_heading( 'faq', $language );
		$conclusion_heading = $this->localized_heading( 'conclusion', $language );
		while ( count( $faq ) < 4 ) {
			$faq[] = $this->fallback_faq_question( count( $faq ), $language, (string) ( $context['primary_keyword'] ?? $title ) );
		}
		$prompt = sprintf(
			"Write only the closing HTML block for the article \"%s\".\nRequirements: first add <h2>%s</h2>, then exactly 4 FAQ items in accordion format using <details class=\"cgm-faq-item\"><summary>Question</summary><div class=\"cgm-faq-answer\"><p>Answer</p></div></details>. Questions must be: %s. Each answer 55-95 words. After that add <h2>%s</h2> and one strong concluding paragraph with a practical call to action. Return ONLY HTML. Never use markdown fences, backticks or standalone tokens like html, n, or nn.",
			$title,
			$faq_heading,
			implode( ' | ', array_slice( $faq, 0, 4 ) ),
			$conclusion_heading
		);
		$result = $this->chat_with_retry( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 1600 );
		$html = trim( (string) ( $result['text'] ?? '' ) );
		if ( false === stripos( $html, '<h2' ) ) {
			$html = '<h2>' . esc_html( $faq_heading ) . '</h2>' . $html . '<h2>' . esc_html( $conclusion_heading ) . '</h2><p>' . esc_html__( 'Apply these insights in a structured way and keep improving the result over time.', 'contentgem' ) . '</p>';
		}
		return [ 'html' => $html, 'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ) ];
	}

	private function fallback_faq_question( int $index, string $language, string $keyword ): string {
		$language = strtolower( trim( $language ) );
		$sets = [
			'dutch' => [
				'Wat is belangrijk om te weten over %s?',
				'Hoe pas je %s in de praktijk toe?',
				'Welke fouten worden vaak gemaakt bij %s?',
				'Wanneer levert %s het meeste resultaat op?',
			],
			'english' => [
				'What matters most when evaluating %s?',
				'How do you apply %s in practice?',
				'Which mistakes are common with %s?',
				'When does %s deliver the best results?',
			],
		];
		$template = $sets[ $language ][ $index ] ?? $sets['english'][ $index ] ?? 'How should you approach %s?';
		return sprintf( $template, $keyword );
	}

	private function chat_with_retry( array $messages, string $system_prompt = '', int $max_tokens = 1200, int $attempts = 3 ): array {
		$last = [ 'text' => '', 'tokens_used' => 0 ];
		for ( $i = 0; $i < $attempts; $i++ ) {
			$last = $this->chat( $messages, $system_prompt, $max_tokens );
			if ( '' !== trim( (string) ( $last['text'] ?? '' ) ) ) {
				return $last;
			}
		}
		return $last;
	}

	private function infer_language_label( array $context ): string {
		$explicit = strtolower( trim( (string) ( $context['language'] ?? $context['taal'] ?? '' ) ) );
		if ( '' === $explicit ) {
			$explicit = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
			if ( 'custom' === $explicit ) {
				$custom = sanitize_text_field( (string) get_option( 'contentgem_content_language_custom', '' ) );
				if ( '' !== $custom ) {
					return $custom;
				}
			}
		}
		$explicit = str_replace( '_', '-', $explicit );
		$map = [
			'nl' => 'Dutch', 'nederlands' => 'Dutch', 'dutch' => 'Dutch',
			'en' => 'English', 'engels' => 'English', 'english' => 'English',
			'de' => 'German', 'deutsch' => 'German', 'german' => 'German',
			'fr' => 'French', 'français' => 'French', 'francais' => 'French', 'french' => 'French',
			'es' => 'Spanish', 'español' => 'Spanish', 'espanol' => 'Spanish', 'spanish' => 'Spanish',
			'it' => 'Italian', 'italiano' => 'Italian', 'italian' => 'Italian',
			'pt' => 'Portuguese', 'português' => 'Portuguese', 'portugues' => 'Portuguese', 'portuguese' => 'Portuguese',
		];
		if ( isset( $map[ $explicit ] ) ) {
			return $map[ $explicit ];
		}
		if ( 'auto' !== $explicit && preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $explicit ) ) {
			$parts = explode( '-', $explicit );
			$code = sanitize_key( $parts[0] );
			return strtoupper( $code );
		}
		$text = implode( ' ', array_filter( [
			(string) ( $context['primary_keyword'] ?? '' ),
			(string) ( $context['focus_keyword'] ?? '' ),
			(string) ( $context['suggested_title'] ?? '' ),
			(string) ( $context['topic'] ?? '' ),
			(string) ( $context['cluster_name'] ?? '' ),
			(string) ( $context['cluster'] ?? '' ),
			implode( ' ', (array) ( $context['gsc_queries'] ?? [] ) ),
		] ) );
		$lang = class_exists( 'CGM_NLP_Engine' ) ? ( new CGM_NLP_Engine() )->detect_language( $text ) : 'en';
		return 'en' === $lang ? 'English' : 'Dutch';
	}



	private function localized_heading( string $type, string $language ): string {
		$language = strtolower( trim( $language ) );
		$labels = [
			'faq' => [
				'dutch' => 'Veelgestelde vragen', 'english' => 'Frequently asked questions', 'german' => 'Häufig gestellte Fragen',
				'french' => 'Questions fréquentes', 'spanish' => 'Preguntas frecuentes', 'italian' => 'Domande frequenti', 'portuguese' => 'Perguntas frequentes'
			],
			'conclusion' => [
				'dutch' => 'Conclusie', 'english' => 'Conclusion', 'german' => 'Fazit',
				'french' => 'Conclusion', 'spanish' => 'Conclusión', 'italian' => 'Conclusione', 'portuguese' => 'Conclusão'
			],
		];
		return $labels[ $type ][ $language ] ?? $labels[ $type ]['english'];
	}

	private function parse_clusters_response( string $raw ): array {
		$try_decode = static function ( string $json ) {
			$parsed = json_decode( $json, true );
			if ( is_array( $parsed ) ) {
				return array_slice( array_values( array_filter( $parsed, 'is_string' ) ), 0, 12 );
			}
			return null;
		};
		$result = $try_decode( $raw );
		if ( null !== $result ) {
			return $result;
		}
		$stripped = preg_replace( '/^```(?:json)?\s*/i', '', trim( $raw ) );
		$stripped = preg_replace( '/\s*```$/', '', trim( $stripped ?? '' ) );
		$result   = $try_decode( $stripped );
		if ( null !== $result ) {
			return $result;
		}
		$start = strpos( $raw, '[' );
		$end   = strrpos( $raw, ']' );
		if ( false !== $start && false !== $end && $end > $start ) {
			$result = $try_decode( substr( $raw, $start, $end - $start + 1 ) );
			if ( null !== $result ) {
				return $result;
			}
		}
		throw new RuntimeException( __( 'AI returned no valid JSON array for clusters.', 'contentgem' ) );
	}

	private function parse_json_response( string $raw ): array {
		$parsed = json_decode( $raw, true );
		if ( is_array( $parsed ) ) {
			return $parsed;
		}
		$stripped = preg_replace( '/^```(?:json)?\s*/i', '', trim( $raw ) );
		$stripped = preg_replace( '/\s*```$/', '', trim( $stripped ?? '' ) );
		$parsed   = json_decode( $stripped, true );
		if ( is_array( $parsed ) ) {
			return $parsed;
		}
		$start = strpos( $raw, '{' );
		$end   = strrpos( $raw, '}' );
		if ( false !== $start && false !== $end && $end > $start ) {
			$parsed = json_decode( substr( $raw, $start, $end - $start + 1 ), true );
			if ( is_array( $parsed ) ) {
				return $parsed;
			}
		}
		throw new RuntimeException( __( 'AI returned no valid JSON for suggestion.', 'contentgem' ) );
	}
}
