<?php
/**
 * Contentgem cache helper.
 */
defined( 'ABSPATH' ) || exit;

class CGM_Cache {
	public static function get( string $key ) {
		return get_transient( $key );
	}

	public static function set( string $key, $value, int $ttl ): void {
		set_transient( $key, $value, $ttl );
	}

	public static function delete( string $key ): void {
		delete_transient( $key );
	}

	public static function clear_analysis_lists( int $site_id = 0 ): void {
		global $wpdb;
		if ( $site_id > 0 ) {
			delete_transient( 'contentgem_clusters_' . $site_id );
		}
		$likes = [
			$wpdb->esc_like( '_transient_contentgem_gaps_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_contentgem_gaps_' ) . '%',
			$wpdb->esc_like( '_transient_contentgem_clusters_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_contentgem_clusters_' ) . '%',
		];
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
				$likes[0], $likes[1], $likes[2], $likes[3]
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}
