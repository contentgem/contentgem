<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Job_Queue {
	protected CGM_Analysis_Run_Repository $repo;
	public function __construct( ?CGM_Analysis_Run_Repository $repo = null ) { $this->repo = $repo ?: new CGM_Analysis_Run_Repository(); }
	public function enqueue( string $job_type, array $payload, array $args = [] ): int { return $this->repo->create_run( [ 'run_type' => $job_type, 'status' => 'queued', 'started_by' => get_current_user_id(), 'input_json' => wp_json_encode( $payload ) ] ); }
}
