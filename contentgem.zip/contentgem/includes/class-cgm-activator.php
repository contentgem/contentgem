<?php
/**
 * Class CGM_Activator
 *
 * Beheert plugin-activatie: database-installatie, upgrades en defaults.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Activator {

	/**
	 * Wordt uitgevoerd bij plugin-activatie.
	 * Maakt database-tabellen aan en slaat versie op.
	 */
	public static function install(): void {
		self::create_tables();
		self::backfill_topic_post_counts();
		update_option( 'contentgem_db_version', CONTENTGEM_DB_VERSION );
		update_option( 'contentgem_version', CONTENTGEM_VERSION );

		add_option( 'contentgem_api_key', '' );
		add_option( 'contentgem_gsc_tokens', '' );
		add_option( 'contentgem_niche', '' );
		add_option( 'contentgem_niche_description', '' );

		if ( false === get_option( 'contentgem_onboarding_complete', false ) ) {
			add_option( 'contentgem_onboarding_complete', false );
		}
		if ( false === get_option( 'contentgem_force_onboarding', false ) ) {
			add_option( 'contentgem_force_onboarding', false );
		}

		update_option( 'contentgem_do_activation_redirect', true );
	}

	/**
	 * Wordt uitgevoerd bij versie-upgrade.
	 */
	public static function upgrade(): void {
		global $wpdb;

		$installed = get_option( 'contentgem_db_version', '0.0.0' );

		if ( version_compare( $installed, '1.0.2', '<' ) ) {
			self::create_tables();
		}

		if ( version_compare( $installed, '1.1.0', '<' ) ) {
			$table  = $wpdb->prefix . 'cgm_cannibalization';
			$column = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
					 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'overlap_score'",
					DB_NAME,
					$table
				)
			);

			if ( empty( $column ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD COLUMN overlap_score INT NOT NULL DEFAULT 0 AFTER similarity_score" );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD KEY idx_overlap_score (site_id, overlap_score)" );
			}
		}

		if ( version_compare( $installed, '1.2.0', '<' ) ) {
			$table  = $wpdb->prefix . 'cgm_gaps';
			$column = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
					 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'gsc_clicks'",
					DB_NAME,
					$table
				)
			);

			if ( empty( $column ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD COLUMN gsc_clicks INT UNSIGNED NOT NULL DEFAULT 0 AFTER gsc_impressions" );
			}
		}

		if ( version_compare( $installed, '1.3.0', '<' ) ) {
			$table = $wpdb->prefix . 'cgm_gaps';
			$fixes_exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'fixes_broken_link'",
					DB_NAME,
					$table
				)
			);
			$broken_exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'broken_url'",
					DB_NAME,
					$table
				)
			);
			if ( ! $fixes_exists ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD COLUMN fixes_broken_link TINYINT(1) NOT NULL DEFAULT 0" );
			}
			if ( ! $broken_exists ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD COLUMN broken_url VARCHAR(500) DEFAULT NULL" );
			}
		}

		if ( version_compare( $installed, '1.4.0', '<' ) ) {
			$table      = $wpdb->prefix . 'cgm_gaps';
			$key_exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
					 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = 'unique_broken_url'",
					DB_NAME,
					$table
				)
			);
			if ( ! $key_exists ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE {$table} ADD UNIQUE KEY unique_broken_url (site_id, broken_url(191))" );
			}
		}

		self::create_tables();
		self::backfill_topic_post_counts();
		update_option( 'contentgem_db_version', CONTENTGEM_DB_VERSION );
	}

	/**
	 * Wordt uitgevoerd bij plugin-deactivatie.
	 */
	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'cgm_run_analysis' );
		wp_clear_scheduled_hook( 'cgm_run_analysis_job' );
		wp_clear_scheduled_hook( 'cgm_run_linkscan_job' );
		wp_clear_scheduled_hook( 'cgm_run_assistant_draft_job' );
		wp_clear_scheduled_hook( 'cgm_process_jobs' );
	}

	/**
	 * Maakt alle plugin-tabellen aan via dbDelta.
	 */
	private static function create_tables(): void {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tables = self::get_schema( $charset );
		foreach ( $tables as $sql ) {
			dbDelta( $sql );
		}
	}

	/**
	 * Berekent post_count voor bestaande clusters eenmalig/backfill.
	 */
	private static function backfill_topic_post_counts(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'cgm_topics';

		$topics = $wpdb->get_results( "SELECT id, post_ids, post_count FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		foreach ( (array) $topics as $topic ) {
			$post_ids = json_decode( (string) ( $topic->post_ids ?? '[]' ), true );
			$count    = is_array( $post_ids ) ? count( $post_ids ) : 0;
			if ( (int) ( $topic->post_count ?? -1 ) !== $count ) {
				$wpdb->update( $table, [ 'post_count' => $count ], [ 'id' => (int) $topic->id ], [ '%d' ], [ '%d' ] );
			}
		}
	}

	/**
	 * Retourneert alle CREATE TABLE statements.
	 *
	 * @param string $charset Charset collation string.
	 * @return string[]
	 */
	private static function get_schema( string $charset ): array {
		global $wpdb;
		$p = $wpdb->prefix;

		return [
			"CREATE TABLE {$p}cgm_sites (
				id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				blog_id          BIGINT UNSIGNED NOT NULL DEFAULT 1,
				niche_label      VARCHAR(255)    NOT NULL DEFAULT '',
				tone_snapshot    LONGTEXT,
				analysis_status  ENUM('idle','running','done','error') DEFAULT 'idle',
				created_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				UNIQUE KEY blog_id (blog_id)
			) $charset;",

			"CREATE TABLE {$p}cgm_jobs (
				id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				job_key          VARCHAR(191) NOT NULL,
				site_id          BIGINT UNSIGNED NOT NULL DEFAULT 0,
				type             VARCHAR(100) NOT NULL,
				status           VARCHAR(20) NOT NULL DEFAULT 'queued',
				progress_current INT UNSIGNED NOT NULL DEFAULT 0,
				progress_total   INT UNSIGNED NOT NULL DEFAULT 100,
				step             VARCHAR(100) NOT NULL DEFAULT '',
				message          TEXT NULL,
				payload_json     LONGTEXT NULL,
				result_json      LONGTEXT NULL,
				error_json       LONGTEXT NULL,
				attempts         INT UNSIGNED NOT NULL DEFAULT 0,
				max_attempts     INT UNSIGNED NOT NULL DEFAULT 1,
				idempotency_key  VARCHAR(191) NOT NULL DEFAULT '',
				job_token        VARCHAR(191) NOT NULL DEFAULT '',
				locked_at        DATETIME NULL,
				locked_by        VARCHAR(191) NOT NULL DEFAULT '',
				next_run_at      DATETIME NULL,
				created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				UNIQUE KEY uniq_job_key (job_key),
				KEY idx_type_status (type, status),
				KEY idx_site_type (site_id, type),
				KEY idx_site_type_idempotency (site_id, type, idempotency_key)
			) $charset;",

			"CREATE TABLE {$p}cgm_job_events (
				id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				job_id     BIGINT UNSIGNED NOT NULL,
				level      VARCHAR(20) NOT NULL DEFAULT 'info',
				message    TEXT NULL,
				meta_json  LONGTEXT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY idx_job_created (job_id, created_at)
			) $charset;",

			"CREATE TABLE {$p}cgm_topics (
				id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				site_id        BIGINT UNSIGNED NOT NULL,
				cluster_name   VARCHAR(255)    NOT NULL,
				coverage_score FLOAT           NOT NULL DEFAULT 0,
				post_ids       LONGTEXT,
				post_count     INT UNSIGNED    NOT NULL DEFAULT 0,
				updated_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY idx_site_coverage (site_id, coverage_score),
				KEY idx_site_cluster_name (site_id, cluster_name(191))
			) $charset;",

			"CREATE TABLE {$p}cgm_gaps (
				id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				site_id           BIGINT UNSIGNED NOT NULL,
				topic_id          BIGINT UNSIGNED NOT NULL,
				suggested_title   VARCHAR(255)    NOT NULL DEFAULT '',
				search_intent     ENUM('informational','commercial','navigational') DEFAULT 'informational',
				gsc_impressions   INT UNSIGNED    NOT NULL DEFAULT 0,
				gsc_clicks        INT UNSIGNED    NOT NULL DEFAULT 0,
				fixes_broken_link TINYINT(1)      NOT NULL DEFAULT 0,
				broken_url        VARCHAR(500)    DEFAULT NULL,
				priority_score    FLOAT           NOT NULL DEFAULT 0,
				status            ENUM('open','in_progress','published') DEFAULT 'open',
				created_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY idx_site_priority (site_id, priority_score),
				KEY idx_site_status_priority (site_id, status, priority_score),
				KEY idx_site_topic_status (site_id, topic_id, status),
				KEY idx_site_intent_status (site_id, search_intent, status),
				KEY idx_site_broken_status (site_id, fixes_broken_link, status),
				UNIQUE KEY unique_broken_url (site_id, broken_url(191))
			) $charset;",

			"CREATE TABLE {$p}cgm_token_usage (
				id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id      BIGINT UNSIGNED NOT NULL,
				tier         ENUM('free','starter','growth','unlimited') NOT NULL,
				tokens_used  BIGINT UNSIGNED NOT NULL DEFAULT 0,
				tokens_limit BIGINT UNSIGNED NOT NULL,
				reset_date   DATE            NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY idx_user (user_id)
			) $charset;",

			"CREATE TABLE {$p}cgm_drafts (
				id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
				gap_id        BIGINT UNSIGNED  NOT NULL,
				wp_post_id    BIGINT UNSIGNED  NOT NULL DEFAULT 0,
				tokens_spent  INT UNSIGNED     NOT NULL DEFAULT 0,
				quality_score TINYINT UNSIGNED NOT NULL DEFAULT 0,
				created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY idx_gap (gap_id)
			) $charset;",

			"CREATE TABLE {$p}cgm_cannibalization (
				id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				site_id          BIGINT UNSIGNED NOT NULL,
				post_id_1        BIGINT UNSIGNED NOT NULL,
				post_id_2        BIGINT UNSIGNED NOT NULL,
				title_1          VARCHAR(255) NOT NULL DEFAULT '',
				title_2          VARCHAR(255) NOT NULL DEFAULT '',
				overlap_score    INT UNSIGNED NOT NULL DEFAULT 0,
				similarity_score FLOAT NOT NULL DEFAULT 0,
				status           ENUM('open','merged','ignored') DEFAULT 'open',
				created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY idx_site (site_id),
				KEY idx_status (status)
			) $charset;",

			"CREATE TABLE {$p}cgm_broken_links_cache (
				id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				site_id        BIGINT UNSIGNED NOT NULL,
				source_post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				broken_url     VARCHAR(500)    NOT NULL,
				anchor_text    VARCHAR(255)    NOT NULL DEFAULT '',
				slug_text      VARCHAR(255)    NOT NULL DEFAULT '',
				first_seen_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
				last_seen_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				UNIQUE KEY uniq_site_url_anchor (site_id, broken_url(191), anchor_text(191)),
				KEY idx_site_id (site_id),
				KEY idx_source_post (source_post_id)
			) $charset;",
			"CREATE TABLE {$p}cgm_content_nodes (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	node_type VARCHAR(50) NOT NULL,
	wp_object_id BIGINT UNSIGNED NULL,
	slug VARCHAR(191) NOT NULL,
	title TEXT NULL,
	status VARCHAR(50) NOT NULL DEFAULT 'active',
	meta_json LONGTEXT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_node_type (node_type),
	KEY idx_wp_object_id (wp_object_id),
	KEY idx_slug (slug)
) $charset;",

"CREATE TABLE {$p}cgm_content_edges (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	from_node_id BIGINT UNSIGNED NOT NULL,
	to_node_id BIGINT UNSIGNED NOT NULL,
	edge_type VARCHAR(50) NOT NULL,
	weight DECIMAL(8,4) NOT NULL DEFAULT 1.0000,
	meta_json LONGTEXT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_from_node (from_node_id),
	KEY idx_to_node (to_node_id),
	KEY idx_edge_type (edge_type)
) $charset;",

"CREATE TABLE {$p}cgm_embeddings (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	object_type VARCHAR(50) NOT NULL,
	object_id BIGINT UNSIGNED NOT NULL,
	provider VARCHAR(50) NOT NULL,
	model VARCHAR(100) NOT NULL,
	embedding_hash VARCHAR(64) NOT NULL,
	vector_json LONGTEXT NULL,
	content_hash VARCHAR(64) NOT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_object (object_type, object_id),
	KEY idx_content_hash (content_hash)
) $charset;",

"CREATE TABLE {$p}cgm_serp_snapshots (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	keyword_node_id BIGINT UNSIGNED NULL,
	query VARCHAR(191) NOT NULL,
	locale VARCHAR(20) NOT NULL DEFAULT 'en',
	device_type VARCHAR(20) NOT NULL DEFAULT 'desktop',
	snapshot_json LONGTEXT NOT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_keyword_node (keyword_node_id),
	KEY idx_query (query)
) $charset;",

"CREATE TABLE {$p}cgm_analysis_runs (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	run_type VARCHAR(50) NOT NULL,
	status VARCHAR(20) NOT NULL DEFAULT 'queued',
	started_by BIGINT UNSIGNED NULL,
	input_json LONGTEXT NULL,
	result_json LONGTEXT NULL,
	error_json LONGTEXT NULL,
	started_at DATETIME NULL,
	finished_at DATETIME NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_run_type (run_type),
	KEY idx_status (status),
	KEY idx_started_by (started_by)
) $charset;",

"CREATE TABLE {$p}cgm_link_suggestions (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	source_post_id BIGINT UNSIGNED NOT NULL,
	target_post_id BIGINT UNSIGNED NOT NULL,
	anchor_text TEXT NOT NULL,
	placement_hint VARCHAR(191) NULL,
	confidence DECIMAL(5,4) NOT NULL DEFAULT 0.0000,
	status VARCHAR(20) NOT NULL DEFAULT 'suggested',
	meta_json LONGTEXT NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_source_post (source_post_id),
	KEY idx_target_post (target_post_id),
	KEY idx_status (status)
) $charset;",

"CREATE TABLE {$p}cgm_content_overlap (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	source_post_id BIGINT UNSIGNED NOT NULL,
	compare_post_id BIGINT UNSIGNED NOT NULL,
	similarity_score DECIMAL(6,5) NOT NULL,
	overlap_type VARCHAR(50) NOT NULL DEFAULT 'semantic',
	recommended_angle TEXT NULL,
	recommended_intent VARCHAR(100) NULL,
	recommended_structure VARCHAR(100) NULL,
	created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_source_post (source_post_id),
	KEY idx_compare_post (compare_post_id),
	KEY idx_similarity (similarity_score)
) $charset;"

		];
	}
}