<?php
defined( 'ABSPATH' ) || exit;

class CGM_Codebase_Summarizer {
	public function summarize( array $file_record ): array {
		$symbols = (array) ( $file_record['symbols'] ?? [] );
		$parts = [];
		$parts[] = 'File type: ' . ( $file_record['type'] ?? 'unknown' );
		if ( ! empty( $symbols['classes'] ) ) {
			$parts[] = 'Classes: ' . implode( ', ', array_slice( (array) $symbols['classes'], 0, 8 ) );
		}
		if ( ! empty( $symbols['functions'] ) ) {
			$parts[] = 'Functions: ' . implode( ', ', array_slice( (array) $symbols['functions'], 0, 8 ) );
		}
		if ( ! empty( $symbols['rest_routes'] ) ) {
			$parts[] = 'REST routes: ' . implode( ', ', array_slice( (array) $symbols['rest_routes'], 0, 8 ) );
		}
		if ( ! empty( $symbols['options'] ) ) {
			$parts[] = 'Option keys: ' . implode( ', ', array_slice( (array) $symbols['options'], 0, 12 ) );
		}
		return [
			'summary' => implode( ' | ', $parts ),
			'hash' => (string) ( $file_record['hash'] ?? '' ),
			'generated_at' => gmdate( 'c' ),
		];
	}
}
