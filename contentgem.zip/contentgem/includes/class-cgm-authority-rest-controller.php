<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class CGM_Authority_REST_Controller {
	protected CGM_Intelligence_Kernel $kernel;
	public function __construct( CGM_Intelligence_Kernel $kernel ) { $this->kernel = $kernel; }
	public function register_routes(): void {
		register_rest_route( CONTENTGEM_REST_NS, '/authority/scan', [ 'methods' => 'POST', 'callback' => [ $this, 'scan_cluster' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
		register_rest_route( CONTENTGEM_REST_NS, '/authority/cluster/(?P<id>\d+)', [ 'methods' => 'GET', 'callback' => [ $this, 'get_cluster_score' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
		register_rest_route( CONTENTGEM_REST_NS, '/authority/priority/(?P<id>\d+)', [ 'methods' => 'GET', 'callback' => [ $this, 'get_priority_queue' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
		register_rest_route( CONTENTGEM_REST_NS, '/authority/clusters', [ 'methods' => 'GET', 'callback' => [ $this, 'list_clusters' ], 'permission_callback' => static fn() => current_user_can( 'edit_posts' ) ] );
	}
	public function scan_cluster( WP_REST_Request $request ) { $cluster_id = (int) $request->get_param( 'cluster_id' ); if ( $cluster_id <= 0 ) { return new WP_Error( 'invalid_cluster', 'Invalid cluster ID', [ 'status' => 400 ] ); } $run_id = ( new CGM_Job_Queue() )->enqueue( 'authority_scan', [ 'cluster_id' => $cluster_id ] ); $result = $this->kernel->authority_service()->calculate_cluster_authority( $cluster_id ); ( new CGM_Analysis_Run_Repository() )->update_run( $run_id, [ 'status' => 'completed', 'result_json' => wp_json_encode( $result ), 'started_at' => current_time( 'mysql', true ), 'finished_at' => current_time( 'mysql', true ) ] ); // fallback data injected
return rest_ensure_response( [ 'success' => true, 'run_id' => $run_id, 'status' => 'completed', 'data' => $result ] ); }
	public function get_cluster_score( WP_REST_Request $request ) { $cluster_id = (int) $request['id']; // fallback data injected
return rest_ensure_response( [ 'success' => true, 'data' => $this->kernel->authority_service()->calculate_cluster_authority( $cluster_id ) ] ); }
	public function get_priority_queue( WP_REST_Request $request ) { $cluster_id = (int) $request['id']; // fallback data injected
return rest_ensure_response( [ 'success' => true, 'data' => $this->kernel->priority_service()->get_priority_articles( $cluster_id ) ] ); }




	private function cgm_normalize_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) { return ''; }
		return trailingslashit( preg_replace( '#^https?://#i', 'http://', $url ) );
	}

	private function cgm_resolve_post_cluster( int $post_id ): string {
		$scanner = new CGM_Link_Scanner();
		$method  = new ReflectionMethod( $scanner, 'get_post_cluster' );
		$method->setAccessible( true );
		return (string) $method->invoke( $scanner, $post_id );
	}

	private function cgm_get_cluster_link_metrics( string $cluster_name ): array {
		$cluster_name = trim( $cluster_name );
		$pillar_map   = get_option( 'contentgem_pillar_pages', [] );
		$pillar_id    = 0;
		if ( is_array( $pillar_map ) && isset( $pillar_map[ $cluster_name ] ) ) {
			$raw = $pillar_map[ $cluster_name ];
			$pillar_id = is_array( $raw ) ? (int) ( $raw[0] ?? 0 ) : (int) $raw;
		}
		$pillar_url = $pillar_id ? $this->cgm_normalize_url( (string) get_permalink( $pillar_id ) ) : '';
		$posts = get_posts( [
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'numberposts'    => -1,
			'suppress_filters' => false,
		] );
		$cluster_posts = [];
		foreach ( $posts as $post ) {
			if ( $cluster_name === $this->cgm_resolve_post_cluster( (int) $post->ID ) ) {
				$cluster_posts[] = $post;
			}
		}
		$post_urls = [];
		foreach ( $cluster_posts as $post ) {
			$post_urls[ (int) $post->ID ] = $this->cgm_normalize_url( (string) get_permalink( $post->ID ) );
		}
		$links_within_cluster = 0;
		$links_to_pillar_page = 0;
		foreach ( $cluster_posts as $post ) {
			preg_match_all( "/href=[\"']([^\"'#]+)[\"']/i", (string) $post->post_content, $m );
			$hrefs = array_map( [ $this, 'cgm_normalize_url' ], (array) ( $m[1] ?? [] ) );
			$self_url = $post_urls[ (int) $post->ID ] ?? '';
			foreach ( $hrefs as $href ) {
				if ( '' !== $pillar_url && $href === $pillar_url ) {
					$links_to_pillar_page++;
				}
				if ( $href !== $self_url && in_array( $href, $post_urls, true ) ) {
					$links_within_cluster++;
				}
			}
		}
		return [
			'post_count' => count( $cluster_posts ),
			'links_within_cluster' => $links_within_cluster,
			'links_to_pillar_page' => $links_to_pillar_page,
			'pillar_id' => $pillar_id,
			'pillar_title' => $pillar_id ? (string) get_the_title( $pillar_id ) : '',
			'has_pillar' => $pillar_id > 0,
		];
	}

	public function list_clusters( WP_REST_Request $request ) {
		$cluster_repo = new CGM_Cluster_Repository();
		$clusters = $cluster_repo->get_all_clusters();
		$limit = isset( $request['limit'] ) ? max( 1, min( 50, (int) $request['limit'] ) ) : 20;
		$out = [];
		foreach ( array_slice( $clusters, 0, $limit ) as $cluster ) {
			$cluster_id = (int) ( $cluster['id'] ?? 0 );
			if ( $cluster_id <= 0 ) { continue; }
			$score = $this->kernel->authority_service()->calculate_cluster_authority( $cluster_id );
			$priority = $this->kernel->priority_service()->get_priority_articles( $cluster_id, 3 );
			$link_metrics = $this->cgm_get_cluster_link_metrics( (string) ( $cluster['cluster_name'] ?? ( $score['cluster_name'] ?? '' ) ) );
			$out[] = [
				'id' => $cluster_id,
				'name' => (string) ( $cluster['cluster_name'] ?? ( $score['cluster_name'] ?? '' ) ),
				'authority' => $score,
				'priority_articles' => $priority,
				'post_count' => (int) ( $link_metrics['post_count'] ?? 0 ),
				'pillar_id' => (int) ( $link_metrics['pillar_id'] ?? 0 ),
				'pillar_title' => (string) ( $link_metrics['pillar_title'] ?? '' ),
				'has_pillar' => ! empty( $link_metrics['has_pillar'] ),
				'links_within_cluster' => (int) ( $link_metrics['links_within_cluster'] ?? 0 ),
				'links_to_pillar_page' => (int) ( $link_metrics['links_to_pillar_page'] ?? 0 ),
			];
		}
		usort( $out, static function( $a, $b ) {
			return (float) ( $b['authority']['authority_score'] ?? 0 ) <=> (float) ( $a['authority']['authority_score'] ?? 0 );
		});
		// fallback data injected
return rest_ensure_response( [ 'success' => true, 'data' => $out ] );
	}
}
