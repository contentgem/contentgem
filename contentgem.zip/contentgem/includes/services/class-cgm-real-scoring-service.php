<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CGM_Real_Scoring_Service {

    public function calculate_cluster_score($cluster_id){

        $posts = get_posts([
            'post_type' => 'post',
            'numberposts' => -1,
            'meta_query' => [
                [
                    'key' => 'cgm_cluster_id',
                    'value' => $cluster_id
                ]
            ]
        ]);

        $post_count = count($posts);

        $pillar = false;
        foreach ($posts as $p) {
            if (stripos($p->post_title, 'pillar') !== false) {
                $pillar = true;
                break;
            }
        }

        $links = 0;
        foreach ($posts as $p) {
            if (strpos($p->post_content, '<a ') !== false) {
                $links++;
            }
        }

        $comp = get_option('cgm_competitor_' . $cluster_id);
        $comp_coverage = is_array($comp) && isset($comp['coverage']) ? (float)$comp['coverage'] : null;

        $content_score = min(60, $post_count * 6);
        $pillar_score = $pillar ? 20 : 0;
        $link_score = min(20, $links * 2);

        $score = $content_score + $pillar_score + $link_score;

        if ($comp_coverage !== null) {
            $gap = max(0, $comp_coverage - $score);
            $score -= ($gap * 0.3);
        }

        $final = round(max(0, min(100, $score)), 1);

        update_option('cgm_cluster_score_' . $cluster_id, $final);

        return $final;
    }
}
