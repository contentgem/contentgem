<?php
defined( 'ABSPATH' ) || exit;

class CGM_Schema_Registry {
	public function get( string $schema_name ): array {
		$schemas = $this->all();
		return $schemas[ $schema_name ] ?? [];
	}

	private function all(): array {
		return [
			'title_suggestions_v1' => [
				'name' => 'title_suggestions_v1',
				'schema' => [
					'type' => 'object',
					'additionalProperties' => false,
					'properties' => [
						'suggestions' => [
							'type' => 'array',
							'items' => [
								'type' => 'object',
								'additionalProperties' => false,
								'properties' => [
									'title' => [ 'type' => 'string' ],
									'keyword' => [ 'type' => 'string' ],
									'rationale' => [ 'type' => 'string' ],
								],
								'required' => [ 'title', 'keyword', 'rationale' ],
							],
						],
					],
					'required' => [ 'suggestions' ],
				],
			],
			'semantic_keyword_suggestions_v1' => [
				'name' => 'semantic_keyword_suggestions_v1',
				'schema' => [
					'type' => 'object',
					'additionalProperties' => false,
					'properties' => [
						'keywords' => [
							'type' => 'array',
							'items' => [ 'type' => 'string' ],
						],
					],
					'required' => [ 'keywords' ],
				],
			],
		];
	}
}
