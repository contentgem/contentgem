<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CGM_Intelligence_Kernel {
	protected array $deps;
	protected ?CGM_Authority_Service $authority_service = null;
	protected ?CGM_Priority_Service $priority_service = null;
	protected ?CGM_Graph_Service $graph_service = null;
	protected ?CGM_Competitor_Service $competitor_service = null;
	protected ?CGM_Differentiation_Service $differentiation_service = null;
	protected ?CGM_Linking_Service $linking_service = null;

	public function __construct( array $deps = [] ) {
		$this->deps = $deps;
	}

	public function authority_service(): CGM_Authority_Service {
		if ( null === $this->authority_service ) {
			$this->authority_service = new CGM_Authority_Service(
				$this->deps['post_repo'],
				$this->deps['cluster_repo'],
				$this->deps['keyword_repo'],
				$this->graph_service(),
				$this->deps['entity_extractor']
			);
		}
		return $this->authority_service;
	}

	public function priority_service(): CGM_Priority_Service {
		if ( null === $this->priority_service ) {
			$this->priority_service = new CGM_Priority_Service(
				$this->authority_service(),
				$this->deps['serp_repo'],
				$this->deps['competitor_repo']
			);
		}
		return $this->priority_service;
	}

	public function graph_service(): CGM_Graph_Service {
		if ( null === $this->graph_service ) {
			$this->graph_service = new CGM_Graph_Service(
				$this->deps['graph_repo'],
				$this->deps['entity_extractor'],
				$this->deps['post_repo'],
				$this->deps['cluster_repo'],
				$this->deps['keyword_repo'],
				$this->deps['content_parser']
			);
		}
		return $this->graph_service;
	}

	public function competitor_service(): CGM_Competitor_Service {
		if ( null === $this->competitor_service ) {
			$this->competitor_service = new CGM_Competitor_Service(
				$this->deps['serp_client'],
				$this->deps['serp_repo'],
				$this->deps['content_parser'],
				$this->deps['entity_extractor'],
				$this->deps['post_repo'],
				$this->deps['cluster_repo']
			);
		}
		return $this->competitor_service;
	}

	public function differentiation_service(): CGM_Differentiation_Service {
		if ( null === $this->differentiation_service ) {
			$this->differentiation_service = new CGM_Differentiation_Service(
				$this->deps['post_repo'],
				$this->deps['content_parser'],
				$this->deps['overlap_repo']
			);
		}
		return $this->differentiation_service;
	}

	public function linking_service(): CGM_Linking_Service {
		if ( null === $this->linking_service ) {
			$this->linking_service = new CGM_Linking_Service(
				$this->deps['post_repo'],
				$this->deps['content_parser']
			);
		}
		return $this->linking_service;
	}
}
