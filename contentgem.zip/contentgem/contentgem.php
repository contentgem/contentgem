<?php
/**
 * Plugin Name: Contentgem
 * Plugin URI:  https://contentgem.ai
 * Description: AI-powered topical authority analysis and content gap detection for WordPress.
 * Version: 5.0.9
 * Requires PHP: 7.4
 * Requires at least: 6.2
 * Author:      Contentgem
 * Author URI:  https://contentgem.ai
 * License:     GPL-2.0-or-later
 * Text Domain: contentgem
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

// Prevent page/object/db caching for Contentgem admin and REST traffic.
add_action( 'init', static function (): void {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$is_contentgem_rest = false !== strpos( $uri, '/wp-json/contentgem/v1' );
	$is_contentgem_admin = is_admin() && isset( $_GET['page'] ) && 'contentgem' === sanitize_key( (string) $_GET['page'] );
	if ( $is_contentgem_rest || $is_contentgem_admin ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		if ( ! defined( 'DONOTCACHEDB' ) ) {
			define( 'DONOTCACHEDB', true );
		}
	}
}, 1 );

add_filter( 'rest_post_dispatch', static function ( $result, $server, $request ) {
	if ( ! $result instanceof WP_HTTP_Response ) {
		return $result;
	}
	$route = (string) $request->get_route();
	if ( 0 === strpos( $route, '/contentgem/v1/' ) ) {
		$result->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		$result->header( 'Pragma', 'no-cache' );
		$result->header( 'Expires', 'Wed, 11 Jan 1984 05:00:00 GMT' );
	}
	return $result;
}, 10, 3 );

// ── PHP 7.4 polyfills (str_contains, str_starts_with, str_ends_with) ─────────
require_once plugin_dir_path( __FILE__ ) . 'includes/class-cgm-polyfills.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-cgm-security.php';

// Keep Contentgem admin copy in English on plugin pages.
add_filter( 'admin_footer_text', static function ( $text ) {
	if ( is_admin() && isset( $_GET['page'] ) && 'contentgem' === sanitize_key( (string) $_GET['page'] ) ) {
		return 'Thank you for creating with WordPress.';
	}
	return $text;
} );

add_filter( 'update_footer', static function ( $text ) {
	if ( is_admin() && isset( $_GET['page'] ) && 'contentgem' === sanitize_key( (string) $_GET['page'] ) ) {
		return 'Version ' . esc_html( get_bloginfo( 'version' ) );
	}
	return $text;
}, 11 );

// ── Constanten ────────────────────────────────────────────────────────────────
define( 'CONTENTGEM_VERSION', '5.0.9' );
define( 'CONTENTGEM_DB_VERSION', '1.8.1' );
define( 'CONTENTGEM_FILE',       __FILE__ );
define( 'CONTENTGEM_DIR',        plugin_dir_path( __FILE__ ) );
define( 'CONTENTGEM_URL',        plugin_dir_url( __FILE__ ) );
define( 'CONTENTGEM_REST_NS',    'contentgem/v1' );

// ── Core includes needed early ────────────────────────────────────────────────
require_once CONTENTGEM_DIR . 'includes/class-cgm-activator.php';
require_once CONTENTGEM_DIR . 'includes/class-cgm-paywall.php';
require_once CONTENTGEM_DIR . 'includes/freemium/cg-plan.php';
require_once CONTENTGEM_DIR . 'includes/freemium/cg-features.php';
require_once CONTENTGEM_DIR . 'includes/freemium/cg-limits.php';

// ── Vendor autoloader ─────────────────────────────────────────────────────────
if ( file_exists( CONTENTGEM_DIR . 'vendor/autoload.php' ) ) {
    require_once CONTENTGEM_DIR . 'vendor/autoload.php';
}

// ── API Keys (stel in via wp-config.php) ─────────────────────────────────────
// define( 'CONTENTGEM_ANTHROPIC_KEY',       '' ); // Verplicht
// define( 'CONTENTGEM_GOOGLE_CLIENT_ID',    '' ); // Optioneel (GSC/GA4)
// define( 'CONTENTGEM_GOOGLE_CLIENT_SECRET','' ); // Optioneel (GSC/GA4)
// define( 'CONTENTGEM_FREEMIUS_SECRET',     '' ); // Optioneel (webhooks)
// define( 'CONTENTGEM_DEBUG', false );            // true = extra logging

// ── Autoloader ────────────────────────────────────────────────────────────────
spl_autoload_register( function ( string $class ): void {
	if ( ! str_starts_with( $class, 'CGM_' ) ) {
		return;
	}
	$filename = 'class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';

	$locations = [
		CONTENTGEM_DIR . 'includes/' . $filename,
		CONTENTGEM_DIR . 'admin/' . $filename,
	];

	foreach ( $locations as $path ) {
		if ( file_exists( $path ) ) {
			require_once $path;
			return;
		}
	}
} );

// ── Freemius SDK ──────────────────────────────────────────────────────────────
if ( ! function_exists( 'contentgem_fs' ) ) {
	function contentgem_fs() {
		global $contentgem_fs;
		if ( ! isset( $contentgem_fs ) ) {
			// Probeer vendor-pad (Composer), val terug op includes/freemius.
			$sdk_start = CONTENTGEM_DIR . 'vendor/freemius/wordpress-sdk/start.php';
			if ( ! file_exists( $sdk_start ) ) {
				$sdk_start = CONTENTGEM_DIR . 'includes/freemius/start.php';
			}
			require_once $sdk_start;
			$contentgem_fs = fs_dynamic_init( [
				'id'                  => '26143',
				'slug'                => 'contentgem',
				'type'                => 'plugin',
				'public_key'          => 'pk_2de65b19328aa4c48e3dca0231bc2',
				'is_premium'          => false,
				'is_premium_only'     => false,
				'has_premium_version' => false,
				'has_paid_plans'      => true,
				'has_addons'          => false,
				'is_org_compliant'    => true,
				'enable_anonymous'    => true,
				'menu'                => [
					'slug'            => 'contentgem',
					'first-path'      => 'admin.php?page=contentgem',
					'account'         => true,
					'contact'         => false,
					'support'         => false,
				],
			] );
		}
		return $contentgem_fs;
	}
	contentgem_fs();
	// Zorg dat de account menu pagina toegankelijk is.
	contentgem_fs()->add_filter( 'show_account_even_if_free', '__return_true' );
	contentgem_fs()->add_filter( 'is_submenu_visible', '__return_true', 10, 2 );
	contentgem_fs()->add_filter( 'is_long_term_user_without_site', '__return_false' );
	do_action( 'contentgem_fs_loaded' );
}


/**
 * Returns true when the current user may access the plugin UI.
 */
function cgm_user_has_access(): bool {
	return is_admin() ? current_user_can( 'edit_posts' ) : true;
}

/**
 * Returns true when the current site has an active paid plan or trial.
 */
function cgm_user_has_paid_plan(): bool {
	if ( ! function_exists( 'contentgem_fs' ) ) {
		return false;
	}

	try {
		$fs = contentgem_fs();
		if ( ! is_object( $fs ) ) {
			return false;
		}

		if ( method_exists( $fs, 'is_paying_or_trial' ) ) {
			return (bool) $fs->is_paying_or_trial();
		}

		return method_exists( $fs, 'is_paying' ) ? (bool) $fs->is_paying() : false;
	} catch ( \Throwable $e ) {
		return false;
	}
}

/**
 * Lightweight alias used throughout the plugin.
 */
function cgm_is_premium(): bool {
	return cgm_user_has_paid_plan();
}

/**
 * Freemium helper wrappers used across the plugin.
 */
function cgm_get_current_plan(): string {
	return function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free';
}

function cgm_current_plan_has_feature( string $feature ): bool {
	return function_exists( 'cgm_has_feature' ) ? cgm_has_feature( $feature ) : false;
}

function cgm_get_current_plan_limits(): array {
	return function_exists( 'cgm_get_limits' ) ? cgm_get_limits() : [];
}

/**
 * Determines whether the admin page should render the premium paywall.
 */
function cgm_should_show_paywall(): bool {
	return false;
}

/**
 * Returns the draft-generation limit for the Free plan.
 *
 * As of v5.0.8.23: Free draft generation is unlimited.
 * The -1 sentinel is used across the plugin to mean "unlimited" and lets
 * downstream helpers (remaining counter, UI badges, SSE error payloads)
 * continue to operate without dead-code paths.
 */
function cgm_get_free_article_limit(): int {
	return -1;
}

/**
 * Returns how many free articles the current user already generated.
 * Kept for backward compatibility — the counter is no longer enforced,
 * but we still track it for analytics purposes.
 */
function cgm_get_free_articles_used( int $user_id = 0 ): int {
	$user_id = $user_id > 0 ? $user_id : get_current_user_id();
	if ( $user_id <= 0 ) {
		return 0;
	}
	return max( 0, (int) get_user_meta( $user_id, 'cgm_free_articles_used', true ) );
}

/**
 * Returns how many free article slots are currently reserved by pending jobs.
 * Retained for API compatibility; value no longer gates generation.
 */
function cgm_get_free_articles_reserved( int $user_id = 0 ): int {
	$user_id = $user_id > 0 ? $user_id : get_current_user_id();
	if ( $user_id <= 0 ) {
		return 0;
	}
	return max( 0, (int) get_user_meta( $user_id, 'cgm_free_articles_reserved', true ) );
}

/**
 * Returns how many free articles remain for the user.
 * Always returns a large sentinel (9999) since Free drafts are unlimited.
 */
function cgm_get_free_articles_remaining( int $user_id = 0 ): int {
	// Draft generation is unlimited on every tier — keep the return value
	// aligned with what the premium path already returned so the React SPA
	// and token-manager keep rendering "unlimited-like" values.
	return 9999;
}

/**
 * Returns whether the user may generate another article.
 * Draft generation is unlimited on every tier.
 */
function cgm_can_generate_article( int $user_id = 0 ): bool {
	return true;
}

/**
 * Alias for AI generation checks.
 */
function cgm_can_use_ai( int $user_id = 0 ): bool {
	return cgm_can_generate_article( $user_id );
}

/**
 * Reserves a free article slot for a pending generation.
 * No-op gate now (always succeeds); counter kept for analytics.
 */
function cgm_reserve_free_article_generation( int $user_id = 0 ): bool {
	$user_id = $user_id > 0 ? $user_id : get_current_user_id();
	if ( $user_id <= 0 ) {
		return false;
	}

	if ( cgm_is_premium() ) {
		return true;
	}

	update_user_meta( $user_id, 'cgm_free_articles_reserved', cgm_get_free_articles_reserved( $user_id ) + 1 );
	return true;
}

/**
 * Releases a previously reserved free article slot.
 */
function cgm_release_free_article_generation( int $user_id = 0 ): void {
	$user_id = $user_id > 0 ? $user_id : get_current_user_id();
	if ( $user_id <= 0 || cgm_is_premium() ) {
		return;
	}

	$reserved = cgm_get_free_articles_reserved( $user_id );
	update_user_meta( $user_id, 'cgm_free_articles_reserved', max( 0, $reserved - 1 ) );
}

/**
 * Commits a reserved free article slot after a successful generation.
 */
function cgm_commit_free_article_generation( int $user_id = 0 ): void {
	$user_id = $user_id > 0 ? $user_id : get_current_user_id();
	if ( $user_id <= 0 || cgm_is_premium() ) {
		return;
	}

	$reserved = cgm_get_free_articles_reserved( $user_id );
	if ( $reserved > 0 ) {
		update_user_meta( $user_id, 'cgm_free_articles_reserved', max( 0, $reserved - 1 ) );
	}
	update_user_meta( $user_id, 'cgm_free_articles_used', cgm_get_free_articles_used( $user_id ) + 1 );
}

/**
 * Increments the free article usage counter after a successful draft generation.
 * Backward-compatible alias.
 */
function cgm_increment_free_article_usage( int $user_id = 0 ): void {
	cgm_commit_free_article_generation( $user_id );
}

/**
 * Returns the best available Freemius upgrade URL.
 *
 * @param string $period annual|monthly
 */
function cgm_get_upgrade_url( string $period = 'annual' ): string {
	if ( ! function_exists( 'contentgem_fs' ) ) {
		return admin_url( 'admin.php?page=contentgem' );
	}

	try {
		$fs = contentgem_fs();
		if ( ! is_object( $fs ) ) {
			return admin_url( 'admin.php?page=contentgem' );
		}

		$billing_period = ( 'monthly' === strtolower( $period ) && defined( 'WP_FS__PERIOD_MONTHLY' ) )
			? constant( 'WP_FS__PERIOD_MONTHLY' )
			: ( defined( 'WP_FS__PERIOD_ANNUALLY' ) ? constant( 'WP_FS__PERIOD_ANNUALLY' ) : 'annual' );

		if ( method_exists( $fs, 'get_upgrade_url' ) ) {
			$url = (string) $fs->get_upgrade_url( $billing_period, false );
			if ( '' !== $url ) {
				return $url;
			}
		}

		if ( method_exists( $fs, 'pricing_url' ) ) {
			$url = (string) $fs->pricing_url( $billing_period, false );
			if ( '' !== $url ) {
				return $url;
			}
		}
	} catch ( \Throwable $e ) {
		return admin_url( 'admin.php?page=contentgem' );
	}

	return admin_url( 'admin.php?page=contentgem' );
}

/**
 * Returns the best available Freemius account or connect URL.
 */
function cgm_get_account_url(): string {
	if ( ! function_exists( 'contentgem_fs' ) ) {
		return admin_url( 'admin.php?page=contentgem' );
	}

	try {
		$fs = contentgem_fs();
		if ( ! is_object( $fs ) ) {
			return admin_url( 'admin.php?page=contentgem' );
		}

		if ( method_exists( $fs, 'is_registered' ) && ! $fs->is_registered() && method_exists( $fs, 'get_account_url' ) ) {
			$url = (string) $fs->get_account_url( false, [ 'connect' => 'true' ], false );
			if ( '' !== $url ) {
				return $url;
			}
		}

		if ( method_exists( $fs, 'get_account_url' ) ) {
			$url = (string) $fs->get_account_url();
			if ( '' !== $url ) {
				return $url;
			}
		}
	} catch ( \Throwable $e ) {
		return admin_url( 'admin.php?page=contentgem' );
	}

	return admin_url( 'admin.php?page=contentgem' );
}

/**
 * Backward-compatible aliases used by older UI code.
 */
function cgm_get_fs_checkout_url( string $period = 'annual' ): string {
	return cgm_get_upgrade_url( $period );
}

function cgm_get_fs_pricing_url( string $period = 'annual' ): string {
	return cgm_get_upgrade_url( $period );
}

function cgm_get_account_bridge_url(): string {
	return cgm_get_account_url();
}

function cgm_get_fs_account_url(): string {
	return cgm_get_account_url();
}

// ── Activatie / deactivatie ───────────────────────────────────────────────────
register_activation_hook( __FILE__, [ 'CGM_Activator', 'install' ] );
register_deactivation_hook( __FILE__, [ 'CGM_Activator', 'deactivate' ] );

add_action( 'admin_init', 'contentgem_handle_activation_redirect' );



function contentgem_handle_activation_redirect(): void {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( wp_doing_ajax() ) {
		return;
	}

	if ( isset( $_GET['activate-multi'] ) ) {
		return;
	}

	$should_redirect = (bool) get_option( 'contentgem_do_activation_redirect', false );
	if ( ! $should_redirect ) {
		return;
	}

	delete_option( 'contentgem_do_activation_redirect' );
	update_option( 'contentgem_force_onboarding', true );

	wp_safe_redirect( admin_url( 'admin.php?page=contentgem' ) );
	exit;
}

// ── Plugin initialisatie ──────────────────────────────────────────────────────
add_action( 'plugins_loaded', 'contentgem_init' );

function contentgem_init(): void {
	// DB upgrade indien nodig
	if ( get_option( 'contentgem_db_version' ) !== CONTENTGEM_DB_VERSION ) {
		CGM_Activator::upgrade();
	}

	// Admin menu + REST API
	if ( is_admin() ) {
		new CGM_Admin_Menu();
	}
	$api = new CGM_Rest_Api();

	add_action( 'cgm_process_jobs', [ 'CGM_Job_Runner', 'process_next' ] );
	add_action( 'cgm_process_draft_job', [ 'CGM_Rest_Api', 'process_draft_job' ] );
	$set_request_json = static function( WP_REST_Request $request, array $payload ): void {
		if ( method_exists( $request, 'set_json_params' ) ) {
			$request->set_json_params( $payload );
			return;
		}
		$request->set_header( 'content-type', 'application/json' );
		$request->set_body( wp_json_encode( $payload ) );
	};
	add_action( 'cgm_run_analysis_job', function( string $job_id, string $token ) use ( $api, $set_request_json ): void {
		$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/analyze-run' );
		$set_request_json( $request, [ 'job_id' => $job_id, 'token' => $token ] );
		$api->post_analyse_run( $request );
	} , 10, 2 );
	add_action( 'cgm_run_analysis', function( int $site_id ) use ( $api, $set_request_json ): void {
		$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/analyze-run' );
		$set_request_json( $request, [ 'site_id' => $site_id ] );
		$api->post_analyze_run( $request );
	} , 10, 1 );
	add_action( 'cgm_run_linkscan_job', function( string $job_id, string $token ) use ( $api, $set_request_json ): void {
		$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/broken-links/scan/run' );
		$set_request_json( $request, [ 'job_id' => $job_id, 'token' => $token ] );
		$api->post_scan_links_run( $request );
	} , 10, 2 );
	add_action( 'cgm_run_assistant_draft_job', function( string $job_id, string $token ) use ( $api, $set_request_json ): void {
		$request = new WP_REST_Request( 'POST', '/' . CONTENTGEM_REST_NS . '/assistant/draft-run' );
		$set_request_json( $request, [ 'job_id' => $job_id, 'token' => $token ] );
		$api->post_assistant_draft_run( $request );
	} , 10, 2 );


// Intelligence core bootstrap (v41/v42 foundation)
if ( ! function_exists( 'contentgem_get_intelligence_kernel' ) ) {
	function contentgem_get_intelligence_kernel(): CGM_Intelligence_Kernel {
		static $kernel = null;
		if ( null === $kernel ) {
			$deps = [
				'post_repo'            => new CGM_Post_Repository(),
				'cluster_repo'         => new CGM_Cluster_Repository(),
				'keyword_repo'         => new CGM_Keyword_Repository(),
				'pillar_repo'          => new CGM_Pillar_Repository(),
				'graph_repo'           => new CGM_Graph_Repository(),
				'serp_repo'            => new CGM_SERP_Repository(),
				'embedding_repo'       => new CGM_Embedding_Repository(),
				'analysis_run_repo'    => new CGM_Analysis_Run_Repository(),
				'competitor_repo'      => new CGM_Competitor_Repository(),
				'link_suggestion_repo' => new CGM_Link_Suggestion_Repository(),
				'overlap_repo'         => new CGM_Overlap_Repository(),
				'content_parser'       => new CGM_Content_Parser(),
				'entity_extractor'     => new CGM_Entity_Extractor(),
				'serp_client'          => new CGM_SERP_Client(),
				'cache'                => new CGM_Cache(),
				'logger'               => new CGM_Logger(),
			];
			$kernel = new CGM_Intelligence_Kernel( $deps );
		}
		return $kernel;
	}
}

add_action( 'rest_api_init', static function (): void {
	$kernel = contentgem_get_intelligence_kernel();
	( new CGM_Authority_REST_Controller( $kernel ) )->register_routes();
	( new CGM_Competitor_REST_Controller( $kernel ) )->register_routes();
	( new CGM_Differentiation_REST_Controller( $kernel ) )->register_routes();
	( new CGM_Linking_REST_Controller( $kernel ) )->register_routes();
} );

add_action( 'save_post', static function ( int $post_id, WP_Post $post, bool $update ): void {
	if ( ! $update || wp_is_post_revision( $post_id ) ) {
		return;
	}
	if ( ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
		return;
	}
	contentgem_get_intelligence_kernel()->graph_service()->rebuild_graph_for_post( $post_id );
}, 25, 3 );

	// IndexNow — automatisch pingen bij publiceren/bijwerken
	CGM_IndexNow::register_hooks();

	// Draft SVG parsing, sanitization and rendering hooks
	CGM_Draft_SVG::register_hooks();

	// i18n
	load_plugin_textdomain( 'contentgem', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );


if ( ! function_exists( 'cgm_clear_cached_lists' ) ) {
	function cgm_clear_cached_lists( int $site_id = 0 ): void {
		global $wpdb;

		if ( $site_id > 0 ) {
			delete_transient( 'contentgem_clusters_' . $site_id );
		}

		$likes = [
			$wpdb->esc_like( '_transient_contentgem_gaps_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_contentgem_gaps_' ) . '%',
			$wpdb->esc_like( '_transient_contentgem_clusters_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_contentgem_clusters_' ) . '%',
		];
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
				$likes[0],
				$likes[1],
				$likes[2],
				$likes[3]
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}


	$recalculate_cluster_coverage = function ( int $post_id, ?WP_Post $post = null ): void {
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}
		$post = $post ?: get_post( $post_id );
		if ( ! $post || 'publish' !== $post->post_status || ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
			return;
		}
		global $wpdb;
		$site_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}cgm_sites WHERE blog_id = %d LIMIT 1",
				get_current_blog_id()
			)
		);
		if ( $site_id <= 0 ) {
			return;
		}
		cgm_clear_cached_lists( $site_id );
		$builder = new CGM_Cluster_Builder( $site_id );
		$builder->assign_new_post_to_clusters( $post_id );
	};

	add_action( 'publish_post', function( int $post_id ) use ( $recalculate_cluster_coverage ): void {
		$recalculate_cluster_coverage( $post_id );
	} );
	add_action( 'publish_page', function( int $post_id ) use ( $recalculate_cluster_coverage ): void {
		$recalculate_cluster_coverage( $post_id );
	} );
	add_action( 'save_post', function( int $post_id, WP_Post $post, bool $update ) use ( $recalculate_cluster_coverage ): void {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! $update ) {
			return;
		}
		$recalculate_cluster_coverage( $post_id, $post );
	}, 10, 3 );
}

add_action('admin_enqueue_scripts', function(){ wp_enqueue_script('cg-dropdown-fix', plugin_dir_url(__FILE__).'assets/js/dropdown-fix.js', [], '1.0', true);});
