<?php
/**
 * Class CGM_Rest_Api
 *
 * Registreert alle Contentgem REST endpoints onder namespace contentgem/v1.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

// PHP 7.4 polyfills for functions introduced in PHP 8.0
if ( ! function_exists( 'str_starts_with' ) ) {
	function str_starts_with( string $haystack, string $needle ): bool {
		return strncmp( $haystack, $needle, strlen( $needle ) ) === 0;
	}
}
if ( ! function_exists( 'str_ends_with' ) ) {
	function str_ends_with( string $haystack, string $needle ): bool {
		return $needle !== '' && substr( $haystack, -strlen( $needle ) ) === $needle;
	}
}
if ( ! function_exists( 'str_contains' ) ) {
	function str_contains( string $haystack, string $needle ): bool {
		return strpos( $haystack, $needle ) !== false;
	}
}

class CGM_Rest_Api {

	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_filter( 'rest_pre_dispatch', [ $this, 'gate_premium_routes' ], 10, 3 );
	}

	/**
	 * Centralised premium-feature gate. Runs before any REST callback fires.
	 * If the active plan lacks the feature mapped to the incoming route,
	 * we short-circuit with a 402.
	 *
	 * @param mixed           $result  Current pre-dispatch result (null means continue).
	 * @param WP_REST_Server  $server  REST server.
	 * @param WP_REST_Request $request Incoming request.
	 * @return mixed
	 */
	public function gate_premium_routes( $result, $server, $request ) {
		if ( null !== $result ) {
			return $result; // Someone else already decided; don't interfere.
		}
		if ( ! ( $request instanceof WP_REST_Request ) ) {
			return $result;
		}
		$route = (string) $request->get_route();
		$ns    = defined( 'CONTENTGEM_REST_NS' ) ? CONTENTGEM_REST_NS : 'contentgem/v1';
		if ( strpos( $route, '/' . $ns . '/' ) !== 0 ) {
			return $result; // Not one of ours.
		}
		if ( ! function_exists( 'cgm_has_feature' ) ) {
			return $result;
		}

		// Map route prefixes (relative to the namespace) to required features.
		// Route format after the namespace prefix: /competitor/analyze, /gsc/queries, ...
		$relative = substr( $route, strlen( '/' . $ns ) );
		$map = [
			'/competitor/'       => 'competitor_analysis',
			'/linking/'          => 'internal_linking_automation',
			'/gsc/'              => 'gsc_integration',
			'/differentiation/'  => 'semantic_differentiation',
			'/authority/'        => 'authority_dashboard',
			'/reports'           => 'saved_reports',
			'/optimizer/'        => 'optimizer',
		];
		foreach ( $map as $prefix => $feature ) {
			if ( strpos( $relative, $prefix ) === 0 ) {
				if ( cgm_has_feature( $feature ) ) {
					return $result;
				}
				$upgrade_url = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '';
				return new WP_Error(
					'contentgem_feature_locked',
					__( 'This feature requires a paid Contentgem plan.', 'contentgem' ),
					[
						'status'      => 402,
						'feature'     => $feature,
						'plan'        => function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free',
						'upgrade_url' => $upgrade_url,
					]
				);
			}
		}
		return $result;
	}

	private function log_debug( string $message, array $context = [] ): void {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}
		$payload = '';
		if ( ! empty( $context ) ) {
			$encoded = wp_json_encode( $context );
			$payload = $encoded ? ' ' . $encoded : '';
		}
		error_log( '[ContentGem] ' . $message . $payload );
	}

	public function register_routes(): void {
		$ns = CONTENTGEM_REST_NS;

		// GET /plan-state — lightweight endpoint any edit_posts user can call
		// to refresh their current plan + limits after a license activation.
		// Unlike /plan-diagnostic this exposes no Freemius internals.
		register_rest_route( $ns, '/plan-state', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_plan_state' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /plan-diagnostic — shows exactly what Freemius reports so
		// cluster-cap mismatches can be debugged. Admin-only.
		register_rest_route( $ns, '/plan-diagnostic', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_plan_diagnostic' ],
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'show_in_index'       => false,
		] );

		// GET /clusters
		register_rest_route( $ns, '/clusters', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_clusters' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gaps
		register_rest_route( $ns, '/gaps', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gaps' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'per_page' => [ 'default' => 20, 'sanitize_callback' => 'absint' ],
				'page'     => [ 'default' => 1,  'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /suggest
		register_rest_route( $ns, '/suggest', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_suggest' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'gap_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /draft (SSE streaming)
		register_rest_route( $ns, '/draft', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_draft' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'gap_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// GET /tokens
		register_rest_route( $ns, '/tokens', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_tokens' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// POST /jobs
		register_rest_route( $ns, '/jobs', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_jobs' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /jobs/{id}
		register_rest_route( $ns, '/jobs/(?P<id>[A-Za-z0-9\-_]+)', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_job_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /jobs/{id}/retry
		register_rest_route( $ns, '/jobs/(?P<id>[A-Za-z0-9\-_]+)/retry', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_job_retry' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// POST /analyse/start
		register_rest_route( $ns, '/analyse/start', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_analyse_start' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		// POST /analyse/run
		register_rest_route( $ns, '/analyze-run', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_analyse_run' ],
			'permission_callback' => [ $this, 'check_async_job_permission' ],
			'show_in_index'       => false,
		] );
		// GET /analyse/status
		register_rest_route( $ns, '/analyse/status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_analyse_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		register_rest_route( $ns, '/analysis/start', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_analyse_start' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		register_rest_route( $ns, '/analysis/status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_analyse_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		// POST /broken-links/scan/start
		register_rest_route( $ns, '/broken-links/scan/start', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_scan_links_start' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		// POST /broken-links/scan/run
		register_rest_route( $ns, '/broken-links/scan/run', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_scan_links_run' ],
			'permission_callback' => [ $this, 'check_async_job_permission' ],
			'show_in_index'       => false,
		] );
		// GET /broken-links/scan/status
		register_rest_route( $ns, '/broken-links/scan/status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_scan_links_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /analyze
		register_rest_route( $ns, '/analyze', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_analyze' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// v4.7 — Strict keyword match toggle for Content Gaps title generation.
		register_rest_route( $ns, '/gaps/strict-match', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_gap_strict_match' ],
				'permission_callback' => [ $this, 'check_permission' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'set_gap_strict_match' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'enabled' => [ 'required' => true ],
				],
			],
		] );

		// v5.0.8 — Keyword-only filter toggle for Content Gaps display.
		register_rest_route( $ns, '/gaps/keyword-only', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_gap_keyword_only' ],
				'permission_callback' => [ $this, 'check_permission' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'set_gap_keyword_only' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'enabled' => [ 'required' => true ],
				],
			],
		] );

		// GET /status
		register_rest_route( $ns, '/status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/api-key
		register_rest_route( $ns, '/settings/api-key', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_api_key' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'api_key' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// GET /settings
		register_rest_route( $ns, '/settings', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_settings' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		register_rest_route( $ns, '/settings/builder-mode', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_settings_builder_mode' ],
				'permission_callback' => [ $this, 'check_permission' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'post_settings_builder_mode' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'mode' => [ 'required' => true ],
				],
			],
		] );

		// POST /settings/ai-system
		register_rest_route( $ns, '/settings/ai-system', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_ai_system' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/codebase/index-status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_codebase_index_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		register_rest_route( $ns, '/codebase/reindex', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_codebase_reindex' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		register_rest_route( $ns, '/codebase/summary', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_codebase_summary' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		register_rest_route( $ns, '/codebase/task-context-preview', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_codebase_task_context_preview' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/hard-reset
		register_rest_route( $ns, '/settings/hard-reset', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_hard_reset' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /cannibalization
		register_rest_route( $ns, '/cannibalization', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_cannibalization' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /merge
		register_rest_route( $ns, '/merge', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_merge' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'post_id_keep'   => [ 'required' => true, 'sanitize_callback' => 'absint' ],
				'post_id_remove' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /cannibalization/{id}/ignore
		register_rest_route( $ns, '/cannibalization/(?P<id>\d+)/ignore', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_cannibalization_ignore' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /settings/language
		register_rest_route( $ns, '/settings/language', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_language' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'language' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /settings/niche
		register_rest_route( $ns, '/settings/niche', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_niche' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'niche'       => [ 'required' => true,  'sanitize_callback' => 'sanitize_text_field' ],
				'description' => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
			],
		] );

		// POST /suggest-clusters
		register_rest_route( $ns, '/suggest-clusters', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_suggest_clusters' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/settings/suggest-single-cluster', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_suggest_single_cluster' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/clusters
		register_rest_route( $ns, '/settings/clusters', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_clusters' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/settings/auto-detect-clusters', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_auto_detect_clusters' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/settings/revert-clusters', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_revert_clusters' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /pillar-pages
		register_rest_route( $ns, '/pillar-pages', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_pillar_pages' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /pillar-pages
		register_rest_route( $ns, '/pillar-pages', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_pillar_pages' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /indexnow/status
		register_rest_route( $ns, '/indexnow/status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_indexnow_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /indexnow/ping
		register_rest_route( $ns, '/indexnow/ping', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_indexnow_ping' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /indexnow/regenerate-key
		register_rest_route( $ns, '/indexnow/regenerate-key', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_indexnow_regenerate_key' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );





		// GET /settings/competitor-insights
		register_rest_route( $ns, '/settings/competitor-insights', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_competitor_insights' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/site-structure
		register_rest_route( $ns, '/settings/site-structure', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_site_structure' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// POST /ai-assistant/save-draft
		register_rest_route( $ns, '/ai-assistant/save-draft', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_ai_assistant_save_draft' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /ai-assistant/generate
		register_rest_route( $ns, '/ai-assistant/generate', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_ai_assistant_generate' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/generate
		register_rest_route( $ns, '/assistant/generate', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_generate' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/analyze-writing-style
		register_rest_route( $ns, '/settings/analyze-writing-style', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_analyze_writing_style' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/tone-of-voice
		register_rest_route( $ns, '/settings/tone-of-voice', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_tone_of_voice' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/competitor-domains
		register_rest_route( $ns, '/settings/competitor-domains', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_competitor_domains' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/cluster-keywords
		register_rest_route( $ns, '/settings/cluster-keywords', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_cluster_keywords' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/suggest-cluster-keywords
		register_rest_route( $ns, '/settings/suggest-cluster-keywords', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_suggest_cluster_keywords' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// GET /cannibalization/gsc
		register_rest_route( $ns, '/cannibalization/gsc', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_cannibalization' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );



		// POST /gaps/create-pillar
		register_rest_route( $ns, '/gaps/create-pillar', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_create_pillar_gap' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// DELETE /gaps/{id}
		register_rest_route( $ns, '/gaps/(?P<id>[\d]+)', [
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => [ $this, 'delete_gap' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /cluster-terms
		register_rest_route( $ns, '/cluster-terms', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_cluster_terms' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /cluster-terms/{id}/rename
		register_rest_route( $ns, '/cluster-terms/(?P<id>\d+)/rename', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_cluster_term_rename' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'id'       => [ 'required' => true, 'sanitize_callback' => 'absint' ],
				'name'     => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
				'taxonomy' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /cluster-terms/{id}/delete
		register_rest_route( $ns, '/cluster-terms/(?P<id>\d+)/delete', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_cluster_term_delete' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'id'       => [ 'required' => true, 'sanitize_callback' => 'absint' ],
				'taxonomy' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /auto-categorize
		register_rest_route( $ns, '/auto-categorize', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_auto_categorize' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /onboarding/complete
		register_rest_route( $ns, '/onboarding/complete', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_onboarding_complete' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /drafts
		register_rest_route( $ns, '/drafts', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_drafts' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /drafts/{wp_post_id}/delete
		register_rest_route( $ns, '/drafts/(?P<wp_post_id>\d+)/delete', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_draft_delete' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'wp_post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /drafts/{wp_post_id}/publish
		register_rest_route( $ns, '/drafts/(?P<wp_post_id>\d+)/publish', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_draft_publish' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'wp_post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /drafts/{wp_post_id}/regenerate-visuals
		register_rest_route( $ns, '/drafts/(?P<wp_post_id>\d+)/regenerate-visuals', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_draft_regenerate_visuals' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'wp_post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /drafts/{wp_post_id}/remove-from-dashboard
		register_rest_route( $ns, '/drafts/(?P<wp_post_id>\d+)/remove-from-dashboard', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_draft_remove_from_dashboard' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'wp_post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /drafts/publish-all
		register_rest_route( $ns, '/drafts/publish-all', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_drafts_publish_all' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /drafts/import-published
		register_rest_route( $ns, '/drafts/import-published', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_drafts_import_published' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /drafts/schedule-drip
		register_rest_route( $ns, '/drafts/schedule-drip', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_drafts_schedule_drip' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /settings/gsc
		register_rest_route( $ns, '/settings/gsc', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_gsc' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'client_id'     => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
				'client_secret' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /settings/gsc-credentials
		register_rest_route( $ns, '/settings/gsc-credentials', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_settings_gsc' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'client_id'     => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
				'client_secret' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// GET /gsc/connect
		register_rest_route( $ns, '/gsc/connect', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_connect' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gsc/callback
		register_rest_route( $ns, '/gsc/callback', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_callback' ],
			'permission_callback' => [ $this, 'check_gsc_callback_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gsc/sites
		register_rest_route( $ns, '/gsc/sites', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_sites' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /gsc/select-site
		register_rest_route( $ns, '/gsc/select-site', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_gsc_select_site' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'site_url' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// DELETE /gsc/disconnect
		register_rest_route( $ns, '/gsc/disconnect', [
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => [ $this, 'delete_gsc_disconnect' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gsc/queries
		register_rest_route( $ns, '/gsc/queries', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_queries' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'limit' => [ 'default' => 100, 'sanitize_callback' => 'absint' ],
			],
		] );





		// POST /competitor/create-gaps
		register_rest_route( $ns, '/competitor/create-gaps', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_competitor_create_gaps' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /competitor/analyze
		register_rest_route( $ns, '/competitor/analyze', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_competitor_analyze' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// POST /competitor/find-competitors
		register_rest_route( $ns, '/competitor/find-competitors', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_competitor_find_competitors' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// GET /competitor/history
		register_rest_route( $ns, '/competitor/history', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_competitor_history' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /competitor/history/clear
		register_rest_route( $ns, '/competitor/history/clear', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_competitor_history_clear' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// POST /competitor/history/delete
		register_rest_route( $ns, '/competitor/history/delete', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_competitor_history_delete' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );


		// GET /competitor/latest-analysis
		register_rest_route( $ns, '/competitor/latest-analysis', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_competitor_latest_analysis' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /competitor/meta-summary
		register_rest_route( $ns, '/competitor/meta-summary', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_competitor_meta_summary' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gsc/indexation
		register_rest_route( $ns, '/gsc/indexation', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_indexation' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /gsc/indexation/scan
		register_rest_route( $ns, '/gsc/indexation/scan', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_gsc_indexation_scan' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /gsc/intelligence
		register_rest_route( $ns, '/gsc/intelligence', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_gsc_intelligence' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// GET /broken-links
		register_rest_route( $ns, '/broken-links', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_broken_links' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /broken-links/scan
		register_rest_route( $ns, '/broken-links/scan', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_broken_links_scan' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /broken-links/fix
		register_rest_route( $ns, '/broken-links/fix', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_broken_links_fix' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'source_post_id' => [ 'required' => true,  'sanitize_callback' => 'absint' ],
				'broken_url'     => [ 'required' => true,  'sanitize_callback' => 'sanitize_url' ],
				'new_url'        => [ 'required' => true,  'sanitize_callback' => 'sanitize_url' ],
				'new_title'      => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /fix-internal-links
		register_rest_route( $ns, '/fix-internal-links', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_fix_internal_links' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );



		// POST /internal-links/preview
		register_rest_route( $ns, '/internal-links/preview', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_internal_links_preview' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /internal-links/apply
		register_rest_route( $ns, '/internal-links/apply', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_internal_links_apply' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// Legacy aliases used by the current bundled UI
		register_rest_route( $ns, '/link-reinsert/dry-run', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_internal_links_preview' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/link-reinsert/apply', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_internal_links_apply' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		register_rest_route( $ns, '/link-reinsert/diagnose-post', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_internal_links_diagnose_post' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /broken-links/generate-draft
		register_rest_route( $ns, '/broken-links/generate-draft', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_broken_links_generate_draft' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'broken_url'     => [ 'required' => true,  'sanitize_callback' => 'sanitize_url' ],
				'anchor_text'    => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
				'source_post_id' => [ 'required' => false, 'sanitize_callback' => 'absint', 'default' => 0 ],
			],
		] );

		// POST /link-suggestions/insert
		register_rest_route( $ns, '/link-suggestions/insert', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_insert_link_suggestion' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'source_post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
				'anchor_text'    => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
				'target_url'     => [ 'required' => true, 'sanitize_callback' => 'sanitize_url' ],
			],
		] );

		// GET /link-suggestions
		register_rest_route( $ns, '/link-suggestions', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_link_suggestions' ],
			'permission_callback' => [ $this, 'check_paid_plan' ],
			'show_in_index'       => false,
			'args'                => [
				'post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /assistant/chat (SSE streaming)
		register_rest_route( $ns, '/assistant/chat', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_chat' ],
			'permission_callback' => [ $this, 'check_paid_plan' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/meta-description
		register_rest_route( $ns, '/assistant/meta-description', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_meta_description' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'post_id' => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			],
		] );

		// POST /assistant/optimize-title
		register_rest_route( $ns, '/assistant/optimize-title', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_optimize_title' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );
		// POST /assistant/semantic-keywords
		register_rest_route( $ns, '/assistant/semantic-keywords', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_semantic_keywords' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/title-keyword-suggestions
		register_rest_route( $ns, '/assistant/title-keyword-suggestions', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_title_keyword_suggestions' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/excerpt
		register_rest_route( $ns, '/assistant/excerpt', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_excerpt' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/save-meta
		register_rest_route( $ns, '/assistant/save-meta', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_save_meta' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'post_id'          => [ 'required' => true, 'sanitize_callback' => 'absint' ],
				'meta_description' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
			],
		] );

		// POST /assistant/draft
		register_rest_route( $ns, '/assistant/draft', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_draft' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
			'args'                => [
				'gap_id'                  => [ 'required' => false, 'type' => 'integer' ],
				'custom_topic'            => [ 'required' => false, 'type' => 'string' ],
				'focus_keyword'           => [ 'required' => false, 'type' => 'string' ],
				'target_audience'         => [ 'required' => false, 'type' => 'string' ],
				'tone'                    => [ 'required' => false, 'type' => 'string' ],
				'additional_instructions' => [ 'required' => false, 'type' => 'string' ],
				'prefilled_topic'         => [ 'required' => false, 'type' => 'string' ],
			],
		] );


		// GET /assistant/draft-status
		register_rest_route( $ns, '/assistant/draft-status', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_assistant_draft_status' ],
			'permission_callback' => [ $this, 'check_permission' ],
			'show_in_index'       => false,
		] );

		// POST /assistant/draft-run
		register_rest_route( $ns, '/assistant/draft-run', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'post_assistant_draft_run' ],
			'permission_callback' => [ $this, 'check_async_job_permission' ],
			'show_in_index'       => false,
		] );
	}

	// - Permission ------------------------------

	public function check_paid_plan( WP_REST_Request $request = null ) {
		$request = $request instanceof WP_REST_Request ? $request : new WP_REST_Request( 'GET' );
		$permission = $this->check_permission( $request );
		if ( true !== $permission ) {
			return $permission;
		}

		if ( ! function_exists( 'cgm_user_has_paid_plan' ) || ! cgm_user_has_paid_plan() ) {
			return new WP_Error( 'contentgem_upgrade_required', __( 'This feature requires a paid Contentgem plan.', 'contentgem' ), [ 'status' => 403 ] );
		}

		return true;
	}

	public function check_permission( WP_REST_Request $request = null ) {
		$permission = CGM_Security::require_capability( 'edit_posts' );
		if ( true !== $permission ) {
			return $permission;
		}

		if ( $request instanceof WP_REST_Request ) {
			$nonce = CGM_Security::require_rest_nonce( $request );
			if ( true !== $nonce ) {
				return $nonce;
			}
		}

		return true;
	}

	public function check_gsc_callback_permission( WP_REST_Request $request ) {
		$code  = sanitize_text_field( (string) ( $request->get_param( 'code' ) ?? '' ) );
		$state = sanitize_text_field( (string) ( $request->get_param( 'state' ) ?? '' ) );
		$error = sanitize_text_field( (string) ( $request->get_param( 'error' ) ?? '' ) );
		if ( '' !== $error ) {
			return true;
		}
		if ( '' === $code || '' === $state ) {
			return new WP_Error( 'rest_forbidden', __( 'Invalid OAuth callback request.', 'contentgem' ), [ 'status' => 403 ] );
		}
		return true;
	}

	public function check_async_job_permission( WP_REST_Request $request ) {
		if ( current_user_can( 'edit_posts' ) ) {
			return $this->check_permission( $request );
		}

		$validated = CGM_Security::validate_async_job_request( $request );
		return is_wp_error( $validated ) ? $validated : true;
	}

	private function maybe_reject_free_article_generation() {
		$user_id = get_current_user_id();
		if ( ! function_exists( 'cgm_can_generate_article' ) || cgm_can_generate_article( $user_id ) ) {
			return null;
		}

		$limit = function_exists( 'cgm_get_free_article_limit' ) ? cgm_get_free_article_limit() : 3;
		$upgrade_url = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '';
		return new WP_Error(
			'contentgem_free_limit_reached',
			sprintf( __( 'Free plan limit reached. You can generate up to %d articles before upgrading.', 'contentgem' ), $limit ),
			[
				'status' => 403,
				'upgrade_url' => $upgrade_url,
				'remaining' => function_exists( 'cgm_get_free_articles_remaining' ) ? cgm_get_free_articles_remaining( $user_id ) : 0,
			]
		);
	}

	/**
	 * Gate a REST endpoint behind a feature flag.
	 *
	 * @param string $feature Feature slug defined in cg-features.php.
	 * @return true|WP_Error True when allowed, WP_Error (402) when locked.
	 */
	private function require_feature( string $feature ) {
		if ( ! function_exists( 'cgm_has_feature' ) || cgm_has_feature( $feature ) ) {
			return true;
		}
		$upgrade_url = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '';
		return new WP_Error(
			'contentgem_feature_locked',
			__( 'This feature requires a paid Contentgem plan.', 'contentgem' ),
			[
				'status'      => 402,
				'feature'     => $feature,
				'plan'        => function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free',
				'upgrade_url' => $upgrade_url,
			]
		);
	}

	/**
	 * Lightweight plan-state endpoint. Returns current plan + cluster limit
	 * so the frontend can refresh after a license activation without a full
	 * page reload.
	 *
	 * GET /wp-json/contentgem/v1/plan-state
	 *
	 * @return WP_REST_Response
	 */
	public function get_plan_state() {
		$plan  = function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free';
		$limit = function_exists( 'cgm_get_limit' ) ? cgm_get_limit( 'clusters' ) : 4;

		return new WP_REST_Response( [
			'plan'         => $plan,
			'planLabel'    => function_exists( 'cgm_get_plan_label' ) ? cgm_get_plan_label() : 'Free',
			'clusterLimit' => (int) $limit,
			'isPremium'    => function_exists( 'cgm_is_premium' ) ? (bool) cgm_is_premium() : false,
			'upgradeUrl'   => function_exists( 'cgm_get_upgrade_url' ) ? (string) cgm_get_upgrade_url() : '',
		], 200 );
	}

	/**
	 * Admin-only diagnostic endpoint. Dumps everything we can learn
	 * about the current Freemius licensing state so cluster-cap and
	 * plan-mapping bugs can be traced without guessing.
	 *
	 * GET /wp-json/contentgem/v1/plan-diagnostic
	 *
	 * @return WP_REST_Response
	 */
	public function get_plan_diagnostic() {
		$out = [
			'resolved_plan'       => function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'unknown',
			'resolved_plan_label' => function_exists( 'cgm_get_plan_label' ) ? cgm_get_plan_label() : 'unknown',
			'cluster_limit'       => function_exists( 'cgm_get_limit' ) ? cgm_get_limit( 'clusters' ) : 'unknown',
			'is_premium'          => function_exists( 'cgm_is_premium' ) ? cgm_is_premium() : false,
			'has_paid_plan'       => function_exists( 'cgm_user_has_paid_plan' ) ? cgm_user_has_paid_plan() : false,
			'dev_override'        => '',
			'wp_debug'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'freemius'            => [],
		];

		// Detect developer override that might be masking the real plan.
		$dev_plan = get_user_meta( get_current_user_id(), 'contentgem_tier', true );
		if ( $dev_plan ) {
			$out['dev_override'] = $dev_plan;
			$out['dev_override_active'] = ( defined( 'WP_DEBUG' ) && WP_DEBUG && in_array( $dev_plan, [ 'free', 'growth', 'unlimited' ], true ) );
		}

		// Probe Freemius state directly.
		if ( function_exists( 'contentgem_fs' ) ) {
			try {
				$fs = contentgem_fs();
				if ( is_object( $fs ) ) {
					$out['freemius']['loaded']       = true;
					$out['freemius']['is_paying']    = method_exists( $fs, 'is_paying' ) ? (bool) $fs->is_paying() : null;
					$out['freemius']['is_trial']     = method_exists( $fs, 'is_trial' ) ? (bool) $fs->is_trial() : null;
					$out['freemius']['is_free_plan'] = method_exists( $fs, 'is_free_plan' ) ? (bool) $fs->is_free_plan() : null;
					$out['freemius']['plan_name']    = method_exists( $fs, 'get_plan_name' ) ? (string) $fs->get_plan_name() : '';
					$out['freemius']['plan_title']   = method_exists( $fs, 'get_plan_title' ) ? (string) $fs->get_plan_title() : '';

					// Check each known plan-slug. If any returns true here but
					// cgm_get_plan() returns 'free', we know it's a resolver bug.
					if ( method_exists( $fs, 'is_plan' ) ) {
						$out['freemius']['is_plan'] = [
							'free'      => (bool) $fs->is_plan( 'free', true ),
							'starter'   => (bool) $fs->is_plan( 'starter', true ),
							'growth'    => (bool) $fs->is_plan( 'growth', true ),
							'pro'       => (bool) $fs->is_plan( 'pro', true ),
							'unlimited' => (bool) $fs->is_plan( 'unlimited', true ),
							'agency'    => (bool) $fs->is_plan( 'agency', true ),
						];
					}

					// License details.
					if ( method_exists( $fs, '_get_license' ) ) {
						$license = $fs->_get_license();
						if ( $license && is_object( $license ) ) {
							$out['freemius']['license'] = [
								'id'         => $license->id ?? null,
								'plan_id'    => $license->plan_id ?? null,
								'quota'      => $license->quota ?? null,
								'is_cancelled' => $license->is_cancelled ?? null,
								'expiration' => $license->expiration ?? null,
							];
						} else {
							$out['freemius']['license'] = null;
						}
					}
				} else {
					$out['freemius']['loaded'] = false;
				}
			} catch ( \Throwable $e ) {
				$out['freemius']['error'] = $e->getMessage();
			}
		} else {
			$out['freemius']['loaded'] = false;
			$out['freemius']['note']   = 'contentgem_fs() function not defined';
		}

		return new WP_REST_Response( $out, 200 );
	}

	/**
	 * Reject a request if adding N more clusters would exceed the plan cap.
	 *
	 * @param int $proposed_total The total number of clusters after the operation completes.
	 * @return true|WP_Error
	 */
	private function maybe_reject_cluster_overflow( int $proposed_total ) {
		if ( ! function_exists( 'cgm_get_limit' ) ) {
			return true;
		}
		$limit = (int) cgm_get_limit( 'clusters' );
		if ( $limit < 0 ) {
			return true; // Unlimited.
		}
		if ( $proposed_total <= $limit ) {
			return true;
		}
		$upgrade_url = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '';
		return new WP_Error(
			'contentgem_cluster_limit_reached',
			sprintf(
				/* translators: 1: cluster limit on the current plan */
				__( 'Your current plan allows up to %d clusters. Upgrade to add more.', 'contentgem' ),
				$limit
			),
			[
				'status'      => 402,
				'limit'       => $limit,
				'current'     => $proposed_total,
				'plan'        => function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free',
				'upgrade_url' => $upgrade_url,
			]
		);
	}


	private function reserve_free_generation_slot( int $user_id = 0 ) {
		$user_id = $user_id > 0 ? $user_id : get_current_user_id();
		if ( ! function_exists( 'cgm_is_premium' ) || cgm_is_premium() ) {
			return true;
		}

		if ( ! function_exists( 'cgm_reserve_free_article_generation' ) || ! cgm_reserve_free_article_generation( $user_id ) ) {
			return $this->maybe_reject_free_article_generation();
		}

		return true;
	}

	private function commit_free_generation_slot( int $user_id = 0 ): void {
		$user_id = $user_id > 0 ? $user_id : get_current_user_id();
		if ( function_exists( 'cgm_commit_free_article_generation' ) ) {
			cgm_commit_free_article_generation( $user_id );
		}
	}

	private function release_free_generation_slot( int $user_id = 0 ): void {
		$user_id = $user_id > 0 ? $user_id : get_current_user_id();
		if ( function_exists( 'cgm_release_free_article_generation' ) ) {
			cgm_release_free_article_generation( $user_id );
		}
	}

	// - Handlers -------------------------------

	public function get_clusters( WP_REST_Request $request ) {
		global $wpdb;

		$site_id       = $this->get_site_id();
		$transient_key = 'contentgem_clusters_' . $site_id;
		$cached        = CGM_Cache::get( $transient_key );

		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, cluster_name, coverage_score, post_count FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d ORDER BY coverage_score ASC, cluster_name ASC",
				$site_id
			)
		);

		$clusters = array_map( static function( $row ) {
			$row->post_count = (int) ( $row->post_count ?? 0 );
			return $row;
		}, $rows );

		$total_posts = (int) array_sum( array_column(
			array_map( static function( $r ) { return (array) $r; }, $clusters ),
			'post_count'
		) );

		$data = [
			'clusters'         => $clusters,
			'overall_coverage' => $this->calculate_overall_coverage( $rows ),
			'total_clusters'   => count( $rows ),
			'total_posts'      => $total_posts,
		];

		CGM_Cache::set( $transient_key, $data, 15 * MINUTE_IN_SECONDS );

		return rest_ensure_response( $data );
	}


	private function cgm_get_all_cluster_names(): array {
		global $wpdb;
		$clusters = [];
		$site_id  = $this->get_site_id();
		if ( $site_id > 0 ) {
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT cluster_name FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name <> '' ORDER BY cluster_name ASC", $site_id ) );
			if ( is_array( $rows ) ) {
				$clusters = array_merge( $clusters, array_map( 'sanitize_text_field', $rows ) );
			}
		}
		$opt = get_option( 'contentgem_clusters', [] );
		if ( is_string( $opt ) ) {
			$decoded = json_decode( $opt, true );
			$opt = is_array( $decoded ) ? $decoded : preg_split( '/\r\n|\r|\n/', $opt );
		}
		if ( is_array( $opt ) ) {
			$clusters = array_merge( $clusters, array_map( 'sanitize_text_field', $opt ) );
		}
		$clusters = array_values( array_unique( array_filter( array_map( 'trim', $clusters ) ) ) );
		sort( $clusters, SORT_NATURAL | SORT_FLAG_CASE );
		return $clusters;
	}

	private function cgm_normalize_keyword_text( string $text ): array {
		$text = mb_strtolower( wp_strip_all_tags( $text ) );
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		$stop = [ 'the','and','for','with','that','this','from','your','into','what','when','waar','de','het','een','van','met','voor','over','naar','hoe','wat','waarom','content','guide','tips','best','seo' ];
		$tokens = array_values( array_filter( array_unique( $tokens ), static function( $token ) use ( $stop ) {
			return mb_strlen( $token ) >= 4 && ! in_array( $token, $stop, true );
		} ) );
		return $tokens;
	}

	private function cgm_find_existing_keyword_matches( string $suggested_title, string $cluster_name = '' ): array {
		static $posts_cache = null;
		if ( null === $posts_cache ) {
			$posts_cache = get_posts( [
				'post_type' => 'post',
				'post_status' => 'publish',
				'numberposts' => -1,
				'suppress_filters' => false,
			] );
		}
		$target_tokens = $this->cgm_normalize_keyword_text( $suggested_title );
		$target_phrase = mb_strtolower( trim( wp_strip_all_tags( $suggested_title ) ) );
		$matches = [];
		foreach ( (array) $posts_cache as $post ) {
			$title = (string) $post->post_title;
			$title_lc = mb_strtolower( $title );
			$meta_kw = (string) get_post_meta( (int) $post->ID, '_cgm_primary_keyword', true );
			if ( '' === $meta_kw ) {
				$meta_kw = (string) get_post_meta( (int) $post->ID, '_contentgem_focus_keyword', true );
			}
			$post_cluster = '';
			try {
				$scanner = new CGM_Link_Scanner();
				$method  = new ReflectionMethod( $scanner, 'get_post_cluster' );
				$method->setAccessible( true );
				$post_cluster = (string) $method->invoke( $scanner, (int) $post->ID );
			} catch ( Exception $e ) {
				$post_cluster = '';
			}
			if ( '' !== $cluster_name && '' !== $post_cluster && mb_strtolower( $post_cluster ) !== mb_strtolower( $cluster_name ) ) {
				continue;
			}
			$post_tokens = $this->cgm_normalize_keyword_text( $title . ' ' . $meta_kw );
			$overlap = count( array_intersect( $target_tokens, $post_tokens ) );
			$denom = max( 1, min( max( 1, count( $target_tokens ) ), max( 1, count( $post_tokens ) ) ) );
			$ratio = $overlap / $denom;
			if ( ( '' !== $target_phrase && false !== mb_strpos( $title_lc, $target_phrase ) ) || $ratio >= 0.6 ) {
				$matches[] = [
					'post_id' => (int) $post->ID,
					'title'   => $title,
					'edit_url'=> admin_url( 'post.php?post=' . (int) $post->ID . '&action=edit' ),
					'ratio'   => $ratio,
				];
			}
		}
		usort( $matches, static fn( $a, $b ) => $b['ratio'] <=> $a['ratio'] );
		return array_slice( $matches, 0, 3 );
	}

	private function cgm_build_synthetic_cluster_gaps( string $cluster_name, int $count = 1 ): array {
		$cluster_name = trim( sanitize_text_field( $cluster_name ) );
		if ( '' === $cluster_name ) { return []; }
		$keyword_map = get_option( 'cgm_cluster_keywords', [] );
		$keyword_map = is_array( $keyword_map ) ? $keyword_map : [];
		$keywords = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $keyword_map[ $cluster_name ] ?? [] ) ) ) );
		$templates = [
			'What is %s and how does it work?',
			'Best practices for %s in modern SEO',
			'Common mistakes in %s and how to avoid them',
		];
		$rows = [];
		for ( $i = 0; $i < min( $count, count( $templates ) ); $i++ ) {
			$row = (object) [
				'id' => -1 * abs( crc32( $cluster_name . '|' . $i ) ),
				'suggested_title' => sprintf( $templates[ $i ], $cluster_name ),
				'search_intent' => 'informational',
				'priority_score' => 32 - $i,
				'status' => 'open',
				'topic_id' => 0,
				'fixes_broken_link' => false,
				'broken_url' => null,
				'cluster_name' => $cluster_name,
				'category_id' => null,
				'category_slug' => sanitize_title( $cluster_name ),
				'semantic_tags' => array_slice( array_unique( array_merge( [ sanitize_title( $cluster_name ) ], $keywords ) ), 0, 6 ),
				'suggested_length' => 1400,
				'suggested_length_label' => 'Detailed guide',
				'length_reason' => 'Synthetic fallback gap to ensure cluster coverage.',
				'is_synthetic' => true,
			];
			$matches = $this->cgm_find_existing_keyword_matches( (string) $row->suggested_title, $cluster_name );
			$row->already_written = ! empty( $matches );
			$row->already_written_titles = array_map( static fn( $m ) => (string) $m['title'], $matches );
			$row->already_written_matches = $matches;
			$rows[] = $row;
		}
		return $rows;
	}

	public function get_gaps( WP_REST_Request $request ) {
		global $wpdb;

		$site_id  = $this->get_site_id();
		$per_page = max( 1, min( 100, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ) );
		$page     = max( 1, (int) ( $request->get_param( 'page' ) ?: 1 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$cluster           = sanitize_text_field( $request->get_param( 'cluster' ) ?? '' );
		$fixes_broken_link = $request->get_param( 'fixes_broken_link' );
		$intent            = sanitize_text_field( $request->get_param( 'intent' ) ?? '' );
		$keyword_only_raw  = $request->get_param( 'keyword_only' );
		$keyword_only      = null !== $keyword_only_raw && '' !== $keyword_only_raw ? filter_var( $keyword_only_raw, FILTER_VALIDATE_BOOLEAN ) : false;

		$where  = [ 'g.site_id = %d', "g.status = 'open'" ];
		$params = [ $site_id ];

		if ( '' !== $cluster ) {
			$where[]  = 't.cluster_name = %s';
			$params[] = $cluster;
		}
		if ( 'true' === $fixes_broken_link ) {
			$where[] = 'g.fixes_broken_link = 1';
		} elseif ( 'false' === $fixes_broken_link ) {
			$where[] = 'g.fixes_broken_link = 0';
		}
		if ( '' !== $intent ) {
			$where[]  = 'g.search_intent = %s';
			$params[] = $intent;
		}

		$where_sql     = implode( ' AND ', $where );
		$cache_payload = [
			'site_id'           => $site_id,
			'page'              => $page,
			'per_page'          => $per_page,
			'cluster'           => $cluster,
			'fixes_broken_link' => (string) $fixes_broken_link,
			'intent'            => $intent,
			'keyword_only'      => $keyword_only ? '1' : '0',
		];
		$transient_key = 'contentgem_gaps_' . md5( wp_json_encode( $cache_payload ) );

		$cluster_terms = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_terms = is_array( $cluster_terms ) ? $cluster_terms : [];

		$cluster_keywords_map = get_option( 'cgm_cluster_keywords', [] );
		$cluster_keywords_map = is_array( $cluster_keywords_map ) ? $cluster_keywords_map : [];
		$all_clusters = $this->cgm_get_all_cluster_names();

		if ( $keyword_only ) {
			$rows = $this->cgm_build_keyword_only_gaps( $cluster, $intent, $cluster_keywords_map, $cluster_terms, $site_id );
			$total = count( $rows );
			$rows  = array_slice( $rows, $offset, $per_page );
		} else {
			$query_params = array_merge(
				$params,
				[ $per_page, $offset ]
			);
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT g.id, g.suggested_title, g.search_intent, g.priority_score, g.status, g.topic_id, g.fixes_broken_link, g.broken_url, t.cluster_name
					 FROM {$wpdb->prefix}cgm_gaps g
					 LEFT JOIN {$wpdb->prefix}cgm_topics t ON g.topic_id = t.id
					 WHERE {$where_sql}
					 ORDER BY g.priority_score DESC, g.id DESC
					 LIMIT %d OFFSET %d",
					$query_params
				)
			);

			$total = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*)
					 FROM {$wpdb->prefix}cgm_gaps g
					 LEFT JOIN {$wpdb->prefix}cgm_topics t ON g.topic_id = t.id
					 WHERE {$where_sql}",
					$params
				)
			);
		}

		foreach ( $rows as $row ) {
			if ( empty( $row->cluster_name ) ) {
				$row->cluster_name = $this->relink_gap_topic_to_best_cluster( $row );
			}
			$key                = (string) ( $row->cluster_name ?? '' );
			$cat_id             = (int) ( $cluster_terms[ $key ]['category_id'] ?? 0 );
			$cat_slug           = (string) ( $cluster_terms[ $key ]['category_slug'] ?? '' );
			$row->category_id   = $cat_id > 0 ? $cat_id : null;
			$row->category_slug = '' !== $cat_slug ? $cat_slug : null;
			$row->semantic_tags = $this->build_gap_semantic_tags( (string) ( $row->suggested_title ?? '' ), $key, (array) ( $cluster_keywords_map[ $key ] ?? [] ) );
			$row->fixes_broken_link = (bool) ( $row->fixes_broken_link ?? false );
			$row->broken_url        = ! empty( $row->broken_url ) ? $row->broken_url : null;
					$length_meta         = $this->get_gap_length_recommendation( (string) ( $row->suggested_title ?? '' ), (string) ( $row->search_intent ?? 'informational' ) );
			$row->suggested_length = (int) ( $length_meta['words'] ?? 0 );
			$row->suggested_length_label = (string) ( $length_meta['label'] ?? '' );
			$row->length_reason = (string) ( $length_meta['reason'] ?? '' );
			$matches = $this->cgm_find_existing_keyword_matches( (string) ( $row->suggested_title ?? '' ), $key );
			$row->already_written = ! empty( $matches );
			$row->already_written_titles = array_map( static fn( $m ) => (string) $m['title'], $matches );
			$row->already_written_matches = $matches;
		}

		if ( '' !== $cluster && empty( $rows ) ) {
			$rows = $this->cgm_build_synthetic_cluster_gaps( $cluster, 3 );
			$total = max( $total, count( $rows ) );
		} elseif ( '' === $cluster && 1 === $page ) {
			$present_clusters = array_values( array_unique( array_filter( array_map( static fn( $row ) => (string) ( $row->cluster_name ?? '' ), $rows ) ) ) );
			$missing_clusters = array_values( array_diff( $all_clusters, $present_clusters ) );
			foreach ( $missing_clusters as $missing_cluster ) {
				if ( count( $rows ) >= $per_page ) { break; }
				foreach ( $this->cgm_build_synthetic_cluster_gaps( $missing_cluster, 1 ) as $synthetic ) {
					$rows[] = $synthetic;
				}
			}
		}

		$seen_broken_urls = [];
		$rows             = array_values( array_filter( $rows, static function( $row ) use ( &$seen_broken_urls ) {
			if ( ! empty( $row->fixes_broken_link ) && ! empty( $row->broken_url ) ) {
				if ( in_array( $row->broken_url, $seen_broken_urls, true ) ) {
					return false;
				}
				$seen_broken_urls[] = $row->broken_url;
			}
			return true;
		} ) );

		$data = [
			'gaps'     => $rows,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'all_clusters' => $all_clusters,
		];

		return rest_ensure_response( $data );
	}

	public function post_suggest( WP_REST_Request $request ) {
		return new WP_Error(
			'gap_suggest_removed',
			__( 'The Suggest action has been removed from Content Gaps. Generate a draft directly from the gap row.', 'contentgem' ),
			[ 'status' => 410 ]
		);
	}

	public function post_draft( WP_REST_Request $request ): void {
		set_time_limit( 0 );
		ini_set( 'max_execution_time', '0' );
		ignore_user_abort( true );

		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		header( 'X-Accel-Buffering: no' );

		$reservation = $this->reserve_free_generation_slot( get_current_user_id() );
		if ( is_wp_error( $reservation ) ) {
			echo "data: " . wp_json_encode( [ 'type' => 'error', 'code' => 'free_limit_reached', 'message' => $reservation->get_error_message(), 'upgrade_url' => function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '' ] ) . "\n\n";
			echo "data: [DONE]\n\n";
			exit;
		}

		$gap_id = $request->get_param( 'gap_id' );
		$gap    = $this->get_gap_or_error( $gap_id );
		if ( is_wp_error( $gap ) ) {
			echo "data: " . wp_json_encode( [ 'type' => 'error', 'message' => $gap->get_error_message() ] ) . "\n\n";
			echo "data: [DONE]\n\n";
			exit;
		}

		$tokens = new CGM_Token_Manager( get_current_user_id() );

		try {
			$creator = new CGM_Draft_Creator(
				new CGM_Claude_Client( $this->get_api_key() ),
				$tokens
			);

			$post_id = $creator->create( $gap_id, function ( string $chunk ) {
				echo "data: " . wp_json_encode( [ 'type' => 'chunk', 'content' => $chunk ] ) . "\n\n";
				if ( ob_get_level() > 0 ) ob_flush();
				flush();
			} );

			$this->commit_free_generation_slot( get_current_user_id() );
			$balance = $tokens->get_balance();
			echo "data: " . wp_json_encode( [
				'type'              => 'done',
				'wp_post_id'        => $post_id,
				'tokens_remaining'  => $balance['remaining'],
				'drafts_remaining'  => function_exists( 'cgm_get_free_articles_remaining' ) ? cgm_get_free_articles_remaining( get_current_user_id() ) : 9999,
			] ) . "\n\n";
		} catch ( \Throwable $e ) {
			$this->release_free_generation_slot( get_current_user_id() );
			if ( strpos( $e->getMessage(), 'No API key' ) === 0 ) {
				echo "data: " . wp_json_encode( [ 'type' => 'error', 'code' => 'no_api_key', 'message' => 'Add your Anthropic API key in Settings first.' ] ) . "\n\n";
			} else {
				echo "data: " . wp_json_encode( [ 'type' => 'error', 'message' => $e->getMessage() ] ) . "\n\n";
			}
		}

		echo "data: [DONE]\n\n";
		exit;
	}

	public function get_tokens( WP_REST_Request $request ): WP_REST_Response {
		$manager = new CGM_Token_Manager( get_current_user_id() );
		return rest_ensure_response( $manager->get_balance() );
	}


	// - Async analysis ---------------------------â"€

	public function post_analyse_start( WP_REST_Request $request ): WP_REST_Response {
		$site_id = $this->get_site_id();
		$job     = $this->queue_analysis_job( $site_id );
		if ( empty( $job['existing'] ) ) {
			$this->kickoff_analysis_job( $job['job_id'], $job['job_token'] );
		}
		$current = CGM_Jobs::get_job( $job['job_id'] ) ?: [];
		return rest_ensure_response( [
			'job_id'  => $job['job_id'],
			'status'  => (string) ( $current['status'] ?? 'queued' ),
			'progress' => (int) ( $current['progress'] ?? 1 ),
			'site_id' => $job['site_id'],
			'message' => ! empty( $job['existing'] ) ? 'Analysis already running. Reusing the active job.' : 'Analysis queued. Processing will start immediately in the background.',
			'updated' => (int) ( $current['updated'] ?? time() ),
		] );
	}

	public function get_analyse_status( WP_REST_Request $request ): WP_REST_Response {
		$requested_job_id = sanitize_text_field( $request->get_param( 'job_id' ) ?? '' );
		$active_job_id    = CGM_Jobs::get_active_analysis_job_id();
		$job_id           = $requested_job_id ?: $active_job_id;

		if ( empty( $job_id ) ) {
			return rest_ensure_response( [ 'status' => 'idle', 'progress' => 0, 'message' => '', 'job_id' => '', 'active_job' => '' ] );
		}

		$job = CGM_Jobs::get_job( $job_id );
		if ( ! $job ) {
			return rest_ensure_response( [ 'status' => 'idle', 'progress' => 0, 'message' => '', 'job_id' => '', 'active_job' => '' ] );
		}
		$progress = (int) ( $job['progress'] ?? 0 );
		$status   = (string) ( $job['status'] ?? 'unknown' );
		$updated  = (int) ( $job['updated'] ?? ( $job['started'] ?? time() ) );
		$stall_after = (int) apply_filters( 'contentgem/analysis_stall_after_seconds', 300 );
		if ( in_array( $status, [ 'queued', 'running' ], true ) && ( time() - $updated ) > $stall_after ) {
			$status = 'stalled';
			$job['message'] = sprintf( 'Analysis appears stalled. No updates for %d minutes. Please retry.', max( 1, (int) floor( ( time() - $updated ) / 60 ) ) );
			if ( $active_job_id === $job_id ) {
				delete_option( CGM_Jobs::ACTIVE_ANALYSE_OPTION );
				$active_job_id = '';
			}
		}
		if ( 'done' !== $status ) {
			$progress = min( 99, max( 0, $progress ) );
		} else {
			$progress = 100;
		}
		return rest_ensure_response( [
			'job_id'    => $job_id,
			'active_job'=> $active_job_id,
			'status'    => $status,
			'progress'  => $progress,
			'message'   => $job['message'] ?? '',
			'result'    => $job['result'] ?? null,
			'updated'   => $updated,
			'started'   => $job['started'] ?? null,
			'step'      => (string) ( $job['step'] ?? '' ),
		] );
	}

	public function post_analyse_run( WP_REST_Request $request ): WP_REST_Response {
		$body   = $request->get_json_params();
		$job_id = sanitize_text_field( (string) ( $body['job_id'] ?? '' ) );
		$job    = $job_id ? get_option( 'cgm_job_' . $job_id, null ) : null;
		$can_admin_kickoff = current_user_can( 'edit_posts' ) && ! empty( $job_id ) && is_array( $job );
		if ( ! $can_admin_kickoff ) {
			$validated = CGM_Security::validate_async_job_request( $request );
			if ( is_wp_error( $validated ) ) {
				return rest_ensure_response( [ 'error' => 'Invalid' ] );
			}
		}
		if ( is_array( $job ) && in_array( (string) ( $job['status'] ?? '' ), [ 'running', 'done' ], true ) ) {
			return rest_ensure_response( [ 'ok' => true, 'status' => $job['status'] ] );
		}

		if ( ! $this->acquire_job_lock( $job_id, 300 ) ) {
			$status = is_array( $job ) ? (string) ( $job['status'] ?? 'running' ) : 'running';
			return rest_ensure_response( [ 'ok' => true, 'status' => $status ] );
		}

		set_time_limit( 300 );
		ignore_user_abort( true );
		global $wpdb;

		$reserved_memory = str_repeat( 'x', 262144 );
		$job_id_for_shutdown = $job_id;
		register_shutdown_function( function() use ( &$reserved_memory, $job_id_for_shutdown ) {
			$reserved_memory = null;
			$err = error_get_last();
			if ( ! is_array( $err ) || empty( $job_id_for_shutdown ) ) {
				return;
			}
			if ( ! in_array( (int) $err['type'], [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR ], true ) ) {
				return;
			}
			$current_job = get_option( 'cgm_job_' . $job_id_for_shutdown, [] );
			$current_status = (string) ( $current_job['status'] ?? '' );
			if ( ! in_array( $current_status, [ 'queued', 'running' ], true ) ) {
				return;
			}
			$current_job['status'] = 'error';
			$current_job['message'] = 'Analysis failed: ' . wp_strip_all_tags( (string) ( $err['message'] ?? 'fatal error' ) );
			$current_job['updated'] = time();
			update_option( 'cgm_job_' . $job_id_for_shutdown, $current_job, false );
			$this->release_job_lock( $job_id_for_shutdown );
			delete_option( CGM_Jobs::ACTIVE_ANALYSE_OPTION );
		} );

		$site_id = $this->get_site_id();
		if ( ! $site_id ) {
			$wpdb->insert( $wpdb->prefix . 'cgm_sites', [
				'blog_id'         => get_current_blog_id(),
				'niche_label'     => get_bloginfo( 'name' ),
				'analysis_status' => 'running',
			], [ '%d', '%s', '%s' ] );
			$site_id = (int) $wpdb->insert_id;
		}
		$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'running' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
		if ( function_exists( 'cgm_clear_cached_lists' ) ) {
			cgm_clear_cached_lists( $site_id );
		} else {
			CGM_Cache::clear_analysis_lists( $site_id );
		}
		CGM_Cache::delete( 'contentgem_cannibalization_' . get_current_blog_id() );

		try {
			$this->update_job( $job_id, 'running', 5, 'Counting content...', null, 'counting_content' );
			$crawler     = new CGM_Crawler( $site_id );
			$batch_size  = max( 10, (int) apply_filters( 'contentgem/batch_size', 50 ) );
			$analysis_cap = max( 50, (int) apply_filters( 'contentgem/analysis_max_posts', 250 ) );
			$post_counts = wp_count_posts( 'post' );
			$page_counts = wp_count_posts( 'page' );
			$total_posts_all = (int) ( $post_counts->publish ?? 0 ) + (int) ( $page_counts->publish ?? 0 );
			$total_posts = max( 1, min( $total_posts_all, $analysis_cap ) );
			$posts       = [];
			$offset      = 0;
			do {
				$batch = $crawler->get_posts_batch( $offset );
				if ( empty( $batch ) ) {
					break;
				}
				foreach ( $batch as $post_obj ) {
					$posts[] = $post_obj;
					if ( count( $posts ) >= $total_posts ) {
						break;
					}
				}
				$offset += $batch_size;
				$crawl_progress = 5 + (int) min( 20, round( ( count( $posts ) / $total_posts ) * 20 ) );
				$this->update_job( $job_id, 'running', $crawl_progress, sprintf( 'Crawling content... %d/%d', min( count( $posts ), $total_posts ), $total_posts ), null, 'crawling_content' );
			} while ( count( $batch ) === $batch_size && count( $posts ) < $total_posts );

			if ( empty( $posts ) ) {
				$this->update_job( $job_id, 'running', 22, 'Building analysis context from saved plugin data...', null, 'plugin_context' );
				$plugin_result = $this->run_plugin_context_analysis( $site_id );
				$this->update_job( $job_id, 'done', 100, 'Plugin-context analysis complete from saved clusters, keywords and settings.', $plugin_result, 'plugin_context_complete' );
				$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'done' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
				return rest_ensure_response( [ 'ok' => true ] );
			}

			$sample_note = $total_posts_all > $analysis_cap ? sprintf( ' (sampled first %d items)', $analysis_cap ) : '';
			$this->log_debug( 'analysis run started', [ 'job_id' => $job_id, 'site_id' => $site_id, 'posts_sampled' => count( $posts ), 'posts_total' => $total_posts_all ] );
			$this->update_job( $job_id, 'running', 30, 'Analysing content signals' . $sample_note . '...', null, 'analysing_signals' );
			$nlp = new CGM_NLP_Engine();
			$nlp->set_corpus( $posts );
			$this->update_job( $job_id, 'running', 45, 'Building clusters...', null, 'building_clusters' );
			$cluster_builder = new CGM_Cluster_Builder( $site_id, $nlp );
			$clusters_found  = $cluster_builder->build();

			$this->update_job( $job_id, 'running', 62, 'Loading Search Console data...', null, 'loading_gsc' );
			$gsc_impressions = [];
			$gsc_clicks      = [];
			$gsc_connector   = new CGM_GSC_Connector();
			if ( $gsc_connector->is_connected() ) {
				$top_queries = $gsc_connector->get_top_queries( 250 );
				foreach ( $top_queries as $q ) {
					$gsc_impressions[ $q['query'] ] = $q['impressions'];
					$gsc_clicks[ $q['query'] ]      = $q['clicks'];
				}
			}

			$this->update_job( $job_id, 'running', 78, 'Detecting content gaps...', null, 'detecting_gaps' );
			$claude_client = null;
			try {
				$claude_client = new CGM_Claude_Client( $this->get_api_key() );
			} catch ( \RuntimeException $e ) {
			}
			$gap_analyzer = new CGM_Gap_Analyzer( $site_id, $gsc_impressions, $nlp, $claude_client, $gsc_clicks );
			$gaps_found   = $gap_analyzer->analyze();
			$gaps_found   += $this->augment_analysis_with_plugin_context( $site_id, is_array( $clusters_found ) ? $clusters_found : [] );

			$this->update_job( $job_id, 'running', 92, 'Checking cannibalization...', null, 'checking_cannibalization' );
			try {
				$gap_analyzer->detect_cannibalization_and_save();
			} catch ( \Exception $e ) {
			}

			$this->update_job( $job_id, 'running', 97, 'Saving results...', null, 'saving_results' );
			$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'done' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
			$this->update_job( $job_id, 'done', 100, 'Analysis complete' . $sample_note . '.', [
				'clusters'       => $clusters_found,
				'gaps'           => $gaps_found,
				'posts_analyzed' => count( $posts ),
				'posts_total'    => $total_posts_all,
				'sampled'        => $total_posts_all > $analysis_cap,
			] );
		} catch ( \Throwable $e ) {
			$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'error' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
			$this->log_debug( 'analysis failed', [ 'job_id' => $job_id, 'message' => $e->getMessage() ] );
			$this->update_job( $job_id, 'error', 0, 'Analysis failed: ' . $e->getMessage(), null, 'failed' );
		}
		return rest_ensure_response( [ 'ok' => true ] );
	}

	private function get_job_lock_key( string $job_id ): string {
		return 'cgm_job_lock_' . md5( $job_id );
	}

	private function acquire_job_lock( string $job_id, int $ttl = 300 ): bool {
		$key = $this->get_job_lock_key( $job_id );
		if ( false !== get_transient( $key ) ) {
			return false;
		}
		set_transient( $key, 1, $ttl );
		return true;
	}

	private function release_job_lock( string $job_id ): void {
		delete_transient( $this->get_job_lock_key( $job_id ) );
	}

	private function update_job( string $job_id, string $status, int $progress, string $message, ?array $result = null, string $step = '' ): void {
		CGM_Jobs::update_job( $job_id, $status, $progress, $message, $result, $step );
		if ( in_array( $status, [ 'done', 'error' ], true ) ) {
			$this->release_job_lock( $job_id );
		}
	}

	private function kickoff_analysis_job( string $job_id, string $token ): void {
		if ( empty( $job_id ) || empty( $token ) ) {
			return;
		}
		$url = rest_url( CONTENTGEM_REST_NS . '/analyze-run' );
		wp_remote_post( $url, [
			'timeout'  => 0.01,
			'blocking' => false,
			'headers'  => [ 'Content-Type' => 'application/json' ],
			'body'     => wp_json_encode( [ 'job_id' => $job_id, 'token' => $token ] ),
		] );
	}

	public function post_scan_links_start( WP_REST_Request $request ): WP_REST_Response {
		$service = new CGM_Job_Service();
		$job = $service->start_job( 'scan_broken_links', [], [
			'site_id' => $this->get_site_id(),
			'message' => 'Starting link scan...',
			'idempotency_key' => 'scan_broken_links:' . get_current_blog_id(),
		] );
		update_option( 'cgm_last_linkscan_job_id', $job['job_key'], false );
		if ( empty( $job['existing'] ) ) {
			$service->schedule_processing();
		} else {
			$this->release_free_generation_slot( get_current_user_id() );
		}
		return rest_ensure_response( [ 'job_id' => $job['job_key'], 'status' => ! empty( $job['existing'] ) ? 'running' : 'queued' ] );
	}

	public function get_scan_links_status( WP_REST_Request $request ): WP_REST_Response {
		$job_id = sanitize_text_field( $request->get_param( 'job_id' ) ?? '' );
		if ( empty( $job_id ) ) {
			$job_id = (string) get_option( 'cgm_last_linkscan_job_id', '' );
		}
		$repo = new CGM_Job_Repository();
		$job = $repo->get_by_key( $job_id );
		if ( $job ) {
			return rest_ensure_response( [
				'job_id' => $job_id,
				'status' => CGM_Job_Service::to_legacy_status( (string) $job['status'] ),
				'normalized_status' => (string) $job['status'],
				'progress' => (int) ( 'completed' === $job['status'] ? 100 : min( 99, (int) $job['progress_percentage'] ) ),
				'message' => $job['message'] ?? '',
				'links' => (array) ( $job['result']['links'] ?? [] ),
			] );
		}
		$legacy = get_option( 'cgm_job_' . $job_id, null );
		if ( ! $legacy ) {
			return rest_ensure_response( [ 'status' => 'unknown', 'progress' => 0 ] );
		}
		$result = [];
		if ( ( $legacy['status'] ?? '' ) === 'done' ) {
			$result = get_option( 'cgm_linkscan_result_' . $job_id, [] );
		}
		return rest_ensure_response( [
			'job_id' => $job_id,
			'status' => $legacy['status'],
			'progress' => $legacy['progress'] ?? 0,
			'message' => $legacy['message'] ?? '',
			'links' => $result,
		] );
	}

	public function post_scan_links_run( WP_REST_Request $request ): WP_REST_Response {
		$body   = $request->get_json_params();
		$job_id = sanitize_text_field( (string) ( $body['job_id'] ?? '' ) );
		$validated = CGM_Security::validate_async_job_request( $request );
		if ( is_wp_error( $validated ) ) {
			return rest_ensure_response( [ 'error' => 'Invalid' ] );
		}
		$job = get_option( 'cgm_job_' . $job_id, null );
		if ( ! is_array( $job ) ) {
			return rest_ensure_response( [ 'error' => 'Invalid' ] );
		}
		set_time_limit( 300 );
		ignore_user_abort( true );
		$this->update_job( $job_id, 'running', 10, 'Scanning links...' );
		try {
			$scanner      = new CGM_Link_Scanner();
			$broken_links = $scanner->scan_broken_internal_links();
			update_option( 'cgm_linkscan_result_' . $job_id, $broken_links, false );
			$this->update_job( $job_id, 'done', 100, count( $broken_links ) . ' broken links found.', [ 'links' => $broken_links ] );
		} catch ( \Throwable $e ) {
			$this->update_job( $job_id, 'error', 0, 'Scan failed: ' . $e->getMessage() );
		}
		return rest_ensure_response( [ 'ok' => true ] );
	}

	public function post_analyze( WP_REST_Request $request ): WP_REST_Response {
		$site_id = $this->get_site_id();
		if ( $site_id <= 0 ) {
			global $wpdb;
			$wpdb->insert(
				$wpdb->prefix . 'cgm_sites',
				[
					'blog_id'         => get_current_blog_id(),
					'niche_label'     => get_bloginfo( 'name' ),
					'analysis_status' => 'idle',
				],
				[ '%d', '%s', '%s' ]
			);
			$site_id = (int) $wpdb->insert_id;
		}

		if ( function_exists( 'cgm_clear_cached_lists' ) ) {
			cgm_clear_cached_lists( $site_id );
		} else {
			CGM_Cache::clear_analysis_lists( $site_id );
		}
		delete_transient( 'contentgem_cannibalization_' . get_current_blog_id() );

		$job = $this->queue_analysis_job( $site_id );
		return rest_ensure_response( [
			'status' => 'queued',
			'site_id' => $job['site_id'],
			'job_id' => $job['job_id'],
		] );
	}

	public function post_analyze_run( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		$body    = $request->get_json_params();
		$site_id = (int) ( $body['site_id'] ?? $this->get_site_id() );
		if ( $site_id ) {
			$this->run_analysis( $site_id );
		}
		return rest_ensure_response( [ 'ok' => true ] );
	}

	private function run_analysis( int $site_id ): void {
		global $wpdb;
		try {
			$crawler = new CGM_Crawler( $site_id );
			$posts   = $crawler->get_posts_batch( 0 );
			$nlp = new CGM_NLP_Engine();
			if ( ! empty( $posts ) ) $nlp->set_corpus( $posts );
			$cluster_builder = new CGM_Cluster_Builder( $site_id, $nlp );
			$cluster_builder->build();
			$claude_client = null;
			try { $claude_client = new CGM_Claude_Client( $this->get_api_key() ); } catch ( \RuntimeException $e ) {}
			$gap_analyzer = new CGM_Gap_Analyzer( $site_id, [], $nlp, $claude_client, [] );
			$gap_analyzer->analyze();
			try { $gap_analyzer->detect_cannibalization_and_save(); } catch ( \Exception $e ) {}
			$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'done', 'niche_label' => get_bloginfo( 'name' ) ], [ 'id' => $site_id ], [ '%s', '%s' ], [ '%d' ] );
			try {
				$ai_client = CGM_AI_Client::from_settings();
				$tone_analyzer = new CGM_Tone_Analyzer( $ai_client );
				$tone_analyzer->analyze_and_save( $site_id );
			} catch ( \Exception $e ) {}
			do_action( 'contentgem/analysis_complete', $site_id );
		} catch ( \Throwable $e ) {
			$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'error' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
		}
	}

	public function get_status( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;

		$site = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}cgm_sites WHERE blog_id = %d",
				get_current_blog_id()
			)
		);

		$gsc = new CGM_GSC_Connector();

		return rest_ensure_response( [
			'analysis_status' => $site->analysis_status ?? 'idle',
			'gsc_connected'   => $gsc->is_connected(),
			'plugin_version'  => CONTENTGEM_VERSION,
		] );
	}

	public function post_settings_api_key( WP_REST_Request $request ) {
		$api_key  = trim( (string) $request->get_param( 'api_key' ) );
		$provider = sanitize_text_field( (string) ( $request->get_json_params()['provider'] ?? 'claude' ) );

		if ( empty( $api_key ) ) {
			return new WP_Error( 'invalid_api_key', __( 'API key cannot be empty.', 'contentgem' ), [ 'status' => 400 ] );
		}

		if ( 'claude' === $provider && ! ( strpos( $api_key, 'sk-ant-' ) === 0 ) ) {
			return new WP_Error( 'invalid_api_key', __( 'Anthropic API key must start with "sk-ant-".', 'contentgem' ), [ 'status' => 400 ] );
		}
		if ( 'openai' === $provider && ! ( strpos( $api_key, 'sk-' ) === 0 ) ) {
			return new WP_Error( 'invalid_api_key', __( 'OpenAI API key must start with "sk-".', 'contentgem' ), [ 'status' => 400 ] );
		}

		update_option( 'contentgem_ai_provider', $provider );
		if ( 'openai' === $provider ) {
			update_option( 'contentgem_openai_api_key', $api_key );
		} else {
			update_option( 'contentgem_claude_api_key', $api_key );
			update_option( 'contentgem_api_key', $api_key ); // legacy compatibility
		}

		return rest_ensure_response( [
			'success' => true,
			'provider' => $provider,
			'claude_api_key_set' => '' !== (string) get_option( 'contentgem_claude_api_key', get_option( 'contentgem_api_key', '' ) ),
			'openai_api_key_set' => '' !== (string) get_option( 'contentgem_openai_api_key', '' ),
		] );
	}

	public function get_settings( WP_REST_Request $request ): WP_REST_Response {
		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$clusters = is_array( $clusters ) ? $this->normalise_cluster_list( $clusters ) : [];
		$clusters_initialized = (bool) get_option( 'contentgem_clusters_initialized', false );
		if ( empty( $clusters ) && ! $clusters_initialized ) {
			$clusters = $this->detect_existing_clusters();
			if ( ! empty( $clusters ) ) {
				update_option( 'contentgem_clusters', wp_json_encode( $clusters ) );
				update_option( 'contentgem_clusters_initialized', true, false );
				$this->build_cluster_terms( $clusters );
			}
		}
		$gsc      = new CGM_GSC_Connector();
		$tokens   = new CGM_Token_Manager( get_current_user_id() );
		$tier     = $tokens->get_tier();

		$tier_labels = [
			'free'      => 'Free',
			'starter'   => 'Starter',
			'growth'    => 'Growth',
			'unlimited' => 'Unlimited',
		];

		$provider        = (string) get_option( 'contentgem_ai_provider', 'claude' );
		$claude_api_key  = (string) get_option( 'contentgem_claude_api_key', '' );
		if ( '' === $claude_api_key ) {
			$claude_api_key = (string) get_option( 'contentgem_api_key', '' );
		}
		$openai_api_key  = (string) get_option( 'contentgem_openai_api_key', '' );
		$has_own_api_key = 'openai' === $provider ? '' !== $openai_api_key : '' !== $claude_api_key;
		$license_sites   = ( function_exists( 'contentgem_fs' ) && ( contentgem_fs()->is_plan( 'unlimited', true ) || contentgem_fs()->is_plan( 'agency', true ) ) )
			? 'unlimited'
			: 'single';

		$clusters_arr      = is_array( $clusters ) ? $clusters : [];
		$cluster_terms_raw = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_terms_raw = is_array( $cluster_terms_raw ) ? $cluster_terms_raw : [];
		$pending_clusters  = array_values( array_filter( $clusters_arr, function( $c ) use ( $cluster_terms_raw ) { return ! isset( $cluster_terms_raw[ $c ] ); } ) );
		$site_structure    = $this->get_site_structure();
		$site_pages        = get_posts( [
			'post_type'      => 'page',
			'post_status'    => [ 'publish', 'draft', 'private', 'pending', 'future' ],
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );
		$site_pages = array_map( static function( $post ) {
			return [ 'id' => (int) $post->ID, 'title' => get_the_title( $post->ID ), 'url' => (string) get_permalink( $post->ID ) ];
		}, is_array( $site_pages ) ? $site_pages : [] );

		$competitor_history_grouped = $this->get_grouped_competitor_history();
		$competitor_history  = $this->flatten_grouped_competitor_history( $competitor_history_grouped );
		$latest_comp         = get_option( 'contentgem_latest_competitor_analysis', [] );
		if ( is_array( $latest_comp ) && ! empty( $latest_comp ) ) {
			$latest_entry = $this->make_competitor_history_entry( $latest_comp );
			$latest_key = strtolower( trim( (string) ( $latest_entry['keyword'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $latest_entry['cluster'] ?? '' ) ) );
			$exists = false;
			foreach ( $competitor_history as $hist_item ) {
				$item_key = strtolower( trim( (string) ( $hist_item['keyword'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $hist_item['cluster'] ?? '' ) ) );
				if ( $item_key === $latest_key ) { $exists = true; break; }
			}
			if ( ! $exists ) { array_unshift( $competitor_history, $latest_entry ); }
		}
		$competitor_history  = array_slice( $competitor_history, 0, 25 );
		$latest_competitor   = get_option( 'contentgem_latest_competitor_analysis', [] );
		$latest_competitor   = is_array( $latest_competitor ) ? $latest_competitor : [];

		$flags = new CGM_Feature_Flags();
		$builder_integrator = class_exists( 'CGM_Builder_Integrator' ) ? new CGM_Builder_Integrator() : null;
		$preferred_builder_mode = $builder_integrator ? $builder_integrator->get_preferred_builder() : 'none';
		$available_builders = [
			'standard'  => true,
			'elementor' => $builder_integrator ? $builder_integrator->is_elementor_available() : false,
			'divi'      => $builder_integrator ? $builder_integrator->is_divi_available() : false,
		];
		$codebase_status = $this->get_codebase_status_payload();
		$indexnow_status = class_exists( 'CGM_IndexNow' ) ? CGM_IndexNow::get_status() : [
			'active'            => false,
			'key'               => '',
			'key_url'           => '',
			'last_ping_url'     => '',
			'last_ping_time'    => '',
			'recent_log'        => [],
			'public_base_url'   => rtrim( home_url( '/' ), '/' ),
			'verification_path' => '',
		];

		return rest_ensure_response( [
			'niche'               => get_option( 'contentgem_niche', '' ),
			'niche_description'   => get_option( 'contentgem_niche_description', '' ),
			'content_language'   => $this->get_configured_language_value(),
			'content_language_custom' => (string) get_option( 'contentgem_content_language_custom', '' ),
			'api_key_set'         => $has_own_api_key,
			'has_own_api_key'     => $has_own_api_key,
			'claude_api_key_set'  => '' !== $claude_api_key,
			'openai_api_key_set'  => '' !== $openai_api_key,
			'clusters'            => $clusters_arr,
			'cluster_keywords'    => get_option( 'cgm_cluster_keywords', [] ),
			'competitor_domains'  => (array) get_option( 'contentgem_competitor_domains', [] ),
			'tone_of_voice'       => (string) get_option( 'contentgem_tone_of_voice', '' ),
			'ai_provider'         => (string) get_option( 'contentgem_ai_provider', 'claude' ),
			'pending_clusters'    => $pending_clusters,
			'onboarding_complete' => (bool) (
				get_option( 'contentgem_onboarding_complete', false )
				&& ! get_option( 'contentgem_force_onboarding', false )
			),
			'gsc_connected'       => $gsc->is_connected(),
			'gsc_client_id_set'   => '' !== (string) get_option( 'contentgem_gsc_client_id', '' ),
			'gsc_client_secret_set'=> '' !== (string) get_option( 'contentgem_gsc_client_secret', '' ),
			'gsc_client_id'       => (string) get_option( 'contentgem_gsc_client_id', '' ),
			'gsc_client_secret_mask' => '' !== (string) get_option( 'contentgem_gsc_client_secret', '' ) ? str_repeat( '•', 24 ) : '',
			'gsc_site_url'        => (string) get_option( 'contentgem_gsc_site_url', '' ),
			'gsc_redirect_uri'    => $gsc->get_redirect_uri(),
			'gsc_debug'           => $gsc->get_debug_payload(),
			'tier'                => $tier,
			'tier_label'          => $tier_labels[ $tier ] ?? $tier,
			'upgrade_url'         => 'https://contentgem.ai/upgrade',
			'license_sites'       => $license_sites,
			'site_structure'      => $site_structure,
			'site_pages'          => $site_pages,
			'competitor_history'  => $competitor_history,
			'latest_competitor_analysis' => $latest_competitor,
			'latest_competitor_analysis_by_cluster' => (array) get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] ),
			'show_source_list'    => $flags->show_source_list(),
			'enable_token_optimization' => $flags->token_optimization_enabled(),
			'enable_fact_check' => $flags->fact_check_enabled(),
			'enable_full_source_grounding' => $flags->full_source_grounding_enabled(),
			'openai_default_model' => $flags->default_model(),
			'openai_show_token_stats' => $flags->show_token_stats(),
			'openai_enable_batch' => $flags->batch_enabled(),
			'openai_enable_flex' => $flags->flex_enabled(),
			'openai_reasoning_profile' => $flags->reasoning_profile(),
			'codebase_status'     => $codebase_status,
			'indexnow_status'     => $indexnow_status,
			'preferred_builder_mode' => $preferred_builder_mode,
			'available_builders'   => $available_builders,
		] );
	}



	private function sanitize_builder_mode( $mode ): string {
		$mode = sanitize_key( (string) $mode );
		if ( 'standard' === $mode ) {
			$mode = 'none';
		}
		return in_array( $mode, [ 'none', 'elementor', 'divi' ], true ) ? $mode : 'none';
	}

	public function get_settings_builder_mode( WP_REST_Request $request ): WP_REST_Response {
		$builder_integrator = class_exists( 'CGM_Builder_Integrator' ) ? new CGM_Builder_Integrator() : null;
		$mode = $builder_integrator ? $builder_integrator->get_preferred_builder() : 'none';
		return rest_ensure_response( [
			'success' => true,
			'mode'    => $mode,
			'available_builders' => [
				'standard'  => true,
				'elementor' => $builder_integrator ? $builder_integrator->is_elementor_available() : false,
				'divi'      => $builder_integrator ? $builder_integrator->is_divi_available() : false,
			],
		] );
	}

	public function post_settings_builder_mode( WP_REST_Request $request ): WP_REST_Response {
		$body = (array) $request->get_json_params();
		$mode = $this->sanitize_builder_mode( $body['mode'] ?? $request->get_param( 'mode' ) ?? 'none' );
		update_option( 'contentgem_builder_preference', $mode, false );
		return $this->get_settings_builder_mode( $request );
	}

	public function post_settings_ai_system( WP_REST_Request $request ): WP_REST_Response {
		$body = (array) $request->get_json_params();
		update_option( 'cgm_show_source_list', ! empty( $body['show_source_list'] ), false );
		update_option( 'cgm_enable_token_optimization', ! empty( $body['enable_token_optimization'] ), false );
		update_option( 'cgm_enable_fact_check', ! empty( $body['enable_fact_check'] ), false );
		update_option( 'cgm_enable_full_source_grounding', ! empty( $body['enable_full_source_grounding'] ), false );
		update_option( 'cgm_openai_default_model', sanitize_text_field( (string) ( $body['openai_default_model'] ?? 'gpt-5.4-mini' ) ), false );
		update_option( 'cgm_openai_show_token_stats', ! empty( $body['openai_show_token_stats'] ), false );
		update_option( 'cgm_openai_enable_batch', ! empty( $body['openai_enable_batch'] ), false );
		update_option( 'cgm_openai_enable_flex', ! empty( $body['openai_enable_flex'] ), false );
		$reasoning = sanitize_key( (string) ( $body['openai_reasoning_profile'] ?? 'balanced' ) );
		if ( ! in_array( $reasoning, [ 'minimal', 'balanced', 'deep' ], true ) ) {
			$reasoning = 'balanced';
		}
		update_option( 'cgm_openai_reasoning_profile', $reasoning, false );
		return rest_ensure_response( [ 'success' => true ] + $this->get_settings( new WP_REST_Request( 'GET', '/' . CONTENTGEM_REST_NS . '/settings' ) )->get_data() );
	}

	private function get_codebase_status_payload(): array {
		$indexer = new CGM_Codebase_Indexer();
		$index = $indexer->get_index();
		return [
			'available' => ! empty( $index['files'] ),
			'built_at' => (string) ( $index['built_at'] ?? get_option( 'cgm_codebase_index_last_built', '' ) ),
			'version' => (string) ( $index['version'] ?? get_option( 'cgm_codebase_index_version', '' ) ),
			'file_count' => (int) ( $index['file_count'] ?? ( is_array( $index['files'] ?? null ) ? count( $index['files'] ) : 0 ) ),
		];
	}

	public function get_codebase_index_status( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( $this->get_codebase_status_payload() );
	}

	public function post_codebase_reindex( WP_REST_Request $request ): WP_REST_Response {
		$index = ( new CGM_Codebase_Indexer() )->build_index();
		return rest_ensure_response( [
			'success' => true,
			'built_at' => (string) ( $index['built_at'] ?? '' ),
			'file_count' => (int) ( $index['file_count'] ?? 0 ),
			'version' => (string) ( $index['version'] ?? '' ),
		] );
	}

	public function get_codebase_summary( WP_REST_Request $request ): WP_REST_Response {
		$index = ( new CGM_Codebase_Indexer() )->get_index();
		$files = array_slice( (array) ( $index['files'] ?? [] ), 0, 50 );
		$summary = array_map( static function( array $file ): array {
			return [
				'path' => (string) ( $file['path'] ?? '' ),
				'type' => (string) ( $file['type'] ?? '' ),
				'summary' => (string) ( $file['summary']['summary'] ?? '' ),
			];
		}, $files );
		return rest_ensure_response( [ 'files' => $summary ] );
	}

	public function get_codebase_task_context_preview( WP_REST_Request $request ): WP_REST_Response {
		$task = sanitize_key( (string) $request->get_param( 'task' ) );
		$hint = sanitize_text_field( (string) $request->get_param( 'hint' ) );
		$bundle = ( new CGM_Codebase_Grounder() )->get_context_for_task( $task ?: 'technical_build_plan', $hint ? [ $hint ] : [] );
		return rest_ensure_response( $bundle );
	}

	private function use_openai_task_stack(): bool {
		return 'openai' === (string) get_option( 'contentgem_ai_provider', 'claude' ) && '' !== (string) get_option( 'contentgem_openai_api_key', '' );
	}

	private function build_openai_schema_payload( string $schema_name ): array {
		if ( '' === $schema_name ) {
			return [];
		}
		$schema = ( new CGM_Schema_Registry() )->get( $schema_name );
		if ( empty( $schema['schema'] ) ) {
			return [];
		}
		return [
			'type' => 'json_schema',
			'name' => (string) ( $schema['name'] ?? $schema_name ),
			'strict' => true,
			'schema' => $schema['schema'],
		];
	}

	private function run_openai_task( string $task_name, array $messages, array $args = [] ): array {
		$flags = new CGM_Feature_Flags();
		$builder_integrator = class_exists( 'CGM_Builder_Integrator' ) ? new CGM_Builder_Integrator() : null;
		$preferred_builder_mode = $builder_integrator ? $builder_integrator->get_preferred_builder() : 'none';
		$available_builders = [
			'standard'  => true,
			'elementor' => $builder_integrator ? $builder_integrator->is_elementor_available() : false,
			'divi'      => $builder_integrator ? $builder_integrator->is_divi_available() : false,
		];
		$registry = new CGM_Task_Registry();
		$optimizer = new CGM_Token_Optimizer( $flags );
		$prompt_library = new CGM_Prompt_Library();
		$task = $optimizer->optimize_task_config( $registry->get( $task_name ), $args );
		$schema_payload = $this->build_openai_schema_payload( (string) ( $task['schema'] ?? '' ) );
		if ( ! empty( $schema_payload ) ) {
			$task['schema_payload'] = $schema_payload;
		}
		$language_code = ( new CGM_Language_Service() )->get_language_code();
		$instructions = trim( $prompt_library->get_instructions( $task_name, $language_code ) . "

" . $prompt_library->get_source_mode_appendix( $flags->show_source_list() && ! empty( $task['supports_sources'] ), $language_code ) );
		$grounded_bundle = [];
		if ( ! empty( $task['supports_grounding'] ) && $flags->should_ground_task( $task_name ) ) {
			$grounded_bundle = ( new CGM_Codebase_Grounder() )->get_context_for_task( $task_name, (array) ( $args['grounding_hints'] ?? [] ) );
		}
		$client = new CGM_OpenAI_Client( (string) get_option( 'contentgem_openai_api_key', '' ) );
		$result = $client->create_response( $task_name, $task, [
			'instructions' => $instructions,
			'messages' => $messages,
			'grounded_context' => $grounded_bundle,
		] );
		if ( $flags->show_source_list() && ! empty( $grounded_bundle['sources'] ) ) {
			$result['sources'] = array_values( array_merge( (array) ( $result['sources'] ?? [] ), (array) $grounded_bundle['sources'] ) );
			$result['sources'] = ( new CGM_Source_Manager() )->normalize_sources( $result['sources'] );
		}
		$result['meta']['grounded'] = ! empty( $grounded_bundle['files'] );
		return $result;
	}

	private function assistant_prompt_looks_technical( array $messages ): bool {
		$haystack = strtolower( implode( "
", array_map( static function( array $message ): string {
			return (string) ( $message['content'] ?? '' );
		}, $messages ) ) );
		foreach ( [ 'plugin', 'patch', 'buildplan', 'build plan', 'rest', 'endpoint', 'settings', 'class', 'codebase', 'bug', 'refactor', 'wordpress plugin' ] as $needle ) {
			if ( false !== strpos( $haystack, $needle ) ) {
				return true;
			}
		}
		return false;
	}


	private function get_saved_clusters(): array {
		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		return is_array( $clusters ) ? $this->normalise_cluster_list( $clusters ) : [];
	}

	private function blocked_cluster_labels(): array {
		return [
			'generate clusters with ai',
			'ai suggest cluster',
			'admin',
			'auto-detect existing clusters',
			'auto-generate clusters',
			'revert clusters',
		];
	}

	private function is_valid_cluster_label( string $cluster_name ): bool {
		$label = trim( wp_strip_all_tags( $cluster_name ) );
		if ( '' === $label ) {
			return false;
		}
		$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );
		if ( in_array( $key, $this->blocked_cluster_labels(), true ) ) {
			return false;
		}
		if ( preg_match( '/^(generate|suggest|revert|detect)/i', $label ) ) {
			return false;
		}
		return true;
	}

	private function normalise_cluster_list( array $clusters ): array {
		$seen       = [];
		$normalised = [];
		foreach ( $clusters as $cluster_name ) {
			$label = trim( sanitize_text_field( (string) $cluster_name ) );
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );
			if ( ! $this->is_valid_cluster_label( $label ) || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$normalised[] = $label;
		}
		return $normalised;
	}

	private function save_cluster_snapshot( array $clusters, string $reason = '' ): void {
		update_option( 'contentgem_clusters_snapshot', wp_json_encode( $this->normalise_cluster_list( $clusters ) ) );
		update_option( 'contentgem_clusters_snapshot_meta', [
			'reason'     => sanitize_text_field( $reason ),
			'saved_at'   => time(),
			'cluster_count' => count( $clusters ),
		], false );
	}

	private function get_cluster_snapshot(): array {
		$snapshot = json_decode( (string) get_option( 'contentgem_clusters_snapshot', '[]' ), true );
		return is_array( $snapshot ) ? array_values( array_filter( array_map( 'sanitize_text_field', $snapshot ) ) ) : [];
	}

	private function persist_clusters( array $clusters, bool $replace = false ): array {
		$clusters = $this->normalise_cluster_list( $clusters );
		if ( $replace ) {
			$this->delete_managed_cluster_terms();
		}
		update_option( 'contentgem_clusters', wp_json_encode( $clusters ) );
		update_option( 'contentgem_clusters_initialized', true, false );
		$this->build_cluster_terms( $clusters );
		if ( function_exists( 'cgm_clear_cached_lists' ) ) {
			cgm_clear_cached_lists( $this->get_site_id() );
		}
		global $wpdb;
		$likes = [
			$wpdb->esc_like( '_transient_contentgem_gaps_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_contentgem_gaps_' ) . '%',
		];
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$likes[0],
				$likes[1]
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $clusters;
	}

	private function queue_analysis_job( int $site_id ): array {
		$job = CGM_Jobs::create_analysis_job( $site_id );
		global $wpdb;
		$site_id = (int) $job['site_id'];
		if ( $site_id <= 0 ) {
			$wpdb->insert( $wpdb->prefix . 'cgm_sites', [
				'blog_id'         => get_current_blog_id(),
				'niche_label'     => get_bloginfo( 'name' ),
				'analysis_status' => 'queued',
			], [ '%d', '%s', '%s' ] );
			$site_id = (int) $wpdb->insert_id;
			$current = CGM_Jobs::get_job( (string) $job['job_id'] ) ?: [];
			$current['site_id'] = $site_id;
			CGM_Jobs::save_job( (string) $job['job_id'], $current );
			$job['site_id'] = $site_id;
		} else {
			$wpdb->update( $wpdb->prefix . 'cgm_sites', [ 'analysis_status' => 'queued' ], [ 'id' => $site_id ], [ '%s' ], [ '%d' ] );
		}
		if ( empty( $job['existing'] ) ) {
			wp_schedule_single_event( time(), 'cgm_run_analysis_job', [ $job['job_id'], $job['job_token'] ] );
			if ( function_exists( 'spawn_cron' ) ) {
				spawn_cron();
			}
		}
		return $job;
	}

	public function post_suggest_clusters( WP_REST_Request $request ) {
		$body        = $request->get_json_params();
		$niche       = sanitize_text_field( $body['niche'] ?? '' ) ?: (string) get_option( 'contentgem_niche', '' );
		$description = sanitize_text_field( $body['description'] ?? '' ) ?: (string) get_option( 'contentgem_niche_description', '' );

		if ( empty( $niche ) ) {
			return new WP_Error( 'no_niche', __( 'Set your niche first.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$tokens = new CGM_Token_Manager( get_current_user_id() );

		try {
			$provider = (string) get_option( 'contentgem_ai_provider', 'claude' );
			$provider_key = 'openai' === $provider ? (string) get_option( 'contentgem_openai_api_key', '' ) : (string) get_option( 'contentgem_claude_api_key', (string) get_option( 'contentgem_api_key', '' ) );
			if ( '' === $provider_key ) { $provider_key = (string) get_option( 'contentgem_api_key', '' ); }
			$client = new CGM_Claude_Client( $provider_key );
			$result = $client->suggest_clusters( $niche, $description );
			$tokens->deduct( $result['tokens_used'] );
			$clusters = array_slice( $this->normalise_cluster_list( (array) ( $result['clusters'] ?? [] ) ), 0, 8 );
			return rest_ensure_response( [ 'clusters' => $clusters ] );
		} catch ( \Throwable $e ) {
			$this->release_free_generation_slot( get_current_user_id() );
			if ( strpos( $e->getMessage(), 'No API key' ) === 0 ) {
				return new WP_Error( 'no_api_key', __( 'Add your Anthropic API key in Settings first.', 'contentgem' ), [ 'status' => 422 ] );
			}
			return new WP_Error( 'suggest_clusters_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_settings_suggest_single_cluster( WP_REST_Request $request ) {
		$body        = $request->get_json_params();
		$niche       = sanitize_text_field( $body['niche'] ?? '' ) ?: (string) get_option( 'contentgem_niche', '' );
		$description = sanitize_text_field( $body['description'] ?? '' ) ?: (string) get_option( 'contentgem_niche_description', '' );
		$existing    = $this->get_saved_clusters();
		if ( empty( $niche ) ) {
			return new WP_Error( 'no_niche', __( 'Set your niche first.', 'contentgem' ), [ 'status' => 400 ] );
		}

		// Don't burn an AI call if the user already hit their cluster cap —
		// the suggestion would be unusable (save would fail).
		$cap_check = $this->maybe_reject_cluster_overflow( count( $existing ) + 1 );
		if ( is_wp_error( $cap_check ) ) {
			return $cap_check;
		}

		$signature = $this->get_cluster_suggestion_signature( $niche, $description, $existing );
		$state     = $this->get_cluster_suggestion_state();
		if ( (string) ( $state['signature'] ?? '' ) !== $signature ) {
			$state = [
				'signature' => $signature,
				'queue'     => [],
				'history'   => [],
			];
		}

		$queue   = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $state['queue'] ?? [] ) ) ) );
		$history = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $state['history'] ?? [] ) ) ) );

		try {
			if ( empty( $queue ) ) {
				$queue = $this->build_single_cluster_suggestion_pool( $niche, $description, $existing, $history );
				if ( empty( $queue ) && ! empty( $history ) ) {
					$history = [];
					$queue   = $this->build_single_cluster_suggestion_pool( $niche, $description, $existing, $history );
				}
			}

			$cluster = sanitize_text_field( (string) array_shift( $queue ) );
			if ( '' === $cluster ) {
				return new WP_Error( 'no_cluster', __( 'Could not generate a cluster suggestion.', 'contentgem' ), [ 'status' => 500 ] );
			}

			$history[] = $cluster;
			$history   = array_slice( array_values( array_unique( $history ) ), -30 );
			$this->save_cluster_suggestion_state( [
				'signature' => $signature,
				'queue'     => array_values( array_unique( $queue ) ),
				'history'   => $history,
			] );

			return rest_ensure_response( [
				'cluster'            => $cluster,
				'queued_suggestions' => count( $queue ),
				'history'            => $history,
			] );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'suggest_cluster_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_settings_clusters( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$raw  = $body['clusters'] ?? [];
		$replace = ! empty( $body['replace'] );

		if ( ! is_array( $raw ) ) {
			return new WP_Error( 'invalid_clusters', __( 'Invalid format.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$existing = $this->get_saved_clusters();
		$incoming = $this->normalise_cluster_list( $raw );

		// Enforce plan cluster cap before touching any persistence.
		$merged_preview = $replace ? $incoming : array_values( array_unique( array_merge( $existing, $incoming ) ) );
		$cap_check      = $this->maybe_reject_cluster_overflow( count( $merged_preview ) );
		if ( is_wp_error( $cap_check ) ) {
			return $cap_check;
		}

		$this->save_cluster_snapshot( $existing, 'manual_update' );
		$clusters = $this->persist_clusters( $replace ? $incoming : array_merge( $existing, $incoming ), $replace );

		$cluster_terms = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_terms = is_array( $cluster_terms ) ? $cluster_terms : [];

		return rest_ensure_response( [ 'success' => true, 'clusters' => $clusters, 'terms' => $cluster_terms ] );
	}

	public function post_settings_auto_detect_clusters( WP_REST_Request $request ) {
		$detected = $this->detect_existing_clusters();
		$existing = $this->get_saved_clusters();
		$body = $request->get_json_params();
		$replace = ! empty( $body['replace'] );

		$merged_preview = $replace ? $detected : array_values( array_unique( array_merge( $existing, $detected ) ) );
		$cap_check      = $this->maybe_reject_cluster_overflow( count( $merged_preview ) );
		if ( is_wp_error( $cap_check ) ) {
			return $cap_check;
		}

		$this->save_cluster_snapshot( $existing, 'auto_detect' );
		$clusters = $this->persist_clusters( $replace ? $detected : array_merge( $existing, $detected ), $replace );

		return rest_ensure_response( [
			'success'           => true,
			'detected_clusters' => $detected,
			'clusters'          => $clusters,
			'can_revert'        => ! empty( $existing ),
			'mode'              => $replace ? 'replace' : 'merge',
		] );
	}

	public function post_settings_revert_clusters( WP_REST_Request $request ) {
		$snapshot = $this->get_cluster_snapshot();
		if ( empty( $snapshot ) ) {
			return new WP_Error( 'no_snapshot', __( 'No previous cluster state available to revert.', 'contentgem' ), [ 'status' => 400 ] );
		}

		// A revert operation could restore a snapshot that was taken before
		// the user downgraded — that snapshot can legally exceed the current
		// plan cap. Truncate to cap on revert so we never leave Free users
		// in an over-cap state that would then block further saves.
		$limit = function_exists( 'cgm_get_limit' ) ? (int) cgm_get_limit( 'clusters' ) : -1;
		if ( $limit >= 0 && count( $snapshot ) > $limit ) {
			$snapshot = array_slice( $snapshot, 0, $limit );
		}

		$current = $this->get_saved_clusters();
		$this->save_cluster_snapshot( $current, 'pre_revert_current' );
		$clusters = $this->persist_clusters( $snapshot, true );
		return rest_ensure_response( [
			'success'  => true,
			'clusters' => $clusters,
			'message'  => __( 'Clusters reverted to the previous state.', 'contentgem' ),
		] );
	}

	// - Pillar Pages ----------------------------â"€

	/**
	 * GET /pillar-pages
	 *
	 * Returns all clusters with:
	 *  - their posts (id + title)
	 *  - which post is currently the pillar (post meta _cgm_is_pillar)
	 */
	public function get_pillar_pages( WP_REST_Request $request ): WP_REST_Response {
		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		if ( ! is_array( $clusters ) || empty( $clusters ) ) {
			return rest_ensure_response( [ 'clusters' => [], 'pillar_owner_map' => [] ] );
		}

		$raw_pillar_map = (array) get_option( 'contentgem_pillar_pages', [] );
		$pillar_map = [];
		foreach ( $raw_pillar_map as $cluster_name => $raw_ids ) {
			$ids = is_array( $raw_ids ) ? $raw_ids : [ $raw_ids ];
			$ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
			$pillar_map[ sanitize_text_field( (string) $cluster_name ) ] = isset( $ids[0] ) ? [ (int) $ids[0] ] : [];
		}
		if ( $pillar_map !== $raw_pillar_map ) {
			update_option( 'contentgem_pillar_pages', $pillar_map, false );
		}
		$cluster_keywords = get_option( 'cgm_cluster_keywords', [] );
		$cluster_keywords = is_array( $cluster_keywords ) ? $cluster_keywords : [];
		$result = [];
		$pillar_owner_map = [];

		foreach ( $pillar_map as $cluster_name => $raw_ids ) {
			$ids = is_array( $raw_ids ) ? $raw_ids : [ $raw_ids ];
			$ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
			if ( isset( $ids[0] ) ) {
				$pillar_owner_map[ (int) $ids[0] ] = sanitize_text_field( (string) $cluster_name );
			}
		}

		foreach ( $clusters as $cluster_name ) {
			$cluster_name = sanitize_text_field( $cluster_name );
			$posts_in_cluster = [];
			$cat = get_term_by( 'name', $cluster_name, 'category' );
			if ( $cat ) {
				$wp_posts = get_posts( [
					'numberposts' => -1,
					'post_status' => [ 'publish', 'draft', 'private', 'pending', 'future' ],
					'post_type'   => [ 'post', 'page' ],
					'category'    => $cat->term_id,
					'orderby'     => 'title',
					'order'       => 'ASC',
				] );
				foreach ( $wp_posts as $p ) {
					$posts_in_cluster[ (int) $p->ID ] = [
						'id'        => (int) $p->ID,
						'title'     => $p->post_title,
						'url'       => get_permalink( $p->ID ),
						'post_type' => $p->post_type,
						'is_pillar' => (bool) get_post_meta( $p->ID, '_cgm_is_pillar', true ),
					];
				}
			}

			$meta_posts = get_posts( [
				'numberposts' => -1,
				'post_status' => [ 'publish', 'draft', 'private', 'pending', 'future' ],
				'post_type'   => [ 'post', 'page' ],
				'meta_key'    => '_cgm_cluster',
				'meta_value'  => $cluster_name,
				'orderby'     => 'title',
				'order'       => 'ASC',
			] );
			foreach ( $meta_posts as $p ) {
				$posts_in_cluster[ (int) $p->ID ] = [
					'id'        => (int) $p->ID,
					'title'     => $p->post_title,
					'url'       => get_permalink( $p->ID ),
					'post_type' => $p->post_type,
					'is_pillar' => (bool) get_post_meta( $p->ID, '_cgm_is_pillar', true ),
				];
			}

			$raw_pillar = $pillar_map[ $cluster_name ] ?? [];
			$pillar_ids = is_array( $raw_pillar ) ? $raw_pillar : [ $raw_pillar ];
			$pillar_ids = array_values( array_filter( array_unique( array_map( 'absint', $pillar_ids ) ) ) );
			$current_pillar_id = (int) ( $pillar_ids[0] ?? 0 );

			if ( $current_pillar_id > 0 ) {
				$post_obj = get_post( $current_pillar_id );
				$post_belongs = isset( $posts_in_cluster[ $current_pillar_id ] );
				if ( ! $post_belongs && $post_obj instanceof WP_Post && in_array( $post_obj->post_type, [ 'post', 'page' ], true ) ) {
					$post_belongs = true;
					$posts_in_cluster[ $current_pillar_id ] = [
						'id'        => (int) $post_obj->ID,
						'title'     => $post_obj->post_title,
						'url'       => (string) get_permalink( $post_obj->ID ),
						'post_type' => $post_obj->post_type,
						'is_pillar' => true,
					];
				}
				if ( ! $post_belongs || ! ( $post_obj instanceof WP_Post ) || 'trash' === get_post_status( $current_pillar_id ) || 'auto-draft' === get_post_status( $current_pillar_id ) ) {
					$current_pillar_id = 0;
					$pillar_ids = [];
					unset( $pillar_map[ $cluster_name ] );
				}
			}

			$result[] = [
				'cluster_name'      => $cluster_name,
				'keywords'          => array_values( array_filter( (array) ( $cluster_keywords[ $cluster_name ] ?? [] ) ) ),
				'posts'             => array_values( $posts_in_cluster ),
				'current_pillar_id' => $current_pillar_id,
				'pillar_ids'        => $pillar_ids,
			];
		}

		update_option( 'contentgem_pillar_pages', $pillar_map, false );
		return rest_ensure_response( [ 'clusters' => $result, 'pillar_owner_map' => $pillar_owner_map ] );
	}

	/**
	 * POST /pillar-pages
	 *
	 * Saves the pillar page assignment per cluster.
	 * Body: { "pillar_pages": { "ClusterName": post_id, ... } }
	 */
	public function post_pillar_pages( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) { $body = []; }
		$pillar_input = [];
		if ( isset( $body['pillar_pages'] ) && is_array( $body['pillar_pages'] ) ) {
			$pillar_input = (array) $body['pillar_pages'];
		} elseif ( isset( $body['cluster_name'] ) ) {
			$pillar_input = [ (string) $body['cluster_name'] => ( $body['post_id'] ?? 0 ) ];
		} else {
			$pillar_input = (array) $body;
		}

		$pillar_map = (array) get_option( 'contentgem_pillar_pages', [] );
		$clusters   = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		if ( ! is_array( $clusters ) ) {
			$clusters = [];
		}

		$normalized_existing = [];
		$used_posts = [];
		foreach ( $pillar_map as $existing_cluster => $raw_ids ) {
			$existing_cluster = sanitize_text_field( (string) $existing_cluster );
			$ids = is_array( $raw_ids ) ? $raw_ids : [ $raw_ids ];
			$ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
			$normalized_existing[ $existing_cluster ] = isset( $ids[0] ) ? [ (int) $ids[0] ] : [];
			if ( isset( $ids[0] ) ) {
				$used_posts[ (int) $ids[0] ] = $existing_cluster;
			}
		}
		$pillar_map = $normalized_existing;

		$updated = [];
		$conflicts = [];

		foreach ( $pillar_input as $cluster_name => $post_id_raw ) {
			$cluster_name = sanitize_text_field( (string) $cluster_name );
			if ( ! in_array( $cluster_name, $clusters, true ) ) {
				$clusters[] = $cluster_name;
			}

			$ids = is_array( $post_id_raw ) ? $post_id_raw : [ $post_id_raw ];
			$ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
			if ( count( $ids ) > 1 ) {
				$ids = [ (int) $ids[0] ];
			}
			$post_id = (int) ( $ids[0] ?? 0 );

			if ( $post_id > 0 ) {
				$belongs = false;
				$cat = get_term_by( 'name', $cluster_name, 'category' );
				if ( $cat && has_term( (int) $cat->term_id, 'category', $post_id ) ) {
					$belongs = true;
				}
				if ( ! $belongs ) {
					$post_cluster = (string) get_post_meta( $post_id, '_cgm_cluster', true );
					$belongs = ( $post_cluster === $cluster_name );
				}
				if ( ! $belongs ) {
					update_post_meta( $post_id, '_cgm_cluster', $cluster_name );
				}
				if ( isset( $used_posts[ $post_id ] ) && $used_posts[ $post_id ] !== $cluster_name ) {
					$conflicts[ $post_id ] = [ 'from' => $used_posts[ $post_id ], 'to' => $cluster_name ];
					return new WP_Error( 'pillar_conflict', 'This page is already selected as pillar in another cluster.', [ 'status' => 409, 'conflicts' => $conflicts ] );
				}
				$pillar_map[ $cluster_name ] = [ $post_id ];
				$used_posts[ $post_id ] = $cluster_name;
				update_post_meta( $post_id, '_cgm_is_pillar', '1' );
				update_post_meta( $post_id, '_cgm_cluster', $cluster_name );
			} else {
				unset( $pillar_map[ $cluster_name ] );
			}

			$updated[] = $cluster_name;
		}

		$active_pillar_ids = [];
		foreach ( $pillar_map as $cluster_name => $ids ) {
			$ids = is_array( $ids ) ? $ids : [ $ids ];
			$ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
			$pillar_map[ $cluster_name ] = $ids;
			foreach ( $ids as $pid ) {
				$active_pillar_ids[ $pid ] = true;
			}
		}

		$previous_pillars = get_posts( [
			'numberposts' => -1,
			'post_status' => 'publish',
			'post_type'   => [ 'post', 'page' ],
			'meta_key'    => '_cgm_is_pillar',
			'meta_value'  => '1',
		] );
		foreach ( $previous_pillars as $p ) {
			if ( ! isset( $active_pillar_ids[ (int) $p->ID ] ) ) {
				delete_post_meta( (int) $p->ID, '_cgm_is_pillar' );
			}
		}

		update_option( 'contentgem_pillar_pages', $pillar_map, false );
		update_option( 'contentgem_clusters', wp_json_encode( array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $clusters ) ) ) ) ) );

		return rest_ensure_response( [
			'success'      => true,
			'updated'      => $updated,
			'pillar_pages' => $pillar_map,
		] );
	}

// - IndexNow -------------------------------

	public function get_indexnow_status( WP_REST_Request $request ): WP_REST_Response {
		return rest_ensure_response( CGM_IndexNow::get_status() );
	}

	public function post_indexnow_ping( WP_REST_Request $request ) {
		$url = sanitize_url( (string) ( $request->get_json_params()['url'] ?? '' ) );
		if ( empty( $url ) ) {
			return new WP_Error( 'missing_url', 'URL is required.', [ 'status' => 400 ] );
		}
		$success = CGM_IndexNow::manual_ping( $url );
		return rest_ensure_response( [ 'success' => $success, 'url' => $url ] );
	}

	public function post_indexnow_regenerate_key( WP_REST_Request $request ): WP_REST_Response {
		$key = CGM_IndexNow::regenerate_key();
		return rest_ensure_response( [
			'success'  => true,
			'key_url'  => rtrim( home_url( '/' ), '/' ) . '/' . $key . '.txt',
		] );
	}






	public function post_internal_links_preview( WP_REST_Request $request ): WP_REST_Response {
		$body         = $request->get_json_params();
		$scope        = sanitize_text_field( $body['scope'] ?? 'published' );
		$cluster      = sanitize_text_field( $body['cluster'] ?? '' );
		$content_type = sanitize_key( (string) ( $body['content_type'] ?? 'post' ) );
		if ( ! in_array( $content_type, [ 'post', 'page' ], true ) ) {
			$content_type = 'post';
		}

		$post_status = ( 'published' === $scope ) ? [ 'publish' ] : [ 'draft', 'pending', 'future', 'private' ];
		$posts = get_posts( [
			'numberposts' => -1,
			'post_status' => $post_status,
			'post_type'   => [ $content_type ],
		] );

		$scanner = new CGM_Link_Scanner();
		$diag = new CGM_Reinsert_Diagnostic_Service( $scanner );
		$summary = [
			'posts_affected'  => 0,
			'posts_to_update' => 0,
			'links_to_remove' => 0,
			'links_to_insert' => 0,
			'net_change'      => 0,
			'skipped'         => 0,
		];
		$changes = [];
		$items   = [];
		$cluster_resolver = new ReflectionMethod( $scanner, 'get_post_cluster' );
		$cluster_resolver->setAccessible( true );

		foreach ( $posts as $post ) {
			$source = $diag->detect_content_source( (int) $post->ID );
			$post_cluster = (string) $cluster_resolver->invoke( $scanner, (int) $post->ID );
			if ( $cluster && $post_cluster !== $cluster ) {
				continue;
			}
			if ( '' === $post_cluster ) {
				$summary['skipped']++;
				$changes[] = [
					'post_id' => (int) $post->ID,
					'title' => (string) $post->post_title,
					'cluster' => '',
					'links_to_remove' => 0,
					'links_to_add' => 0,
					'new_links' => [],
					'source_type' => $source['source'],
					'supported' => false,
					'skip_reason' => 'No resolvable cluster',
				];
				continue;
			}
			if ( empty( $source['supported'] ) ) {
				$summary['skipped']++;
				$changes[] = [
					'post_id' => (int) $post->ID,
					'title' => (string) $post->post_title,
					'cluster' => $post_cluster,
					'links_to_remove' => 0,
					'links_to_add' => 0,
					'new_links' => [],
					'source_type' => $source['source'],
					'supported' => false,
					'skip_reason' => (string) $source['reason'],
				];
				continue;
			}

			$estimate = $diag->estimate_insertable_targets_for_post( (int) $post->ID, 6 );
			$new_links = (array) ( $estimate['links'] ?? [] );
			$before = $diag->get_content_snapshot( (int) $post->ID );
			$remove_candidates = count( (array) ( $before['internal_links_body_only'] ?? [] ) );
			$links_to_add = (int) ( $estimate['count'] ?? 0 );
			if ( $links_to_add <= 0 ) {
				$summary['skipped']++;
				$changes[] = [
					'post_id' => (int) $post->ID,
					'title' => (string) $post->post_title,
					'cluster' => $post_cluster,
					'links_to_remove' => $remove_candidates,
					'links_to_add' => 0,
					'new_links' => [],
					'source_type' => $source['source'],
					'supported' => true,
					'skip_reason' => 'No valid targets found',
				];
				continue;
			}

			$summary['posts_affected']++;
			$summary['posts_to_update']++;
			$summary['links_to_insert'] += $links_to_add;
			$summary['links_to_remove'] += $remove_candidates;
			$change = [
				'post_id'         => (int) $post->ID,
				'title'           => (string) $post->post_title,
				'cluster'         => $post_cluster,
				'links_to_remove' => $remove_candidates,
				'links_to_add'    => $links_to_add,
				'new_links'       => $new_links,
				'source_type'     => $source['source'],
				'supported'       => true,
				'skip_reason'     => '',
			];
			$changes[] = $change;
			$items[]   = [
				'post_id' => (int) $post->ID,
				'title' => (string) $post->post_title,
				'cluster' => $post_cluster,
				'suggestions' => $new_links,
				'source_type' => $source['source'],
				'supported' => true,
			];
		}

		$summary['net_change'] = $summary['links_to_insert'] - $summary['links_to_remove'];
		return rest_ensure_response( [
			'summary' => $summary,
			'changes' => $changes,
			'items'   => $items,
		] );
	}
	private function cgm_count_internal_links( string $content ): int {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $host ) {
			return 0;
		}
		preg_match_all( "#href=['\"]([^'\"#]+)['\"]#i", $content, $matches );
		$urls = (array) ( $matches[1] ?? [] );
		$count = 0;
		foreach ( $urls as $url ) {
			$url_host = wp_parse_url( $url, PHP_URL_HOST );
			if ( $url_host && strtolower( (string) $url_host ) === strtolower( (string) $host ) ) {
				$count++;
			}
		}
		return $count;
	}

	private function cgm_strip_internal_links( string $content ): string {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $host || '' === $content ) {
			return $content;
		}
		$pattern = "#<a\b[^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>#is";
		$stripped = preg_replace_callback(
			$pattern,
			function( $m ) use ( $host ) {
				$url = (string) ( $m[1] ?? '' );
				$text = (string) ( $m[2] ?? '' );
				$url_host = wp_parse_url( $url, PHP_URL_HOST );
				if ( $url_host && strtolower( (string) $url_host ) === strtolower( (string) $host ) ) {
					return wp_strip_all_tags( $text );
				}
				return $m[0];
			},
			$content
		);
		return is_string( $stripped ) ? $stripped : $content;
	}


	private function cgm_get_or_create_cluster_category_id( string $cluster ): int {
		$cluster = trim( wp_strip_all_tags( $cluster ) );
		if ( '' === $cluster ) {
			return 0;
		}
		$exists = term_exists( $cluster, 'category' );
		if ( is_array( $exists ) && ! empty( $exists['term_id'] ) ) {
			return (int) $exists['term_id'];
		}
		if ( is_int( $exists ) ) {
			return (int) $exists;
		}
		$created = wp_insert_term( $cluster, 'category' );
		if ( is_wp_error( $created ) ) {
			return 0;
		}
		return (int) ( $created['term_id'] ?? 0 );
	}



	public function post_internal_links_apply( WP_REST_Request $request ): WP_REST_Response {
		// Prevent timeout: increase execution time for bulk operations
		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 300 ); // 5 minutes for bulk processing
		}
		
		// Reduce memory pressure
		wp_cache_flush();
		
		$body    = $request->get_json_params();
		$scope   = sanitize_text_field( $body['scope'] ?? 'published' );
		$cluster = sanitize_text_field( $body['cluster'] ?? '' );

		$preview_request = new WP_REST_Request( 'POST', '/' );
		$preview_request->set_body( wp_json_encode( [ 'scope' => $scope, 'cluster' => $cluster, 'content_type' => 'post' ] ) );
		$preview_request->set_header( 'content-type', 'application/json' );
		$preview = $this->post_internal_links_preview( $preview_request );
		$data    = $preview->get_data();
		$diag    = new CGM_Reinsert_Diagnostic_Service( new CGM_Link_Scanner() );

		$posts_updated    = 0;
		$links_inserted   = 0;
		$links_removed    = 0;
		$updated_post_ids = [];
		$skipped          = [];
		$failed           = [];
		$partials         = [];

		$changes = (array) ( $data['changes'] ?? [] );
		$total   = count( $changes );
		$batch   = 0;

		foreach ( $changes as $item ) {
			$batch++;
			$post_id = (int) ( $item['post_id'] ?? 0 );
			if ( ! $post_id ) { continue; }
			
			$result = $diag->apply_single_post_reinsert( $post_id );
			$status = (string) ( $result['status'] ?? 'failed' );
			
			if ( 'success' === $status ) {
				$posts_updated++;
				$links_inserted += (int) ( $result['links_inserted'] ?? 0 );
				$links_removed += (int) ( $result['links_removed'] ?? 0 );
				$updated_post_ids[] = $post_id;
			} elseif ( 'partial' === $status ) {
				$partials[] = $result;
			} elseif ( 'skipped' === $status ) {
				$skipped[] = $result;
			} else {
				$failed[] = $result;
			}
			
			// Cleanup every 5 posts to prevent memory buildup
			if ( 0 === ( $batch % 5 ) ) {
				wp_cache_flush();
				// Clear object cache
				if ( function_exists( 'wp_cache_flush_group' ) ) {
					wp_cache_flush_group( 'posts' );
				}
			}
		}

		// Final cleanup
		wp_cache_flush();

		return rest_ensure_response( [
			'success'          => $posts_updated > 0,
			'posts_updated'    => $posts_updated,
			'links_inserted'   => $links_inserted,
			'links_removed'    => $links_removed,
			'updated_post_ids' => $updated_post_ids,
			'skipped'          => $skipped,
			'failed'           => $failed,
			'partials'         => $partials,
			'message'          => $posts_updated > 0 ? __( 'Internal links were reinserted successfully.', 'contentgem' ) : __( 'No supported posts were updated.', 'contentgem' ),
		] );
	}

	public function post_internal_links_diagnose_post( WP_REST_Request $request ): WP_REST_Response {
		$post_id = absint( (int) $request->get_param( 'post_id' ) );
		$diag = new CGM_Reinsert_Diagnostic_Service( new CGM_Link_Scanner() );
		return rest_ensure_response( $diag->apply_single_post_reinsert( $post_id ) );
	}

	public function get_competitor_insights( WP_REST_Request $request ): WP_REST_Response {
		$cluster = sanitize_text_field( $request->get_param( 'cluster' ) );
		if ( empty( $cluster ) ) {
			return rest_ensure_response( [ 'insights' => '' ] );
		}
		$insights = $this->get_competitor_insights_for_cluster( $cluster );
		return rest_ensure_response( [ 'insights' => $insights, 'cluster' => $cluster ] );
	}

	public function get_competitor_history( WP_REST_Request $request ): WP_REST_Response {
		$cluster = sanitize_text_field( (string) $request->get_param( 'cluster' ) );
		$cluster_key = '' !== $cluster ? $this->normalize_competitor_cluster_key( $cluster ) : '';
		$grouped = $this->get_grouped_competitor_history();
		$items = $this->flatten_grouped_competitor_history( $grouped, $cluster_key );
		$latest = get_option( 'contentgem_latest_competitor_analysis', [] );
		if ( is_array( $latest ) && ! empty( $latest ) ) {
			$latest_entry = isset( $latest['competitors'], $latest['gaps'] ) ? $this->make_competitor_history_entry( $latest ) : $latest;
			if ( is_array( $latest_entry ) && ! empty( $latest_entry ) ) {
				$latest_cluster_key = (string) ( $latest_entry['cluster_key'] ?? $this->normalize_competitor_cluster_key( (string) ( $latest_entry['cluster'] ?? '' ) ) );
				$matches_filter = '' === $cluster_key || $latest_cluster_key === $cluster_key;
				if ( $matches_filter ) {
					$latest_id = (string) ( $latest_entry['id'] ?? '' );
					$exists = false;
					foreach ( $items as $item ) { if ( $latest_id !== '' && (string) ( $item['id'] ?? '' ) === $latest_id ) { $exists = true; break; } }
					if ( ! $exists ) { array_unshift( $items, $latest_entry ); }
				}
			}
		}
		$items = array_slice( $items, 0, 50 );
		$items = array_map( function( array $item ): array {
			if ( ! empty( $item['captured_at'] ) ) {
				$timestamp = strtotime( (string) $item['captured_at'] );
				if ( $timestamp ) { $item['captured_at_human'] = wp_date( 'Y-m-d H:i', $timestamp ); }
			}
			return $item;
		}, $items );
		return rest_ensure_response( [ 'items' => $items, 'cluster' => $cluster, 'cluster_key' => $cluster_key ] );
	}

	public function post_competitor_history_clear( WP_REST_Request $request ): WP_REST_Response {
		$cluster = sanitize_text_field( (string) $request->get_param( 'cluster' ) );
		if ( '' === $cluster ) {
			delete_option( 'contentgem_competitor_history' );
			delete_option( 'contentgem_competitor_history_by_cluster' );
			delete_option( 'contentgem_latest_competitor_analysis' );
			delete_option( 'contentgem_latest_competitor_analysis_by_cluster' );
			return rest_ensure_response( [ 'success' => true ] );
		}
		$cluster_key = $this->normalize_competitor_cluster_key( $cluster );
		$grouped = $this->get_grouped_competitor_history();
		unset( $grouped[ $cluster_key ] );
		$this->persist_grouped_competitor_history( $grouped );
		$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
		$latest_by_cluster = is_array( $latest_by_cluster ) ? $latest_by_cluster : [];
		unset( $latest_by_cluster[ $cluster_key ] );
		update_option( 'contentgem_latest_competitor_analysis_by_cluster', $latest_by_cluster, false );
		return rest_ensure_response( [ 'success' => true, 'cluster_key' => $cluster_key ] );
	}

	public function post_competitor_history_delete( WP_REST_Request $request ): WP_REST_Response {
		$id = sanitize_text_field( (string) $request->get_param( 'id' ) );
		if ( '' === $id ) {
			return new WP_Error( 'missing_id', __( 'Missing report id.', 'contentgem' ), [ 'status' => 400 ] );
		}
		$grouped = $this->get_grouped_competitor_history();
		foreach ( $grouped as $cluster_key => $items ) {
			$grouped[ $cluster_key ] = array_values( array_filter( (array) $items, static function( array $item ) use ( $id ): bool {
				return (string) ( $item['id'] ?? '' ) !== $id;
			} ) );
		}
		$this->persist_grouped_competitor_history( $grouped );
		$latest = get_option( 'contentgem_latest_competitor_analysis', [] );
		if ( is_array( $latest ) && (string) ( $latest['id'] ?? '' ) === $id ) { delete_option( 'contentgem_latest_competitor_analysis' );
			delete_option( 'contentgem_latest_competitor_analysis_by_cluster' ); }
		return rest_ensure_response( [ 'success' => true, 'items' => $this->flatten_grouped_competitor_history( $grouped ) ] );
	}


	private function normalize_competitor_cluster_key( string $cluster ): string {
		$cluster = sanitize_text_field( $cluster );
		if ( '' === $cluster ) {
			return '_unclustered';
		}
		$key = sanitize_title( $cluster );
		return '' !== $key ? $key : md5( strtolower( $cluster ) );
	}

	private function get_grouped_competitor_history(): array {
		$grouped = get_option( 'contentgem_competitor_history_by_cluster', [] );
		if ( is_array( $grouped ) && ! empty( $grouped ) ) {
			return $grouped;
		}
		$legacy = get_option( 'contentgem_competitor_history', [] );
		$legacy = is_array( $legacy ) ? array_values( array_filter( $legacy, 'is_array' ) ) : [];
		$grouped = [];
		foreach ( $legacy as $item ) {
			$cluster_key = $this->normalize_competitor_cluster_key( (string) ( $item['cluster'] ?? '' ) );
			if ( ! isset( $grouped[ $cluster_key ] ) ) {
				$grouped[ $cluster_key ] = [];
			}
			$grouped[ $cluster_key ][] = $item;
		}
		update_option( 'contentgem_competitor_history_by_cluster', $grouped, false );
		return $grouped;
	}

	private function flatten_grouped_competitor_history( array $grouped, string $cluster_key = '' ): array {
		if ( '' !== $cluster_key ) {
			return array_values( array_filter( (array) ( $grouped[ $cluster_key ] ?? [] ), 'is_array' ) );
		}
		$flat = [];
		foreach ( $grouped as $items ) {
			foreach ( (array) $items as $item ) {
				if ( is_array( $item ) ) {
					$flat[] = $item;
				}
			}
		}
		usort( $flat, static function( array $a, array $b ): int {
			return strtotime( (string) ( $b['captured_at'] ?? '' ) ) <=> strtotime( (string) ( $a['captured_at'] ?? '' ) );
		} );
		return array_values( $flat );
	}

	private function persist_grouped_competitor_history( array $grouped ): void {
		update_option( 'contentgem_competitor_history_by_cluster', $grouped, false );
		update_option( 'contentgem_competitor_history', $this->flatten_grouped_competitor_history( $grouped ), false );
	}

	private function get_site_structure_page_id_map(): array {
		$targets = $this->get_site_structure_link_targets();
		$map = [];
		foreach ( $targets as $target ) {
			$page_id = (int) ( $target['page_id'] ?? 0 );
			if ( $page_id > 0 ) {
				$map[ $page_id ] = [
					'title' => (string) ( $target['title'] ?? '' ),
					'type' => (string) ( $target['type'] ?? 'page' ),
					'priority' => (int) ( $target['priority'] ?? 60 ),
				];
			}
		}
		return $map;
	}

	private function build_competitor_meta_summary( array $items, string $cluster = '' ): array {
		$rows = array_values( array_filter( $items, 'is_array' ) );
		$normalized_cluster = strtolower( trim( $cluster ) );
		if ( '' !== $normalized_cluster ) {
			$rows = array_values( array_filter( $rows, static function( array $item ) use ( $normalized_cluster ): bool {
				return strtolower( trim( (string) ( $item['cluster'] ?? '' ) ) ) === $normalized_cluster;
			} ) );
		}
		$competitors = [];
		$topics = [];
		$actions = [];
		$total_gaps = 0;
		$critical_gaps = 0;
		$total_avg_words = 0;
		$avg_words_count = 0;
		foreach ( $rows as $item ) {
			$total_gaps += absint( $item['gap_count'] ?? ( is_array( $item['gaps'] ?? null ) ? count( (array) $item['gaps'] ) : 0 ) );
			$critical_gaps += absint( $item['critical_gap_count'] ?? 0 );
			$avg_words = absint( $item['avg_words'] ?? 0 );
			if ( $avg_words > 0 ) { $total_avg_words += $avg_words; $avg_words_count++; }
			foreach ( (array) ( $item['competitors'] ?? [] ) as $comp ) {
				if ( ! is_array( $comp ) ) { continue; }
				$host = sanitize_text_field( (string) ( $comp['host'] ?? $comp['url'] ?? '' ) );
				if ( '' === $host ) { continue; }
				$competitors[ $host ] = ( $competitors[ $host ] ?? 0 ) + 1;
			}
			foreach ( (array) ( $item['common_h2s'] ?? [] ) as $h2 ) {
				$h2 = sanitize_text_field( (string) $h2 );
				if ( '' === $h2 ) { continue; }
				$topics[ $h2 ] = ( $topics[ $h2 ] ?? 0 ) + 1;
			}
			foreach ( (array) ( $item['recommendations'] ?? [] ) as $rec ) {
				$action = '';
				if ( is_array( $rec ) ) {
					$action = sanitize_text_field( (string) ( $rec['action'] ?? $rec['description'] ?? '' ) );
				} elseif ( is_string( $rec ) ) {
					$action = sanitize_text_field( $rec );
				}
				if ( '' === $action ) { continue; }
				$actions[ $action ] = ( $actions[ $action ] ?? 0 ) + 1;
			}
		}
		arsort( $competitors );
		arsort( $topics );
		arsort( $actions );
		return [
			'cluster' => $cluster,
			'reports' => count( $rows ),
			'totalGaps' => $total_gaps,
			'criticalGaps' => $critical_gaps,
			'avgWords' => $avg_words_count ? (int) round( $total_avg_words / max( 1, $avg_words_count ) ) : 0,
			'competitors' => array_slice( array_keys( $competitors ), 0, 5 ),
			'topics' => array_slice( array_keys( $topics ), 0, 8 ),
			'actions' => array_slice( array_keys( $actions ), 0, 6 ),
		];
	}


	private function make_competitor_history_entry( array $latest_report ): array {
		$competitors = array_values( array_filter( (array) ( $latest_report['competitors'] ?? [] ), 'is_array' ) );
		$gaps        = array_values( array_filter( (array) ( $latest_report['gaps'] ?? [] ), 'is_array' ) );
		$raw_recs    = (array) ( $latest_report['recommendations'] ?? [] );
		$detail_recs = (array) ( $latest_report['detailed_recommendations'] ?? [] );
		$recs        = array_values( array_filter( array_merge( $detail_recs, $raw_recs ), function( $rec ) { return is_array( $rec ) || is_string( $rec ); } ) );
		$avg_words   = 0;

		$clean_competitors = array_map( function( array $comp ): array {
			$url = esc_url_raw( (string) ( $comp['url'] ?? '' ) );
			$host = wp_parse_url( $url, PHP_URL_HOST );
			return [
				'url'        => $url,
				'host'       => is_string( $host ) ? strtolower( preg_replace( '/^www\./', '', $host ) ) : '',
				'title'      => sanitize_text_field( (string) ( $comp['title'] ?? '' ) ),
				'word_count' => absint( $comp['word_count'] ?? 0 ),
				'h2_count'   => is_array( $comp['h2s'] ?? null ) ? count( (array) $comp['h2s'] ) : absint( $comp['h2_count'] ?? 0 ),
				'has_faq'    => ! empty( $comp['has_faq'] ),
				'has_table'  => ! empty( $comp['has_table'] ),
				'has_schema' => ! empty( $comp['has_schema'] ),
			];
		}, $competitors );

		if ( ! empty( $clean_competitors ) ) {
			$avg_words = (int) round( array_sum( array_column( $clean_competitors, 'word_count' ) ) / max( 1, count( $clean_competitors ) ) );
		}

		$common_h2s = [];
		foreach ( $competitors as $comp ) {
			foreach ( array_slice( (array) ( $comp['h2s'] ?? [] ), 0, 12 ) as $h2 ) {
				$h2 = sanitize_text_field( (string) $h2 );
				if ( $h2 !== '' ) {
					$common_h2s[ strtolower( $h2 ) ] = $h2;
				}
			}
		}

		$clean_gaps = array_map( function( array $gap ): array {
			return [
				'type'        => sanitize_text_field( (string) ( $gap['type'] ?? '' ) ),
				'severity'    => sanitize_text_field( (string) ( $gap['severity'] ?? '' ) ),
				'description' => sanitize_text_field( (string) ( $gap['description'] ?? '' ) ),
				'action'      => sanitize_text_field( (string) ( $gap['action'] ?? '' ) ),
			];
		}, array_slice( $gaps, 0, 10 ) );

		$clean_recs = array_map( function( $rec ): array {
			if ( is_string( $rec ) ) {
				return [
					'type'        => 'recommendation',
					'severity'    => 'medium',
					'description' => sanitize_text_field( $rec ),
					'action'      => sanitize_text_field( $rec ),
					'benefit'     => '',
				];
			}
			return [
				'type'        => sanitize_text_field( (string) ( $rec['type'] ?? '' ) ),
				'severity'    => sanitize_text_field( (string) ( $rec['severity'] ?? '' ) ),
				'description' => sanitize_text_field( (string) ( $rec['description'] ?? '' ) ),
				'action'      => sanitize_text_field( (string) ( $rec['action'] ?? '' ) ),
				'benefit'     => sanitize_text_field( (string) ( $rec['benefit'] ?? '' ) ),
			];
		}, array_slice( $recs, 0, 12 ) );

		$context_snippets = [];
		foreach ( (array) ( $latest_report['context_snippets'] ?? [] ) as $snippet ) {
			$snippet = sanitize_text_field( (string) $snippet );
			if ( '' !== $snippet ) {
				$context_snippets[] = $snippet;
			}
		}
		if ( empty( $context_snippets ) ) {
			foreach ( $competitors as $comp ) {
				foreach ( array_slice( (array) ( $comp['paragraph_snippets'] ?? [] ), 0, 2 ) as $snippet ) {
					$snippet = sanitize_text_field( (string) $snippet );
					if ( '' !== $snippet ) {
						$context_snippets[] = $snippet;
					}
				}
			}
		}
		$context_snippets = array_values( array_slice( array_unique( $context_snippets ), 0, 8 ) );

		$heading_contexts = [];
		foreach ( (array) ( $latest_report['heading_contexts'] ?? [] ) as $pair ) {
			if ( ! is_array( $pair ) ) {
				continue;
			}
			$heading = sanitize_text_field( (string) ( $pair['heading'] ?? '' ) );
			$context = sanitize_text_field( (string) ( $pair['context'] ?? '' ) );
			$host    = sanitize_text_field( (string) ( $pair['host'] ?? '' ) );
			if ( '' === $heading || '' === $context ) {
				continue;
			}
			$heading_contexts[] = [ 'host' => $host, 'heading' => $heading, 'context' => $context ];
		}
		if ( empty( $heading_contexts ) ) {
			foreach ( $competitors as $comp ) {
				$host = wp_parse_url( (string) ( $comp['url'] ?? '' ), PHP_URL_HOST );
				$host = is_string( $host ) ? strtolower( preg_replace( '/^www\./', '', $host ) ) : '';
				foreach ( array_slice( (array) ( $comp['heading_contexts'] ?? [] ), 0, 2 ) as $pair ) {
					if ( ! is_array( $pair ) ) {
						continue;
					}
					$heading = sanitize_text_field( (string) ( $pair['heading'] ?? '' ) );
					$context = sanitize_text_field( (string) ( $pair['context'] ?? '' ) );
					if ( '' === $heading || '' === $context ) {
						continue;
					}
					$heading_contexts[] = [ 'host' => $host, 'heading' => $heading, 'context' => $context ];
				}
			}
		}
		$heading_contexts = array_values( array_slice( $heading_contexts, 0, 10 ) );

		if ( empty( $clean_recs ) && ! empty( $heading_contexts ) ) {
			foreach ( array_slice( $heading_contexts, 0, 4 ) as $pair ) {
				$clean_recs[] = [
					'type'        => 'contextual_section',
					'severity'    => 'medium',
					'description' => $pair['heading'],
					'action'      => 'Add a dedicated section for "' . $pair['heading'] . '" and explain it with concrete detail like: ' . $pair['context'],
					'benefit'     => 'This mirrors real competitor context while giving you a clearer, more reader-oriented section.',
				];
			}
		}

		$critical_gap_count = count( array_filter( $clean_gaps, function( array $gap ): bool {
			return in_array( $gap['severity'], [ 'high', 'critical' ], true );
		} ) );

		return [
			'id'                 => sanitize_text_field( (string) ( $latest_report['id'] ?? uniqid( 'cgm_comp_', true ) ) ),
			'keyword'            => sanitize_text_field( (string) ( $latest_report['keyword'] ?? '' ) ),
			'cluster'            => sanitize_text_field( (string) ( $latest_report['cluster'] ?? '' ) ),
			'cluster_key'        => $this->normalize_competitor_cluster_key( (string) ( $latest_report['cluster'] ?? '' ) ),
			'captured_at'        => sanitize_text_field( (string) ( $latest_report['captured_at'] ?? gmdate( 'c' ) ) ),
			'gap_count'          => count( $clean_gaps ),
			'critical_gap_count' => $critical_gap_count,
			'avg_words'          => $avg_words,
			'common_h2s'         => array_values( array_slice( $common_h2s, 0, 12 ) ),
			'context_snippets'   => $context_snippets,
			'heading_contexts'   => $heading_contexts,
			'competitors'        => $clean_competitors,
			'gaps'               => $clean_gaps,
			'recommendations'    => $clean_recs,
			'report_summary'     => sanitize_textarea_field( (string) ( $latest_report['report_summary'] ?? '' ) ),
			'your_url'           => esc_url_raw( (string) ( $latest_report['your_page']['url'] ?? '' ) ),
		];
	}

	private function save_competitor_history_entry( array $entry ): void {
		$grouped = $this->get_grouped_competitor_history();
		$cluster_key = (string) ( $entry['cluster_key'] ?? $this->normalize_competitor_cluster_key( (string) ( $entry['cluster'] ?? '' ) ) );
		if ( ! isset( $grouped[ $cluster_key ] ) || ! is_array( $grouped[ $cluster_key ] ) ) {
			$grouped[ $cluster_key ] = [];
		}
		$dedupe_key = strtolower( trim( (string) ( $entry['keyword'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $entry['cluster'] ?? '' ) ) );
		$grouped[ $cluster_key ] = array_values( array_filter( (array) $grouped[ $cluster_key ], static function( array $item ) use ( $dedupe_key ): bool {
			$existing_key = strtolower( trim( (string) ( $item['keyword'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $item['cluster'] ?? '' ) ) );
			return $existing_key !== $dedupe_key;
		} ) );
		array_unshift( $grouped[ $cluster_key ], $entry );
		$grouped[ $cluster_key ] = array_slice( $grouped[ $cluster_key ], 0, 25 );
		$this->persist_grouped_competitor_history( $grouped );
		$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
		$latest_by_cluster = is_array( $latest_by_cluster ) ? $latest_by_cluster : [];
		$latest_by_cluster[ $cluster_key ] = $entry;
		update_option( 'contentgem_latest_competitor_analysis_by_cluster', $latest_by_cluster, false );
		update_option( 'contentgem_latest_competitor_analysis', $entry, false );
	}

	// - AI Assistant ----------------------------â"€


	private function cgm_response_looks_truncated( string $content ): bool {
		$plain = trim( wp_strip_all_tags( $content ) );
		if ( '' === $plain ) return false;
		$tail = mb_substr( $plain, -180 );
		if ( preg_match( '/(?:\b(?:and|or|with|including|because|which|that|en|of|met|omdat|waarbij)\s*)$/iu', $tail ) ) return true;
		if ( preg_match( '/[\,:;\-–—]\s*$/u', $tail ) ) return true;
		if ( preg_match( '/<h[1-6][^>]*>[^<]*$/i', $content ) || preg_match( '/<p[^>]*>[^<]*$/i', $content ) || preg_match( '/<li[^>]*>[^<]*$/i', $content ) ) return true;
		$last = mb_substr( $plain, -1 );
		return ! in_array( $last, [ '.', '!', '?', '”', '"' ], true );
	}


	private function cgm_article_looks_incomplete( string $html ): bool {
		$plain = trim( wp_strip_all_tags( $html ) );
		if ( '' === $plain ) {
			return true;
		}

		if ( $this->cgm_response_looks_truncated( $html ) ) {
			return true;
		}

		$has_conclusion = (bool) preg_match( '/<h2[^>]*>\s*(?:conclusion|final thoughts|samenvatting|conclusie|slot|afsluiting)\b/i', $html );
		$has_faq = (bool) preg_match( '/<h2[^>]*>\s*(?:faq|veelgestelde vragen|frequently asked questions)\b/i', $html );

		return ! $has_conclusion || ! $has_faq;
	}

	private function cgm_finalize_article_ending( string $html, string $topic, string $language = 'English' ): string {
		$html = trim( (string) $html );
		if ( '' === $html ) {
			return $html;
		}

		$is_dutch = in_array( strtolower( $language ), [ 'nl', 'nederlands', 'dutch' ], true );
		if ( ! preg_match( '/<h2[^>]*>\s*(?:conclusion|final thoughts|samenvatting|conclusie|slot|afsluiting)\b/i', $html ) ) {
			$heading = $is_dutch ? 'Conclusie' : 'Conclusion';
			$line = $is_dutch
				? sprintf( 'Dit artikel over %s is afgerond met een korte afsluiting zodat de tekst niet abrupt eindigt.', $topic )
				: sprintf( 'This article about %s has been completed with a concise closing section so it does not end abruptly.', $topic );
			$html .= "\n\n<h2>" . esc_html( $heading ) . "</h2><p>" . esc_html( $line ) . "</p>";
		}

		$plain = trim( wp_strip_all_tags( $html ) );
		if ( '' !== $plain && ! preg_match( '/[.!?]["\')\]]*\s*$/u', $plain ) ) {
			$html .= '<p>' . esc_html( $is_dutch ? 'Belangrijkste punt: zorg voor een volledige en duidelijke afronding.' : 'Key takeaway: end the article with a complete and clear final thought.' ) . '</p>';
		}

		return $html;
	}

	private function cgm_ensure_complete_article( CGM_Claude_Client $client, string $html, array $context ): array {
		$topic          = (string) ( $context['topic'] ?? '' );
		$primary        = (string) ( $context['primary_keyword'] ?? $topic );
		$word_count     = max( 1200, (int) ( $context['word_count'] ?? 1600 ) );
		$language       = (string) ( $context['language'] ?? 'English' );
		$current_words  = (int) str_word_count( wp_strip_all_tags( $html ) );
		$target_floor   = $word_count >= 3500 ? 0.95 : ( $word_count >= 1800 ? 0.9 : 0.85 );
		$tokens_used    = 0;
		$attempts       = 0;
		$needs_more     = $current_words < (int) floor( $word_count * $target_floor ) || $this->cgm_article_looks_incomplete( $html );

		while ( $attempts < 5 && $needs_more ) {
			$attempts++;
			$expanded = $client->expand_article( $html, [
				'suggested_title'    => $topic,
				'primary_keyword'    => $primary,
				'word_count'         => $word_count,
				'current_word_count' => $current_words,
				'language'           => $language,
			] );
			$expanded_html = trim( (string) ( $expanded['html'] ?? '' ) );
			$expanded_html = preg_replace( '/^```(?:html)?\s*/i', '', $expanded_html );
			$expanded_html = preg_replace( '/\s*```$/', '', (string) $expanded_html );
			$expanded_html = preg_replace( '/^(?:[\'"`])+\s*(?:html)?\s*/i', '', trim( (string) $expanded_html ) );
			$expanded_html = preg_replace( '/\s*(?:[\'"`])+$/', '', trim( (string) $expanded_html ) );
			if ( '' === trim( wp_strip_all_tags( $expanded_html ) ) ) {
				break;
			}
			$new_words = (int) str_word_count( wp_strip_all_tags( $expanded_html ) );
			$new_incomplete = $this->cgm_article_looks_incomplete( $expanded_html );
			$tokens_used += (int) ( $expanded['tokens_used'] ?? 0 );
			if ( $new_words <= $current_words && $new_incomplete === $this->cgm_article_looks_incomplete( $html ) ) {
				break;
			}
			$html = $expanded_html;
			$current_words = $new_words;
			$needs_more = $current_words < (int) floor( $word_count * $target_floor ) || $new_incomplete;
		}

		if ( $this->cgm_article_looks_incomplete( $html ) ) {
			$system = 'You finish HTML articles cleanly without repeating previous sections.';
			$prompt = sprintf(
				"Continue and finish this HTML article about %s.\n\nRequirements:\n- Write ONLY in %s\n- Do not repeat existing paragraphs\n- Add only the missing ending, missing FAQ answers or missing conclusion\n- Return ONLY the missing HTML to append\n- End with a complete final sentence\n\nARTICLE HTML:\n%s",
				$topic,
				$language,
				$html
			);
			$continued = $client->chat( [ [ 'role' => 'user', 'content' => $prompt ] ], $system, 8000 );
			$continued_html = trim( (string) ( $continued['text'] ?? '' ) );
			$continued_html = preg_replace( '/^```(?:html)?\s*/i', '', $continued_html );
			$continued_html = preg_replace( '/\s*```$/', '', (string) $continued_html );
			if ( '' !== trim( wp_strip_all_tags( $continued_html ) ) ) {
				$html .= "\n\n" . $continued_html;
				$tokens_used += (int) ( $continued['tokens_used'] ?? 0 );
			}
		}

		$html = $this->cgm_finalize_article_ending( $html, $topic, $language );

		return [
			'html'        => $html,
			'tokens_used' => $tokens_used,
			'word_count'  => (int) str_word_count( wp_strip_all_tags( $html ) ),
			'incomplete'  => $this->cgm_article_looks_incomplete( $html ),
		];
	}

	public function post_ai_assistant_save_draft( WP_REST_Request $request ) {
		$body    = $request->get_json_params();
		$title   = sanitize_text_field( $body['title']   ?? 'AI Assistant Draft' );
		$content = (string) ( $body['content'] ?? '' );
		$cluster = sanitize_text_field( $body['cluster'] ?? '' );
		$post_id = absint( $body['wp_post_id'] ?? 0 );
		$content_type = in_array( sanitize_key( (string) ( $body['content_type'] ?? 'post' ) ), [ 'post', 'page' ], true ) ? sanitize_key( (string) ( $body['content_type'] ?? 'post' ) ) : 'post';

		$allow_svg = ! empty( $body['include_svg_visuals'] );
		$content = $this->normalize_article_output_html( $content, $allow_svg );
		$content = contentgem_clean_ai_article_output( $content, $allow_svg );
		if ( '' === trim( wp_strip_all_tags( $content ) ) && false === stripos( $content, '<svg' ) ) {
			return new WP_Error( 'no_content', 'Content is required.', [ 'status' => 400 ] );
		}

		$post_args = [
			'post_title'   => $title,
			'post_content' => wp_kses_post( $content ),
			'post_status'  => 'draft',
			'post_author'  => get_current_user_id(),
			'post_type'    => $content_type,
		];

		if ( $post_id > 0 ) {
			$existing = get_post( $post_id );
			if ( ! $existing instanceof WP_Post ) {
				return new WP_Error( 'not_found', 'Draft not found.', [ 'status' => 404 ] );
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return new WP_Error( 'forbidden', 'You cannot edit this draft.', [ 'status' => 403 ] );
			}
			$post_args['ID'] = $post_id;
			$post_id = wp_update_post( $post_args, true );
		} else {
			$post_id = wp_insert_post( $post_args, true );
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta( $post_id, '_cgm_ai_draft', '1' );
		if ( $cluster ) { update_post_meta( $post_id, '_cgm_cluster', $cluster ); }
		update_post_meta( $post_id, '_cgm_content_type', $content_type );
		if ( 'post' === $content_type && $cluster ) {
			$draft_service = new CGM_Draft_Service( $this );
			$draft_service->assign_cluster_metadata( (int) $post_id, (string) $cluster, array_filter( [ (string) ( $body['focus_keyword'] ?? '' ), (string) $title ] ), (string) $title, (string) $content );
		}
		if ( $allow_svg ) {
			CGM_Draft_SVG::store_for_post( (int) $post_id, $content, $content );
		} else {
			$this->clear_post_draft_visual_meta( (int) $post_id );
			update_post_meta( $post_id, '_cgm_draft_text', $content );
			wp_update_post( [ 'ID' => (int) $post_id, 'post_content' => wp_kses_post( $content ) ] );
		}

		$builder_integrator = new CGM_Builder_Integrator();
		$builder_mode = $builder_integrator->sync_generated_post(
			(int) $post_id,
			(string) $content,
			[
				'post_type'    => $content_type,
				'builder_mode' => $this->sanitize_builder_mode( $body['builder_mode'] ?? 'auto' ),
			]
		);
		update_post_meta( $post_id, '_contentgem_builder_mode', $builder_mode );

		return rest_ensure_response( [
			'success'    => true,
			'wp_post_id' => $post_id,
			'edit_url'   => get_edit_post_link( $post_id, 'raw' ),
			'updated'    => ! empty( $post_args['ID'] ),
			'builder_mode' => $builder_mode,
		] );
	}

	public function post_assistant_generate( WP_REST_Request $request ): WP_REST_Response {
		$body     = $request->get_json_params();
		$messages = (array) ( $body['messages'] ?? [] );
		$system   = (string) ( $body['system'] ?? '' );

		if ( empty( $messages ) ) {
			return new WP_Error( 'no_messages', 'No messages provided.', [ 'status' => 400 ] );
		}

		$clean_messages = [];
		foreach ( $messages as $msg ) {
			$role    = in_array( $msg['role'] ?? '', [ 'user', 'assistant' ], true ) ? $msg['role'] : 'user';
			$content = sanitize_textarea_field( $msg['content'] ?? '' );
			if ( '' !== $content ) {
				$clean_messages[] = [ 'role' => $role, 'content' => $content ];
			}
		}

		if ( empty( $clean_messages ) ) {
			return new WP_Error( 'no_messages', 'No valid messages provided.', [ 'status' => 400 ] );
		}

		try {
			$system = trim( $system );
			$language_service = new CGM_Language_Service();
			$system .= ( '' !== $system ? "\n\n" : '' ) . $language_service->build_language_rules( $language_service->get_language_code() );
			$tone = (string) get_option( 'contentgem_tone_of_voice', '' );
			if ( '' !== $tone ) {
				$system .= ( '' !== $system ? "

" : '' ) . "TONE OF VOICE INSTRUCTIONS:
" . $tone;
			}
			$system .= ( '' !== $system ? "

" : '' ) . 'Return only clean article HTML. Do not include SVG, figures, cards, captions, legends, metric lists, related-term stacks or any non-article visual output. Do not begin with stray tokens such as nn. End cleanly after the conclusion.';
			$cache_payload = [ 'system' => $system, 'messages' => $clean_messages, 'endpoint' => 'assistant_generate' ];
			$cached = $this->cgm_get_cached_ai_result( 'assistant_generate', $cache_payload );
			if ( is_array( $cached ) && ! empty( $cached['content'] ) ) {
				$cached['cached'] = true;
				return rest_ensure_response( $cached );
			}
			$provider_sources = [];
			$provider_usage = [];
			$provider_model = '';
			if ( $this->use_openai_task_stack() ) {
				$task_name = $this->assistant_prompt_looks_technical( $clean_messages ) ? 'technical_build_plan' : 'ai_assistant_research';
				$openai_result = $this->run_openai_task( $task_name, $clean_messages, [ 'cache_hints' => [ $system, $clean_messages ] ] );
				$content = (string) ( $openai_result['content'] ?? '' );
				$provider_sources = (array) ( $openai_result['sources'] ?? [] );
				$provider_usage = (array) ( $openai_result['usage'] ?? [] );
				$provider_model = (string) ( $openai_result['meta']['model'] ?? '' );
				$result = [ 'tokens_used' => (int) ( $provider_usage['total_tokens'] ?? 0 ) ];
			} else {
				$client  = CGM_AI_Client::from_settings();
				$result  = $client->chat( $clean_messages, $system, 4200 );
				$content = (string) ( $result['text'] ?? '' );
				$provider_model = method_exists( $client, 'get_model' ) ? (string) $client->get_model() : '';
			}
			$content = preg_replace( '/^```(?:html)?\s*/i', '', trim( $content ) );
			$content = preg_replace( '/\s*```$/', '', trim( (string) $content ) );
			$content = $this->normalize_article_output_html( (string) $content, false );
			$content = contentgem_clean_ai_article_output( (string) $content, false );
			if ( isset( $client ) && $this->cgm_response_looks_truncated( $content ) ) {
				$continuation_messages = $clean_messages;
				$continuation_messages[] = [ 'role' => 'assistant', 'content' => $content ];
				$continuation_messages[] = [ 'role' => 'user', 'content' => 'Continue exactly where you left off and finish the article in the same language and HTML style. Do not restart or repeat the beginning. Return HTML only.' ];
				$continued = $client->chat( $continuation_messages, $system, 2600 );
				$continued_text = (string) ( $continued['text'] ?? '' );
				$continued_text = preg_replace( '/^```(?:html)?\s*/i', '', trim( $continued_text ) );
				$continued_text = preg_replace( '/\s*```$/', '', trim( (string) $continued_text ) );
				if ( '' !== trim( $continued_text ) ) {
					$content .= "\n\n" . $continued_text;
					$content = $this->normalize_article_output_html( (string) $content, false );
					$content = contentgem_clean_ai_article_output( (string) $content, false );
					$result['tokens_used'] = (int) ( $result['tokens_used'] ?? 0 ) + (int) ( $continued['tokens_used'] ?? 0 );
				}
			}
			if ( '' === trim( $content ) ) {
				return new WP_Error( 'assistant_generate_error', 'AI returned an empty response.', [ 'status' => 502 ] );
			}
			$payload = [
				'content'     => $content,
				'html'        => $content,
				'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
				'cached'      => false,
				'sources'     => $provider_sources,
				'usage'       => $provider_usage,
				'model'       => $provider_model,
			];
			$this->cgm_set_cached_ai_result( 'assistant_generate', $cache_payload, $payload, 15 * MINUTE_IN_SECONDS );
			return rest_ensure_response( $payload );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'assistant_generate_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_ai_assistant_generate( WP_REST_Request $request ): void {
		$body     = $request->get_json_params();
		$messages = (array) ( $body['messages'] ?? [] );
		$system   = sanitize_textarea_field( $body['system'] ?? '' );

		if ( empty( $messages ) ) {
			wp_send_json_error( [ 'message' => 'No messages provided.' ], 400 );
			return;
		}

		$clean_messages = [];
		foreach ( $messages as $msg ) {
			$role    = in_array( $msg['role'] ?? '', [ 'user', 'assistant' ], true ) ? $msg['role'] : 'user';
			$content = sanitize_textarea_field( $msg['content'] ?? '' );
			if ( ! empty( $content ) ) {
				$clean_messages[] = [ 'role' => $role, 'content' => $content ];
			}
		}

		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );

			header( 'Content-Type: text/event-stream' );
			header( 'Cache-Control: no-cache' );
			header( 'X-Accel-Buffering: no' );
			if ( ob_get_level() > 0 ) ob_end_flush();

			$client->chat_stream(
				$clean_messages,
				$system,
				function ( string $chunk ) {
					echo 'data: ' . wp_json_encode( [ 'type' => 'chunk', 'content' => $chunk ] ) . "\n\n";
					if ( ob_get_level() > 0 ) ob_flush();
					flush();
				}
			);

			echo 'data: [DONE]' . "\n\n";
			if ( ob_get_level() > 0 ) ob_flush();
			flush();

		} catch ( \Throwable $e ) {
			echo 'data: ' . wp_json_encode( [ 'type' => 'error', 'message' => $e->getMessage() ] ) . "\n\n";
			flush();
		}

		exit;
	}

	public function post_analyze_writing_style( WP_REST_Request $request ) {
		$post_ids = array_map( 'absint', (array) ( $request->get_json_params()['post_ids'] ?? [] ) );
		$post_ids = array_filter( $post_ids );

		if ( empty( $post_ids ) ) {
			return new WP_Error( 'no_posts', 'At least one post is required.', [ 'status' => 400 ] );
		}

		// Collect post content samples
		$samples = [];
		foreach ( array_slice( $post_ids, 0, 5 ) as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post || $post->post_status !== 'publish' ) continue;
			$text = wp_strip_all_tags( $post->post_content );
			// Take first 800 words of each post
			$words = explode( ' ', $text );
			$samples[] = implode( ' ', array_slice( $words, 0, 800 ) );
		}

		if ( empty( $samples ) ) {
			return new WP_Error( 'no_content', 'Could not load post content.', [ 'status' => 422 ] );
		}

		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );

			$combined = implode( "\n\n---\n\n", $samples );

			$prompt = "Analyse the writing style of the following blog post excerpts. ".
				"Write a concise tone of voice description (max 150 words) that captures:\n" .
				"- Formality level (casual/professional/friendly)\n" .
				"- Sentence style (short/long/varied)\n" .
				"- Use of 'you' vs impersonal\n" .
				"- Typical vocabulary and any specific patterns\n" .
				"- What to avoid (jargon, clickbait, etc.)\n\n" .
				"Write it as actionable instructions for an AI writing assistant, starting with 'Write in...' or 'Use a...'\n\n" .
				"EXCERPTS:\n" . $combined;

			$result = $client->generate_article(
				'You are a writing style analyst. Return only the tone of voice description, no explanation.',
				$prompt
			);

			$tone = trim( $result['html'] ?? '' );

			if ( empty( $tone ) ) {
				return new WP_Error( 'empty_response', 'AI returned empty response.', [ 'status' => 500 ] );
			}

			return rest_ensure_response( [
				'tone_of_voice' => $tone,
				'tokens_used'   => $result['tokens_used'] ?? 0,
			] );

		} catch ( \Throwable $e ) {
			return new WP_Error( 'ai_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}


	private function sanitize_structure_page_entry( $raw ): array {
		$entry = is_array( $raw ) ? $raw : [];
		$page_id = absint( $entry['page_id'] ?? 0 );
		$title = sanitize_text_field( (string) ( $entry['title'] ?? '' ) );
		$url   = esc_url_raw( (string) ( $entry['url'] ?? '' ) );
		$priority = max( 1, min( 100, (int) ( $entry['priority'] ?? 50 ) ) );
		if ( $page_id > 0 ) {
			$post = get_post( $page_id );
			if ( $post instanceof WP_Post && 'page' === $post->post_type ) {
				$title = get_the_title( $page_id );
				$url   = (string) get_permalink( $page_id );
			}
		}
		return [ 'page_id' => $page_id, 'title' => $title, 'url' => $url, 'priority' => $priority ];
	}

	private function sanitize_structure_node_entry( $raw, array $known_ids = [] ): array {
		$entry = is_array( $raw ) ? $raw : [];
		$id = sanitize_key( (string) ( $entry['id'] ?? wp_unique_id( 'node_' ) ) );
		$type = sanitize_key( (string) ( $entry['type'] ?? 'custom' ) );
		$allowed_types = [ 'homepage', 'service', 'about', 'case', 'pillar', 'category', 'custom', 'group' ];
		if ( ! in_array( $type, $allowed_types, true ) ) { $type = 'custom'; }
		$parent = sanitize_key( (string) ( $entry['parent'] ?? '' ) );
		if ( '' !== $parent && ! in_array( $parent, $known_ids, true ) ) { $parent = ''; }
		$title = sanitize_text_field( (string) ( $entry['title'] ?? '' ) );
		$url = esc_url_raw( (string) ( $entry['url'] ?? '' ) );
		$priority = max( 1, min( 100, (int) ( $entry['priority'] ?? 50 ) ) );
		$page_id = absint( $entry['page_id'] ?? 0 );
		if ( $page_id > 0 ) {
			$post = get_post( $page_id );
			if ( $post instanceof WP_Post && 'page' === $post->post_type ) {
				$title = get_the_title( $page_id );
				$url = (string) get_permalink( $page_id );
			}
		}
		return [ 'id' => $id, 'type' => $type, 'title' => $title, 'url' => $url, 'priority' => $priority, 'parent' => $parent, 'page_id' => $page_id ];
	}


	private function clear_post_draft_visual_meta( int $post_id ): void {
		delete_post_meta( $post_id, '_cgm_draft_svgs' );
		delete_post_meta( $post_id, '_cgm_draft_captions' );
		delete_post_meta( $post_id, '_cgm_draft_svg_targets' );
		delete_post_meta( $post_id, '_contentgem_cluster_svg' );
	}

	private function auto_detect_site_structure_from_existing_pages( bool $force = false ): array {
		$current = $this->sanitize_site_structure( get_option( 'contentgem_site_structure', [] ) );
		if ( ! $force && ! empty( $current['nodes'] ) ) {
			return $current;
		}
		$pages = get_posts( [
			'post_type'      => 'page',
			'post_status'    => [ 'publish', 'draft', 'private', 'pending', 'future' ],
			'posts_per_page' => -1,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		] );
		$nodes = [];
		$id_map = [];
		$homepage = [];
		$about_page = [];
		$service_pages = [];
		$case_studies = [];
		foreach ( is_array( $pages ) ? $pages : [] as $post ) {
			if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ) { continue; }
			$page_id = (int) $post->ID;
			$id_map[ $page_id ] = 'page_' . $page_id;
		}
		foreach ( is_array( $pages ) ? $pages : [] as $post ) {
			if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ) { continue; }
			$page_id = (int) $post->ID;
			$title   = get_the_title( $page_id );
			$url     = (string) get_permalink( $page_id );
			$slug    = sanitize_title( (string) $post->post_name );
			$label   = strtolower( trim( $title . ' ' . $slug ) );
			$type    = 'custom';
			$priority = 60;
			if ( 'home' === $slug || '/' === trim( wp_parse_url( $url, PHP_URL_PATH ) ?: '/' ) ) {
				$type = 'homepage';
				$priority = 100;
				$homepage = [ 'page_id' => $page_id, 'title' => $title, 'url' => $url, 'priority' => 100 ];
			} elseif ( preg_match( '/\b(about|about-us|over-ons|company|team)\b/i', $label ) ) {
				$type = 'about';
				$priority = 85;
				if ( empty( $about_page ) ) { $about_page = [ 'page_id' => $page_id, 'title' => $title, 'url' => $url, 'priority' => 85 ]; }
			} elseif ( preg_match( '/\b(case|cases|case-study|case-studies|portfolio|klantverhaal|succesverhaal)\b/i', $label ) ) {
				$type = 'case';
				$priority = 75;
				$case_studies[] = [ 'page_id' => $page_id, 'title' => $title, 'url' => $url, 'priority' => 75 ];
			} elseif ( preg_match( '/\b(service|services|feature|features|solution|solutions|dienst|diensten|use-case|use-cases)\b/i', $label ) ) {
				$type = 'service';
				$priority = 80;
				$service_pages[] = [ 'page_id' => $page_id, 'title' => $title, 'url' => $url, 'priority' => 80 ];
			}
			$nodes[] = [
				'id'       => (string) ( $id_map[ $page_id ] ?? 'page_' . $page_id ),
				'type'     => $type,
				'title'    => $title,
				'url'      => $url,
				'priority' => $priority,
				'parent'   => ! empty( $post->post_parent ) && isset( $id_map[ (int) $post->post_parent ] ) ? (string) $id_map[ (int) $post->post_parent ] : '',
				'page_id'  => $page_id,
			];
		}
		$detected = [
			'template'      => 'autodetected',
			'homepage'      => $homepage,
			'service_pages' => array_values( array_slice( $service_pages, 0, 20 ) ),
			'about_page'    => $about_page,
			'case_studies'  => array_values( array_slice( $case_studies, 0, 20 ) ),
			'nodes'         => $nodes,
		];
		$detected = $this->sanitize_site_structure( $detected );
		update_option( 'contentgem_site_structure', $detected, false );
		return $detected;
	}

	private function sanitize_site_structure( $raw ): array {
		$raw = is_array( $raw ) ? $raw : [];
		$normalize_list = function( $items ): array {
			$clean = [];
			foreach ( is_array( $items ) ? $items : [] as $item ) {
				$entry = $this->sanitize_structure_page_entry( $item );
				if ( $entry['page_id'] || $entry['url'] || $entry['title'] ) { $clean[] = $entry; }
			}
			return $clean;
		};
		$nodes = [];
		$known_ids = [];
		foreach ( is_array( $raw['nodes'] ?? null ) ? $raw['nodes'] : [] as $item ) {
			$id = sanitize_key( (string) ( is_array( $item ) ? ( $item['id'] ?? '' ) : '' ) );
			if ( '' === $id ) { $id = sanitize_key( wp_unique_id( 'node_' ) ); }
			$known_ids[] = $id;
		}
		foreach ( is_array( $raw['nodes'] ?? null ) ? $raw['nodes'] : [] as $index => $item ) {
			if ( is_array( $item ) && empty( $item['id'] ) && isset( $known_ids[ $index ] ) ) { $item['id'] = $known_ids[ $index ]; }
			$node = $this->sanitize_structure_node_entry( $item, $known_ids );
			if ( '' !== $node['title'] || '' !== $node['url'] || $node['page_id'] > 0 ) { $nodes[] = $node; }
		}
		return [
			'template'      => sanitize_key( (string) ( $raw['template'] ?? 'custom' ) ),
			'homepage'      => $this->sanitize_structure_page_entry( $raw['homepage'] ?? [] ),
			'service_pages' => $normalize_list( $raw['service_pages'] ?? [] ),
			'about_page'    => $this->sanitize_structure_page_entry( $raw['about_page'] ?? [] ),
			'case_studies'  => $normalize_list( $raw['case_studies'] ?? [] ),
			'nodes'         => $nodes,
		];
	}

	private function get_site_structure(): array {
		$saved = get_option( 'contentgem_site_structure', [] );
		$structure = $this->sanitize_site_structure( is_array( $saved ) ? $saved : [] );
		if ( empty( $structure['nodes'] ) ) {
			$structure = $this->auto_detect_site_structure_from_existing_pages();
		}
		return $structure;
	}

	private function get_site_structure_link_targets(): array {
		$structure = $this->get_site_structure();
		$targets = [];
		foreach ( [ 'homepage', 'about_page' ] as $single_key ) {
			$entry = is_array( $structure[ $single_key ] ?? null ) ? $structure[ $single_key ] : [];
			if ( ! empty( $entry['url'] ) ) {
				$targets[] = [ 'type' => $single_key, 'page_id' => (int) ( $entry['page_id'] ?? 0 ), 'title' => (string) ( $entry['title'] ?? '' ), 'url' => (string) ( $entry['url'] ?? '' ), 'priority' => (int) ( $entry['priority'] ?? 70 ), 'parent' => '' ];
			}
		}
		foreach ( [ 'service_pages', 'case_studies' ] as $list_key ) {
			foreach ( is_array( $structure[ $list_key ] ?? null ) ? $structure[ $list_key ] : [] as $entry ) {
				if ( empty( $entry['url'] ) ) { continue; }
				$targets[] = [ 'type' => $list_key, 'page_id' => (int) ( $entry['page_id'] ?? 0 ), 'title' => (string) ( $entry['title'] ?? '' ), 'url' => (string) ( $entry['url'] ?? '' ), 'priority' => (int) ( $entry['priority'] ?? 80 ), 'parent' => '' ];
			}
		}
		foreach ( is_array( $structure['nodes'] ?? null ) ? $structure['nodes'] : [] as $node ) {
			if ( empty( $node['url'] ) ) { continue; }
			$targets[] = [
				'type' => (string) ( $node['type'] ?? 'custom' ),
				'page_id' => (int) ( $node['page_id'] ?? 0 ),
				'title' => (string) ( $node['title'] ?? '' ),
				'url' => (string) ( $node['url'] ?? '' ),
				'priority' => (int) ( $node['priority'] ?? 60 ),
				'parent' => (string) ( $node['parent'] ?? '' ),
			];
		}
		usort( $targets, static function( $a, $b ) { return (int)($b['priority'] ?? 0) <=> (int)($a['priority'] ?? 0); } );
		return $targets;
	}

	public function post_settings_site_structure( WP_REST_Request $request ): WP_REST_Response {
		$body = (array) ( $request->get_json_params() ?? [] );
		$detected = $this->auto_detect_site_structure_from_existing_pages();
		$structure = $this->sanitize_site_structure( $body['site_structure'] ?? [] );
		if ( ! empty( $detected['nodes'] ) ) {
			$existing_page_ids = array_values( array_filter( array_map( static function( $node ) { return (int) ( is_array( $node ) ? ( $node['page_id'] ?? 0 ) : 0 ); }, (array) ( $structure['nodes'] ?? [] ) ) ) );
			foreach ( (array) ( $detected['nodes'] ?? [] ) as $node ) {
				$page_id = (int) ( is_array( $node ) ? ( $node['page_id'] ?? 0 ) : 0 );
				if ( $page_id > 0 && ! in_array( $page_id, $existing_page_ids, true ) ) {
					$structure['nodes'][] = $node;
				}
			}
			if ( empty( $structure['homepage'] ) && ! empty( $detected['homepage'] ) ) { $structure['homepage'] = $detected['homepage']; }
			if ( empty( $structure['about_page'] ) && ! empty( $detected['about_page'] ) ) { $structure['about_page'] = $detected['about_page']; }
			if ( empty( $structure['service_pages'] ) && ! empty( $detected['service_pages'] ) ) { $structure['service_pages'] = $detected['service_pages']; }
			if ( empty( $structure['case_studies'] ) && ! empty( $detected['case_studies'] ) ) { $structure['case_studies'] = $detected['case_studies']; }
		}
		$structure = $this->sanitize_site_structure( $structure );
		update_option( 'contentgem_site_structure', $structure, false );
		return rest_ensure_response( [ 'success' => true, 'site_structure' => $structure ] );
	}

	public function post_settings_tone_of_voice( WP_REST_Request $request ): WP_REST_Response {
		$tone = sanitize_textarea_field( (string) ( $request->get_json_params()['tone_of_voice'] ?? '' ) );
		update_option( 'contentgem_tone_of_voice', $tone );
		return rest_ensure_response( [ 'success' => true ] );
	}

	public function post_settings_competitor_domains( WP_REST_Request $request ) {
		$domains = (array) ( $request->get_json_params()['competitor_domains'] ?? [] );
		$domains = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $domains ) ) ) );
		$domains = array_slice( $domains, 0, 20 );
		update_option( 'contentgem_competitor_domains', $domains, false );
		update_option( 'contentgem_competitors', $domains, false );
		$saved = get_option( 'contentgem_competitor_domains', [] );
		return rest_ensure_response( [ 'success' => is_array( $saved ), 'domains' => is_array( $saved ) ? $saved : [] ] );
	}

	public function post_settings_cluster_keywords( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$raw  = $body['cluster_keywords'] ?? [];

		if ( ! is_array( $raw ) ) {
			return new WP_Error( 'invalid_keywords', __( 'Invalid format.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$replace   = ! empty( $body['replace'] );
		$existing  = get_option( 'cgm_cluster_keywords', [] );
		$existing  = is_array( $existing ) ? $existing : [];
		$sanitized = $replace ? [] : $existing;
		foreach ( $raw as $cluster => $keywords ) {
			$cluster_key = sanitize_text_field( (string) $cluster );
			if ( empty( $cluster_key ) ) {
				continue;
			}

			if ( is_array( $keywords ) ) {
				$incoming = array_values(
					array_unique(
						array_filter( array_map( 'sanitize_text_field', $keywords ), static function( $k ) { return $k !== ''; } )
					)
				);
				$sanitized[ $cluster_key ] = $replace
					? $incoming
					: array_values( array_unique( array_merge( (array) ( $existing[ $cluster_key ] ?? [] ), $incoming ) ) );
			}
		}

		update_option( 'cgm_cluster_keywords', $sanitized );

		return rest_ensure_response( [ 'success' => true, 'cluster_keywords' => $sanitized, 'replace' => $replace ] );
	}

	public function post_suggest_cluster_keywords( WP_REST_Request $request ) {
		$body        = $request->get_json_params();
		$clusters    = array_map( 'sanitize_text_field', (array) ( $body['clusters'] ?? [] ) );
		$niche       = sanitize_text_field( $body['niche'] ?? '' ) ?: (string) get_option( 'contentgem_niche', '' );
		$description = sanitize_text_field( $body['description'] ?? '' ) ?: (string) get_option( 'contentgem_niche_description', '' );

		if ( empty( $clusters ) ) {
			return new WP_Error( 'no_clusters', __( 'No clusters provided.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$clusters_list = implode( "\n", array_map( function( $c ) { return "- {$c}"; }, $clusters ) );
		$context       = $niche ? "Website niche: {$niche}." : '';
		if ( $description ) {
			$context .= ' Description: ' . mb_substr( $description, 0, 300 );
		}

		$forced_language = $this->normalize_language_code( (string) get_option( 'contentgem_content_language', 'auto' ) );
		if ( 'auto' !== $forced_language && '' !== $forced_language ) {
			$language_label = $this->language_label_from_code( $forced_language );
		} else {
			$language_code = $this->get_preferred_language_code();
			if ( 'auto' === $language_code && class_exists( 'CGM_NLP_Engine' ) ) {
				$language_code = ( new CGM_NLP_Engine() )->detect_language( implode( ' ', $clusters ) . ' ' . $niche . ' ' . $description );
			}
			$language_label = $this->language_label_from_code( $language_code ?: 'en' );
		}

		$prompt = "You are an SEO expert. For each content cluster below, generate 8-12 highly relevant SEO keywords that a WordPress post in that cluster should contain or rank for. {$context}\n\nLanguage requirement: return all suggested keywords in {$language_label}, matching the language of the clusters and query context. Do not switch language because of anglicisms or unclear terms.\n\nClusters:\n{$clusters_list}\n\nRespond ONLY with valid JSON in this exact format, no explanation, no markdown:\n{\n  \"ClusterName1\": [\"keyword1\", \"keyword2\"],\n  \"ClusterName2\": [\"keyword1\", \"keyword2\"]\n}";

		$tokens = new CGM_Token_Manager( get_current_user_id() );

		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );
			$result = $client->suggest_cluster_keywords( $prompt );
			$tokens->deduct( $result['tokens_used'] ?? 0 );

			$raw_json = trim( (string) ( $result['text'] ?? '' ) );
			$raw_json = preg_replace( '/^```(?:json)?\s*/i', '', $raw_json );
			$raw_json = preg_replace( '/\s*```$/', '', $raw_json );
			if ( preg_match( '/\{[\s\S]*\}/', $raw_json, $match ) ) {
				$raw_json = $match[0];
			}

			$keywords = json_decode( $raw_json, true );
			if ( ! is_array( $keywords ) ) {
				$keywords = $this->fallback_cluster_keywords( $clusters, $niche, $description );
			}

			$sanitized = [];
			foreach ( $keywords as $cluster => $kws ) {
				if ( is_array( $kws ) ) {
					$vals = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $kws ) ) ) );
					if ( ! empty( $vals ) ) {
						$sanitized[ sanitize_text_field( $cluster ) ] = array_slice( $vals, 0, 12 );
					}
				}
			}
			if ( empty( $sanitized ) ) {
				$sanitized = $this->fallback_cluster_keywords( $clusters, $niche, $description );
			}

			return rest_ensure_response( [ 'keywords' => $sanitized, 'used_fallback' => empty( $result['text'] ?? '' ) || ! is_array( json_decode( $raw_json, true ) ) ] );

		} catch ( \Throwable $e ) {
			$sanitized = $this->fallback_cluster_keywords( $clusters, $niche, $description );
			if ( ! empty( $sanitized ) ) {
				return rest_ensure_response( [ 'keywords' => $sanitized, 'used_fallback' => true ] );
			}
			if ( strpos( $e->getMessage(), 'No API key' ) === 0 ) {
				return new WP_Error( 'no_api_key', __( 'Add your API key in Settings first.', 'contentgem' ), [ 'status' => 422 ] );
			}
			return new WP_Error( 'ai_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_settings_niche( WP_REST_Request $request ): WP_REST_Response {
		$niche       = sanitize_text_field( (string) $request->get_param( 'niche' ) );
		$description = sanitize_textarea_field( (string) $request->get_param( 'description' ) );
		$raw_language   = (string) $request->get_param( 'language' );
		$custom_language = sanitize_text_field( (string) $request->get_param( 'custom_language' ) );
		$language       = $this->normalize_language_code( $raw_language );
		if ( 'custom' === strtolower( trim( $raw_language ) ) ) {
			$language = 'custom';
		} elseif ( '' === $language ) {
			$language = $this->get_configured_language_value();
		}
		update_option( 'contentgem_niche', $niche );
		update_option( 'contentgem_niche_description', $description );
		update_option( 'contentgem_content_language', $language );
		update_option( 'contentgem_content_language_custom', 'custom' === $language ? $custom_language : '' );

		return rest_ensure_response( [ 'success' => true, 'niche' => $niche, 'description' => $description, 'content_language' => $language, 'content_language_custom' => 'custom' === $language ? $custom_language : '' ] );
	}

	public function post_settings_language( WP_REST_Request $request ): WP_REST_Response {
		$raw_language   = (string) $request->get_param( 'language' );
		$custom_language = sanitize_text_field( (string) $request->get_param( 'custom_language' ) );
		$language       = $this->normalize_language_code( $raw_language );
		if ( 'custom' === strtolower( trim( $raw_language ) ) ) {
			$language = 'custom';
		}
		if ( '' === $language ) {
			return new WP_Error( 'invalid_language', __( 'Invalid language.', 'contentgem' ), [ 'status' => 400 ] );
		}
		update_option( 'contentgem_content_language', $language );
		update_option( 'contentgem_content_language_custom', 'custom' === $language ? $custom_language : '' );
		return rest_ensure_response( [ 'success' => true, 'content_language' => $language, 'content_language_custom' => 'custom' === $language ? $custom_language : '' ] );
	}

	public function post_onboarding_complete( WP_REST_Request $request ): WP_REST_Response {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', '', [ 'status' => 403 ] );
		}

		// If onboarding sends clusters, always replace (never merge) existing clusters.
		// This ensures what the user configured in onboarding is the final state.
		$body     = $request->get_json_params() ?? [];
		$clusters = $body['clusters'] ?? null;

		$truncated = false;
		$accepted  = [];
		$rejected  = [];
		$limit     = function_exists( 'cgm_get_limit' ) ? (int) cgm_get_limit( 'clusters' ) : -1;

		if ( is_array( $clusters ) && ! empty( $clusters ) ) {
			$incoming = $this->normalise_cluster_list( $clusters );
			if ( ! empty( $incoming ) ) {
				// Enforce plan cluster cap during onboarding too. When a Free
				// user enters more than the cap we silently truncate to the
				// first N so the flow completes, and return the split so the
				// UI can surface an inline "Upgrade to keep the rest" notice.
				if ( $limit >= 0 && count( $incoming ) > $limit ) {
					$accepted  = array_slice( $incoming, 0, $limit );
					$rejected  = array_slice( $incoming, $limit );
					$truncated = true;
					$incoming  = $accepted;
				}
				$this->save_cluster_snapshot( $this->get_saved_clusters(), 'pre_onboarding' );
				$this->persist_clusters( $incoming, true ); // true = replace, not merge
			}
		}

		update_option( 'contentgem_onboarding_complete', true );
		delete_option( 'contentgem_force_onboarding' );

		$response = [ 'success' => true ];
		if ( $truncated ) {
			$response['truncated']   = true;
			$response['limit']       = $limit;
			$response['plan']        = function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'free';
			$response['accepted']    = $accepted;
			$response['rejected']    = $rejected;
			$response['upgrade_url'] = function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : '';
			/* translators: 1: cluster cap on the active plan */
			$response['message']     = sprintf( __( 'Only the first %d clusters were saved. Upgrade to save more.', 'contentgem' ), $limit );
		}
		return rest_ensure_response( $response );
	}

	public function get_cannibalization( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;

		$site_id   = $this->get_site_id();
		$cache_key = 'contentgem_cannibalization_' . $site_id;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$table        = $wpdb->prefix . 'cgm_cannibalization';
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
		$any_rows     = $table_exists && $site_id
			? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE site_id = %d", $site_id ) )
			: 0;

		if ( ! $table_exists || ! $site_id || 0 === $any_rows ) {
			return rest_ensure_response( [
				'pairs'          => [],
				'posts_analyzed' => 0,
				'message'        => __( 'Run an analysis first', 'contentgem' ),
			] );
		}

		$posts_analyzed = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = %s AND post_type = %s",
				'publish',
				'post'
			)
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT c.id, c.post_id_1, c.post_id_2, c.similarity_score, c.overlap_score, c.status,
				        p1.post_title  AS title_1,       p2.post_title  AS title_2,
				        p1.post_status AS post_status_1, p2.post_status AS post_status_2,
				        p1.post_content AS content_1,    p2.post_content AS content_2
				 FROM {$table} c
				 LEFT JOIN {$wpdb->prefix}posts p1 ON p1.ID = c.post_id_1
				 LEFT JOIN {$wpdb->prefix}posts p2 ON p2.ID = c.post_id_2
				 WHERE c.site_id = %d AND c.status = 'open'
				 ORDER BY c.overlap_score DESC, c.similarity_score DESC",
				$site_id
			)
		);

		$structure_pages = $this->get_site_structure_page_id_map();
		$pairs = [];
		foreach ( $rows ?: [] as $row ) {
			$post_id_1 = (int) $row->post_id_1;
			$post_id_2 = (int) $row->post_id_2;
			$is_structure_1 = isset( $structure_pages[ $post_id_1 ] );
			$is_structure_2 = isset( $structure_pages[ $post_id_2 ] );
			$primary_post_id = 0;
			$priority_note = '';
			$title_1 = (string) $row->title_1;
			$title_2 = (string) $row->title_2;
			if ( $is_structure_1 || $is_structure_2 ) {
				$primary_post_id = $is_structure_1 ? $post_id_1 : $post_id_2;
				$priority_note = __( 'Conflict with a site structure page. The main structure page has priority; the post has lower value in this conflict.', 'contentgem' );
				if ( $is_structure_1 ) {
					$title_1 .= ' — ' . __( 'Main structure page (priority)', 'contentgem' );
				}
				if ( $is_structure_2 ) {
					$title_2 .= ' — ' . __( 'Main structure page (priority)', 'contentgem' );
				}
			}
			$pairs[] = [
				'id'               => (int) $row->id,
				'post_id_1'        => $post_id_1,
				'post_id_2'        => $post_id_2,
				'similarity_score' => (float) $row->similarity_score,
				'overlap_score'    => (int) $row->overlap_score,
				'status'           => $row->status,
				'title_1'          => $title_1,
				'title_2'          => $title_2,
				'post_status_1'    => $row->post_status_1,
				'post_status_2'    => $row->post_status_2,
				'word_count_1'     => (int) str_word_count( wp_strip_all_tags( (string) $row->content_1 ) ),
				'word_count_2'     => (int) str_word_count( wp_strip_all_tags( (string) $row->content_2 ) ),
				'site_structure_conflict' => $is_structure_1 || $is_structure_2,
				'site_structure_post_1' => $is_structure_1,
				'site_structure_post_2' => $is_structure_2,
				'priority_post_id' => $primary_post_id,
				'priority_note'    => $priority_note,
			];
		}

		$message = count( $pairs ) > 0
			? sprintf( __( '%d posts analysed', 'contentgem' ), $posts_analyzed )
			: sprintf( __( 'No cannibalization found in %d posts', 'contentgem' ), $posts_analyzed );

		$data = [
			'pairs'          => $pairs,
			'posts_analyzed' => $posts_analyzed,
			'message'        => $message,
		];

		set_transient( $cache_key, $data, 30 * MINUTE_IN_SECONDS );

		return rest_ensure_response( $data );
	}

	public function post_merge( WP_REST_Request $request ) {
		global $wpdb;

		$keep_id   = $request->get_param( 'post_id_keep' );
		$remove_id = $request->get_param( 'post_id_remove' );

		$keep_post   = get_post( $keep_id );
		$remove_post = get_post( $remove_id );

		if ( ! $keep_post instanceof WP_Post || ! $remove_post instanceof WP_Post ) {
			return new WP_Error( 'invalid_post', __( 'Invalid post ID.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$note = sprintf(
			"\n\n<!-- Contentgem merge note: content van \"%s\" (ID %d) samengevoegd op %s -->\n%s",
			esc_html( $remove_post->post_title ),
			$remove_id,
			current_time( 'Y-m-d H:i:s' ),
			wp_kses_post( $remove_post->post_content )
		);

		wp_update_post( [
			'ID'           => $keep_id,
			'post_content' => $keep_post->post_content . $note,
		] );

		update_post_meta( $remove_id, '_redirect_to', get_permalink( $keep_id ) );
		update_post_meta( $remove_id, '_redirect_type', '301' );

		wp_trash_post( $remove_id );

		$id_1  = min( $keep_id, $remove_id );
		$id_2  = max( $keep_id, $remove_id );
		$table = $wpdb->prefix . 'cgm_cannibalization';

		$wpdb->update(
			$table,
			[ 'status' => 'merged' ],
			[
				'site_id'   => $this->get_site_id(),
				'post_id_1' => $id_1,
				'post_id_2' => $id_2,
			],
			[ '%s' ],
			[ '%d', '%d', '%d' ]
		);

		do_action( 'contentgem/posts_merged', $keep_id, $remove_id );

		delete_transient( 'contentgem_cannibalization_' . get_current_blog_id() );

		return rest_ensure_response( [ 'success' => true, 'post_id_keep' => $keep_id ] );
	}

	public function post_cannibalization_ignore( WP_REST_Request $request ) {
		global $wpdb;

		$id    = (int) $request->get_param( 'id' );
		$table = $wpdb->prefix . 'cgm_cannibalization';

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d AND site_id = %d", $id, $this->get_site_id() )
		);

		if ( ! $row ) {
			return new WP_Error( 'not_found', __( 'Cannibalization pair not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		$wpdb->update(
			$table,
			[ 'status' => 'ignored' ],
			[ 'id' => $id ],
			[ '%s' ],
			[ '%d' ]
		);

		return rest_ensure_response( [ 'success' => true ] );
	}



	/**
	 * POST /gaps/create-pillar
	 *
	 * Creates a high-priority pillar gap for the given cluster.
	 * The pillar gap represents the main comprehensive article for the cluster topic.
	 * Priority score: 95 (highest possible - above competitor-validated gaps at 70-85)
	 */
	public function post_create_pillar_gap( WP_REST_Request $request ) {
		global $wpdb;

		$cluster = sanitize_text_field( (string) ( $request->get_json_params()['cluster'] ?? '' ) );
		if ( empty( $cluster ) ) {
			return new WP_Error( 'missing_cluster', 'Cluster is required.', [ 'status' => 400 ] );
		}

		// Resolve site_id
		$site_id = (int) get_option( 'cgm_site_id', 0 );
		if ( ! $site_id ) {
			$site_id = (int) $wpdb->get_var( "SELECT id FROM {$wpdb->prefix}cgm_sites ORDER BY id ASC LIMIT 1" );
		}
		if ( ! $site_id ) {
			return new WP_Error( 'no_site', 'Run a site analysis first.', [ 'status' => 422 ] );
		}

		// Resolve topic_id for the cluster
		$topic_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name = %s LIMIT 1",
			$site_id, $cluster
		) );
		if ( ! $topic_id ) {
			$topic_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d ORDER BY id ASC LIMIT 1",
				$site_id
			) );
		}
		if ( ! $topic_id ) {
			return new WP_Error( 'no_topic', 'No topic clusters found. Run a site analysis first.', [ 'status' => 422 ] );
		}

		// Build pillar gap title
		$niche = (string) get_option( 'contentgem_niche', $cluster );
		$title = "The complete guide to {$cluster}";

		// Check if a pillar gap already exists for this cluster
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}cgm_gaps WHERE site_id = %d AND topic_id = %d AND priority_score >= 94 LIMIT 1",
			$site_id, $topic_id
		) );

		if ( $existing ) {
			return new WP_Error( 'pillar_exists', 'A pillar gap already exists for this cluster.', [ 'status' => 409 ] );
		}

		$priority = 95.0;

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'cgm_gaps',
			[
				'site_id'         => $site_id,
				'topic_id'        => $topic_id,
				'suggested_title' => $title,
				'search_intent'   => 'informational',
				'priority_score'  => $priority,
				'status'          => 'open',
			],
			[ '%d', '%d', '%s', '%s', '%f', '%s' ]
		);

		if ( ! $inserted ) {
			return new WP_Error( 'insert_failed', 'Could not create pillar gap.', [ 'status' => 500 ] );
		}

		return rest_ensure_response( [
			'success'        => true,
			'gap_id'         => $wpdb->insert_id,
			'title'          => $title,
			'cluster'        => $cluster,
			'priority_score' => $priority,
		] );
	}

	public function delete_gap( WP_REST_Request $request ) {
		global $wpdb;
		$id = (int) $request->get_param( 'id' );
		if ( ! $id ) {
			return new WP_Error( 'invalid_id', 'Invalid gap ID.', [ 'status' => 400 ] );
		}
		$deleted = $wpdb->delete( $wpdb->prefix . 'cgm_gaps', [ 'id' => $id ], [ '%d' ] );
		if ( false === $deleted ) {
			return new WP_Error( 'delete_failed', 'Could not delete gap.', [ 'status' => 500 ] );
		}
		return rest_ensure_response( [ 'success' => true, 'id' => $id ] );
	}

	public function get_cluster_terms( WP_REST_Request $request ): WP_REST_Response {
		$raw = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$raw = is_array( $raw ) ? $raw : [];

		if ( empty( $raw ) ) {
			$clusters_raw = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
			$clusters_raw = is_array( $clusters_raw ) ? $clusters_raw : [];

			if ( ! empty( $clusters_raw ) ) {
				$raw = $this->build_cluster_terms( $clusters_raw );
			}
		}

		$result = [];
		foreach ( $raw as $cluster_name => $ids ) {
			$cat_id  = (int) ( $ids['category_id'] ?? 0 );
			$tag_id  = (int) ( $ids['tag_id'] ?? 0 );
			$cat_obj = $cat_id > 0 ? get_term( $cat_id, 'category' ) : null;
			$tag_obj = $tag_id > 0 ? get_term( $tag_id, 'post_tag' ) : null;

			$result[] = [
				'cluster_name'  => $cluster_name,
				'category_id'   => $cat_id,
				'category_name' => ( $cat_obj instanceof WP_Term ) ? $cat_obj->name : '',
				'tag_id'        => $tag_id,
				'tag_name'      => ( $tag_obj instanceof WP_Term ) ? $tag_obj->name : '',
			];
		}

		return rest_ensure_response( [ 'terms' => $result ] );
	}

	public function post_cluster_term_rename( WP_REST_Request $request ) {
		$id       = absint( $request->get_param( 'id' ) );
		$name     = CGM_Security::sanitize_term_name( $request->get_param( 'name' ) );
		$taxonomy = sanitize_key( (string) $request->get_param( 'taxonomy' ) );

		if ( ! in_array( $taxonomy, [ 'category', 'post_tag' ], true ) ) {
			return new WP_Error( 'invalid_taxonomy', __( 'Invalid taxonomy.', 'contentgem' ), [ 'status' => 400 ] );
		}
		if ( $id <= 0 || '' === $name ) {
			return new WP_Error( 'invalid_term', __( 'Choose a valid term and name.', 'contentgem' ), [ 'status' => 400 ] );
		}
		$term = get_term( $id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'invalid_term', __( 'Term not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		$result = wp_update_term( $id, $taxonomy, [ 'name' => $name ] );

		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'rename_failed', $result->get_error_message(), [ 'status' => 500 ] );
		}

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function post_cluster_term_delete( WP_REST_Request $request ) {
		$id       = absint( $request->get_param( 'id' ) );
		$taxonomy = sanitize_key( (string) $request->get_param( 'taxonomy' ) );

		if ( ! in_array( $taxonomy, [ 'category', 'post_tag' ], true ) ) {
			return new WP_Error( 'invalid_taxonomy', __( 'Invalid taxonomy.', 'contentgem' ), [ 'status' => 400 ] );
		}
		if ( $id <= 0 ) {
			return new WP_Error( 'invalid_term', __( 'Choose a valid term.', 'contentgem' ), [ 'status' => 400 ] );
		}
		$term = get_term( $id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'invalid_term', __( 'Term not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		$result = wp_delete_term( $id, $taxonomy );

		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'delete_failed', $result->get_error_message(), [ 'status' => 500 ] );
		}

		if ( false === $result ) {
			return new WP_Error( 'not_found', __( 'Term not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function get_drafts( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;

		$site_id = $this->get_site_id();

		// Gap-generated drafts (via Content Gaps flow)
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.id, d.wp_post_id, d.gap_id, d.created_at,
				        g.suggested_title,
				        t.cluster_name,
				        p.post_status, p.post_date, p.post_title, p.post_content
				 FROM {$wpdb->prefix}cgm_drafts d
				 INNER JOIN {$wpdb->prefix}cgm_gaps g ON g.id = d.gap_id AND g.site_id = %d
				 LEFT JOIN {$wpdb->prefix}cgm_topics t ON t.id = g.topic_id
				 LEFT JOIN {$wpdb->posts} p ON p.ID = d.wp_post_id
				 WHERE p.post_status != 'trash' OR p.ID IS NULL
				 ORDER BY d.created_at DESC",
				$site_id
			)
		);

		// AI Assistant drafts (saved directly via WP REST API with _cgm_ai_draft meta)
		$gap_post_ids = array_column( $rows ?? [], 'wp_post_id' );
		$ai_posts = get_posts( [
			'numberposts' => 50,
			'post_status' => [ 'draft', 'publish', 'future', 'private' ],
			'post_type'   => 'post',
			'meta_key'    => '_cgm_ai_draft',
			'meta_value'  => '1',
			'orderby'     => 'date',
			'order'       => 'DESC',
		] );
		$ai_rows = [];
		foreach ( $ai_posts as $p ) {
			if ( in_array( $p->ID, $gap_post_ids ) ) continue; // skip if already in gap drafts
			$ai_rows[] = (object) [
				'id'              => 'ai_' . $p->ID,
				'wp_post_id'      => $p->ID,
				'gap_id'          => null,
				'created_at'      => $p->post_date,
				'suggested_title' => $p->post_title,
				'cluster_name'    => get_post_meta( $p->ID, '_cgm_cluster', true ) ?: 'AI Assistant',
				'post_status'     => $p->post_status,
				'post_date'       => $p->post_date,
				'post_title'      => $p->post_title,
				'post_content'    => $p->post_content,
			];
		}
		$rows = array_merge( $rows ?? [], $ai_rows );

		if ( ! empty( $rows ) ) {
			$drafts = [];
			foreach ( $rows as $row ) {
				$post_id  = (int) $row->wp_post_id;
				$edit_url = get_edit_post_link( $post_id, 'raw' )
					?: admin_url( "post.php?post={$post_id}&action=edit" );

				$post_status = $row->post_status ?? 'draft';
				$drafts[]    = [
					'id'              => (int) $row->id,
					'wp_post_id'      => $post_id,
					'suggested_title' => $row->post_title ?? $row->suggested_title ?? '',
					'cluster_name'    => $row->cluster_name ?? '',
					'post_status'     => $post_status,
					'post_date'       => $row->post_date ?? '',
					'word_count'      => (int) str_word_count( wp_strip_all_tags( (string) $row->post_content ) ),
					'edit_url'        => $edit_url,
					'post_url'        => 'publish' === $post_status ? get_permalink( $post_id ) : '',
				];
			}

			return rest_ensure_response( [ 'drafts' => $drafts ] );
		}

		$meta_posts = $wpdb->get_results(
			"SELECT p.ID AS wp_post_id, p.post_title, p.post_status, p.post_date, p.post_content,
			        pm.meta_value AS gap_id
			 FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			 WHERE pm.meta_key = '_contentgem_gap_id'
			   AND p.post_status != 'trash'
			 ORDER BY p.post_date DESC
			 LIMIT 100"
		);

		return rest_ensure_response( [ 'drafts' => $this->map_wp_posts_to_drafts( $meta_posts ?? [], true ) ] );
	}

	public function post_draft_delete( WP_REST_Request $request ) {
		global $wpdb;

		if ( ! current_user_can( 'delete_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}

		$wp_post_id = (int) $request->get_param( 'wp_post_id' );

		$post = get_post( $wp_post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		wp_trash_post( $wp_post_id );

		$wpdb->delete(
			$wpdb->prefix . 'cgm_drafts',
			[ 'wp_post_id' => $wp_post_id ],
			[ '%d' ]
		);

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function post_draft_publish( WP_REST_Request $request ) {
		if ( ! current_user_can( 'publish_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}

		$wp_post_id = (int) $request->get_param( 'wp_post_id' );

		$post = get_post( $wp_post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		$result = wp_update_post( [ 'ID' => $wp_post_id, 'post_status' => 'publish' ], true );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( [
			'success'  => true,
			'post_url' => get_permalink( $wp_post_id ),
		] );
	}

	public function post_draft_remove_from_dashboard( WP_REST_Request $request ) {
		global $wpdb;

		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}

		$wp_post_id = (int) $request->get_param( 'wp_post_id' );

		$wpdb->delete(
			$wpdb->prefix . 'cgm_drafts',
			[ 'wp_post_id' => $wp_post_id ],
			[ '%d' ]
		);

		delete_post_meta( $wp_post_id, '_contentgem_gap_id' );

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function post_drafts_publish_all( WP_REST_Request $request ) {
		global $wpdb;

		if ( ! current_user_can( 'publish_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}

		// Publish all generated drafts in a robust way:
		// 1) posts tracked in cgm_drafts
		// 2) AI Assistant drafts marked with _cgm_ai_draft
		// 3) legacy Contentgem draft posts marked with _contentgem_gap_id
		$allowed_statuses = [ 'draft', 'pending', 'future', 'private' ];
		$tracked_ids      = $wpdb->get_col(
			"SELECT DISTINCT d.wp_post_id
			 FROM {$wpdb->prefix}cgm_drafts d
			 INNER JOIN {$wpdb->posts} p ON p.ID = d.wp_post_id
			 WHERE p.post_status IN ('draft','pending','future','private')"
		);

		$ai_ids = get_posts( [
			'post_type'      => 'post',
			'post_status'    => $allowed_statuses,
			'numberposts'    => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_key'       => '_cgm_ai_draft',
			'meta_value'     => '1',
		] );

		$legacy_gap_ids = get_posts( [
			'post_type'      => 'post',
			'post_status'    => $allowed_statuses,
			'numberposts'    => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_key'       => '_contentgem_gap_id',
			'orderby'        => 'date',
			'order'          => 'DESC',
		] );

		$post_ids = array_values( array_filter( array_unique( array_map( 'absint', array_merge( (array) $tracked_ids, (array) $ai_ids, (array) $legacy_gap_ids ) ) ) ) );

		$published = 0;
		$failed    = 0;
		$failed_ids = [];
		$matched    = 0;

		foreach ( $post_ids as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post || ! in_array( $post->post_status, $allowed_statuses, true ) ) {
				continue;
			}
			$matched++;
			$result = wp_update_post( [ 'ID' => $post_id, 'post_status' => 'publish' ], true );
			if ( is_wp_error( $result ) ) {
				$failed++;
				$failed_ids[] = $post_id;
			} else {
				$published++;
			}
		}

		return rest_ensure_response( [
			'success'     => true,
			'matched_rows'=> $matched,
			'published'   => $published,
			'failed'      => $failed,
			'failed_ids'  => array_slice( $failed_ids, 0, 20 ),
		] );
	}

	public function post_drafts_import_published( WP_REST_Request $request ) {
		global $wpdb;

		$site_id  = $this->get_site_id();
		$existing = $wpdb->get_col( "SELECT wp_post_id FROM {$wpdb->prefix}cgm_drafts" );
		$posts    = get_posts( [ 'post_status' => 'publish', 'numberposts' => -1, 'post_type' => 'post' ] );
		$imported = 0;

		foreach ( $posts as $post ) {
			if ( in_array( $post->ID, $existing, true ) ) {
				continue;
			}
			$wpdb->insert(
				$wpdb->prefix . 'cgm_drafts',
				[
					'site_id'         => $site_id,
					'wp_post_id'      => $post->ID,
					'suggested_title' => $post->post_title,
					'cluster_name'    => '',
					'status'          => 'published',
				]
			);
			$imported++;
		}

		return rest_ensure_response( [ 'success' => true, 'imported' => $imported ] );
	}

	// - GSC handlers -----------------------------

	public function post_settings_gsc( WP_REST_Request $request ) {
		$current_id     = (string) get_option( 'contentgem_gsc_client_id', '' );
		$current_secret = (string) get_option( 'contentgem_gsc_client_secret', '' );
		$client_id      = trim( (string) $request->get_param( 'client_id' ) );
		$client_secret  = trim( (string) $request->get_param( 'client_secret' ) );
		if ( '' === $client_id ) {
			$client_id = $current_id;
		}
		if ( '' === $client_secret || false !== strpos( $client_secret, '•' ) ) {
			$client_secret = $current_secret;
		}

		if ( '' === $client_id || '' === $client_secret ) {
			return new WP_Error( 'invalid_credentials', __( 'Client ID and Client Secret are required.', 'contentgem' ), [ 'status' => 400 ] );
		}

		update_option( 'contentgem_gsc_client_id', sanitize_text_field( $client_id ), false );
		update_option( 'contentgem_gsc_client_secret', trim( wp_unslash( $client_secret ) ), false );

		$saved_id     = (string) get_option( 'contentgem_gsc_client_id', '' );
		$saved_secret = (string) get_option( 'contentgem_gsc_client_secret', '' );
		$gsc          = new CGM_GSC_Connector();

		return rest_ensure_response( [
			'success'           => '' !== $saved_id && '' !== $saved_secret,
			'client_id_set'     => '' !== $saved_id,
			'client_secret_set' => '' !== $saved_secret,
			'client_id'         => $saved_id,
			'client_secret_mask'=> '' !== $saved_secret ? str_repeat( '•', 24 ) : '',
			'redirect_uri'      => $gsc->get_redirect_uri(),
			'debug'             => $gsc->get_debug_payload(),
		] );
	}

	public function get_gsc_connect( WP_REST_Request $request ) {
		$gsc         = new CGM_GSC_Connector();
		$auth_url    = $gsc->get_auth_url();
		$has_id      = '' !== (string) get_option( 'contentgem_gsc_client_id', '' );
		$has_secret  = '' !== (string) get_option( 'contentgem_gsc_client_secret', '' );

		if ( ! $has_id || ! $has_secret || empty( $auth_url ) ) {
			return new WP_Error( 'no_credentials', __( 'Set and save the Google Client ID and Client Secret first.', 'contentgem' ), [ 'status' => 422 ] );
		}

		return rest_ensure_response( [
			'auth_url'          => $auth_url,
			'redirect_uri'      => $gsc->get_redirect_uri(),
			'client_id_set'     => $has_id,
			'client_secret_set' => $has_secret,
			'debug'             => $gsc->get_debug_payload(),
		] );
	}

	public function get_gsc_callback( WP_REST_Request $request ): void {
		$code      = sanitize_text_field( (string) ( $request->get_param( 'code' ) ?? '' ) );
		$state     = sanitize_text_field( (string) ( $request->get_param( 'state' ) ?? '' ) );
		$error     = sanitize_text_field( (string) ( $request->get_param( 'error' ) ?? '' ) );
		$admin_url = admin_url( 'admin.php?page=contentgem' );

		if ( ! empty( $error ) || empty( $code ) ) {
			wp_safe_redirect( add_query_arg( 'gsc_error', '1', $admin_url ) );
			exit;
		}

		$gsc = new CGM_GSC_Connector();
		$ok  = $gsc->handle_callback( $code, $state );

		wp_safe_redirect( add_query_arg( $ok ? 'gsc_connected' : 'gsc_error', '1', $admin_url ) );
		exit;
	}

	public function get_gsc_sites( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();

		if ( ! $gsc->is_connected() && ! $gsc->refresh_access_token() ) {
			return new WP_Error( 'not_connected', __( 'GSC is not connected.', 'contentgem' ), [ 'status' => 422, 'debug' => $gsc->get_debug_payload() ] );
		}

		$sites = $gsc->get_site_list();
		$site_urls = array_values( array_filter( array_map( static function( $entry ) {
			if ( is_array( $entry ) ) {
				return (string) ( $entry['url'] ?? '' );
			}
			return is_string( $entry ) ? $entry : '';
		}, $sites ) ) );

		return rest_ensure_response( [ 'sites' => $site_urls, 'site_entries' => $sites, 'connected' => $gsc->is_connected(), 'debug' => $gsc->get_debug_payload() ] );
	}

	public function post_gsc_select_site( WP_REST_Request $request ) {
		$site_url = CGM_Security::sanitize_gsc_property( $request->get_param( 'site_url' ) );

		if ( '' === $site_url ) {
			return new WP_Error( 'invalid_site', __( 'Choose a valid property.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$gsc = new CGM_GSC_Connector();
		$sites = $gsc->get_site_list();
		$allowed_sites = array_values( array_filter( array_map( static function( $entry ) {
			if ( is_array( $entry ) ) {
				return CGM_Security::sanitize_gsc_property( (string) ( $entry['url'] ?? '' ) );
			}
			return CGM_Security::sanitize_gsc_property( is_string( $entry ) ? $entry : '' );
		}, is_array( $sites ) ? $sites : [] ) ) );

		if ( ! empty( $allowed_sites ) && ! in_array( $site_url, $allowed_sites, true ) ) {
			return new WP_Error( 'invalid_site', __( 'Choose a valid property from Google Search Console.', 'contentgem' ), [ 'status' => 400 ] );
		}

		update_option( 'contentgem_gsc_site_url', $site_url, false );

		return rest_ensure_response( [ 'success' => true, 'site_url' => $site_url ] );
	}

	public function delete_gsc_disconnect( WP_REST_Request $request ): WP_REST_Response {
		$gsc = new CGM_GSC_Connector();
		$gsc->disconnect();

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function get_gsc_queries( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();

		if ( ! $gsc->is_connected() ) {
			return new WP_Error( 'not_connected', __( 'GSC is not connected.', 'contentgem' ), [ 'status' => 422 ] );
		}

		$limit   = max( 1, min( 1000, (int) $request->get_param( 'limit' ) ) );
		$queries = $gsc->get_top_queries( $limit );

		return rest_ensure_response( [ 'queries' => $queries, 'total' => count( $queries ) ] );
	}

	// - Broken-link scanner -------------------------â"€

	public function get_broken_links( WP_REST_Request $request ): WP_REST_Response {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', '', [ 'status' => 403 ] );
		}

		$cached = get_transient( 'contentgem_broken_links' );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		return rest_ensure_response( $this->run_broken_link_scan() );
	}

	public function post_broken_links_scan( WP_REST_Request $request ): WP_REST_Response {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', '', [ 'status' => 403 ] );
		}

		delete_transient( 'contentgem_broken_links' );

		return rest_ensure_response( $this->run_broken_link_scan() );
	}

	public function post_broken_links_fix( WP_REST_Request $request ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', '', [ 'status' => 403 ] );
		}

		$source_post_id = absint( $request->get_param( 'source_post_id' ) );
		$broken_url     = sanitize_url( $request->get_param( 'broken_url' ) );
		$new_url        = sanitize_url( $request->get_param( 'new_url' ) );
		$new_title      = sanitize_text_field( $request->get_param( 'new_title' ) ?? '' );

		$scanner = new CGM_Link_Scanner();
		$success = $scanner->fix_link( $source_post_id, $broken_url, $new_url, $new_title );

		if ( ! $success ) {
			return new WP_Error( 'fix_failed', __( 'Link could not be updated.', 'contentgem' ), [ 'status' => 500 ] );
		}

		delete_transient( 'contentgem_broken_links' );

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Link updated.', 'contentgem' ),
		] );
	}

	private function run_broken_link_scan(): array {
		$scanner      = new CGM_Link_Scanner();
		$broken_links = $scanner->scan_broken_internal_links();
		$post_count   = (int) wp_count_posts( 'post' )->publish;

		$this->persist_broken_links_cache( $broken_links );
		$this->sync_gap_broken_link_flags_from_cache();
		$this->flush_gap_related_transients();

		$result = [
			'links'         => $broken_links,
			'total'         => count( $broken_links ),
			'scanned_posts' => $post_count,
		];

		set_transient( 'contentgem_broken_links', $result, 10 * MINUTE_IN_SECONDS );
		set_transient( 'contentgem_broken_links_simple', $this->get_broken_links_simple_payload(), 10 * MINUTE_IN_SECONDS );

		return $result;
	}

	private function persist_broken_links_cache( array $broken_links ): void {
		global $wpdb;

		$site_id = $this->get_site_id();
		$table   = $wpdb->prefix . 'cgm_broken_links_cache';
		$now     = current_time( 'mysql' );

		$wpdb->delete( $table, [ 'site_id' => $site_id ], [ '%d' ] );

		foreach ( $broken_links as $link ) {
			$url        = (string) ( $link['broken_url'] ?? '' );
			$anchor     = sanitize_text_field( (string) ( $link['anchor_text'] ?? '' ) );
			$slug       = trim( basename( (string) parse_url( $url, PHP_URL_PATH ) ), '/' );
			$slug_text  = strtolower( str_replace( [ '-', '_' ], ' ', $slug ) );
			$source_id  = (int) ( $link['source_post_id'] ?? 0 );

			if ( '' === $url ) {
				continue;
			}

			$wpdb->insert(
				$table,
				[
					'site_id'        => $site_id,
					'source_post_id' => $source_id,
					'broken_url'     => $url,
					'anchor_text'    => strtolower( $anchor ),
					'slug_text'      => $slug_text,
					'first_seen_at'  => $now,
					'last_seen_at'   => $now,
				],
				[ '%d', '%d', '%s', '%s', '%s', '%s', '%s' ]
			);
		}
	}

	private function get_broken_links_simple_payload(): array {
		global $wpdb;

		$site_id = $this->get_site_id();
		$table   = $wpdb->prefix . 'cgm_broken_links_cache';
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT broken_url, anchor_text, slug_text FROM {$table} WHERE site_id = %d",
				$site_id
			)
		);

		return array_map( static function( $row ) {
			return [
				'broken_url'  => (string) ( $row->broken_url ?? '' ),
				'anchor_text' => strtolower( (string) ( $row->anchor_text ?? '' ) ),
				'slug_text'   => strtolower( (string) ( $row->slug_text ?? '' ) ),
			];
		}, (array) $rows );
	}

	private function sync_gap_broken_link_flags_from_cache(): void {
		global $wpdb;

		$site_id            = $this->get_site_id();
		$broken_links_simple = $this->get_broken_links_simple_payload();
		$gaps               = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT g.id, g.suggested_title, g.topic_id, t.cluster_name
				 FROM {$wpdb->prefix}cgm_gaps g
				 LEFT JOIN {$wpdb->prefix}cgm_topics t ON g.topic_id = t.id
				 WHERE g.site_id = %d AND g.status = 'open'",
				$site_id
			)
		);

		foreach ( (array) $gaps as $gap ) {
			$calculated_broken = false;
			$calculated_url    = '';
			$title_lc          = strtolower( (string) ( $gap->suggested_title ?? '' ) );
			$cluster_lc        = strtolower( (string) ( $gap->cluster_name ?? '' ) );
			$title_field       = (string) ( $gap->suggested_title ?? '' );

			foreach ( $broken_links_simple as $bl ) {
				foreach ( [ $bl['anchor_text'], $bl['slug_text'] ] as $check ) {
					if ( '' === (string) $check ) {
						continue;
					}
					$sim = 0;
					similar_text( $title_lc, (string) $check, $sim );
					if ( $sim > 50 ) {
						$calculated_broken = true;
						$calculated_url    = (string) ( $bl['broken_url'] ?? '' );
						break 2;
					}
					similar_text( $cluster_lc, (string) $check, $sim );
					if ( $sim > 50 ) {
						$calculated_broken = true;
						$calculated_url    = (string) ( $bl['broken_url'] ?? '' );
						break 2;
					}
				}
			}

			$update = [
				'fixes_broken_link' => $calculated_broken ? 1 : 0,
				'broken_url'        => $calculated_broken ? $calculated_url : null,
			];
			$formats = [ '%d', '%s' ];
			if ( $calculated_broken && '' !== $calculated_url ) {
				$slug                  = trim( basename( (string) parse_url( $calculated_url, PHP_URL_PATH ) ), '/' );
				$update['suggested_title'] = ucwords( str_replace( [ '-', '_' ], ' ', $slug ) );
				$formats[]             = '%s';
			}

			$wpdb->update( $wpdb->prefix . 'cgm_gaps', $update, [ 'id' => (int) $gap->id ], $formats, [ '%d' ] );
		}
	}

	private function flush_gap_related_transients(): void {
		global $wpdb;

		$option_like = $wpdb->esc_like( '_transient_contentgem_gaps_' ) . '%';
		$timeout_like = $wpdb->esc_like( '_transient_timeout_contentgem_gaps_' ) . '%';
		$cluster_like = $wpdb->esc_like( '_transient_contentgem_clusters_' ) . '%';
		$cluster_timeout_like = $wpdb->esc_like( '_transient_timeout_contentgem_clusters_' ) . '%';

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s", $option_like, $timeout_like, $cluster_like, $cluster_timeout_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	// - Internal link suggestions ----------------------â"€

	public function get_link_suggestions( WP_REST_Request $request ) {
		$post_id = (int) ( $request->get_param( 'source_post_id' ) ?: $request->get_param( 'post_id' ) );
		$forced_target_id = (int) ( $request->get_param( 'forced_target_id' ) ?: 0 );
		$forced_pillar_url = (string) ( $request->get_param( 'forced_pillar_url' ) ?: $request->get_param( 'pillar_url' ) ?: '' );

		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		if ( $forced_target_id > 0 && '' === $forced_pillar_url ) {
			$forced_pillar_url = (string) get_permalink( $forced_target_id );
		}

		$scanner     = new CGM_Link_Scanner();
		$suggestions = $scanner->get_link_suggestions( $post_id, $forced_pillar_url );
		if ( $forced_target_id > 0 ) {
			$forced_title = (string) get_the_title( $forced_target_id );
			$forced_url   = (string) get_permalink( $forced_target_id );
			$forced_entry = [
				'source_post_id' => $post_id,
				'target_post_id' => $forced_target_id,
				'target_title'   => $forced_title,
				'target_url'     => $forced_url,
				'anchor_text'    => $forced_title,
				'match_score'    => 1000,
				'context_hint'   => 'Selected pillar page',
			];
			$suggestions = array_values( array_filter( (array) $suggestions, static function( $row ) use ( $forced_target_id ) {
				return (int) ( $row['target_post_id'] ?? 0 ) !== $forced_target_id;
			} ) );
			array_unshift( $suggestions, $forced_entry );
		}

		$data = [
			'post_id'          => $post_id,
			'source_post_id'   => $post_id,
			'post_title'       => $post->post_title,
			'forced_target_id' => $forced_target_id,
			'suggestions'      => array_slice( $suggestions, 0, 10 ),
			'total'            => count( $suggestions ),
		];
		return rest_ensure_response( $data );
	}

	// - Insert link suggestion ------------------------

	public function post_insert_link_suggestion( WP_REST_Request $request ) {
		$source_post_id = (int) $request->get_param( 'source_post_id' );
		$anchor_text    = sanitize_text_field( $request->get_param( 'anchor_text' ) );
		$target_url     = sanitize_url( $request->get_param( 'target_url' ) );

		$post = get_post( $source_post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		if ( strpos( $post->post_content, $target_url ) !== false ) {
			return new WP_Error( 'already_linked', __( 'This link already exists in the post.', 'contentgem' ), [ 'status' => 409 ] );
		}

		$link        = '<a href="' . esc_url( $target_url ) . '">' . esc_html( $anchor_text ) . '</a>';
		$new_content = preg_replace(
			'/' . preg_quote( $anchor_text, '/' ) . '/i',
			$link,
			$post->post_content,
			1
		);

		if ( $new_content === null || $new_content === $post->post_content ) {
			return new WP_Error( 'not_found_in_content', __( 'Anchor text not found in post content.', 'contentgem' ), [ 'status' => 422 ] );
		}

		$result = wp_update_post( [
			'ID'           => $source_post_id,
			'post_content' => $new_content,
		], true );

		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'update_failed', $result->get_error_message(), [ 'status' => 500 ] );
		}

		delete_transient( 'contentgem_link_suggestions_' . $source_post_id );

		return rest_ensure_response( [
			'success'    => true,
			'post_id'    => $source_post_id,
			'anchor'     => $anchor_text,
			'target_url' => $target_url,
		] );
	}

	// - Fix internal links --------------------------

	public function post_fix_internal_links( WP_REST_Request $request ): WP_REST_Response {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', '', [ 'status' => 403 ] );
		}

		$fixed         = 0;
		$posts_updated = 0;
		$paged         = 1;

		do {
			$posts = get_posts( [
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'paged'          => $paged,
				'fields'         => 'ids',
			] );

			foreach ( $posts as $post_id ) {
				$content = get_post_field( 'post_content', $post_id );
				$count   = 0;

				$new_content = preg_replace_callback(
					'/href=["\']([^"\']*\?p=(\d+))["\']/',
					function ( $matches ) use ( &$count ) {
						$linked_id = intval( $matches[2] );
						$permalink = get_permalink( $linked_id );
						if ( $permalink ) {
							$count++;
							return 'href="' . esc_url( $permalink ) . '"';
						}
						return $matches[0];
					},
					$content
				);

				if ( $count > 0 ) {
					wp_update_post( [
						'ID'           => $post_id,
						'post_content' => $new_content,
					] );
					$fixed        += $count;
					$posts_updated++;
				}
			}

			$paged++;
		} while ( count( $posts ) === 100 );

		return rest_ensure_response( [
			'fixed'         => $fixed,
			'posts_updated' => $posts_updated,
		] );
	}

	// - Broken-links generate draft ---------------------â"€

	public function post_broken_links_generate_draft( WP_REST_Request $request ) {
		$broken_url     = sanitize_text_field( $request->get_param( 'broken_url' ) ?? '' );
		$anchor_text    = sanitize_text_field( $request->get_param( 'anchor_text' ) ?? '' );
		$source_post_id = intval( $request->get_param( 'source_post_id' ) ?? 0 );

		$slug  = trim( basename( parse_url( $broken_url, PHP_URL_PATH ) ), '/' );
		$title = ! empty( $anchor_text ) ? $anchor_text : ucwords( str_replace( '-', ' ', $slug ) );

		try {
			$niche  = get_option( 'contentgem_niche', '' );
			$client = new CGM_Claude_Client( $this->get_api_key() );

			$prompt  = "Write a complete SEO article about: \"{$title}\"\n";
			$prompt .= "The URL of this article should be: /{$slug}/\n";
			$prompt .= "Use '{$title}' as H1 and in the first paragraph.\n";
			if ( ! empty( $niche ) ) $prompt .= "Context: website about {$niche}.\n";
			$prompt .= "Minimum 1000 words. FAQ section at the end in accordion format using <details><summary>Question</summary><div><p>Answer</p></div></details>. No duplicate H1 in body.";

			$system_prompt = 'You are an expert SEO content writer.';
			$result        = $client->generate_article( $system_prompt, $prompt );

			$body_html   = $result['html'] ?? '';
			$tokens_used = (int) ( $result['tokens_used'] ?? 0 );

			$body_html = preg_replace( '/<h1[^>]*>.*?<\/h1>/is', '', $body_html, 1 );

			$post_id = wp_insert_post( [
				'post_title'   => $title,
				'post_content' => wp_kses_post( $body_html ),
				'post_status'  => 'draft',
				'post_name'    => sanitize_title( $slug ),
				'post_type'    => $content_type,
			] );

			if ( is_wp_error( $post_id ) ) {
				return new WP_Error( 'draft_failed', $post_id->get_error_message(), [ 'status' => 500 ] );
			}

			$builder_integrator = new CGM_Builder_Integrator();
			$builder_mode = $builder_integrator->sync_generated_post(
				(int) $post_id,
				(string) $body_html,
				[
					'post_type'    => $content_type,
					'builder_mode' => sanitize_key( (string) ( $request->get_param( 'builder_mode' ) ?? 'auto' ) ),
				]
			);
			update_post_meta( $post_id, '_contentgem_builder_mode', $builder_mode );

			$new_url = get_permalink( $post_id );

			if ( $source_post_id > 0 ) {
				$scanner = new CGM_Link_Scanner();
				$scanner->fix_link( $source_post_id, $broken_url, $new_url );
			}

			$tokens = new CGM_Token_Manager( get_current_user_id() );
			$tokens->deduct( $tokens_used );

			delete_transient( 'contentgem_broken_links' );
			delete_transient( 'contentgem_broken_links_simple' );

			do_action( 'contentgem/draft_created', $post_id, 0 );

			return rest_ensure_response( [
				'success'    => true,
				'wp_post_id' => $post_id,
				'new_url'    => $new_url,
				'slug'       => $slug,
			] );

		} catch ( \Throwable $e ) {
			$this->release_free_generation_slot( get_current_user_id() );
			if ( strpos( $e->getMessage(), 'No API key' ) === 0 ) {
				return new WP_Error( 'no_api_key', __( 'Add your Anthropic API key in Settings first.', 'contentgem' ), [ 'status' => 422 ] );
			}
			return new WP_Error( 'generation_failed', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	// - AI Assistant handlers -------------------------

	public function post_assistant_chat( WP_REST_Request $request ): void {
		set_time_limit( 0 );
		ini_set( 'max_execution_time', '0' );
		ignore_user_abort( true );

		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		header( 'X-Accel-Buffering: no' );

		$body    = $request->get_json_params();
		$message = sanitize_text_field( $body['message'] ?? '' );
		$history = is_array( $body['history'] ?? null ) ? $body['history'] : [];

		if ( empty( $message ) ) {
			echo "data: " . wp_json_encode( [ 'type' => 'error', 'message' => 'Message is required.' ] ) . "\n\n";
			echo "data: [DONE]\n\n";
			exit;
		}

		$tokens   = new CGM_Token_Manager( get_current_user_id() );
		$messages = [];

		foreach ( $history as $hist ) {
			$role    = in_array( $hist['role'] ?? '', [ 'user', 'assistant' ], true ) ? $hist['role'] : 'user';
			$content = sanitize_textarea_field( $hist['content'] ?? '' );
			if ( '' !== $content ) {
				$messages[] = [ 'role' => $role, 'content' => $content ];
			}
		}
		$messages[] = [ 'role' => 'user', 'content' => $message ];

		$niche         = (string) get_option( 'contentgem_niche', 'general' );
		$system_prompt = 'You are a WordPress SEO assistant that helps with optimising content. '
		                 . "Website niche: {$niche}. Always reply in the language of the user.";
		if ( ( new CGM_Feature_Flags() )->fact_check_enabled() ) {
			$system_prompt .= "

" . ( new CGM_Fact_Checker() )->build_instruction_appendix( ( new CGM_Language_Service() )->get_language_code() );
		}

		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );
			$result = $client->chat_stream( $messages, $system_prompt, function ( string $chunk ) {
				echo "data: " . wp_json_encode( [ 'type' => 'chunk', 'content' => $chunk ] ) . "\n\n";
				if ( ob_get_level() > 0 ) ob_flush();
				flush();
			} );

			$tokens->deduct( $result['tokens_used'] );

			echo "data: " . wp_json_encode( [ 'type' => 'done' ] ) . "\n\n";
		} catch ( \Throwable $e ) {
			$this->release_free_generation_slot( get_current_user_id() );
			if ( strpos( $e->getMessage(), 'No API key' ) === 0 ) {
				echo "data: " . wp_json_encode( [ 'type' => 'error', 'code' => 'no_api_key', 'message' => 'Add your Anthropic API key in Settings first.' ] ) . "\n\n";
			} else {
				echo "data: " . wp_json_encode( [ 'type' => 'error', 'message' => $e->getMessage() ] ) . "\n\n";
			}
		}

		echo "data: [DONE]\n\n";
		exit;
	}

	public function post_assistant_meta_description( WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$post    = get_post( $post_id );

		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		try {
			$language_service = new CGM_Language_Service();
			$rules = $language_service->build_language_rules( $language_service->get_language_code() );
			$title           = sanitize_text_field( $post->post_title );
			$content_excerpt = sanitize_textarea_field( mb_substr( wp_strip_all_tags( $post->post_content ), 0, 500 ) );
			$client          = CGM_AI_Client::from_settings();
			$result          = $client->chat(
				[[
					'role' => 'user',
					'content' => "Write one SEO meta description under 160 characters.
{$rules}
Title: {$title}
Excerpt: {$content_excerpt}
Return valid JSON only with keys: meta_description"
				]],
				'You generate concise SEO meta descriptions and return JSON only.',
				120
			);
			$decoded = json_decode( (string) ( $result['text'] ?? '' ), true );
			$meta = sanitize_text_field( (string) ( $decoded['meta_description'] ?? '' ) );
			if ( '' === $meta ) {
				$meta = sanitize_text_field( mb_substr( $content_excerpt, 0, 155 ) );
			}
			return rest_ensure_response( [ 'meta_description' => $meta, 'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ), 'provider' => $client->get_provider() ] );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'meta_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}


	private function cgm_ai_cache_key( string $prefix, array $payload ): string {
		return 'cgm_ai_' . $prefix . '_' . md5( wp_json_encode( $payload ) . '|' . get_current_blog_id() );
	}

	private function cgm_get_cached_ai_result( string $prefix, array $payload ) {
		return CGM_Cache::get( $this->cgm_ai_cache_key( $prefix, $payload ) );
	}

	private function cgm_set_cached_ai_result( string $prefix, array $payload, $value, int $ttl = 3600 ): void {
		CGM_Cache::set( $this->cgm_ai_cache_key( $prefix, $payload ), $value, $ttl );
	}

	private function generate_ai_semantic_keywords( string $topic, string $cluster_name = '' ): array {
		$topic = sanitize_text_field( $topic );
		$cluster_name = sanitize_text_field( $cluster_name );
		if ( '' === $topic ) {
			return [];
		}
		$cache_payload = [ 'topic' => $topic, 'cluster' => $cluster_name, 'type' => 'semantic_keywords' ];
		$cached = $this->cgm_get_cached_ai_result( 'semantic_keywords', $cache_payload );
		if ( is_array( $cached ) ) {
			return $this->filter_semantic_keyword_list( $cached );
		}
		try {
			$client = CGM_AI_Client::from_settings();
			$language_service = new CGM_Language_Service();
			$result = $client->chat(
				[
					[
						'role' => 'user',
						'content' => "Return exactly 10 concise semantic SEO support terms for this topic as a JSON array of strings.\n"
							. "Topic: {$topic}
"
							. ( $cluster_name ? "Cluster context: {$cluster_name}\n" : '' )
							. $language_service->build_language_rules( $language_service->get_language_code() ) . "\n"
							. "Rules: return only a JSON array of strings; no markdown; no explanations; prefer related entities, modifiers, subtopics and search refinements; do not repeat the main keyword verbatim more than once.",
					],
				],
				'You generate compact semantic keyword support lists for SEO drafting. Return only valid JSON.',
				180
			);
			$items = $this->cgm_extract_json_array( (string) ( $result['text'] ?? '' ) );
			$normalized = [];
			foreach ( $items as $item ) {
				if ( is_string( $item ) ) {
					$normalized[] = sanitize_text_field( $item );
				} elseif ( is_array( $item ) && ! empty( $item['keyword'] ) ) {
					$normalized[] = sanitize_text_field( (string) $item['keyword'] );
				}
			}
			$normalized = array_values( array_slice( array_unique( array_filter( $normalized ) ), 0, 10 ) );
			if ( ! empty( $normalized ) ) {
				$this->cgm_set_cached_ai_result( 'semantic_keywords', $cache_payload, $normalized, HOUR_IN_SECONDS );
			}
			return $normalized;
		} catch ( \Throwable $e ) {
			return [];
		}
	}

	private function cgm_extract_json_array( string $text ): array {
		$text = trim( $text );
		if ( '' === $text ) {
			return [];
		}
		$decoded = json_decode( $text, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}
		if ( preg_match( '/\[.*\]/s', $text, $m ) ) {
			$decoded = json_decode( $m[0], true );
			return is_array( $decoded ) ? $decoded : [];
		}
		return [];
	}

	private function cgm_normalize_title_keyword_suggestions( array $items, string $fallback_keyword = '', string $language_code = 'en', string $cluster = '', string $niche = '' ): array {
		$normalized = [];
		$seen       = [];
		$title_quality = new CGM_Title_Quality_Service( new CGM_Language_Service() );
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$title     = $title_quality->normalize_title( sanitize_text_field( (string) ( $item['title'] ?? '' ) ), $language_code );
			$keyword   = $title_quality->normalize_keyword( sanitize_text_field( (string) ( $item['keyword'] ?? '' ) ) );
			$rationale = sanitize_text_field( (string) ( $item['rationale'] ?? '' ) );
			if ( '' === $title && '' === $keyword ) {
				continue;
			}
			if ( '' === $keyword ) {
				$keyword = '' !== $fallback_keyword ? $title_quality->normalize_keyword( $fallback_keyword ) : $title;
			}
			if ( '' !== $title && ! $title_quality->is_valid_title( $title, $language_code, $cluster ) ) {
				continue;
			}
			$key = strtolower( $title . '|' . $keyword );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$normalized[] = [
				'title'     => $title,
				'keyword'   => $keyword,
				'rationale' => $rationale,
			];
			if ( count( $normalized ) >= 5 ) {
				break;
			}
		}
		if ( empty( $normalized ) ) {
			$normalized = $this->cgm_build_fallback_title_keyword_suggestions( $fallback_keyword, $cluster, $language_code, $niche );
		}
		return $normalized;
	}

	private function cgm_title_matches_language_heuristic( string $text, string $language_code ): bool {
		$language_service = new CGM_Language_Service();
		return $language_service->validate_output_language( $text, $language_code );
	}

	private function cgm_build_fallback_title_keyword_suggestions( string $keyword, string $cluster, string $language_code, string $niche = '' ): array {
		$seed = '' !== trim( $keyword ) ? $keyword : $cluster;
		$seed = $this->cgm_humanize_phrase( $seed );
		$variants = $this->cgm_build_gap_title_blueprints( $seed, $cluster, $language_code, $niche, false );
		$title_quality = new CGM_Title_Quality_Service( new CGM_Language_Service() );
		$out = [];
		foreach ( $variants as $variant ) {
			$title = $title_quality->normalize_title( sanitize_text_field( (string) ( $variant['title'] ?? '' ) ), $language_code );
			if ( ! $title_quality->is_valid_title( $title, $language_code, $cluster ) ) {
				continue;
			}
			$out[] = [
				'title' => $title,
				'keyword' => $title_quality->normalize_keyword( '' !== $keyword ? $keyword : $seed ),
				'rationale' => 'nl' === $language_code ? 'Aangescherpt op basis van de ingestelde contenttaal en zoekintentie.' : 'Refined to match the configured content language and search intent.',
			];
			if ( count( $out ) >= 3 ) {
				break;
			}
		}
		return $out;
	}

	public function post_assistant_title_keyword_suggestions( WP_REST_Request $request ) {
		$body    = $request->get_json_params();
		$title   = sanitize_text_field( $body['title'] ?? '' );
		$keyword = sanitize_text_field( $body['keyword'] ?? '' );
		$cluster = sanitize_text_field( $body['cluster'] ?? '' );

		if ( '' === $title && '' === $keyword && '' === $cluster ) {
			return new WP_Error( 'invalid_context', __( 'Enter a title, keyword or cluster first.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$language_service = new CGM_Language_Service();
		$title_quality    = new CGM_Title_Quality_Service( $language_service );
		$language_code    = $language_service->get_language_code();
		$language_label   = $language_service->get_language_label( $language_code );
		$niche = sanitize_text_field( (string) get_option( 'contentgem_niche', get_bloginfo( 'name' ) ) );
		$errors = [];
		$cache_payload = [ $title, $keyword, $cluster, $language_label, 'title_keyword_suggestions_v2' ];
		$cache_key = $this->cgm_ai_cache_key( 'title_keyword_suggestions', $cache_payload );
		$cached    = CGM_Cache::get( $cache_key );
		if ( is_array( $cached ) && ! empty( $cached['suggestions'] ) ) {
			$cached['cached'] = true;
			return rest_ensure_response( $cached );
		}

		if ( $this->use_openai_task_stack() ) {
			try {
				$result = $this->run_openai_task( 'title_suggestions', [
					[ 'role' => 'user', 'content' => implode( "
", array_filter( [
						$title ? 'Current title: ' . $title : '',
						$keyword ? 'Primary keyword: ' . $keyword : '',
						$cluster ? 'Cluster: ' . $cluster : '',
					] ) ) ],
				], [ 'cache_hints' => [ $title, $keyword, $cluster ] ] );
				$suggestions = $this->cgm_normalize_title_keyword_suggestions( (array) ( $result['data']['suggestions'] ?? [] ), $keyword, $language_code, $cluster, sanitize_text_field( (string) get_option( 'contentgem_niche', get_bloginfo( 'name' ) ) ) );
				if ( ! empty( $suggestions ) ) {
					$payload = [
						'suggestions' => $suggestions,
						'cached' => false,
						'tokens_used' => (int) ( $result['usage']['total_tokens'] ?? 0 ),
						'provider' => 'openai',
						'model' => (string) ( $result['meta']['model'] ?? '' ),
						'sources' => (array) ( $result['sources'] ?? [] ),
						'usage' => (array) ( $result['usage'] ?? [] ),
					];
					CGM_Cache::set( $cache_key, $payload, HOUR_IN_SECONDS );
					return rest_ensure_response( $payload );
				}
			} catch ( \Throwable $e ) {
				$errors[] = $e->getMessage();
			}
		}

		$context_bits = array_filter( [
			$cluster ? 'Cluster: ' . $cluster : '',
			$title ? 'Current title: ' . $title : '',
			$keyword ? 'Primary keyword: ' . $keyword : '',
		] );
		$rules = $language_service->build_language_rules( $language_code );
		$payload = null;
		foreach ( [ 'strict', 'very strict' ] as $pass ) {
			try {
				$client = CGM_AI_Client::from_settings();
				$result = $client->chat(
					[
						[
							'role'    => 'user',
							'content' => "Return 3 SEO title + primary keyword suggestions as a compact JSON array.
"
								. "Niche: {$niche}
"
								. $rules . "
"
								. implode( "
", $context_bits ) . "
"
								. "Rules: natural titles, specific search intent, one concise rationale per item, no markdown, no placeholders, no generic labels, no mixed-language output, match the configured content language {$pass}.
"
								. 'Schema: [{"title":"...","keyword":"...","rationale":"..."}]',
						],
					],
					'You generate fast, compact SEO title options. Return only valid JSON.',
					180
				);
				$items       = $this->cgm_extract_json_array( (string) ( $result['text'] ?? '' ) );
				$suggestions = $this->cgm_normalize_title_keyword_suggestions( $items, $keyword, $language_code, $cluster, $niche );
				if ( ! empty( $suggestions ) ) {
					$valid = true;
					foreach ( $suggestions as $s ) {
						if ( ! $title_quality->is_valid_title( (string) ( $s['title'] ?? '' ), $language_code, $cluster ) ) {
							$valid = false;
							break;
						}
					}
					if ( $valid ) {
						$payload = [
							'suggestions' => $suggestions,
							'cached'      => false,
							'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
							'provider'    => $client->get_provider(),
						];
						break;
					}
				}
			} catch ( \Throwable $e ) {
				$errors[] = $e->getMessage();
			}
		}
		if ( null === $payload ) {
			$suggestions = $this->cgm_build_fallback_title_keyword_suggestions( $keyword, $cluster, $language_code, $niche );
			if ( empty( $suggestions ) ) {
				return new WP_Error( 'title_suggestions_error', ! empty( $errors ) ? implode( ' | ', $errors ) : __( 'AI did not return usable title suggestions.', 'contentgem' ), [ 'status' => 500 ] );
			}
			$payload = [
				'suggestions' => $suggestions,
				'cached'      => false,
				'tokens_used' => 0,
				'provider'    => 'fallback',
			];
		}
		CGM_Cache::set( $cache_key, $payload, HOUR_IN_SECONDS );
		return rest_ensure_response( $payload );
	}

	public function post_assistant_semantic_keywords( WP_REST_Request $request ) {
		$body    = $request->get_json_params();
		$topic   = sanitize_text_field( $body['topic'] ?? '' );
		$keyword = sanitize_text_field( $body['keyword'] ?? '' );
		$title   = sanitize_text_field( $body['title'] ?? '' );
		$cluster = sanitize_text_field( $body['cluster'] ?? '' );

		$topic = $topic ?: $keyword ?: $title;
		if ( '' === $topic ) {
			return new WP_Error( 'invalid_topic', __( 'Enter or select a keyword first.', 'contentgem' ), [ 'status' => 400 ] );
		}

		if ( $this->use_openai_task_stack() ) {
			try {
				$result = $this->run_openai_task( 'semantic_keyword_suggestions', [
					[ 'role' => 'user', 'content' => implode( "
", array_filter( [
						'Topic: ' . $topic,
						$keyword ? 'Primary keyword: ' . $keyword : '',
						$title ? 'Title: ' . $title : '',
						$cluster ? 'Cluster: ' . $cluster : '',
					] ) ) ],
				], [ 'cache_hints' => [ $topic, $keyword, $cluster ] ] );
				$keywords = array_values( array_slice( array_filter( array_map( 'sanitize_text_field', (array) ( $result['data']['keywords'] ?? [] ) ) ), 0, 12 ) );
				if ( ! empty( $keywords ) ) {
					return rest_ensure_response( [
						'keywords' => $keywords,
						'topic' => $topic,
						'cluster' => $cluster,
						'sources' => (array) ( $result['sources'] ?? [] ),
						'usage' => (array) ( $result['usage'] ?? [] ),
						'model' => (string) ( $result['meta']['model'] ?? '' ),
					] );
				}
			} catch ( \Throwable $e ) {
				$this->log_debug( 'semantic_keyword_suggestions_openai_failed', [ 'message' => $e->getMessage() ] );
			}
		}

		$keywords = $this->derive_semantic_keywords( $topic, $cluster, $this->get_site_id() );
		$keywords = array_values( array_slice( array_filter( array_map( 'sanitize_text_field', (array) $keywords ) ), 0, 12 ) );

		return rest_ensure_response( [
			'keywords' => $keywords,
			'topic'    => $topic,
			'cluster'  => $cluster,
		] );
	}

	public function post_assistant_optimize_title( WP_REST_Request $request ) {
		$body          = $request->get_json_params();
		$title         = sanitize_text_field( $body['title'] ?? '' );
		$focus_keyword = sanitize_text_field( $body['focus_keyword'] ?? '' );

		if ( empty( $title ) ) {
			return new WP_Error( 'invalid_title', __( 'Title is required.', 'contentgem' ), [ 'status' => 400 ] );
		}

		try {
			$language_service = new CGM_Language_Service();
			$title_quality    = new CGM_Title_Quality_Service( $language_service );
			$language_code    = $language_service->get_language_code();
			$rules            = $language_service->build_language_rules( $language_code );
			$client = CGM_AI_Client::from_settings();
			$result = $client->chat(
				[[
					'role' => 'user',
					'content' => "Optimize this SEO title for clickability, clarity and search intent.
{$rules}
Current title: {$title}
Primary keyword: {$focus_keyword}
Return valid JSON only with keys: title, rationale"
				]],
				'You optimize SEO titles and return concise JSON only.',
				120
			);
			$decoded = json_decode( (string) ( $result['text'] ?? '' ), true );
			$optimized = is_array( $decoded ) ? sanitize_text_field( (string) ( $decoded['title'] ?? '' ) ) : '';
			$optimized = $title_quality->normalize_title( $optimized ?: $title, $language_code );
			if ( ! $title_quality->is_valid_title( $optimized, $language_code ) ) {
				$optimized = $title_quality->normalize_title( $title, $language_code );
			}
			return rest_ensure_response( [
				'title' => $optimized,
				'rationale' => sanitize_text_field( (string) ( $decoded['rationale'] ?? '' ) ),
				'provider' => $client->get_provider(),
				'tokens_used' => (int) ( $result['tokens_used'] ?? 0 ),
			] );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'title_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_assistant_excerpt( WP_REST_Request $request ) {
		$body    = $request->get_json_params();
		$post_id = absint( $body['post_id'] ?? 0 );
		$save    = ! empty( $body['save'] );
		$excerpt = sanitize_textarea_field( $body['excerpt'] ?? '' );

		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		if ( $save && '' !== $excerpt ) {
			wp_update_post( [ 'ID' => $post_id, 'post_excerpt' => $excerpt ] );
			return rest_ensure_response( [ 'success' => true, 'excerpt' => $excerpt ] );
		}

		$tokens = new CGM_Token_Manager( get_current_user_id() );

		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );
			$result = $client->generate_excerpt( $post->post_content );
			$tokens->deduct( $result['tokens_used'] );

			if ( $save ) {
				wp_update_post( [ 'ID' => $post_id, 'post_excerpt' => $result['excerpt'] ] );
			}

			return rest_ensure_response( $result );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'excerpt_error', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function post_assistant_save_meta( WP_REST_Request $request ) {
		$post_id   = (int) $request->get_param( 'post_id' );
		$meta_desc = sanitize_text_field( $request->get_param( 'meta_description' ) );

		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}

		if ( empty( $meta_desc ) ) {
			return new WP_Error( 'invalid_meta', __( 'Meta description is required.', 'contentgem' ), [ 'status' => 400 ] );
		}

		update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
		update_post_meta( $post_id, 'rank_math_description', $meta_desc );

		return rest_ensure_response( [ 'success' => true ] );
	}

	public function post_assistant_draft( WP_REST_Request $request ): WP_REST_Response {
		$reservation = $this->reserve_free_generation_slot( get_current_user_id() );
		if ( is_wp_error( $reservation ) ) {
			return $limit_error;
		}

		$body = $request->get_json_params();
		$payload = [
			'gap_id' => (int) ( $body['gap_id'] ?? 0 ),
			'request_user_id' => get_current_user_id(),
			'custom_topic' => sanitize_text_field( (string) ( $body['custom_topic'] ?? '' ) ),
			'focus_keyword' => sanitize_text_field( (string) ( $body['focus_keyword'] ?? '' ) ),
			'cluster' => sanitize_text_field( (string) ( $body['cluster'] ?? '' ) ),
			'word_count' => max( 1200, (int) ( $body['word_count'] ?? 1600 ) ),
			'additional_instructions' => sanitize_textarea_field( (string) ( $body['additional_instructions'] ?? '' ) ),
			'include_svg_visuals' => ! empty( $body['include_svg_visuals'] ),
			'content_type'            => in_array( sanitize_key( (string) ( $body['content_type'] ?? 'post' ) ), [ 'post', 'page' ], true ) ? sanitize_key( (string) ( $body['content_type'] ?? 'post' ) ) : 'post',
		];
		$service = new CGM_Job_Service();
		$job = $service->start_job( 'assistant_draft', $payload, [
			'site_id' => $this->get_site_id(),
			'message' => 'Starting article generation...',
			'idempotency_key' => $service->generate_idempotency_key( 'assistant_draft', $payload, $this->get_site_id() ),
		] );
		if ( empty( $job['existing'] ) ) {
			$service->schedule_processing();
		} else {
			$this->release_free_generation_slot( get_current_user_id() );
		}
		return rest_ensure_response( [ 'job_id' => $job['job_key'], 'status' => ! empty( $job['existing'] ) ? 'running' : 'queued' ] );
	}

	public function get_assistant_draft_status( WP_REST_Request $request ): WP_REST_Response {
		$job_id = sanitize_text_field( (string) $request->get_param( 'job_id' ) );
		$repo = new CGM_Job_Repository();
		$job = $repo->get_by_key( $job_id );
		if ( $job ) {
			$post_id = (int) ( $job['result']['wp_post_id'] ?? 0 );
			$response = [
				'job_id' => $job_id,
				'status' => CGM_Job_Service::to_legacy_status( (string) $job['status'] ),
				'normalized_status' => (string) $job['status'],
				'progress' => (int) ( 'completed' === $job['status'] ? 100 : min( 99, (int) $job['progress_percentage'] ) ),
				'message' => $job['message'] ?? '',
				'wp_post_id' => $post_id,
				'error' => (string) ( $job['error']['message'] ?? '' ),
			];
			if ( $post_id > 0 ) {
				$post = get_post( $post_id );
				if ( $post instanceof WP_Post ) {
					$response['post_title'] = get_the_title( $post_id );
					$response['post_content'] = (string) $post->post_content;
					$response['edit_url'] = get_edit_post_link( $post_id, 'raw' );
				}
			}
			return rest_ensure_response( $response );
		}
		$legacy = get_option( 'cgm_job_' . $job_id, null );
		if ( ! is_array( $legacy ) ) {
			return rest_ensure_response( [ 'status' => 'unknown' ] );
		}
		return rest_ensure_response( [
			'job_id'     => $job_id,
			'status'     => $legacy['status'] ?? 'unknown',
			'progress'   => (int) ( $legacy['progress'] ?? 0 ),
			'message'    => $legacy['message'] ?? '',
			'wp_post_id' => (int) ( $legacy['wp_post_id'] ?? 0 ),
			'error'      => $legacy['error'] ?? '',
		] );
	}

	public function post_assistant_draft_run( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		$body   = $request->get_json_params();
		$job_id = sanitize_text_field( (string) ( $body['job_id'] ?? '' ) );
		$validated = CGM_Security::validate_async_job_request( $request );
		if ( is_wp_error( $validated ) ) {
			return rest_ensure_response( [ 'error' => 'Invalid' ] );
		}
		$job    = get_option( 'cgm_job_' . $job_id, null );
		if ( ! is_array( $job ) ) {
			return rest_ensure_response( [ 'error' => 'Invalid' ] );
		}
		$payload = (array) ( $job['payload'] ?? [] );
		$request_user_id = (int) ( $payload['request_user_id'] ?? 0 );
		$gap_id  = (int) ( $payload['gap_id'] ?? 0 );
		$custom_topic = sanitize_text_field( (string) ( $payload['custom_topic'] ?? '' ) );
		$focus_keyword = sanitize_text_field( (string) ( $payload['focus_keyword'] ?? '' ) );
		$cluster = sanitize_text_field( (string) ( $payload['cluster'] ?? '' ) );
		$word_count = max( 1200, (int) ( $payload['word_count'] ?? 1600 ) );
		$additional_instructions = sanitize_textarea_field( (string) ( $payload['additional_instructions'] ?? '' ) );
		$content_type = in_array( sanitize_key( (string) ( $payload['content_type'] ?? 'post' ) ), [ 'post', 'page' ], true ) ? sanitize_key( (string) ( $payload['content_type'] ?? 'post' ) ) : 'post';
		$include_svg_visuals = ! empty( $payload['include_svg_visuals'] );
		$this->update_job( $job_id, 'running', 10, 'Preparing context...' );
		$topic = '';
		$site_id = 0;
		if ( $gap_id > 0 ) {
			$gap = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_gaps WHERE id = %d", $gap_id ) );
			if ( $gap ) {
				$topic = (string) $gap->suggested_title;
				$site_id = (int) $gap->site_id;
				if ( '' === $cluster ) $cluster = (string) ( $gap->cluster_name ?? '' );
				if ( '' === $focus_keyword ) $focus_keyword = (string) ( $gap->cluster_name ?? $gap->suggested_title );
			}
		}
		if ( '' === $topic ) {
			$topic = $custom_topic;
		}
		if ( '' === trim( $topic ) ) {
			$this->release_free_generation_slot( $request_user_id );
			$this->update_job( $job_id, 'error', 0, 'Topic is required.' );
			$job = get_option( 'cgm_job_' . $job_id, [] );
			$job['error'] = 'Topic is required.';
			update_option( 'cgm_job_' . $job_id, $job, false );
			return rest_ensure_response( [ 'error' => 'Topic is required.' ] );
		}
		try {
			$site = $site_id > 0 ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_sites WHERE id = %d", $site_id ) ) : null;
			$tone = (string) get_option( 'contentgem_tone_of_voice', '' );
			if ( '' === $tone && ! empty( $site->tone_snapshot ) ) {
				$tone_analyzer = new CGM_Tone_Analyzer( CGM_AI_Client::from_settings() );
				$tone = $tone_analyzer->build_tone_instructions( (string) $site->tone_snapshot );
			}
			$lsi_keywords = $this->derive_semantic_keywords( $focus_keyword ?: $topic, $cluster, $site_id );
			$site_structure_targets = $this->get_site_structure_link_targets();
			$context = [
				'niche_label'             => sanitize_text_field( (string) get_option( 'contentgem_niche', get_bloginfo( 'name' ) ) ),
				'pillar_pages'            => [],
				'suggested_title'         => $topic,
				'primary_keyword'         => $focus_keyword ?: $topic,
				'lsi_keywords'            => $lsi_keywords,
				'word_count'              => $word_count,
				'h2_structure'            => [],
				'search_intent'           => 'informational',
				'internal_links'          => [],
				'tone_instructions'       => $tone,
				'competitor_insights'     => ! empty( $cluster ) ? $this->get_competitor_insights_for_cluster( $cluster ) : '',
				'gsc_queries'             => $this->get_relevant_gsc_queries_for_topic( $focus_keyword ?: $topic, $cluster ),
			];
			$language_service = new CGM_Language_Service();
			$support_note = 'Treat semantic keywords as optional support terms only. Prioritize the title and primary keyword. Do not force every semantic term into the article.';
			$support_note .= "\n" . $language_service->build_language_rules( $language_service->get_language_code() );
			$structure_lines = [];
			foreach ( $site_structure_targets as $target ) {
				$label = str_replace( '_', ' ', (string) ( $target['type'] ?? '' ) );
				$structure_lines[] = '- ' . trim( (string) ( $target['title'] ?? '' ) ) . ' (' . $label . '): ' . trim( (string) ( $target['url'] ?? '' ) );
			}
			if ( ! empty( $structure_lines ) ) {
				$support_note .= "\nImportant internal link targets on this website:\n" . implode( "\n", $structure_lines );
				$support_note .= "\nWhen relevant, naturally link to service pages, the homepage, about page and case studies. Prioritize service pages for commercial intent and about/case studies for trust-building context.";
			}
			$context['additional_instructions'] = trim( $support_note . ( '' !== $additional_instructions ? "\n" . $additional_instructions : '' ) );
			$this->update_job( $job_id, 'running', 35, 'Generating article...' );
			$client = new CGM_Claude_Client( $this->get_api_key() );
			$result = $client->generate_draft( $context, function( string $chunk ) {} );
			$html = (string) ( $result['html'] ?? '' );
			$html = preg_replace( '/^```(?:html)?\s*/i', '', trim( $html ) );
			$html = preg_replace( '/\s*```$/', '', trim( (string) $html ) );
			$html = preg_replace( '/^(?:[\'"`])+\s*(?:html)?\s*/i', '', trim( (string) $html ) );
			$html = preg_replace( '/\s*(?:[\'"`])+$/', '', trim( (string) $html ) );
			$html = $this->normalize_article_output_html( (string) $html, false );
			$html = contentgem_clean_ai_article_output( (string) $html, false );
			$html = contentgem_clean_ai_article_output( (string) $html, false );
			if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
				throw new \RuntimeException( 'AI returned empty article content.' );
			}
			$this->update_job( $job_id, 'running', 55, 'Checking article completeness...' );
			$completion = $this->cgm_ensure_complete_article( $client, $html, [
				'topic'           => $topic,
				'primary_keyword' => $focus_keyword ?: $topic,
				'word_count'      => $word_count,
				'language'        => (string) get_option( 'contentgem_content_language', 'English' ),
			] );
			$html = (string) ( $completion['html'] ?? $html );
			$html = $this->normalize_article_output_html( (string) $html, false );
			$fact_checker = new CGM_Fact_Checker();
			if ( $fact_checker->enabled() ) {
				$this->update_job( $job_id, 'running', 63, 'Fact-checking article...' );
				$fact_checked = $fact_checker->revise_article_html( $client, $html, [
					'topic' => $topic,
					'primary_keyword' => $focus_keyword ?: $topic,
					'language' => (string) get_option( 'contentgem_content_language', 'English' ),
				] );
				$html = $this->normalize_article_output_html( (string) ( $fact_checked['html'] ?? $html ), false );
			}
			$title = $topic;
			if ( preg_match( '/<h1[^>]*>(.*?)<\/h1>/is', $html, $m ) ) {
				$title = wp_strip_all_tags( $m[1] );
				$html = ltrim( str_replace( $m[0], '', $html ) );
			}
			$html = preg_replace( '/\n{3,}/', "\n\n", $html );
			$visual_markup = '';
			if ( $include_svg_visuals ) {
				$this->update_job( $job_id, 'running', 68, 'Generating visuals...' );
				try {
					preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $html, $visual_matches );
					$visual_headings = array_values( array_slice( array_map( static function( string $heading ): string {
						return sanitize_text_field( wp_strip_all_tags( $heading ) );
					}, (array) ( $visual_matches[1] ?? [] ) ), 0, 6 ) );
					$visual_payload = $client->generate_inline_draft_visuals( [
						'topic'           => $topic,
						'suggested_title' => $title,
						'primary_keyword' => $focus_keyword ?: $topic,
						'cluster_name'    => $cluster,
						'language'        => (string) get_option( 'contentgem_content_language', 'English' ),
						'h2_structure'    => $visual_headings,
						'gap_topics'      => array_slice( (array) $lsi_keywords, 0, 4 ),
					], $html );
					$visual_markup = $this->extract_svg_markup_only( (string) ( $visual_payload['text'] ?? '' ) );
				} catch ( \Throwable $visual_error ) {
					$visual_markup = '';
				}
			}
			$combined_draft_response = trim( $html . ( '' !== $visual_markup ? "\n\n" . $visual_markup : '' ) );
			$this->update_job( $job_id, 'running', 75, 'Saving draft...' );
			$wp_post_id = wp_insert_post( [
				'post_title'   => sanitize_text_field( strip_tags( $title ) ),
				'post_content' => wp_kses_post( $html ),
				'post_status'  => 'draft',
				'post_type'    => $content_type,
				'post_name'    => sanitize_title( strip_tags( $title ) ),
			], true );
			if ( is_wp_error( $wp_post_id ) ) {
				throw new \RuntimeException( 'wp_insert_post failed: ' . $wp_post_id->get_error_message() );
			}
			$this->commit_free_generation_slot( get_current_user_id() );
			if ( $gap_id > 0 ) {
				update_post_meta( $wp_post_id, '_contentgem_gap_id', $gap_id );
			}
			update_post_meta( $wp_post_id, '_cgm_ai_draft', '1' );
			update_post_meta( $wp_post_id, '_cgm_cluster', $cluster );
			update_post_meta( $wp_post_id, '_cgm_semantic_keywords', $lsi_keywords );
			update_post_meta( $wp_post_id, '_cgm_include_svg_visuals', $include_svg_visuals ? '1' : '0' );
			update_post_meta( $wp_post_id, '_cgm_fact_check_enabled', $fact_checker->enabled() ? '1' : '0' );
			if ( $include_svg_visuals && '' !== trim( $visual_markup ) ) {
				CGM_Draft_SVG::store_for_post( (int) $wp_post_id, $combined_draft_response, $html );
			} else {
				$this->clear_post_draft_visual_meta( (int) $wp_post_id );
				update_post_meta( $wp_post_id, '_cgm_draft_text', $html );
				wp_update_post( [ 'ID' => (int) $wp_post_id, 'post_content' => wp_kses_post( $html ) ] );
			}
			$builder_integrator = new CGM_Builder_Integrator();
			$builder_mode = $builder_integrator->sync_generated_post(
				(int) $wp_post_id,
				(string) $combined_draft_response,
				[
					'post_type'    => $content_type,
					'builder_mode' => sanitize_key( (string) ( $body['builder_mode'] ?? 'auto' ) ),
				]
			);
			update_post_meta( $wp_post_id, '_contentgem_builder_mode', $builder_mode );
			$this->update_job( $job_id, 'done', 100, 'Draft created.', [ 'wp_post_id' => $wp_post_id, 'builder_mode' => $builder_mode ] );
			$job = get_option( 'cgm_job_' . $job_id, [] );
			$job['wp_post_id'] = $wp_post_id;
			update_option( 'cgm_job_' . $job_id, $job, false );
			return rest_ensure_response( [ 'success' => true, 'wp_post_id' => $wp_post_id ] );
		} catch ( \Throwable $e ) {
			$this->release_free_generation_slot( $request_user_id );
			$this->update_job( $job_id, 'error', 0, $e->getMessage() );
			$job = get_option( 'cgm_job_' . $job_id, [] );
			$job['error'] = $e->getMessage();
			update_option( 'cgm_job_' . $job_id, $job, false );
			return rest_ensure_response( [ 'error' => $e->getMessage() ] );
		}
	}


	public function post_drafts_schedule_drip( WP_REST_Request $request ) {
		$body       = $request->get_json_params();
		$start_date = sanitize_text_field( (string) ( $body['start_date'] ?? '' ) );
		$interval   = sanitize_text_field( (string) ( $body['interval'] ?? 'daily' ) );
		$time       = sanitize_text_field( (string) ( $body['time'] ?? '09:00' ) );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $start_date ) ) {
			return new WP_Error( 'invalid_start_date', __( 'Invalid start date.', 'contentgem' ), [ 'status' => 400 ] );
		}
		if ( ! preg_match( '/^\d{2}:\d{2}$/', $time ) ) {
			return new WP_Error( 'invalid_time', __( 'Invalid publish time.', 'contentgem' ), [ 'status' => 400 ] );
		}

		$map = [
			'daily'        => 1,
			'every day'    => 1,
			'every 2 days' => 2,
			'every 3 days' => 3,
			'weekly'       => 7,
			'every week'   => 7,
		];
		$days = $map[ strtolower( $interval ) ] ?? 7;

		$drafts = get_posts( [
			'post_type'      => 'post',
			'post_status'    => 'draft',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'ASC',
			'meta_query'     => [
				'relation' => 'OR',
				[ 'key' => '_cgm_ai_draft', 'compare' => 'EXISTS' ],
				[ 'key' => '_cgm_gap_id', 'compare' => 'EXISTS' ],
			],
		] );

		if ( empty( $drafts ) ) {
			return rest_ensure_response( [ 'success' => false, 'message' => __( 'No drafts available to schedule.', 'contentgem' ) ] );
		}

		$tz = wp_timezone();
		$scheduled = 0;
		$start = \DateTime::createFromFormat( 'Y-m-d H:i', $start_date . ' ' . $time, $tz );
		if ( ! $start ) {
			return new WP_Error( 'invalid_datetime', __( 'Invalid schedule date/time.', 'contentgem' ), [ 'status' => 400 ] );
		}

		foreach ( $drafts as $index => $draft ) {
			$dt = clone $start;
			if ( $index > 0 ) {
				$dt->modify( '+' . ( $index * $days ) . ' days' );
			}
			$local = $dt->format( 'Y-m-d H:i:s' );
			$gmt = get_gmt_from_date( $local );
			$result = wp_update_post( [
				'ID'            => $draft->ID,
				'post_status'   => 'future',
				'post_date'     => $local,
				'post_date_gmt' => $gmt,
			], true );
			if ( ! is_wp_error( $result ) ) {
				$scheduled++;
			}
		}

		return rest_ensure_response( [ 'success' => true, 'scheduled' => $scheduled ] );
	}

	private function map_wp_posts_to_drafts( array $posts, bool $has_gap_id ): array {
		global $wpdb;

		$drafts = [];
		foreach ( $posts as $post ) {
			$post_id      = (int) $post->wp_post_id;
			$cluster_name = '';

			if ( $has_gap_id && ! empty( $post->gap_id ) ) {
				$gap_row = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT t.cluster_name
						 FROM {$wpdb->prefix}cgm_gaps g
						 LEFT JOIN {$wpdb->prefix}cgm_topics t ON t.id = g.topic_id
						 WHERE g.id = %d",
						(int) $post->gap_id
					)
				);
				$cluster_name = $gap_row->cluster_name ?? '';
			}

			if ( '' === $cluster_name ) {
				$cats         = get_the_category( $post_id );
				$cluster_name = ! empty( $cats ) ? $cats[0]->name : '';
			}

			$edit_url    = get_edit_post_link( $post_id, 'raw' )
				?: admin_url( "post.php?post={$post_id}&action=edit" );
			$post_status = $post->post_status ?? 'draft';

			$drafts[] = [
				'id'              => 0,
				'wp_post_id'      => $post_id,
				'suggested_title' => $post->post_title ?? '',
				'cluster_name'    => $cluster_name,
				'post_status'     => $post_status,
				'post_date'       => $post->post_date ?? '',
				'word_count'      => (int) str_word_count( wp_strip_all_tags( (string) $post->post_content ) ),
				'edit_url'        => $edit_url,
				'post_url'        => 'publish' === $post_status ? get_permalink( $post_id ) : '',
			];
		}

		return $drafts;
	}


	private function delete_managed_cluster_terms(): void {
		$raw = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$raw = is_array( $raw ) ? $raw : [];
		foreach ( $raw as $term_map ) {
			$category_id = (int) ( $term_map['category_id'] ?? 0 );
			$tag_id      = (int) ( $term_map['tag_id'] ?? 0 );
			if ( $category_id > 1 ) {
				wp_delete_term( $category_id, 'category' );
			}
			if ( $tag_id > 0 ) {
				wp_delete_term( $tag_id, 'post_tag' );
			}
		}
		update_option( 'contentgem_cluster_terms', wp_json_encode( [] ) );
	}

	public function post_settings_hard_reset( WP_REST_Request $request ): WP_REST_Response {
		$this->delete_managed_cluster_terms();
		update_option( 'contentgem_clusters', wp_json_encode( [] ) );
		update_option( 'contentgem_clusters_snapshot', wp_json_encode( [] ) );
		update_option( 'contentgem_cluster_terms', wp_json_encode( [] ) );
		update_option( 'cgm_cluster_keywords', [] );
		update_option( 'contentgem_competitor_domains', [] );
		update_option( 'contentgem_competitors', [] );
		update_option( 'contentgem_clusters_initialized', true, false );
		global $wpdb;
		$site_id = $this->get_site_id();
		if ( $site_id > 0 ) {
			$wpdb->delete( $wpdb->prefix . 'cgm_topics', [ 'site_id' => $site_id ], [ '%d' ] );
			$wpdb->delete( $wpdb->prefix . 'cgm_gaps', [ 'site_id' => $site_id ], [ '%d' ] );
		}
		update_option( 'contentgem_latest_competitor_analysis', [] );
		delete_option( 'contentgem_pillar_pages' );
		if ( function_exists( 'cgm_clear_cached_lists' ) ) {
			cgm_clear_cached_lists( $this->get_site_id() );
		} else {
			CGM_Cache::clear_analysis_lists( $this->get_site_id() );
		}
		delete_transient( 'contentgem_cannibalization_' . get_current_blog_id() );
		return rest_ensure_response( [ 'success' => true, 'message' => 'All suggested settings, clusters and competitor domains were reset.' ] );
	}


	private function build_gap_semantic_tags( string $title, string $cluster, array $cluster_keywords = [] ): array {
		$title_tokens   = $this->tokenize_gap_phrase( $title );
		$cluster_tokens = $this->tokenize_gap_phrase( $cluster );
		$tags = [];
		$seen = [];

		$ranked_keywords = [];
		foreach ( $cluster_keywords as $keyword ) {
			$keyword = sanitize_text_field( (string) $keyword );
			if ( '' === $keyword ) {
				continue;
			}
			$kw_tokens = $this->tokenize_gap_phrase( $keyword );
			$overlap = count( array_intersect( $title_tokens, $kw_tokens ) );
			if ( $overlap > 0 ) {
				$ranked_keywords[] = [ 'keyword' => $keyword, 'overlap' => $overlap, 'length' => count( $kw_tokens ) ];
			}
		}
		usort( $ranked_keywords, static function( $a, $b ) {
			return ( $b['overlap'] <=> $a['overlap'] ) ?: ( $b['length'] <=> $a['length'] );
		} );
		foreach ( $ranked_keywords as $row ) {
			$slug = sanitize_title( (string) $row['keyword'] );
			if ( '' !== $slug && ! isset( $seen[ $slug ] ) ) {
				$seen[ $slug ] = true;
				$tags[] = $slug;
			}
			if ( count( $tags ) >= 4 ) {
				break;
			}
		}

		$significant = array_values( array_filter( $title_tokens, function( string $token ) use ( $cluster_tokens ): bool {
			return mb_strlen( $token ) > 2 && ! in_array( $token, $cluster_tokens, true );
		} ) );
		for ( $i = 0; $i < count( $significant ) && count( $tags ) < 4; $i++ ) {
			$single = sanitize_title( $significant[ $i ] );
			if ( '' !== $single && ! isset( $seen[ $single ] ) ) {
				$seen[ $single ] = true;
				$tags[] = $single;
			}
			if ( count( $tags ) >= 4 ) {
				break;
			}
			if ( isset( $significant[ $i + 1 ] ) ) {
				$phrase = sanitize_title( $significant[ $i ] . ' ' . $significant[ $i + 1 ] );
				if ( '' !== $phrase && ! isset( $seen[ $phrase ] ) ) {
					$seen[ $phrase ] = true;
					$tags[] = $phrase;
				}
			}
		}

		if ( count( $tags ) < 2 && ! empty( $cluster_tokens ) ) {
			foreach ( $cluster_tokens as $token ) {
				$slug = sanitize_title( $token );
				if ( '' !== $slug && ! isset( $seen[ $slug ] ) ) {
					$seen[ $slug ] = true;
					$tags[] = $slug;
				}
				if ( count( $tags ) >= 4 ) {
					break;
				}
			}
		}

		if ( count( $tags ) < 2 && '' !== $cluster ) {
			$cluster_slug = sanitize_title( $cluster );
			if ( '' !== $cluster_slug && ! isset( $seen[ $cluster_slug ] ) ) {
				$tags[] = $cluster_slug;
			}
		}
		return array_slice( array_values( array_unique( array_filter( $tags ) ) ), 0, 4 );
	}

	private function tokenize_gap_phrase( string $value ): array {
		$value = function_exists( 'mb_strtolower' ) ? mb_strtolower( wp_strip_all_tags( $value ) ) : strtolower( wp_strip_all_tags( $value ) );
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', $value );
		$stop = [ 'the','and','for','with','your','this','that','van','voor','met','een','het','de','how','what','guide','best','complete','practical' ];
		return array_values( array_filter( array_map( 'trim', (array) $tokens ), function( string $token ) use ( $stop ): bool {
			return '' !== $token && mb_strlen( $token ) > 2 && ! in_array( $token, $stop, true );
		} ) );
	}

	private function build_cluster_terms( array $clusters ): array {
		$cluster_terms = [];

		foreach ( $clusters as $cluster_name ) {
			$cat_result = wp_insert_term( $cluster_name, 'category' );
			if ( is_wp_error( $cat_result ) ) {
				$existing    = get_term_by( 'name', $cluster_name, 'category' );
				$category_id = $existing instanceof WP_Term ? (int) $existing->term_id : 0;
			} else {
				$category_id = (int) $cat_result['term_id'];
			}

			$tag_result = wp_insert_term( $cluster_name, 'post_tag' );
			if ( is_wp_error( $tag_result ) ) {
				$existing = get_term_by( 'name', $cluster_name, 'post_tag' );
				$tag_id   = $existing instanceof WP_Term ? (int) $existing->term_id : 0;
			} else {
				$tag_id = (int) $tag_result['term_id'];
			}

			$cat_obj       = $category_id > 0 ? get_term( $category_id, 'category' ) : null;
			$category_slug = ( $cat_obj instanceof WP_Term ) ? $cat_obj->slug : sanitize_title( $cluster_name );

			$cluster_terms[ $cluster_name ] = [
				'category_id'   => $category_id,
				'tag_id'        => $tag_id,
				'category_slug' => $category_slug,
			];
		}

		update_option( 'contentgem_cluster_terms', wp_json_encode( $cluster_terms ) );

		return $cluster_terms;
	}

	private function detect_existing_clusters(): array {
		global $wpdb;

		$ranked  = [];
		$site_id = $this->get_site_id();

		$add_ranked = static function( array &$ranked, string $name, float $score ): void {
			$name = sanitize_text_field( trim( $name ) );
			if ( '' === $name || mb_strlen( $name ) < 4 ) {
				return;
			}
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $name ) : strtolower( $name );
			if ( ! isset( $ranked[ $key ] ) || $score > $ranked[ $key ]['score'] ) {
				$ranked[ $key ] = [ 'name' => $name, 'score' => $score ];
			}
		};

		if ( $site_id > 0 ) {
			$topic_rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT cluster_name, MAX(coverage_score) AS coverage_score, COUNT(*) AS items FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name <> '' GROUP BY cluster_name ORDER BY coverage_score DESC, items DESC, cluster_name ASC",
					$site_id
				)
			);
			if ( is_array( $topic_rows ) ) {
				foreach ( $topic_rows as $row ) {
					$score = (float) ( $row->coverage_score ?? 0 ) + (int) ( $row->items ?? 0 ) * 5;
					$add_ranked( $ranked, (string) ( $row->cluster_name ?? '' ), 100 + $score );
				}
			}
		}

		$categories = get_terms( [
			'taxonomy'   => 'category',
			'hide_empty' => true,
			'number'     => 20,
			'orderby'    => 'count',
			'order'      => 'DESC',
			'exclude'    => [ 1 ],
		] );
		if ( ! is_wp_error( $categories ) ) {
			foreach ( $categories as $term ) {
				if ( $term instanceof WP_Term && ! empty( $term->name ) && (int) $term->count >= 2 ) {
					$add_ranked( $ranked, $term->name, 50 + (int) $term->count );
				}
			}
		}

		$tags = get_terms( [
			'taxonomy'   => 'post_tag',
			'hide_empty' => true,
			'number'     => 30,
			'orderby'    => 'count',
			'order'      => 'DESC',
		] );
		if ( ! is_wp_error( $tags ) ) {
			foreach ( $tags as $term ) {
				if ( $term instanceof WP_Term && ! empty( $term->name ) && (int) $term->count >= 3 ) {
					$add_ranked( $ranked, $term->name, 10 + (int) $term->count );
				}
			}
		}

		$ranked = array_values( $ranked );
		usort( $ranked, static function( array $a, array $b ): int {
			return $b['score'] <=> $a['score'];
		} );
		return array_values( array_map( static function( array $item ): string {
			return $item['name'];
		}, array_slice( $ranked, 0, 8 ) ) );
	}

	private function get_cluster_suggestion_signature( string $niche, string $description, array $existing ): string {
		return md5( wp_json_encode( [
			'niche'       => $niche,
			'description' => $description,
			'existing'    => array_values( $this->normalise_cluster_list( $existing ) ),
		] ) ?: '' );
	}

	private function get_cluster_suggestion_state(): array {
		$decoded = json_decode( (string) get_option( 'contentgem_single_cluster_suggestion_state', '{}' ), true );
		return is_array( $decoded ) ? $decoded : [];
	}

	private function save_cluster_suggestion_state( array $state ): void {
		update_option( 'contentgem_single_cluster_suggestion_state', wp_json_encode( $state ) );
	}

	private function parse_cluster_candidate_list( string $raw ): array {
		$raw = trim( preg_replace( '/^```(?:json)?\s*/i', '', $raw ) );
		$raw = trim( preg_replace( '/\s*```$/', '', $raw ) );
		if ( preg_match( '/\{[\s\S]*\}/', $raw, $match ) ) {
			$parsed = json_decode( $match[0], true );
			if ( is_array( $parsed ) ) {
				if ( isset( $parsed['clusters'] ) && is_array( $parsed['clusters'] ) ) {
					return $this->normalise_cluster_list( $parsed['clusters'] );
				}
				if ( isset( $parsed['suggestions'] ) && is_array( $parsed['suggestions'] ) ) {
					return $this->normalise_cluster_list( $parsed['suggestions'] );
				}
				if ( isset( $parsed['cluster'] ) || isset( $parsed['name'] ) ) {
					$one = sanitize_text_field( trim( (string) ( $parsed['cluster'] ?? $parsed['name'] ?? '' ) ) );
					return '' !== $one ? [ $one ] : [];
				}
				$flat = [];
				foreach ( $parsed as $value ) {
					if ( is_string( $value ) ) {
						$flat[] = $value;
					} elseif ( is_array( $value ) ) {
						foreach ( $value as $inner ) {
							if ( is_string( $inner ) ) { $flat[] = $inner; }
						}
					}
				}
				return $this->normalise_cluster_list( $flat );
			}
		}
		$raw   = preg_replace( '/[\[\]{}"`]/', '', $raw );
		$parts = preg_split( '/[\r\n,;]+/', $raw );
		return $this->normalise_cluster_list( array_map( 'trim', (array) $parts ) );
	}

	private function build_single_cluster_suggestion_pool( string $niche, string $description, array $existing, array $history = [] ): array {
		$provider = (string) get_option( 'contentgem_ai_provider', 'claude' );
		$provider_key = 'openai' === $provider ? (string) get_option( 'contentgem_openai_api_key', '' ) : (string) get_option( 'contentgem_claude_api_key', (string) get_option( 'contentgem_api_key', '' ) );
		if ( '' === $provider_key ) { $provider_key = (string) get_option( 'contentgem_api_key', '' ); }
		$client = new CGM_Claude_Client( $provider_key );

		$existing_list = implode( ', ', array_slice( $this->normalise_cluster_list( $existing ), 0, 30 ) );
		$history_list  = implode( ', ', array_slice( $this->normalise_cluster_list( $history ), -20 ) );
		$prompt = sprintf(
			'Suggest 8 unique additional SEO content clusters for this site. Focus on clusters that are commercially useful, topic-distinct, and broad enough to support multiple articles. Avoid duplicates, near-duplicates, and wording that overlaps too much with existing clusters or recent suggestions. Return ONLY valid JSON in this format: {"clusters":["...","..."]}. Niche: %s. Description: %s. Existing clusters: %s. Recent suggestions to avoid: %s',
			$niche,
			$description,
			$existing_list,
			$history_list
		);

		$candidates = [];
		try {
			$result = $client->generate_article( '', $prompt );
			$raw = (string) ( $result['text'] ?? $result['html'] ?? '' );
			$candidates = $this->parse_cluster_candidate_list( $raw );
		} catch ( \Throwable $e ) {
			$candidates = [];
		}

		if ( empty( $candidates ) ) {
			$fallback = $client->suggest_clusters( $niche, $description );
			$candidates = $this->normalise_cluster_list( (array) ( $fallback['clusters'] ?? [] ) );
		}

		$blacklist = array_map( 'strtolower', array_merge( $this->normalise_cluster_list( $existing ), $this->normalise_cluster_list( $history ) ) );
		$filtered = [];
		foreach ( $candidates as $candidate ) {
			$key = strtolower( sanitize_text_field( (string) $candidate ) );
			if ( '' === $key || in_array( $key, $blacklist, true ) ) {
				continue;
			}
			$blacklist[] = $key;
			$filtered[] = sanitize_text_field( (string) $candidate );
		}
		return array_slice( $filtered, 0, 8 );
	}

	private function parse_single_cluster_name( string $raw ): string {
		$raw = trim( preg_replace( '/^```(?:json)?\s*/i', '', $raw ) );
		$raw = trim( preg_replace( '/\s*```$/', '', $raw ) );
		if ( preg_match( '/\{[\s\S]*?\}/', $raw, $match ) ) {
			$parsed = json_decode( $match[0], true );
			if ( is_array( $parsed ) ) {
				$candidate = sanitize_text_field( trim( (string) ( $parsed['cluster'] ?? $parsed['name'] ?? '' ) ) );
				if ( '' !== $candidate ) {
					return $candidate;
				}
			}
		}
		$raw = preg_replace( '/[\[\]{}"`]/', '', $raw );
		$parts = preg_split( '/[\r\n,;]+/', $raw );
		foreach ( (array) $parts as $part ) {
			$candidate = sanitize_text_field( trim( $part ) );
			if ( '' !== $candidate ) {
				return $candidate;
			}
		}
		return '';
	}

	private function get_site_id(): int {
		global $wpdb;
		$id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}cgm_sites WHERE blog_id = %d",
				get_current_blog_id()
			)
		);
		return (int) $id;
	}



	public function post_jobs( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		$type = sanitize_key( (string) ( $body['type'] ?? '' ) );
		$payload = is_array( $body['payload'] ?? null ) ? $body['payload'] : [];
		$allowed = [ 'analyze_site', 'scan_broken_links', 'assistant_draft', 'generate_draft' ];
		if ( ! in_array( $type, $allowed, true ) ) {
			return new WP_REST_Response( [ 'error' => 'Unsupported job type.' ], 400 );
		}
		$service = new CGM_Job_Service();
		$job = $service->start_job( $type, $payload, [
			'site_id' => $this->get_site_id(),
			'message' => 'Queued...',
		] );
		if ( empty( $job['existing'] ) ) {
			$service->schedule_processing();
		}
		return rest_ensure_response( $service->normalize_for_response( $job ) );
	}

	public function get_job_status( WP_REST_Request $request ): WP_REST_Response {
		$job_key = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$service = new CGM_Job_Service();
		$job = $service->get_job_by_key( $job_key );
		if ( ! $job ) {
			return new WP_REST_Response( [ 'error' => 'Job not found.' ], 404 );
		}
		return rest_ensure_response( $service->normalize_for_response( $job ) );
	}

	public function post_job_retry( WP_REST_Request $request ): WP_REST_Response {
		$job_key = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$service = new CGM_Job_Service();
		$job = $service->retry_job( $job_key );
		if ( ! $job ) {
			return new WP_REST_Response( [ 'error' => 'Retry unavailable.' ], 400 );
		}
		return rest_ensure_response( $service->normalize_for_response( $job ) );
	}

	private function derive_semantic_keywords( string $topic, string $cluster_name = '', int $site_id = 0 ): array {
		$cache_payload = [ 'topic' => $topic, 'cluster' => $cluster_name, 'site_id' => $site_id, 'type' => 'derived_semantics_v2' ];
		$cached = $this->cgm_get_cached_ai_result( 'derived_semantics', $cache_payload );
		if ( is_array( $cached ) ) {
			return $this->filter_semantic_keyword_list( $cached );
		}

		$keywords = [];
		$cluster_terms = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		if ( is_array( $cluster_terms ) && ! empty( $cluster_name ) && ! empty( $cluster_terms[ $cluster_name ] ) && is_array( $cluster_terms[ $cluster_name ] ) ) {
			$cluster_support_terms = array_slice( array_values( array_filter( array_map( 'sanitize_text_field', $cluster_terms[ $cluster_name ] ) ) ), 0, 4 );
			$keywords = array_merge( $keywords, $cluster_support_terms );
		}

		$keywords = array_merge( $keywords, $this->generate_ai_semantic_keywords( $topic, $cluster_name ) );
		$topic_terms = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $topic ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		$keywords = array_merge( $keywords, array_filter( $topic_terms, static function( $term ) { return mb_strlen( $term ) >= 4 && ! preg_match( '/^\d+$/', (string) $term ); } ) );
		$scored_gsc = $this->get_scored_gsc_queries_for_topic( $topic, $cluster_name, 8 );
		foreach ( $scored_gsc as $item ) {
			$keywords[] = (string) $item['query'];
		}
		$keywords = $this->filter_semantic_keyword_list( $keywords );
		$this->cgm_set_cached_ai_result( 'derived_semantics', $cache_payload, $keywords, HOUR_IN_SECONDS );
		return $keywords;
	}

	private function filter_semantic_keyword_list( $items ): array {
		$items = is_array( $items ) ? $items : [];
		$seen  = [];
		$out   = [];
		foreach ( $items as $item ) {
			$item = sanitize_text_field( (string) $item );
			$item = trim( preg_replace( '/\s+/', ' ', $item ) );
			if ( '' === $item ) { continue; }
			if ( preg_match( '/^\d+$/', $item ) ) { continue; }
			if ( mb_strlen( $item ) < 3 ) { continue; }
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $item ) : strtolower( $item );
			if ( isset( $seen[ $key ] ) ) { continue; }
			$seen[ $key ] = true;
			$out[] = $item;
			if ( count( $out ) >= 12 ) { break; }
		}
		return $out;
	}

	private function get_relevant_gsc_queries_for_topic( string $topic, string $cluster_name = '' ): array {
		$queries = [];
		foreach ( $this->get_scored_gsc_queries_for_topic( $topic, $cluster_name, 12 ) as $item ) {
			$queries[] = sanitize_text_field( (string) $item['query'] );
		}
		return $queries;
	}

	private function get_scored_gsc_queries_for_topic( string $topic, string $cluster_name = '', int $limit = 12 ): array {
		$cache_payload = [ 'topic' => $topic, 'cluster' => $cluster_name, 'limit' => $limit, 'type' => 'gsc_topic_queries_scored_v1' ];
		$cached = $this->cgm_get_cached_ai_result( 'gsc_topic_queries_scored', $cache_payload );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );
		if ( '' === $site_url || '' === $this->get_gsc_token() ) {
			return [];
		}
		$topic_words = $this->words_for_overlap( $topic . ' ' . $cluster_name );
		if ( empty( $topic_words ) ) {
			return [];
		}
		$rows = $this->gsc_query(
			new CGM_GSC_Connector(),
			$site_url,
			gmdate( 'Y-m-d', strtotime( '-90 days' ) ),
			gmdate( 'Y-m-d' ),
			[ 'query' ],
			250
		);
		$scored = [];
		foreach ( $rows as $row ) {
			$query = sanitize_text_field( (string) ( $row['keys'][0] ?? '' ) );
			if ( '' === $query ) {
				continue;
			}
			$query_words = $this->words_for_overlap( $query );
			$overlap = count( array_intersect_key( $topic_words, $query_words ) );
			if ( $overlap <= 0 ) {
				continue;
			}
			$impressions = (float) ( $row['impressions'] ?? 0 );
			$clicks = (float) ( $row['clicks'] ?? 0 );
			$position = (float) ( $row['position'] ?? 99 );
			$score = ( $overlap * 6 ) + min( 30, log( 1 + max( 0, $impressions ) ) * 4 ) + min( 20, log( 1 + max( 0, $clicks ) ) * 6 ) + max( 0, 12 - min( 12, $position ) );
			$scored[] = [
				'query' => $query,
				'impressions' => (int) $impressions,
				'clicks' => (int) $clicks,
				'position' => $position,
				'score' => round( $score, 2 ),
			];
		}
		usort( $scored, static function( array $a, array $b ) {
			return $b['score'] <=> $a['score'];
		} );
		$scored = array_slice( $scored, 0, $limit );
		$this->cgm_set_cached_ai_result( 'gsc_topic_queries_scored', $cache_payload, $scored, 15 * MINUTE_IN_SECONDS );
		return $scored;
	}

	private function sync_gsc_post_signals( CGM_GSC_Connector $gsc ): void {
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );
		if ( '' === $site_url || '' === $this->get_gsc_token() ) {
			return;
		}
		$end_date   = gmdate( 'Y-m-d' );
		$start_date = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		$page_rows  = $this->gsc_query( $gsc, $site_url, $start_date, $end_date, [ 'page' ], 5000 );
		$page_positions = [];
		foreach ( $page_rows as $row ) {
			$url = rtrim( (string) ( $row['keys'][0] ?? '' ), '/' );
			if ( '' === $url ) continue;
			$page_positions[ $url ] = (float) ( $row['position'] ?? 0 );
		}
		if ( ! empty( $page_positions ) ) {
			update_option( 'cgm_gsc_page_positions', $page_positions );
		}
		$query_rows = $this->gsc_query( $gsc, $site_url, $start_date, $end_date, [ 'page', 'query' ], 5000 );
		$per_page_queries = [];
		foreach ( $query_rows as $row ) {
			$url = rtrim( (string) ( $row['keys'][0] ?? '' ), '/' );
			$query = sanitize_text_field( (string) ( $row['keys'][1] ?? '' ) );
			if ( '' === $url || '' === $query ) continue;
			$per_page_queries[ $url ][] = $query;
		}
		$posts = get_posts( [ 'numberposts' => -1, 'post_status' => 'publish', 'post_type' => [ 'post', 'page' ] ] );
		foreach ( $posts as $post ) {
			$permalink = rtrim( (string) get_permalink( $post->ID ), '/' );
			if ( isset( $page_positions[ $permalink ] ) ) {
				update_post_meta( $post->ID, '_cgm_gsc_position', (float) $page_positions[ $permalink ] );
			}
			if ( ! empty( $per_page_queries[ $permalink ] ) ) {
				update_post_meta( $post->ID, '_cgm_gsc_queries', array_values( array_unique( array_map( 'mb_strtolower', $per_page_queries[ $permalink ] ) ) ) );
			}
		}
	}

	private function get_gap_or_error( int $gap_id ) {
		global $wpdb;
		$gap = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_gaps WHERE id = %d", $gap_id ) );
		if ( ! $gap ) {
			return new WP_Error( 'invalid_gap_id', sprintf( __( 'Gap ID %d does not exist.', 'contentgem' ), $gap_id ), [ 'status' => 400 ] );
		}
		return $gap;
	}



	private function get_configured_language_value(): string {
		$configured = strtolower( trim( (string) get_option( 'contentgem_content_language', 'auto' ) ) );
		return '' !== $configured ? $configured : 'auto';
	}

	private function get_custom_language_label(): string {
		return sanitize_text_field( (string) get_option( 'contentgem_content_language_custom', '' ) );
	}

	private function get_preferred_language_code(): string {
		$configured = $this->get_configured_language_value();
		if ( 'custom' === $configured ) {
			$custom = $this->normalize_language_code( $this->get_custom_language_label() );
			if ( '' !== $custom && 'auto' !== $custom && 'custom' !== $custom ) {
				return $custom;
			}
		}
		$forced = $this->normalize_language_code( $configured );
		if ( '' !== $forced && 'auto' !== $forced && 'custom' !== $forced ) {
			return $forced;
		}
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$locale = strtolower( (string) $locale );
		if ( preg_match( '/^[a-z]{2,3}(?:[-_][a-z0-9]{2,8})?$/', $locale ) ) {
			$locale = str_replace( '_', '-', $locale );
			$parts  = explode( '-', $locale );
			return sanitize_key( $parts[0] ?: 'auto' );
		}
		return 'auto';
	}

	private function normalize_language_code( string $language ): string {
		$language = strtolower( trim( sanitize_text_field( $language ) ) );
		$map = [
			'dutch' => 'nl', 'nederlands' => 'nl', 'nl-nl' => 'nl',
			'english' => 'en', 'engels' => 'en', 'en-us' => 'en', 'en-gb' => 'en',
			'deutsch' => 'de', 'german' => 'de',
			'francais' => 'fr', 'français' => 'fr', 'french' => 'fr',
			'espanol' => 'es', 'español' => 'es', 'spanish' => 'es',
			'italiano' => 'it', 'italian' => 'it',
			'portugues' => 'pt', 'português' => 'pt', 'portuguese' => 'pt',
			'svenska' => 'sv', 'swedish' => 'sv',
			'polski' => 'pl', 'polish' => 'pl',
			'norsk' => 'no', 'norwegian' => 'no',
			'dansk' => 'da', 'danish' => 'da',
			'suomi' => 'fi', 'finnish' => 'fi',
			'japanese' => 'ja', '日本語' => 'ja',
		];
		if ( isset( $map[ $language ] ) ) {
			return $map[ $language ];
		}
		if ( 'auto' === $language || 'custom' === $language ) {
			return $language;
		}
		$language = str_replace( '_', '-', $language );
		if ( preg_match( '/^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$/', $language ) ) {
			$parts = explode( '-', $language );
			return sanitize_key( $parts[0] );
		}
		return '';
	}

	private function language_label_from_code( string $code ): string {
		$labels = [
			'nl' => 'Dutch',
			'en' => 'English',
			'de' => 'German',
			'fr' => 'French',
			'es' => 'Spanish',
			'it' => 'Italian',
			'pt' => 'Portuguese',
			'sv' => 'Swedish',
			'pl' => 'Polish',
			'no' => 'Norwegian',
			'da' => 'Danish',
			'fi' => 'Finnish',
			'ja' => 'Japanese',
			'custom' => $this->get_custom_language_label() ?: 'Custom language',
		];
		return $labels[ $code ] ?? ( $this->get_custom_language_label() ?: strtoupper( $code ) );
	}


	private function fallback_cluster_keywords( array $clusters, string $niche = '', string $description = '' ): array {
		$base = [];
		$seed_text = trim( strtolower( $niche . ' ' . $description ) );
		if ( $seed_text !== '' ) {
			$seed_text = preg_replace( '/[^\p{L}\p{N}\s-]+/u', ' ', $seed_text );
			$parts = preg_split( '/\s+/u', $seed_text, -1, PREG_SPLIT_NO_EMPTY );
			foreach ( $parts as $part ) {
				$part = trim( $part );
				if ( mb_strlen( $part ) >= 4 ) $base[] = $part;
			}
		}
		$base = array_values( array_unique( array_slice( $base, 0, 8 ) ) );
		$fallback = [];
		foreach ( $clusters as $cluster ) {
			$cluster = sanitize_text_field( (string) $cluster );
			if ( '' === $cluster ) continue;
			$cluster_parts = preg_split( '/\s+/u', preg_replace( '/[^\p{L}\p{N}\s-]+/u', ' ', mb_strtolower( $cluster ) ), -1, PREG_SPLIT_NO_EMPTY );
			$phrases = [
				$cluster,
				$cluster . ' uitleg',
				$cluster . ' strategie',
				$cluster . ' tips',
				$cluster . ' voorbeelden',
				$cluster . ' analyse',
				$cluster . ' voor beginners',
				$cluster . ' betekenis',
			];
			foreach ( array_slice( $base, 0, 4 ) as $token ) {
				$phrases[] = $cluster . ' ' . $token;
			}
			foreach ( $cluster_parts as $part ) {
				if ( mb_strlen( $part ) >= 4 ) {
					$phrases[] = $part;
					$phrases[] = $part . ' tips';
				}
			}
			$phrases = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $phrases ) ) ) );
			$fallback[ $cluster ] = array_slice( $phrases, 0, 12 );
		}
		return $fallback;
	}


	private function clip_after_conclusion_paragraph( string $html ): string {
		if ( preg_match( '/(<h2[^>]*>\s*(?:Conclusion|Conclusie|Final thoughts|Samenvatting)\s*<\/h2>[\s\S]*?<p>[\s\S]*?<\/p>)/isu', $html, $m ) ) {
			$keep = (string) $m[1];
			$prefix = strstr( $html, $keep, true );
			if ( false !== $prefix ) {
				return trim( $prefix . $keep );
			}
		}
		return $html;
	}

	private function normalize_article_output_html( string $html, bool $allow_svg = false ): string {
		$html = contentgem_clean_ai_article_output( $html, $allow_svg );
		$html = $this->cleanup_generated_draft_html( $html );
		$html = $this->strip_leading_article_artifacts( $html );
		if ( ! $allow_svg ) {
			$html = preg_replace( '/<figure[^>]*>[\s\S]*?<\/figure>/i', '', (string) $html );
			$html = preg_replace( '/<figcaption[\s\S]*?<\/figcaption>/i', '', (string) $html );
			$html = preg_replace( '/<cgm-svg-caption>[\s\S]*?<\/cgm-svg-caption>/i', '', (string) $html );
			$html = preg_replace( '/<svg[\s\S]*?<\/svg>/i', '', (string) $html );
			$html = preg_replace( '/<!--\s*cgm-svg-\d+\s*-->/i', '', (string) $html );
		}
		$html = $this->strip_trailing_visual_artifact_suffix( (string) $html );
		$html = preg_replace( '/(?:<p>\s*<\/p>\s*){1,}/i', '', (string) $html );
		$html = preg_replace( '/
{3,}/', "

", (string) $html );
		return trim( (string) $html );
	}

	private function strip_leading_article_artifacts( string $html ): string {
		$html = ltrim( str_replace( [ "\r\n", "\r" ], "\n", $html ) );
		$html = preg_replace( '/^\s*<!--\s*meta:.*?-->\s*/is', '', (string) $html );
		$html = preg_replace( '/^\s*(?:<p>\s*)?(?:nn|n\s*n|n)(?:\s*<\/p>)?\s*/iu', '', (string) $html );
		$html = preg_replace( '/^\s*(?:n|nn)?\s*`{1,3}\s*(?:html)?\s*/i', '', (string) $html );
		$html = preg_replace( '/^\s*[a-z]{1,3}\s*(?=<h1\b|<h2\b|<p\b)/u', '', (string) $html );
		if ( preg_match( '/^([^<]{1,16})(?=<h1\b|<h2\b|<p\b)/isu', $html, $m ) ) {
			$prefix = trim( html_entity_decode( wp_strip_all_tags( (string) $m[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			if ( '' !== $prefix && ! preg_match( '/[.!?:;]/u', $prefix ) && preg_match( '/^[\p{L}\p{N}\s-]{1,16}$/u', $prefix ) ) {
				$html = (string) substr( $html, strlen( (string) $m[1] ) );
			}
		}
		return ltrim( (string) $html );
	}

	private function cleanup_generated_draft_html( string $html ): string {
		$html = str_replace( [ "\r\n", "\r" ], "\n", $html );
		$html = preg_replace( '/^```(?:html)?\s*/i', '', trim( $html ) );
		$html = preg_replace( '/\s*```$/', '', (string) $html );
		$html = preg_replace( '/(?:^|\n)\s*(?:n|nn)?\s*`{1,3}\s*(?:html)?\s*(?=\n|$)/i', "\n", (string) $html );
		$html = preg_replace( '/`{1,3}\s*html\b/i', ' ', (string) $html );
		$html = preg_replace( '/<!--\s*cgm-insert-after:.*?-->/is', '', (string) $html );
		$html = preg_replace( '/<cgm-svg-caption>[\s\S]*?<\/cgm-svg-caption>/i', '', (string) $html );
		$html = preg_replace( '/<svg[\s\S]*?<\/svg>/i', '', (string) $html );
		$html = preg_replace( '/^(?:\s|&nbsp;)*(?:nn|n\s*n)\b[:\-–—]?\s*/iu', '', (string) $html );
		$html = preg_replace( '/<p>\s*(?:nn|n\s*n)\b[:\-–—]?\s*/iu', '<p>', (string) $html );
		$html = preg_replace( '/(^|>)(\s*)(?:nn|n\s*n)\b[:\-–—]?\s*(?=(\s|<))/iu', '$1$2', (string) $html );

		$artifact_patterns = [
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*(?:Pillar\s*Page|Technical\s*SEO|Core\s*Web\s*Vitals|XML\s*Sitemaps|Structured\s*Data|Crawl\s*Budget|Entity\s*Optimization|Knowledge\s*Graph)\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*Topic cluster architecture showing[^<\n]*\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*Semantic SEO Coverage Analysis\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*(?:Entity Coverage|Topic Clusters|Structured Data|Internal Linking|Knowledge Graph)\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*(?:Covered|Opportunity|Gap)\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*Horizontal gap coverage diagram showing[^<\n]*\s*<\/(?:p|div|span|li|figcaption)>/iu',
			'/<(?:p|div|span|li|figcaption)[^>]*>\s*(?:\d{1,3}%)\s*<\/(?:p|div|span|li|figcaption)>/iu',
		];
		foreach ( $artifact_patterns as $pattern ) {
			$html = preg_replace( $pattern, '', (string) $html );
		}

		$html = preg_replace( '/(?:<p>\s*<\/p>\s*){2,}/i', '', (string) $html );
		$html = preg_replace( '/\n{3,}/', "\n\n", (string) $html );
		$html = preg_replace( '/<p>\s*<\/p>/i', '', (string) $html );
		$html = $this->strip_trailing_visual_artifact_suffix( (string) $html );
		return trim( (string) $html );
	}

	private function strip_trailing_visual_artifact_suffix( string $html ): string {
		$html = trim( str_replace( [ "\r\n", "\r" ], "\n", $html ) );
		if ( '' === $html ) {
			return '';
		}

		$token_pattern = '/(<(?:p|h1|h2|h3|h4|h5|h6|ul|ol|table|blockquote|figure|pre)[^>]*>[\s\S]*?<\/(?:p|h1|h2|h3|h4|h5|h6|ul|ol|table|blockquote|figure|pre)>|[^<]+)/i';
		preg_match_all( $token_pattern, $html, $matches );
		$tokens = array_values( array_filter( (array) ( $matches[0] ?? [] ), static function( $token ): bool {
			return '' !== trim( (string) $token );
		} ) );
		if ( empty( $tokens ) ) {
			return $html;
		}

		$remove_from = count( $tokens );
		$artifact_tokens = 0;
		$special_tokens = 0;
		for ( $i = count( $tokens ) - 1; $i >= 0; $i-- ) {
			$analysis = $this->analyze_visual_artifact_token( (string) $tokens[$i] );
			if ( empty( $analysis['remove'] ) ) {
				break;
			}
			$remove_from = $i;
			$artifact_tokens++;
			$special_tokens += (int) ( $analysis['special'] ?? 0 );
		}

		$should_trim = false;
		if ( $artifact_tokens >= 3 ) {
			$should_trim = true;
		} elseif ( $artifact_tokens >= 1 && $special_tokens >= 2 ) {
			$should_trim = true;
		}
		if ( ! $should_trim || $remove_from >= count( $tokens ) ) {
			return $html;
		}
		$clean = trim( implode( '', array_slice( $tokens, 0, $remove_from ) ) );
		return '' !== $clean ? $clean : $html;
	}

	private function analyze_visual_artifact_token( string $token ): array {
		$prepared = preg_replace( '/<br\s*\/?>(\s*)/i', "\n", $token );
		$prepared = preg_replace( '/<\/(?:p|li|tr|td|th|h[1-6])>/i', "\n", (string) $prepared );
		$text = html_entity_decode( wp_strip_all_tags( (string) $prepared ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/[\t ]+/', ' ', (string) $text );
		$text = trim( preg_replace( '/\n{2,}/', "\n", (string) $text ) );
		if ( '' === $text ) {
			return [ 'remove' => true, 'special' => 0 ];
		}
		if ( preg_match( '/[.!?].{20,}/u', $text ) && str_word_count( wp_strip_all_tags( $text ) ) > 12 ) {
			return [ 'remove' => false, 'special' => 0 ];
		}
		$lines = array_values( array_filter( array_map( 'trim', preg_split( '/\n+/', $text ) ?: [] ), static function( string $line ): bool {
			return '' !== $line;
		} ) );
		if ( empty( $lines ) ) {
			return [ 'remove' => true, 'special' => 0 ];
		}
		$artifact_lines = 0;
		$special = 0;
		foreach ( $lines as $line ) {
			$normalized = trim( preg_replace( '/\s+/', ' ', $line ) );
			$word_count = preg_match_all( '/[\p{L}\p{N}%]+/u', $normalized, $m ) ? count( $m[0] ) : 0;
			$is_percentage = (bool) preg_match( '/^\d{1,3}%$/', $normalized );
			$is_descriptive = (bool) preg_match( '/\b(?:diagram|architecture|cluster|coverage|semantic|topical)\b.*\b(?:showing|analysis|map|overview)\b/iu', $normalized );
			$is_short_label = ! preg_match( '/[.!?:;]$/u', $normalized ) && $word_count > 0 && $word_count <= 4 && mb_strlen( $normalized ) <= 40;
			$looks_like_label_case = (bool) preg_match( '/^(?:[A-Z0-9][\p{L}\p{N}&-]*|[A-Z]{2,})(?:\s+(?:[A-Z0-9][\p{L}\p{N}&-]*|[A-Z]{2,})){0,3}$/u', $normalized );
			$is_legend = (bool) preg_match( '/^(?:covered|opportunity|gap|legend)$/iu', $normalized );
			if ( $is_percentage || $is_descriptive || $is_legend || ( $is_short_label && $looks_like_label_case ) ) {
				$artifact_lines++;
				if ( $is_percentage || $is_descriptive || $is_legend ) {
					$special++;
				}
			}
		}
		$line_count = count( $lines );
		$artifact_ratio = $line_count > 0 ? ( $artifact_lines / $line_count ) : 0;
		$remove = false;
		if ( $line_count >= 5 && $artifact_ratio >= 0.6 ) {
			$remove = true;
		} elseif ( $line_count >= 2 && $artifact_ratio >= 0.8 && $special >= 1 ) {
			$remove = true;
		} elseif ( 1 === $line_count && $artifact_ratio >= 1 && $special >= 1 ) {
			$remove = true;
		}
		return [ 'remove' => $remove, 'special' => $special ];
	}

	private function extract_svg_markup_only( string $response ): string {
		if ( false === stripos( $response, '<svg' ) ) {
			return '';
		}
		preg_match_all(
			'/(?:<!--\s*cgm-insert-after:\s*(.*?)\s*-->)?\s*(<svg[\s\S]*?<\/svg>)\s*(?:<cgm-svg-caption>[\s\S]*?<\/cgm-svg-caption>)?/i',
			$response,
			$matches,
			PREG_SET_ORDER
		);
		if ( empty( $matches ) ) {
			return '';
		}
		$parts = [];
		foreach ( $matches as $match ) {
			$full = trim( (string) ( $match[0] ?? '' ) );
			if ( '' !== $full && false !== stripos( $full, '<svg' ) ) {
				$parts[] = $full;
			}
		}
		return trim( implode( "\n\n", $parts ) );
	}

	public function post_draft_regenerate_visuals( WP_REST_Request $request ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Insufficient permissions.', 'contentgem' ), [ 'status' => 403 ] );
		}
		$wp_post_id = (int) $request->get_param( 'wp_post_id' );
		$post = get_post( $wp_post_id );
		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'not_found', __( 'Post not found.', 'contentgem' ), [ 'status' => 404 ] );
		}
		$raw_text = (string) get_post_meta( $wp_post_id, '_cgm_draft_text', true );
		$source_html = '' !== trim( $raw_text ) ? $raw_text : (string) $post->post_content;
		try {
			$client = new CGM_Claude_Client( $this->get_api_key() );
			preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/is', $source_html, $matches );
			$headings = array_values( array_slice( array_map( static function( string $heading ): string {
				return sanitize_text_field( wp_strip_all_tags( $heading ) );
			}, (array) ( $matches[1] ?? [] ) ), 0, 6 ) );
			$semantic = get_post_meta( $wp_post_id, '_cgm_semantic_keywords', true );
			$semantic = is_array( $semantic ) ? $semantic : [];
			$cluster = (string) get_post_meta( $wp_post_id, '_cgm_cluster', true );
			$visual_response = $client->generate_inline_draft_visuals( [
				'topic' => (string) $post->post_title,
				'suggested_title' => (string) $post->post_title,
				'primary_keyword' => (string) $post->post_title,
				'cluster_name' => $cluster,
				'h2_structure' => $headings,
				'gap_topics' => array_slice( $semantic, 0, 4 ),
			], $source_html );
			$visual_markup = $this->extract_svg_markup_only( (string) ( $visual_response['text'] ?? '' ) );
			$stored = CGM_Draft_SVG::store_for_post( $wp_post_id, '' !== $visual_markup ? (string) $visual_markup : $source_html, $source_html );
			return rest_ensure_response( [ 'success' => true, 'svg_count' => count( (array) ( $stored['svgs'] ?? [] ) ), 'wp_post_id' => $wp_post_id ] );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'visual_regeneration_failed', $e->getMessage(), [ 'status' => 500 ] );
		}
	}

	public function get_api_key(): string {
		$provider = (string) get_option( 'contentgem_ai_provider', 'claude' );
		if ( 'openai' === $provider ) {
			$key = (string) get_option( 'contentgem_openai_api_key', '' );
			if ( empty( $key ) ) {
				throw new \Exception( 'No API key set. Add your OpenAI API key in Contentgem Settings.' );
			}
			return $key;
		}
		$key = (string) get_option( 'contentgem_api_key', '' );
		if ( empty( $key ) ) {
			throw new \Exception( 'No API key set. Add your Anthropic API key in Contentgem Settings.' );
		}
		return $key;
	}

	private function build_context( object $gap ): array {
		global $wpdb;
		$site = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cgm_sites WHERE id = %d", $gap->site_id ) );

		// - Tone of voice --------------------------
		$tone = (string) get_option( 'contentgem_tone_of_voice', '' );
		if ( '' === $tone && ! empty( $site->tone_snapshot ) ) {
			$tone_analyzer = new CGM_Tone_Analyzer( CGM_AI_Client::from_settings() );
			$tone = $tone_analyzer->build_tone_instructions( (string) $site->tone_snapshot );
		}
		if ( '' === $tone ) {
			$tone = (string) ( $site->tone_snapshot ?? '' );
		}

		// - Pillar pages for this cluster -------------------
		$pillar_pages = [];
		$cluster_name = '';

		// Resolve cluster name from topic
		$topic = $wpdb->get_row( $wpdb->prepare(
			"SELECT cluster_name FROM {$wpdb->prefix}cgm_topics WHERE id = %d LIMIT 1",
			$gap->topic_id
		) );
		if ( $topic ) {
			$cluster_name = $topic->cluster_name;
		}

		$pillar_map = (array) get_option( 'contentgem_pillar_pages', [] );
		if ( $cluster_name && ! empty( $pillar_map[ $cluster_name ] ) ) {
			$raw_pillar = $pillar_map[ $cluster_name ];
			$pillar_id  = is_array( $raw_pillar ) ? (int) ( $raw_pillar[0] ?? 0 ) : (int) $raw_pillar;
			$pillar_url = get_permalink( $pillar_id );
			$pillar_ttl = get_the_title( $pillar_id );
			if ( $pillar_url && $pillar_ttl ) {
				$pillar_pages[] = [ 'title' => $pillar_ttl, 'url' => $pillar_url ];
			}
		}

		// - Competitor insights for this cluster ---------------â"€
		$competitor_insights = '';
		if ( $cluster_name ) {
			$competitor_insights = $this->get_competitor_insights_for_cluster( $cluster_name );
		}

		$semantic_keywords = $this->derive_semantic_keywords( (string) $gap->suggested_title, (string) $cluster_name, (int) $gap->site_id );
		$gsc_queries        = $this->get_relevant_gsc_queries_for_topic( (string) $gap->suggested_title, (string) $cluster_name );

		$language_sample = implode( ' ', array_filter( [
			(string) $gap->suggested_title,
			(string) $cluster_name,
			(string) ( $site->niche_label ?? '' ),
			implode( ' ', $semantic_keywords ),
			implode( ' ', $gsc_queries ),
		] ) );
		$forced_language = $this->normalize_language_code( (string) get_option( 'contentgem_content_language', 'auto' ) );
		if ( 'auto' !== $forced_language && '' !== $forced_language ) {
			$language_code = $forced_language;
		} else {
			$language_code = class_exists( 'CGM_NLP_Engine' ) ? ( new CGM_NLP_Engine() )->detect_language( $language_sample ) : $this->get_preferred_language_code();
		}

		return [
			'niche_label'         => $site->niche_label ?? '',
			'tone_instructions'   => $tone,
			'pillar_pages'        => $pillar_pages,
			'taal'                => $language_code ?: 'en',
			'gap_topic'           => $gap->suggested_title,
			'search_intent'       => $gap->search_intent,
			'competitor_insights' => $competitor_insights,
			'lsi_keywords'        => $semantic_keywords,
			'gsc_queries'         => $gsc_queries,
		];
	}

	/**
	 * Get formatted competitor insights for a cluster from the last analysis.
	 * Stored in WordPress option 'contentgem_competitor_cache_{cluster_hash}'.
	 */

	private function relink_gap_topic_to_best_cluster( object $gap ): string {
		global $wpdb;

		$title = sanitize_text_field( (string) ( $gap->suggested_title ?? '' ) );
		if ( '' === $title ) {
			return '';
		}

		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$clusters = is_array( $clusters ) ? $clusters : [];
		$cluster_keywords = get_option( 'cgm_cluster_keywords', [] );
		$cluster_keywords = is_array( $cluster_keywords ) ? $cluster_keywords : [];
		$title_lc = mb_strtolower( $title );
		$best_cluster = '';
		$best_score = 0;

		foreach ( $clusters as $cluster ) {
			$cluster = sanitize_text_field( (string) $cluster );
			if ( '' === $cluster ) {
				continue;
			}
			$score = 0;
			foreach ( preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $cluster ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $token ) {
				if ( mb_strlen( $token ) >= 4 && false !== mb_strpos( $title_lc, $token ) ) {
					$score += 3;
				}
			}
			foreach ( (array) ( $cluster_keywords[ $cluster ] ?? [] ) as $kw ) {
				$kw = mb_strtolower( sanitize_text_field( (string) $kw ) );
				if ( '' !== $kw && false !== mb_strpos( $title_lc, $kw ) ) {
					$score += 4;
				}
			}
			if ( $score > $best_score ) {
				$best_score = $score;
				$best_cluster = $cluster;
			}
		}

		if ( $best_score <= 0 ) {
			return '';
		}

		$site_id = $this->get_site_id();
		$topic = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, cluster_name FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name = %s ORDER BY id ASC LIMIT 1",
				$site_id,
				$best_cluster
			)
		);
		if ( ! $topic ) {
			return $best_cluster;
		}

		$wpdb->update(
			$wpdb->prefix . 'cgm_gaps',
			[ 'topic_id' => (int) $topic->id ],
			[ 'id' => (int) $gap->id ],
			[ '%d' ],
			[ '%d' ]
		);

		return (string) $topic->cluster_name;
	}

	private function get_competitor_insights_for_cluster( string $cluster_name ): string {
		$format_cache_key = 'cgm_comp_insight_fmt_' . md5( $cluster_name );
		$formatted_cached = CGM_Cache::get( $format_cache_key );
		if ( is_string( $formatted_cached ) ) {
			return $formatted_cached;
		}

		$lines = [];
		$cache_key = 'contentgem_comp_cache_' . md5( $cluster_name );
		$cached    = get_option( $cache_key, null );
		if ( is_array( $cached ) ) {
			if ( ! empty( $cached['avg_words'] ) ) {
				$lines[] = '- Target word count: ~' . absint( $cached['avg_words'] ) . ' words (competitor average).';
			}
			if ( ! empty( $cached['common_h2s'] ) && is_array( $cached['common_h2s'] ) ) {
				$h2_list = implode( ', ', array_slice( array_map( 'sanitize_text_field', $cached['common_h2s'] ), 0, 10 ) );
				$lines[] = '- Repeated competitor section themes: ' . $h2_list . '.';
			}
			$elements = [];
			if ( ! empty( $cached['pct_faq'] )    && $cached['pct_faq'] >= 0.5 )   $elements[] = 'FAQ section';
			if ( ! empty( $cached['pct_table'] )  && $cached['pct_table'] >= 0.5 )  $elements[] = 'comparison table';
			if ( ! empty( $cached['pct_schema'] ) && $cached['pct_schema'] >= 0.5 ) $elements[] = 'structured data (schema)';
			if ( ! empty( $elements ) ) {
				$lines[] = '- SERP format patterns used by most competitors: ' . implode( ', ', $elements ) . '.';
			}
			if ( ! empty( $cached['detailed_recommendations'] ) && is_array( $cached['detailed_recommendations'] ) ) {
				$top = array_slice( $cached['detailed_recommendations'], 0, 4 );
				foreach ( $top as $rec ) {
					$action = sanitize_text_field( (string) ( $rec['action'] ?? '' ) );
					$benefit = sanitize_text_field( (string) ( $rec['benefit'] ?? '' ) );
					if ( $action !== '' ) {
						$line = '- Detailed instruction: ' . $action;
						if ( $benefit !== '' ) {
							$line .= ' This improves your content because ' . $benefit;
						}
						$lines[] = $line;
					}
				}
			}
		}

		$grouped_history = $this->get_grouped_competitor_history();
		$history = $this->flatten_grouped_competitor_history( $grouped_history, $this->normalize_competitor_cluster_key( $cluster_name ) );
		if ( is_array( $history ) ) {
			if ( ! empty( $history ) ) {
				$history = array_slice( $history, 0, 8 );
				$avg_words = array_filter( array_map( 'absint', array_column( $history, 'avg_words' ) ) );
				if ( ! empty( $avg_words ) ) {
					$lines[] = '- Recent analyses suggest a working length of about ' . (int) round( array_sum( $avg_words ) / count( $avg_words ) ) . ' words.';
				}
				$all_h2s = [];
				$all_actions = [];
				$all_benefits = [];
				foreach ( $history as $item ) {
					foreach ( array_slice( (array) ( $item['common_h2s'] ?? [] ), 0, 10 ) as $h2 ) {
						$h2 = sanitize_text_field( (string) $h2 );
						if ( $h2 !== '' ) {
							$all_h2s[ strtolower( $h2 ) ] = $h2;
						}
					}
					foreach ( array_slice( (array) ( $item['recommendations'] ?? [] ), 0, 8 ) as $rec ) {
						$action = sanitize_text_field( (string) ( $rec['action'] ?? $rec['description'] ?? '' ) );
						$benefit = sanitize_text_field( (string) ( $rec['benefit'] ?? '' ) );
						if ( $action !== '' ) {
							$all_actions[ strtolower( $action ) ] = $action;
						}
						if ( $benefit !== '' ) {
							$all_benefits[ strtolower( $benefit ) ] = $benefit;
						}
					}
				}
				if ( ! empty( $all_h2s ) ) {
					$lines[] = '- Recurring competitor subtopics to include: ' . implode( ', ', array_slice( array_values( $all_h2s ), 0, 10 ) ) . '.';
				}
				if ( ! empty( $all_actions ) ) {
					$lines[] = '- High-priority writing actions from stored reports: ' . implode( ' | ', array_slice( array_values( $all_actions ), 0, 5 ) ) . '.';
				}
				if ( ! empty( $all_benefits ) ) {
					$lines[] = '- Expected improvement to your page: ' . implode( ' | ', array_slice( array_values( $all_benefits ), 0, 4 ) ) . '.';
				}
			}
		}

		if ( empty( $lines ) ) {
			return '';
		}
		$formatted = implode( "
", array_values( array_unique( $lines ) ) );
		CGM_Cache::set( $format_cache_key, $formatted, HOUR_IN_SECONDS );
		return $formatted;
	}
	private function calculate_overall_coverage( array $rows ): float {
		$overall = count( $rows ) > 0
			? array_sum( array_column( $rows, 'coverage_score' ) ) / count( $rows )
			: 0.0;
		return round( $overall, 2 );
	}

	public function post_auto_categorize( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;

		$posts = $wpdb->get_results(
			"SELECT ID, post_title FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			   AND ID NOT IN (
			     SELECT object_id FROM {$wpdb->term_relationships} tr
			     JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
			     WHERE tt.taxonomy = 'category' AND tt.term_id != 1
			   )"
		);

		$clusters_raw = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$clusters_raw = is_array( $clusters_raw ) ? $clusters_raw : [];

		$cluster_terms_raw = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_terms_raw = is_array( $cluster_terms_raw ) ? $cluster_terms_raw : [];

		if ( empty( $clusters_raw ) || empty( $posts ) ) {
			return rest_ensure_response( [ 'categorized' => 0, 'results' => [] ] );
		}

		$cluster_word_sets = [];
		foreach ( $clusters_raw as $cluster_name ) {
			$cluster_word_sets[ $cluster_name ] = $this->words_for_overlap( (string) $cluster_name );
		}

		$categorized = 0;
		$results     = [];

		foreach ( $posts as $post ) {
			$title_words  = $this->words_for_overlap( $post->post_title );
			$best_cluster = null;
			$best_overlap = 0;

			foreach ( $cluster_word_sets as $cluster_name => $cluster_words ) {
				if ( empty( $cluster_words ) ) continue;

				$intersection = count( array_intersect_key( $title_words, $cluster_words ) );

				if ( $intersection > $best_overlap ) {
					$best_overlap = $intersection;
					$best_cluster = $cluster_name;
				}
			}

			if ( null === $best_cluster || 0 === $best_overlap ) {
				continue;
			}

			$term_data   = $cluster_terms_raw[ $best_cluster ] ?? null;
			$category_id = (int) ( $term_data['category_id'] ?? 0 );
			$tag_id      = (int) ( $term_data['tag_id'] ?? 0 );

			if ( $category_id > 0 ) {
				wp_set_post_categories( (int) $post->ID, [ $category_id ] );
			}

			if ( $tag_id > 0 ) {
				$tag = get_term( $tag_id, 'post_tag' );
				if ( $tag instanceof WP_Term ) {
					wp_set_post_tags( (int) $post->ID, [ $tag->name ] );
				}
			}

			wp_update_post( [
				'ID'        => (int) $post->ID,
				'post_name' => sanitize_title( $post->post_title ),
			] );

			$results[] = [
				'post_id'          => (int) $post->ID,
				'title'            => $post->post_title,
				'assigned_cluster' => $best_cluster,
			];
			++$categorized;
		}

		do_action( 'contentgem/posts_auto_categorized', $categorized, $results );

		return rest_ensure_response( [ 'categorized' => $categorized, 'results' => $results ] );
	}





	// - Competitor Page Comparator ---------------------

	/**
	 * POST /competitor/analyze
	 *
	 * Fetches and parses your page + competitor pages, then builds a gap report.
	 * No external APIs needed - pure HTML parsing via DOMDocument.
	 */

	/**
	 * POST /competitor/create-gaps
	 *
	 * Converts detected competitor gaps into rows in cgm_gaps.
	 * Priority score:
	 *  - Base: 70 (externally validated via competitor pages)
	 *  - +10 if severity = high
	 *  - +5 per competitor that has the topic (max +15)
	 *  - Deduplication: skip if a gap with same title already exists for this site
	 */
	public function post_competitor_create_gaps( WP_REST_Request $request ) {
		global $wpdb;

		$body          = $request->get_json_params();
		$keyword       = sanitize_text_field( $body['keyword'] ?? '' );
		$cluster       = sanitize_text_field( $body['cluster'] ?? '' );
		$gaps          = (array) ( $body['gaps'] ?? [] );
		$comp_h2s      = array_map( 'sanitize_text_field', (array) ( $body['competitor_h2s'] ?? [] ) );

		if ( empty( $gaps ) ) {
			return new WP_Error( 'no_gaps', 'No gaps provided.', [ 'status' => 400 ] );
		}

		// Resolve site_id and topic_id
		$site_id  = (int) get_option( 'cgm_site_id', 0 );
		if ( ! $site_id ) {
			// Try to find site row
			$site_id = (int) $wpdb->get_var( "SELECT id FROM {$wpdb->prefix}cgm_sites ORDER BY id ASC LIMIT 1" );
		}
		if ( ! $site_id ) {
			return new WP_Error( 'no_site', 'Run a site analysis first before creating gaps.', [ 'status' => 422 ] );
		}

		// Resolve topic_id for the cluster (or first available topic)
		$topic_id = 0;
		if ( ! empty( $cluster ) ) {
			$topic_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d AND cluster_name = %s LIMIT 1",
				$site_id, $cluster
			) );
		}
		if ( ! $topic_id ) {
			$topic_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}cgm_topics WHERE site_id = %d ORDER BY id ASC LIMIT 1",
				$site_id
			) );
		}
		if ( ! $topic_id ) {
			return new WP_Error( 'no_topic', 'No topic clusters found. Run a site analysis first.', [ 'status' => 422 ] );
		}

		// Load existing gap titles for deduplication
		$existing_titles = $wpdb->get_col( $wpdb->prepare(
			"SELECT suggested_title FROM {$wpdb->prefix}cgm_gaps WHERE site_id = %d",
			$site_id
		) );
		$existing_titles_lc = array_map( 'mb_strtolower', $existing_titles );

		$created = [];

		// - Gap 1: missing_h2 topics â†' individual gap entries -------â"€
		foreach ( $gaps as $gap ) {
			$type     = $gap['type'] ?? '';
			$severity = $gap['severity'] ?? 'medium';
			$action   = $gap['action'] ?? '';

			if ( $type === 'missing_h2' ) {
				// Extract topic names from action string: "Consider adding sections about: X, Y, Z."
				$topics_raw = '';
				if ( preg_match( '/about:\s*(.+)\.?$/i', $action, $m ) ) {
					$topics_raw = $m[1];
				}
				$topic_names = array_filter( array_map( 'trim', explode( ',', $topics_raw ) ) );

				foreach ( $topic_names as $topic_name ) {
					$title = ucfirst( $topic_name );
					if ( in_array( mb_strtolower( $title ), $existing_titles_lc, true ) ) continue;

					// Count how many competitors cover this topic
					$comp_coverage = 0;
					foreach ( $comp_h2s as $h2 ) {
						similar_text( mb_strtolower( $topic_name ), mb_strtolower( $h2 ), $pct );
						if ( $pct > 50 ) { $comp_coverage++; }
					}

					$priority = 70.0
						+ ( 'high' === $severity ? 10.0 : ( 'medium' === $severity ? 5.0 : 0.0 ) )
						+ min( $comp_coverage * 5.0, 15.0 );

					$inserted = $wpdb->insert(
						$wpdb->prefix . 'cgm_gaps',
						[
							'site_id'        => $site_id,
							'topic_id'       => $topic_id,
							'suggested_title' => $title,
							'search_intent'  => 'informational',
							'priority_score' => $priority,
							'status'         => 'open',
						],
						[ '%d', '%d', '%s', '%s', '%f', '%s' ]
					);

					if ( $inserted ) {
						$existing_titles_lc[] = mb_strtolower( $title );
						$created[] = [
							'title'          => $title,
							'intent'         => 'informational',
							'priority_score' => $priority,
						];
					}
				}
			} elseif ( in_array( $type, [ 'missing_element', 'thin_content', 'missing_schema' ], true ) ) {
				// These become a single improvement gap for the keyword
				$title = 'Improve: ' . $keyword . ' (' . str_replace( '_', ' ', $type ) . ')';
				if ( in_array( mb_strtolower( $title ), $existing_titles_lc, true ) ) continue;

				$priority = 65.0 + ( 'high' === $severity ? 10.0 : ( 'medium' === $severity ? 5.0 : 0.0 ) );

				$inserted = $wpdb->insert(
					$wpdb->prefix . 'cgm_gaps',
					[
						'site_id'        => $site_id,
						'topic_id'       => $topic_id,
						'suggested_title' => $title,
						'search_intent'  => 'informational',
						'priority_score' => $priority,
						'status'         => 'open',
					],
					[ '%d', '%d', '%s', '%s', '%f', '%s' ]
				);

				if ( $inserted ) {
					$existing_titles_lc[] = mb_strtolower( $title );
					$created[] = [
						'title'          => $title,
						'intent'         => 'informational',
						'priority_score' => $priority,
					];
				}
			}
		}

		return rest_ensure_response( [
			'created' => $created,
			'total'   => count( $created ),
		] );
	}

	public function get_competitor_latest_analysis( WP_REST_Request $request ): WP_REST_Response {
		$cluster = sanitize_text_field( (string) $request->get_param( 'cluster' ) );
		$latest  = [];
		if ( '' !== $cluster ) {
			$cluster_key       = $this->normalize_competitor_cluster_key( $cluster );
			$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
			$latest_by_cluster = is_array( $latest_by_cluster ) ? $latest_by_cluster : [];
			$latest            = (array) ( $latest_by_cluster[ $cluster_key ] ?? [] );
		}
		if ( empty( $latest ) ) {
			$latest = get_option( 'contentgem_latest_competitor_analysis', [] );
		}
		if ( ! is_array( $latest ) ) {
			$latest = [];
		}
		return rest_ensure_response( [ 'item' => $latest, 'analysis' => $latest, 'cluster' => $cluster ] );
	}


	public function get_competitor_meta_summary( WP_REST_Request $request ): WP_REST_Response {
		$cluster = sanitize_text_field( (string) $request->get_param( 'cluster' ) );
		$cluster_key = $this->normalize_competitor_cluster_key( $cluster );
		$grouped = $this->get_grouped_competitor_history();
		$items = '' !== $cluster ? $this->flatten_grouped_competitor_history( $grouped, $cluster_key ) : $this->flatten_grouped_competitor_history( $grouped );
		$latest = [];
		if ( '' !== $cluster ) {
			$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
			$latest_by_cluster = is_array( $latest_by_cluster ) ? $latest_by_cluster : [];
			$latest = (array) ( $latest_by_cluster[ $cluster_key ] ?? [] );
		} else {
			$latest = get_option( 'contentgem_latest_competitor_analysis', [] );
		}
		if ( is_array( $latest ) && ! empty( $latest ) ) {
			$latest_entry = isset( $latest['competitors'], $latest['gaps'] ) ? $this->make_competitor_history_entry( $latest ) : $latest;
			if ( is_array( $latest_entry ) && ! empty( $latest_entry ) ) {
				$items = array_merge( [ $latest_entry ], $items );
			}
		}
		$deduped = [];
		$seen = [];
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) { continue; }
			$key = sanitize_text_field( (string) ( $item['id'] ?? '' ) );
			if ( '' === $key ) {
				$key = strtolower( trim( (string) ( $item['cluster'] ?? '' ) ) ) . '|' . strtolower( trim( (string) ( $item['keyword'] ?? '' ) ) ) . '|' . sanitize_text_field( (string) ( $item['captured_at'] ?? '' ) );
			}
			if ( isset( $seen[ $key ] ) ) { continue; }
			$seen[ $key ] = true;
			$deduped[] = $item;
		}
		$summary = $this->build_competitor_meta_summary( $deduped, $cluster );
		$items = $deduped;
		return rest_ensure_response( [ 'summary' => $summary, 'items' => $items, 'cluster' => $cluster ] );
	}


	public function post_competitor_find_competitors( WP_REST_Request $request ) {
		$body            = (array) $request->get_json_params();
		$cluster         = sanitize_text_field( (string) ( $body['cluster'] ?? '' ) );
		$explicit_keyword = sanitize_text_field( (string) ( $body['keyword'] ?? '' ) );
		$keywords        = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $body['keywords'] ?? [] ) ) ) );
		if ( '' !== $explicit_keyword ) {
			array_unshift( $keywords, $explicit_keyword );
		}
		$keywords = array_values( array_unique( array_filter( $keywords ) ) );

		if ( '' === $cluster && empty( $keywords ) ) {
			return new WP_Error( 'missing_cluster', 'Select a cluster or provide keywords first.', [ 'status' => 400 ] );
		}

		$seed_queries = [];
		if ( '' !== $explicit_keyword ) {
			$seed_queries[] = $explicit_keyword;
			if ( '' !== $cluster ) {
				$seed_queries[] = $explicit_keyword . ' ' . $cluster;
				$seed_queries[] = $cluster . ' ' . $explicit_keyword;
			}
		}
		if ( '' !== $cluster && '' === $explicit_keyword ) {
			$seed_queries[] = $cluster;
		}
		foreach ( array_slice( $keywords, 0, 8 ) as $keyword ) {
			$seed_queries[] = $keyword;
			if ( '' !== $cluster ) {
				$seed_queries[] = $cluster . ' ' . $keyword;
			}
		}
		$seed_queries = array_values( array_unique( array_filter( array_map( 'trim', $seed_queries ) ) ) );

		$own_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$own_host = is_string( $own_host ) ? preg_replace( '/^www\./', '', strtolower( $own_host ) ) : '';
		$reference_terms = $this->cgm_build_reference_terms( $cluster, $keywords );
		$keyword_terms   = '' !== $explicit_keyword ? $this->cgm_build_reference_terms( $explicit_keyword, [ $explicit_keyword ] ) : $reference_terms;
		$candidates = [];

		foreach ( array_slice( $seed_queries, 0, 10 ) as $query ) {
			$search_url = 'https://html.duckduckgo.com/html/?q=' . rawurlencode( $query );
			$response   = wp_remote_get( $search_url, [
				'timeout'    => 12,
				'user-agent' => 'Mozilla/5.0 (compatible; ContentGem/1.0; +https://contentgem.ai)',
			] );
			if ( is_wp_error( $response ) ) {
				continue;
			}
			$html = (string) wp_remote_retrieve_body( $response );
			if ( '' === $html ) {
				continue;
			}
			$rank = 0;
			foreach ( $this->cgm_extract_serp_candidates_from_html( $html ) as $url ) {
				$rank++;
				$host = wp_parse_url( $url, PHP_URL_HOST );
				$host = is_string( $host ) ? preg_replace( '/^www\./', '', strtolower( $host ) ) : '';
				if ( '' === $host || $host === $own_host || $this->cgm_is_irrelevant_serp_host( $host, $url ) ) {
					continue;
				}
				if ( ! isset( $candidates[ $url ] ) ) {
					$candidates[ $url ] = [
						'url'        => $url,
						'host'       => $host,
						'query_hits' => 0,
						'query_rank' => 0,
					];
				}
				$candidates[ $url ]['query_hits']++;
				$candidates[ $url ]['query_rank'] += max( 0, 12 - $rank );
			}
		}

		if ( empty( $candidates ) ) {
			return rest_ensure_response( [ 'urls' => [], 'cluster' => $cluster, 'queries' => $seed_queries ] );
		}

		$scored = [];
		foreach ( array_slice( array_values( $candidates ), 0, 24 ) as $candidate ) {
			$page  = $this->parse_page( $candidate['url'] );
			$score = $this->cgm_score_competitor_candidate( $candidate, $page, $reference_terms );
			if ( '' !== $explicit_keyword ) {
				$score += $this->cgm_score_competitor_keyword_relevance( $page, $keyword_terms );
			}
			$score += $this->cgm_score_competitor_freshness( $page );
			if ( $score <= 0 ) {
				continue;
			}
			if ( '' !== $explicit_keyword && ! $this->cgm_competitor_matches_keyword_focus( $page, $keyword_terms ) ) {
				continue;
			}
			$scored[] = [
				'url'              => $candidate['url'],
				'host'             => $candidate['host'],
				'host_group'       => $this->cgm_normalize_host_group( (string) $candidate['host'] ),
				'score'            => round( $score, 2 ),
				'title'            => sanitize_text_field( (string) ( $page['title'] ?? '' ) ),
				'word_count'       => absint( $page['word_count'] ?? 0 ),
				'freshness'        => sanitize_text_field( (string) ( $page['freshness'] ?? '' ) ),
				'freshness_reason' => sanitize_text_field( (string) ( $page['freshness_reason'] ?? '' ) ),
				'query_hits'       => (int) ( $candidate['query_hits'] ?? 0 ),
				'query_rank'       => (int) ( $candidate['query_rank'] ?? 0 ),
			];
		}

		if ( empty( $scored ) ) {
			return rest_ensure_response( [ 'urls' => [], 'cluster' => $cluster, 'queries' => $seed_queries ] );
		}

		usort( $scored, function( $a, $b ) {
			return ( $b['score'] <=> $a['score'] );
		} );

		$selected_hosts  = [];
		$selected_groups = [];
		$selected_slugs  = [];
		$selected_rows   = [];
		$pool            = $scored;

		while ( ! empty( $pool ) && count( $selected_rows ) < 5 ) {
			$best_index = null;
			$best_score = null;
			foreach ( $pool as $index => $row ) {
				$adjusted = (float) $row['score'];
				$host      = (string) ( $row['host'] ?? '' );
				$group     = (string) ( $row['host_group'] ?? $this->cgm_normalize_host_group( $host ) );
				$slug      = $this->cgm_competitor_slug_fingerprint( (string) ( $row['url'] ?? '' ) );

				$adjusted -= (float) ( ( $selected_hosts[ $host ] ?? 0 ) * 18 );
				$adjusted -= (float) ( ( $selected_groups[ $group ] ?? 0 ) * 8 );
				$adjusted -= (float) ( ( $selected_slugs[ $slug ] ?? 0 ) * 10 );
				if ( '' !== $group && ( $selected_groups[ $group ] ?? 0 ) >= 2 ) {
					$adjusted -= 14;
				}
				if ( null === $best_score || $adjusted > $best_score ) {
					$best_score = $adjusted;
					$best_index = $index;
				}
			}

			if ( null === $best_index ) {
				break;
			}

			$pick = $pool[ $best_index ];
			unset( $pool[ $best_index ] );
			$host  = (string) ( $pick['host'] ?? '' );
			$group = (string) ( $pick['host_group'] ?? $this->cgm_normalize_host_group( $host ) );
			$slug  = $this->cgm_competitor_slug_fingerprint( (string) ( $pick['url'] ?? '' ) );
			$selected_hosts[ $host ]  = ( $selected_hosts[ $host ] ?? 0 ) + 1;
			$selected_groups[ $group ] = ( $selected_groups[ $group ] ?? 0 ) + 1;
			$selected_slugs[ $slug ]   = ( $selected_slugs[ $slug ] ?? 0 ) + 1;
			$selected_rows[] = $pick;
		}

		return rest_ensure_response( [
			'cluster' => $cluster,
			'queries' => $seed_queries,
			'urls'    => array_values( array_map( static function( $row ) { return (string) ( $row['url'] ?? '' ); }, $selected_rows ) ),
			'scored'  => array_slice( $scored, 0, 12 ),
			'selected' => $selected_rows,
		] );
	}


	private function cgm_score_competitor_keyword_relevance( array $page, array $keyword_terms ): float {
		if ( empty( $keyword_terms ) ) {
			return 0.0;
		}
		$score   = 0.0;
		$title   = strtolower( (string) ( $page['title'] ?? '' ) );
		$h1      = strtolower( (string) ( $page['h1'] ?? '' ) );
		$meta    = strtolower( (string) ( $page['meta_description'] ?? '' ) );
		$url     = strtolower( (string) ( $page['url'] ?? '' ) );
		$h2_text = strtolower( implode( ' ', array_slice( (array) ( $page['h2s'] ?? [] ), 0, 12 ) ) );
		$haystacks = [
			[ $title, 10.0 ],
			[ $h1, 9.0 ],
			[ $url, 6.0 ],
			[ $meta, 4.5 ],
			[ $h2_text, 2.0 ],
		];
		foreach ( $keyword_terms as $term ) {
			$term = strtolower( trim( (string) $term ) );
			if ( '' === $term ) {
				continue;
			}
			foreach ( $haystacks as $pair ) {
				if ( false !== strpos( $pair[0], $term ) ) {
					$score += $pair[1];
				}
			}
			$tokens = array_values( array_filter( preg_split( '/[^\p{L}\p{N}]+/u', $term ) ) );
			if ( ! empty( $tokens ) ) {
				$combined = $title . ' ' . $h1 . ' ' . $url . ' ' . $meta;
				$hits = 0;
				foreach ( $tokens as $token ) {
					if ( false !== strpos( $combined, strtolower( $token ) ) ) {
						$hits++;
					}
				}
				$score += $hits * 1.75;
			}
		}
		return $score;
	}

	private function cgm_competitor_matches_keyword_focus( array $page, array $keyword_terms ): bool {
		if ( empty( $keyword_terms ) ) {
			return true;
		}
		$primary = strtolower( trim( (string) reset( $keyword_terms ) ) );
		if ( '' === $primary ) {
			return true;
		}
		$title = strtolower( (string) ( $page['title'] ?? '' ) );
		$h1    = strtolower( (string) ( $page['h1'] ?? '' ) );
		$meta  = strtolower( (string) ( $page['meta_description'] ?? '' ) );
		$url   = strtolower( (string) ( $page['url'] ?? '' ) );
		if ( false !== strpos( $title, $primary ) || false !== strpos( $h1, $primary ) || false !== strpos( $url, sanitize_title( $primary ) ) ) {
			return true;
		}
		$primary_tokens = array_values( array_filter( preg_split( '/[^\p{L}\p{N}]+/u', $primary ) ) );
		$combined = strtolower( trim( $title . ' ' . $h1 . ' ' . $url . ' ' . $meta . ' ' . implode( ' ', array_slice( (array) ( $page['h2s'] ?? [] ), 0, 8 ) ) ) );
		$matches = 0;
		foreach ( $primary_tokens as $token ) {
			$token = strtolower( trim( (string) $token ) );
			if ( '' !== $token && false !== strpos( $combined, $token ) ) {
				$matches++;
			}
		}
		$required = max( 1, (int) ceil( count( $primary_tokens ) * 0.75 ) );
		if ( count( $primary_tokens ) <= 2 ) {
			$required = count( $primary_tokens );
		}
		return $matches >= $required;
	}

	private function cgm_extract_serp_candidates_from_html( string $html ): array {
		$urls = [];

		if ( preg_match_all( '/<a[^>]+class="[^"]*(?:result__a|result-link)[^"]*"[^>]+href="([^"]+)"/i', $html, $matches ) ) {
			foreach ( (array) $matches[1] as $href ) {
				$href = html_entity_decode( (string) $href, ENT_QUOTES | ENT_HTML5 );
				if ( preg_match( '/uddg=([^&]+)/', $href, $m ) ) {
					$href = rawurldecode( $m[1] );
				}
				$href = esc_url_raw( $href );
				if ( preg_match( '#^https?://#i', $href ) ) {
					$urls[] = $href;
				}
			}
		}

		if ( empty( $urls ) && preg_match_all( "#https?://[^\\s\"'<>]+#i", $html, $matches ) ) {
			foreach ( (array) $matches[0] as $href ) {
				$href = html_entity_decode( (string) $href, ENT_QUOTES | ENT_HTML5 );
				if ( preg_match( '#^https?://#i', $href ) ) {
					$urls[] = esc_url_raw( $href );
				}
			}
		}

		$urls = array_values( array_unique( array_filter( $urls ) ) );
		return array_slice( $urls, 0, 20 );
	}

	private function cgm_is_irrelevant_serp_host( string $host, string $url = '' ): bool {
		$host = strtolower( preg_replace( '/^www\./', '', $host ) );
		$blocked_hosts = [
			'youtube.com', 'facebook.com', 'instagram.com', 'linkedin.com', 'pinterest.com', 'x.com', 'twitter.com', 'tiktok.com', 'reddit.com', 'amazon.com',
			'duckduckgo.com', 'google.com', 'bing.com', 'w3.org', 'wikipedia.org', 'wiktionary.org', 'springer.com', 'link.springer.com', 'sciencedirect.com', 'doi.org'
		];
		if ( in_array( $host, $blocked_hosts, true ) ) {
			return true;
		}
		$path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		$path_blocks = [ '/wp-admin/', '/tag/', '/author/', '/search', '/book/', '/wiki/', '/privacy', '/login', '/account', '/feed', '.pdf' ];
		foreach ( $path_blocks as $block ) {
			if ( false !== strpos( $path, strtolower( $block ) ) ) {
				return true;
			}
		}
		return false;
	}

	private function cgm_build_reference_terms( string $cluster, array $keywords ): array {
		$text = trim( $cluster . ' ' . implode( ' ', $keywords ) );
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $text ) );
		$stop = [ 'the','and','for','with','from','that','this','your','you','een','het','van','voor','met','over','naar','de','en','how','what','best','guide' ];
		$terms = [];
		foreach ( (array) $tokens as $token ) {
			$token = trim( (string) $token );
			if ( mb_strlen( $token ) < 3 || in_array( $token, $stop, true ) ) {
				continue;
			}
			$terms[ $token ] = true;
		}
		return array_keys( $terms );
	}

	private function cgm_token_overlap_score( array $reference_terms, string $text ): int {
		if ( empty( $reference_terms ) || '' === trim( $text ) ) {
			return 0;
		}
		$text_terms = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $text ) );
		$text_terms = array_filter( array_map( 'trim', (array) $text_terms ) );
		$ref_map = array_fill_keys( $reference_terms, true );
		$score = 0;
		foreach ( $text_terms as $term ) {
			if ( isset( $ref_map[ $term ] ) ) {
				$score++;
			}
		}
		return $score;
	}

	private function cgm_normalize_host_group( string $host ): string {
		$host = preg_replace( '/^www\./', '', strtolower( trim( $host ) ) );
		if ( '' === $host ) {
			return '';
		}
		$parts = array_values( array_filter( explode( '.', $host ) ) );
		$count = count( $parts );
		if ( $count <= 2 ) {
			return $host;
		}
		return implode( '.', array_slice( $parts, -2 ) );
	}

	private function cgm_competitor_slug_fingerprint( string $url ): string {
		$path = strtolower( trim( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		$path = preg_replace( '#/+#', '/', $path );
		$path = trim( (string) $path, '/' );
		if ( '' === $path ) {
			return 'home';
		}
		$parts = array_values( array_filter( explode( '/', $path ) ) );
		return implode( '/', array_slice( $parts, 0, 2 ) );
	}

	private function cgm_score_competitor_freshness( array $page ): float {
		$score = 0.0;
		$freshness = trim( (string) ( $page['freshness'] ?? '' ) );
		if ( '' !== $freshness ) {
			$ts = strtotime( $freshness );
			if ( $ts ) {
				$days_old = (int) floor( ( time() - $ts ) / DAY_IN_SECONDS );
				if ( $days_old <= 30 ) {
					$score += 10.0;
				} elseif ( $days_old <= 180 ) {
					$score += 8.0;
				} elseif ( $days_old <= 365 ) {
					$score += 6.0;
				} elseif ( $days_old <= 730 ) {
					$score += 2.5;
				} elseif ( $days_old <= 1460 ) {
					$score -= 1.0;
				} else {
					$score -= 6.0;
				}
			}
		}

		$combined = strtolower( trim( (string) ( $page['title'] ?? '' ) . ' ' . (string) ( $page['h1'] ?? '' ) . ' ' . (string) ( $page['meta_description'] ?? '' ) . ' ' . (string) ( $page['url'] ?? '' ) ) );
		$current_year = (int) gmdate( 'Y' );
		$recent_year_hits = 0;
		for ( $year = $current_year; $year >= $current_year - 2; $year-- ) {
			if ( false !== strpos( $combined, (string) $year ) ) {
				$recent_year_hits++;
			}
		}
		$score += min( 4.5, $recent_year_hits * 2.0 );

		$recency_terms = [ 'updated', 'latest', 'new', '2024', '2025', '2026', 'gids 202', 'guide 202', 'beste', 'best ', 'comparison', 'vs ' ];
		foreach ( $recency_terms as $term ) {
			if ( false !== strpos( $combined, strtolower( $term ) ) ) {
				$score += 0.75;
			}
		}

		return $score;
	}

	private function cgm_score_competitor_candidate( array $candidate, array $page, array $reference_terms ): float {
		if ( ! empty( $page['error'] ) ) {
			return -100.0;
		}
		$score = 0.0;
		$score += (float) ( (int) ( $candidate['query_hits'] ?? 0 ) * 8 );
		$score += (float) ( (int) ( $candidate['query_rank'] ?? 0 ) * 1.5 );
		$score += (float) ( $this->cgm_token_overlap_score( $reference_terms, (string) ( $page['title'] ?? '' ) ) * 5 );
		$score += (float) ( $this->cgm_token_overlap_score( $reference_terms, (string) ( $page['h1'] ?? '' ) ) * 6 );
		$score += (float) ( $this->cgm_token_overlap_score( $reference_terms, (string) ( $page['meta_description'] ?? '' ) ) * 2 );
		$score += (float) ( $this->cgm_token_overlap_score( $reference_terms, (string) ( $candidate['url'] ?? '' ) ) * 2 );
		$score += (float) ( $this->cgm_token_overlap_score( $reference_terms, implode( ' ', array_slice( (array) ( $page['h2s'] ?? [] ), 0, 12 ) ) ) * 1.5 );
		$word_count = absint( $page['word_count'] ?? 0 );
		if ( $word_count >= 500 && $word_count <= 8000 ) {
			$score += 12;
		} elseif ( $word_count < 250 ) {
			$score -= 20;
		} elseif ( $word_count > 15000 ) {
			$score -= 10;
		}
		$h2_count = is_array( $page['h2s'] ?? null ) ? count( (array) $page['h2s'] ) : 0;
		if ( $h2_count >= 3 ) {
			$score += min( 10, $h2_count );
		}
		if ( ! empty( $page['has_faq'] ) ) { $score += 2; }
		if ( ! empty( $page['has_table'] ) ) { $score += 2; }
		if ( ! empty( $page['has_schema'] ) ) { $score += 1; }
		if ( $this->cgm_is_irrelevant_serp_host( (string) ( $candidate['host'] ?? '' ), (string) ( $candidate['url'] ?? '' ) ) ) {
			$score -= 50;
		}
		return $score;
	}

	private function build_detailed_competitor_guidance( string $keyword, ?array $your_page, array $competitors, array $gaps ): array {
		$comp_ok = array_values( array_filter( $competitors, function( $c ) { return empty( $c['error'] ); } ) );
		if ( empty( $comp_ok ) ) {
			return [];
		}

		$word_counts = array_filter( array_map( 'absint', array_column( $comp_ok, 'word_count' ) ) );
		sort( $word_counts );
		$median = $word_counts ? $word_counts[(int) floor( count( $word_counts ) / 2 )] : 0;
		$avg_h2 = (int) round( array_sum( array_map( function( $c ) { return is_array( $c['h2s'] ?? null ) ? count( $c['h2s'] ) : 0; }, $comp_ok ) ) / max( 1, count( $comp_ok ) ) );
		$avg_images = (int) round( array_sum( array_map( function( $c ) { return absint( $c['image_count'] ?? 0 ); }, $comp_ok ) ) / max( 1, count( $comp_ok ) ) );
		$faq_pct = (int) round( 100 * count( array_filter( $comp_ok, function( $c ) { return ! empty( $c['has_faq'] ); } ) ) / max( 1, count( $comp_ok ) ) );
		$table_pct = (int) round( 100 * count( array_filter( $comp_ok, function( $c ) { return ! empty( $c['has_table'] ); } ) ) / max( 1, count( $comp_ok ) ) );
		$schema_pct = (int) round( 100 * count( array_filter( $comp_ok, function( $c ) { return ! empty( $c['has_schema'] ); } ) ) / max( 1, count( $comp_ok ) ) );
		$avg_internal_links = (int) round( array_sum( array_map( function( $c ) { return absint( $c['internal_links'] ?? 0 ); }, $comp_ok ) ) / max( 1, count( $comp_ok ) ) );

		$all_h2s = [];
		foreach ( $comp_ok as $comp ) {
			foreach ( array_slice( (array) ( $comp['h2s'] ?? [] ), 0, 18 ) as $h2 ) {
				$h2 = sanitize_text_field( (string) $h2 );
				if ( '' === $h2 ) {
					continue;
				}
				$key = strtolower( $h2 );
				$all_h2s[ $key ] = ( $all_h2s[ $key ] ?? 0 ) + 1;
			}
		}
		arsort( $all_h2s );
		$top_h2s = array_slice( array_keys( $all_h2s ), 0, 12 );

		$gaps_by_severity = [ 'critical' => [], 'high' => [], 'medium' => [], 'low' => [] ];
		foreach ( $gaps as $gap ) {
			$severity = sanitize_text_field( (string) ( $gap['severity'] ?? 'low' ) );
			if ( ! isset( $gaps_by_severity[ $severity ] ) ) {
				$severity = 'low';
			}
			$gaps_by_severity[ $severity ][] = sanitize_text_field( (string) ( $gap['description'] ?? $gap['action'] ?? '' ) );
		}

		$instructions = [];
		$instructions[] = [
			'type' => 'content_blueprint',
			'severity' => 'high',
			'description' => sprintf( 'Competitors targeting "%s" typically publish long-form pages around %d words with roughly %d H2 sections.', $keyword, max( 900, $median ), max( 4, $avg_h2 ) ),
			'action' => sprintf( 'Build a comprehensive page brief for "%s" with a concise SERP-matching introduction, %d to %d substantial H2 sections, a practical FAQ, and a conclusion with next-step guidance.', $keyword, max( 4, $avg_h2 - 1 ), max( 6, $avg_h2 + 2 ) ),
			'benefit' => 'This gives your content the same depth and breadth that already performs in the SERP, while making the page feel complete rather than thin.',
		];
		if ( ! empty( $top_h2s ) ) {
			$instructions[] = [
				'type' => 'section_coverage',
				'severity' => 'high',
				'description' => 'Across competitor pages, the most repeated section themes are: ' . implode( ', ', array_map( 'ucfirst', array_slice( $top_h2s, 0, 8 ) ) ) . '.',
				'action' => 'Use these repeated themes as mandatory section candidates, then add unique sections that answer unresolved reader questions, edge cases, comparisons, and implementation obstacles.',
				'benefit' => 'You capture the expected topical entities first and then win on completeness by expanding into the gaps competitors only touch briefly.',
			];
		}
		$instructions[] = [
			'type' => 'section_depth',
			'severity' => 'high',
			'description' => 'Strong competitor pages do not just mention subtopics; they develop them into actionable subsections with supporting explanation.',
			'action' => 'For every major H2, add concrete examples, decision criteria, mistakes to avoid, and at least one reader-oriented takeaway or checklist item.',
			'benefit' => 'This turns the article from a generic overview into a page that is more helpful, memorable and link-worthy for the topic.',
		];
		$instructions[] = [
			'type' => 'serp_format',
			'severity' => 'medium',
			'description' => sprintf( '%d%% of competitors include FAQ blocks, %d%% use tables, %d%% use schema, and competitors average about %d images.', $faq_pct, $table_pct, $schema_pct, max( 1, $avg_images ) ),
			'action' => 'Include structured FAQ questions, add at least one comparison or summary table, use diagrams or visuals where concepts become abstract, and mark up the page with relevant schema.',
			'benefit' => 'These elements improve scanability, feature eligibility and perceived quality while giving your page more SERP-ready formatting than plain text alone.',
		];
		$instructions[] = [
			'type' => 'intent_alignment',
			'severity' => 'medium',
			'description' => 'Competitor pages usually succeed when they answer the intent early instead of delaying the core answer.',
			'action' => 'Open with a direct explanation of the topic, define when it matters, and tell the reader what practical outcome they will get from the rest of the article before moving into deeper sections.',
			'benefit' => 'This reduces pogo-sticking and makes the content feel immediately useful, especially for informational search intent.',
		];
		if ( ! empty( $gaps_by_severity['high'] ) || ! empty( $gaps_by_severity['critical'] ) ) {
			$instructions[] = [
				'type' => 'gap_resolution',
				'severity' => 'high',
				'description' => 'Highest-priority observed weaknesses: ' . implode( ' | ', array_slice( array_merge( $gaps_by_severity['critical'], $gaps_by_severity['high'] ), 0, 4 ) ) . '.',
				'action' => 'Turn each high-priority gap into a dedicated writing task: missing topic coverage becomes a new section, thin content becomes expanded evidence and explanation, and missing elements become explicit implementation steps in the outline.',
				'benefit' => 'Your content improves exactly where competitor consensus says the topic matters most, instead of adding generic filler.',
			];
		}
		$instructions[] = [
			'type' => 'authority_and_links',
			'severity' => 'medium',
			'description' => sprintf( 'Competitor pages often reinforce topical authority with internal links and adjacent supporting topics; the average internal-link count is about %d.', $avg_internal_links ),
			'action' => 'Add internal links to glossary pages, comparisons, definitions, practical guides, and related cluster articles. Write sections with anchor-ready phrasing so this page can support future internal linking.',
			'benefit' => 'This strengthens cluster authority and helps the page act as a stronger hub, not just a standalone article.',
		];
		$instructions[] = [
			'type' => 'differentiation',
			'severity' => 'medium',
			'description' => 'Competitor pages often converge on the same basic outline and explanations.',
			'action' => 'After matching competitor coverage, differentiate with original examples, implementation steps, decision frameworks, comparison angles, reader objections, and concrete next-action recommendations.',
			'benefit' => 'This creates a page that is not only complete, but more usable and more persuasive than the average competing result.',
		];
		$instructions[] = [
			'type' => 'conversion_and_retention',
			'severity' => 'low',
			'description' => 'Most competitor pages end after the informational answer and leave value on the table.',
			'action' => 'End with a short recap, a decision-oriented next step, and a clear path to the most relevant related article, tool page, or cluster page inside your site.',
			'benefit' => 'You retain more readers inside the cluster and turn a strong informational page into a more strategically valuable asset.',
		];

		return $instructions;
	}

	private function build_competitor_report_summary( string $keyword, string $cluster, array $competitors, array $gaps ): string {
		$comp_ok = array_values( array_filter( $competitors, static function( $competitor ): bool {
			return is_array( $competitor ) && empty( $competitor['error'] );
		} ) );
		$heading_frequency = [];
		$context_snippets  = [];
		foreach ( $comp_ok as $competitor ) {
			foreach ( array_slice( (array) ( $competitor['h2s'] ?? [] ), 0, 10 ) as $heading ) {
				$heading = sanitize_text_field( (string) $heading );
				if ( '' === $heading ) {
					continue;
				}
				$key = strtolower( $heading );
				$heading_frequency[ $key ] = [
					'label' => $heading,
					'count' => (int) ( $heading_frequency[ $key ]['count'] ?? 0 ) + 1,
				];
			}
			foreach ( array_slice( (array) ( $competitor['paragraph_snippets'] ?? [] ), 0, 2 ) as $snippet ) {
				$snippet = sanitize_text_field( (string) $snippet );
				if ( '' !== $snippet ) {
					$context_snippets[] = $snippet;
				}
			}
		}
		usort( $heading_frequency, static function( array $a, array $b ): int {
			return (int) ( $b['count'] ?? 0 ) <=> (int) ( $a['count'] ?? 0 );
		} );
		$top_headings = array_values( array_filter( array_map( static function( array $row ): string {
			return sanitize_text_field( (string) ( $row['label'] ?? '' ) );
		}, array_slice( $heading_frequency, 0, 4 ) ) ) );
		$top_gap = '';
		foreach ( $gaps as $gap ) {
			if ( ! is_array( $gap ) ) {
				continue;
			}
			$top_gap = sanitize_text_field( (string) ( $gap['description'] ?? $gap['action'] ?? '' ) );
			if ( '' !== $top_gap ) {
				break;
			}
		}
		$parts = [];
		if ( ! empty( $top_headings ) ) {
			$parts[] = 'Competitor pages for ' . $keyword . ' repeatedly structure their coverage around ' . implode( ', ', array_slice( $top_headings, 0, 3 ) ) . '.';
		}
		if ( ! empty( $context_snippets ) ) {
			$parts[] = 'On-page copy repeatedly explains the topic through angles like "' . trim( mb_substr( $context_snippets[0], 0, 170 ) ) . '".';
		}
		if ( '' !== $top_gap ) {
			$parts[] = 'The clearest opportunity is to improve on: ' . $top_gap . '.';
		}
		if ( empty( $parts ) ) {
			$parts[] = 'Detailed competitor report for ' . $keyword . ( '' !== $cluster ? ' in cluster ' . $cluster : '' ) . '.';
		}
		return sanitize_textarea_field( implode( ' ', array_slice( $parts, 0, 3 ) ) );
	}

	private function build_competitor_context_payload( array $competitors ): array {
		$snippets = [];
		$contexts = [];
		foreach ( $competitors as $competitor ) {
			if ( ! is_array( $competitor ) || ! empty( $competitor['error'] ) ) {
				continue;
			}
			$host = wp_parse_url( (string) ( $competitor['url'] ?? '' ), PHP_URL_HOST );
			$host = is_string( $host ) ? strtolower( preg_replace( '/^www\./', '', $host ) ) : '';
			foreach ( array_slice( (array) ( $competitor['paragraph_snippets'] ?? [] ), 0, 2 ) as $snippet ) {
				$snippet = sanitize_text_field( (string) $snippet );
				if ( '' !== $snippet ) {
					$snippets[] = $snippet;
				}
			}
			foreach ( array_slice( (array) ( $competitor['heading_contexts'] ?? [] ), 0, 3 ) as $pair ) {
				if ( ! is_array( $pair ) ) {
					continue;
				}
				$heading = sanitize_text_field( (string) ( $pair['heading'] ?? '' ) );
				$context = sanitize_text_field( (string) ( $pair['context'] ?? '' ) );
				if ( '' === $heading || '' === $context ) {
					continue;
				}
				$contexts[] = [
					'host'    => $host,
					'heading' => $heading,
					'context' => $context,
				];
			}
		}
		return [
			'context_snippets' => array_values( array_slice( array_unique( $snippets ), 0, 8 ) ),
			'heading_contexts' => array_values( array_slice( $contexts, 0, 10 ) ),
		];
	}

	public function post_competitor_analyze( WP_REST_Request $request ) {

		$body     = $request->get_json_params();
		$keyword  = sanitize_text_field( $body['keyword'] ?? '' );
		$cluster  = sanitize_text_field( $body['cluster'] ?? '' );
		$your_url = sanitize_url( $body['your_url'] ?? home_url( '/' ) );
		$comp_urls = array_map( 'sanitize_url', (array) ( $body['competitor_urls'] ?? [] ) );
		$comp_urls = array_values( array_filter( $comp_urls ) );
		$own_host = preg_replace( '/^www\./i', '', (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		$comp_urls = array_values( array_filter( $comp_urls, static function( $url ) use ( $own_host ) {
			$host = preg_replace( '/^www\./i', '', (string) wp_parse_url( $url, PHP_URL_HOST ) );
			return $host && $own_host && $host !== $own_host;
		} ) );
		if ( ! empty( $comp_urls ) ) {
			$remembered_domains = array_values( array_unique( array_filter( array_map( static function( $url ) {
				$host = wp_parse_url( (string) $url, PHP_URL_HOST );
				return is_string( $host ) ? preg_replace( '/^www\./i', '', strtolower( $host ) ) : '';
			}, $comp_urls ) ) ) );
			if ( ! empty( $remembered_domains ) ) {
				update_option( 'contentgem_competitor_domains', $remembered_domains, false );
			}
		}

		if ( empty( $keyword ) ) {
			return new WP_Error( 'missing_keyword', 'Keyword is required.', [ 'status' => 400 ] );
		}
		if ( empty( $comp_urls ) ) {
			return new WP_Error( 'missing_urls', 'At least one valid competitor URL is required after excluding the current site.', [ 'status' => 400 ] );
		}

		// Parse pages
		$your_page   = ! empty( $your_url ) ? $this->parse_page( $your_url ) : null;
		$competitors = [];
		foreach ( array_slice( $comp_urls, 0, 5 ) as $url ) {
			$competitors[] = $this->parse_page( $url );
		}

		// Build gap analysis
		$gaps                     = $this->analyze_gaps( $keyword, $your_page, $competitors );
		$recommendations          = $this->build_recommendations( $keyword, $your_page, $competitors, $gaps );
		$detailed_recommendations = $this->build_detailed_competitor_guidance( $keyword, $your_page, $competitors, $gaps );

		// - Cache competitor insights for draft generation ----------â"€
		if ( ! empty( $cluster ) ) {
			$comp_ok    = array_filter( $competitors, function( $c ) { return empty( $c['error'] ); } );
			$all_h2s    = [];
			$h2_freq    = [];
			foreach ( $comp_ok as $c ) {
				foreach ( $c['h2s'] as $h2 ) {
					$key = mb_strtolower( trim( $h2 ) );
					$h2_freq[ $key ] = ( $h2_freq[ $key ] ?? 0 ) + 1;
				}
			}
			// Only keep H2s appearing in 2+ competitors
			$common_h2s = array_keys( array_filter( $h2_freq, function( $f ) { return $f >= 2; } ) );
			$n = count( $comp_ok );
			$cache_data = [
				'keyword'    => $keyword,
				'avg_words'  => $n > 0 ? (int) ( array_sum( array_column( iterator_to_array( new ArrayIterator( array_values( $comp_ok ) ) ), 'word_count' ) ) / $n ) : 0,
				'common_h2s' => array_values( $common_h2s ),
				'pct_faq'    => $n > 0 ? count( array_filter( $comp_ok, function( $c ) { return $c['has_faq']; } ) ) / $n : 0,
				'pct_table'  => $n > 0 ? count( array_filter( $comp_ok, function( $c ) { return $c['has_table']; } ) ) / $n : 0,
				'pct_schema'               => $n > 0 ? count( array_filter( $comp_ok, function( $c ) { return $c['has_schema']; } ) ) / $n : 0,
				'detailed_recommendations' => $detailed_recommendations,
				'cached_at'                => gmdate( 'c' ),
			];
			update_option( 'contentgem_comp_cache_' . md5( $cluster ), $cache_data, false );
		}

		$context_payload = $this->build_competitor_context_payload( $competitors );
		$latest_report = [
			'keyword'                  => $keyword,
			'cluster'                  => $cluster,
			'your_page'                => $your_page,
			'competitors'              => $competitors,
			'gaps'                     => $gaps,
			'recommendations'          => $recommendations,
			'detailed_recommendations' => $detailed_recommendations,
			'context_snippets'         => $context_payload['context_snippets'],
			'heading_contexts'         => $context_payload['heading_contexts'],
			'report_summary'           => $this->build_competitor_report_summary( $keyword, $cluster, $competitors, $gaps ),
			'captured_at'              => gmdate( 'c' ),
		];
		$latest_report['cluster_key'] = $this->normalize_competitor_cluster_key( (string) $cluster );
		update_option( 'contentgem_latest_competitor_analysis', $latest_report, false );
		$latest_by_cluster = get_option( 'contentgem_latest_competitor_analysis_by_cluster', [] );
		$latest_by_cluster = is_array( $latest_by_cluster ) ? $latest_by_cluster : [];
		$latest_by_cluster[ $latest_report['cluster_key'] ] = $latest_report;
		update_option( 'contentgem_latest_competitor_analysis_by_cluster', $latest_by_cluster, false );
		$this->save_competitor_history_entry( $this->make_competitor_history_entry( $latest_report ) );

		return rest_ensure_response( $latest_report );
	}

	/**
	 * Fetch a URL and extract SEO-relevant signals.
	 */
	private function parse_page( string $url ): array {
		$result = [
			'url'            => $url,
			'title'          => '',
			'h1'             => '',
			'h2s'            => [],
			'h3_count'       => 0,
			'word_count'     => 0,
			'has_faq'        => false,
			'has_table'      => false,
			'has_list'       => false,
			'has_schema'     => false,
			'schema_types'   => [],
			'image_count'    => 0,
			'internal_links' => 0,
			'external_links' => 0,
			'freshness'      => '',
			'freshness_reason' => '',
			'meta_description' => '',
			'paragraph_snippets' => [],
			'heading_contexts'   => [],
			'error'          => null,
		];

		$response = wp_remote_get( $url, [
			'timeout'    => 15,
			'user-agent' => 'Mozilla/5.0 (compatible; ContentGem/1.0)',
			'sslverify'  => false,
		] );

		if ( is_wp_error( $response ) ) {
			$result['error'] = 'Could not fetch page.';
			return $result;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 400 ) {
			$result['error'] = "HTTP {$code}";
			return $result;
		}

		$html = wp_remote_retrieve_body( $response );
		if ( empty( $html ) ) {
			$result['error'] = 'Empty response.';
			return $result;
		}

		// Parse HTML
		$dom = new DOMDocument();
		@$dom->loadHTML( mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' ) );
		$xpath = new DOMXPath( $dom );

		// Title
		$titles = $xpath->query( '//title' );
		if ( $titles && $titles->length > 0 ) {
			$result['title'] = trim( $titles->item(0)->textContent );
		}

		// Meta description
		$metas = $xpath->query( '//meta[@name="description"]/@content' );
		if ( $metas && $metas->length > 0 ) {
			$result['meta_description'] = trim( $metas->item(0)->textContent );
		}

		// H1
		$h1s = $xpath->query( '//h1' );
		if ( $h1s && $h1s->length > 0 ) {
			$result['h1'] = trim( $h1s->item(0)->textContent );
		}

		// H2s - filter out navigation, promo and boilerplate items
		$h2s = $xpath->query( '//h2' );
		if ( $h2s ) {
			// Patterns that indicate non-content H2s
			$promo_patterns = [
				'/win\b/i', '/gratis/i', '/aanbieding/i', '/korting/i', '/startbewij/i',
				'/weggeven/i', '/cadeau/i', '/\d+%\s+off/i', '/free\s+ship/i',
				'/subscribe/i', '/newsletter/i', '/sign\s+up/i', '/log\s*in/i',
				'/cookie/i', '/privacy/i', '/contact\s+us/i', '/about\s+us/i',
				'/follow\s+us/i', '/social/i', '/share\s+this/i',
				'/menu/i', '/navigation/i', '/sitemap/i',
			];
			foreach ( $h2s as $h2 ) {
				$text = trim( $h2->textContent );
				$len  = mb_strlen( $text );
				// Skip: too short, too long (likely promo sentence), or matches promo pattern
				if ( $len < 5 || $len > 100 ) continue;
				$skip = false;
				foreach ( $promo_patterns as $pattern ) {
					if ( preg_match( $pattern, $text ) ) { $skip = true; break; }
				}
				if ( ! $skip ) $result['h2s'][] = $text;
			}
		}

		// H3 count
		$h3s = $xpath->query( '//h3' );
		$result['h3_count'] = $h3s ? $h3s->length : 0;

		// Word count - prefer article/main content, exclude nav/header/footer/aside
		$content_node = null;
		foreach ( [ '//article', '//main', '//*[@role="main"]', '//*[contains(@class,"content")]', '//*[contains(@class,"entry")]' ] as $q ) {
			$nodes = $xpath->query( $q );
			if ( $nodes && $nodes->length > 0 ) { $content_node = $nodes->item(0); break; }
		}
		if ( ! $content_node ) {
			$body_nodes   = $xpath->query( '//body' );
			$content_node = $body_nodes && $body_nodes->length > 0 ? $body_nodes->item(0) : null;
		}
		if ( $content_node ) {
			// Remove noise nodes before counting
			$noise_tags = [ 'nav', 'header', 'footer', 'aside', 'script', 'style', 'noscript', 'form' ];
			foreach ( $noise_tags as $tag ) {
				$noise_nodes = $xpath->query( './/' . $tag, $content_node );
				if ( $noise_nodes ) {
					foreach ( iterator_to_array( $noise_nodes ) as $noise ) {
						if ( $noise->parentNode ) {
						$noise->parentNode->removeChild( $noise );
					}
					}
				}
			}
			$clean_text           = preg_replace( '/\s+/', ' ', $content_node->textContent );
			$result['word_count'] = str_word_count( trim( $clean_text ) );
		}


		// Extract readable paragraph and heading context from the main content.
		if ( $content_node ) {
			$paragraph_seen     = [];
			$paragraph_snippets = [];
			$paragraph_nodes    = $xpath->query( './/p', $content_node );
			if ( $paragraph_nodes ) {
				foreach ( $paragraph_nodes as $paragraph_node ) {
					$paragraph_text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $paragraph_node->textContent ) ) );
					if ( mb_strlen( $paragraph_text ) < 70 ) {
						continue;
					}
					$paragraph_key = strtolower( mb_substr( $paragraph_text, 0, 160 ) );
					if ( isset( $paragraph_seen[ $paragraph_key ] ) ) {
						continue;
					}
					$paragraph_seen[ $paragraph_key ] = true;
					if ( mb_strlen( $paragraph_text ) > 280 ) {
						$paragraph_text = trim( mb_substr( $paragraph_text, 0, 277 ) ) . '...';
					}
					$paragraph_snippets[] = $paragraph_text;
					if ( count( $paragraph_snippets ) >= 8 ) {
						break;
					}
				}
			}
			$result['paragraph_snippets'] = $paragraph_snippets;

			$heading_contexts = [];
			$heading_nodes    = $xpath->query( './/h2 | .//h3', $content_node );
			if ( $heading_nodes ) {
				foreach ( $heading_nodes as $heading_node ) {
					if ( count( $heading_contexts ) >= 8 ) {
						break;
					}
					$heading_text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $heading_node->textContent ) ) );
					if ( mb_strlen( $heading_text ) < 5 || mb_strlen( $heading_text ) > 120 ) {
						continue;
					}
					$context_text = '';
					$candidate_nodes = $xpath->query( 'following-sibling::*[self::p or self::div or self::section][position()<=3]', $heading_node );
					if ( $candidate_nodes ) {
						foreach ( $candidate_nodes as $candidate_node ) {
							$paragraph_candidates = [];
							if ( in_array( strtolower( $candidate_node->nodeName ), [ 'div', 'section' ], true ) ) {
								$nested = $xpath->query( './/p', $candidate_node );
								if ( $nested ) {
									foreach ( $nested as $nested_paragraph ) {
										$paragraph_candidates[] = $nested_paragraph;
									}
								}
							} else {
								$paragraph_candidates[] = $candidate_node;
							}
							foreach ( $paragraph_candidates as $paragraph_candidate ) {
								$context_candidate = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $paragraph_candidate->textContent ) ) );
								if ( mb_strlen( $context_candidate ) < 70 ) {
									continue;
								}
								$context_text = $context_candidate;
								break 2;
							}
						}
					}
					if ( '' === $context_text ) {
						$fallback_nodes = $xpath->query( 'following::p[position()<=5]', $heading_node );
						if ( $fallback_nodes ) {
							foreach ( $fallback_nodes as $fallback_node ) {
								$context_candidate = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $fallback_node->textContent ) ) );
								if ( mb_strlen( $context_candidate ) < 70 ) {
									continue;
								}
								$context_text = $context_candidate;
								break;
							}
						}
					}
					if ( '' === $context_text ) {
						continue;
					}
					if ( mb_strlen( $context_text ) > 240 ) {
						$context_text = trim( mb_substr( $context_text, 0, 237 ) ) . '...';
					}
					$heading_contexts[] = [
						'heading' => $heading_text,
						'context' => $context_text,
					];
				}
			}
			$result['heading_contexts'] = $heading_contexts;
		}

		// FAQ detection
		$faq_indicators = [ 'faq', 'frequently asked', 'veelgestelde', 'vragen' ];
		$html_lc        = mb_strtolower( $html );
		foreach ( $faq_indicators as $ind ) {
			if ( strpos( $html_lc, $ind ) !== false ) { $result['has_faq'] = true; break; }
		}

		// Table
		$tables           = $xpath->query( '//table' );
		$result['has_table'] = $tables && $tables->length > 0;

		// Lists
		$lists            = $xpath->query( '//ul | //ol' );
		$result['has_list'] = $lists && $lists->length > 0;

		// Schema.org
		$schemas = $xpath->query( '//*[@type="application/ld+json"]' );
		if ( $schemas && $schemas->length > 0 ) {
			$result['has_schema'] = true;
			foreach ( $schemas as $schema ) {
				$json = json_decode( $schema->textContent, true );
				if ( isset( $json['@type'] ) ) {
					$result['schema_types'][] = is_array( $json['@type'] ) ? implode( ', ', $json['@type'] ) : $json['@type'];
				}
			}
		}

		// Images
		$images              = $xpath->query( '//img' );
		$result['image_count'] = $images ? $images->length : 0;

		// Links
		$parsed_host = parse_url( $url, PHP_URL_HOST );
		$links       = $xpath->query( '//a[@href]' );
		if ( $links ) {
			foreach ( $links as $link ) {
				$href      = $link->getAttribute( 'href' );
				$link_host = parse_url( $href, PHP_URL_HOST );
				if ( empty( $link_host ) || $link_host === $parsed_host ) {
					$result['internal_links']++;
				} else {
					$result['external_links']++;
				}
			}
		}

		// Freshness: look for published/modified date and visible recency hints.
		$date_patterns = [
			'/"datePublished"\s*:\s*"([^"]+)"/i',
			'/"dateModified"\s*:\s*"([^"]+)"/i',
			'/published_time"\s+content="([^"]+)"/i',
			'/modified_time"\s+content="([^"]+)"/i',
			'/<meta[^>]+property="article:published_time"[^>]+content="([^"]+)"/i',
			'/<meta[^>]+property="article:modified_time"[^>]+content="([^"]+)"/i',
			'/<time[^>]+datetime="([^"]+)"/i',
		];
		foreach ( $date_patterns as $pattern ) {
			if ( preg_match( $pattern, $html, $m ) ) {
				$ts = strtotime( $m[1] );
				if ( $ts ) {
					$result['freshness'] = gmdate( 'Y-m-d', $ts );
					$result['freshness_reason'] = 'Published/updated date found in page metadata.';
					break;
				}
			}
		}

		if ( '' === $result['freshness'] ) {
			$combined_visible = trim( strtolower( $result['title'] . ' ' . $result['h1'] . ' ' . $result['meta_description'] . ' ' . $url . ' ' . implode( ' ', array_slice( (array) ( $result['h2s'] ?? [] ), 0, 6 ) ) ) );
			if ( preg_match( '/\b(20[2-3][0-9])\b/', $combined_visible, $m ) ) {
				$year = (int) $m[1];
				$result['freshness'] = sprintf( '%04d-01-01', $year );
				$result['freshness_reason'] = 'Recent year detected in title, URL or headings.';
			}
		}

		return $result;
	}

	/**
	 * Compare your page against competitors and identify gaps.
	 */
	private function analyze_gaps( string $keyword, ?array $your_page, array $competitors ): array {
		$gaps    = [];
		$comp_ok = array_values( array_filter( $competitors, function( $c ) { return empty( $c['error'] ); } ) );

		if ( empty( $comp_ok ) ) return $gaps;

		$has_your_page = $your_page && empty( $your_page['error'] );

		// - Competitor averages -----------------------â"€
		// Use median word count (not mean) to avoid skew from portal/homepage outliers
		// Also cap at 2500 - realistic article length target
		$word_counts = array_column( $comp_ok, 'word_count' );
		sort( $word_counts );
		$mid        = (int) floor( count( $word_counts ) / 2 );
		$median_wc  = count( $word_counts ) % 2 === 0
			? (int) ( ( $word_counts[ $mid - 1 ] + $word_counts[ $mid ] ) / 2 )
			: $word_counts[ $mid ];
		$avg_words  = min( $median_wc, 2500 );
		$avg_images = (int) ( array_sum( array_column( $comp_ok, 'image_count' ) ) / count( $comp_ok ) );
		$pct_faq    = count( array_filter( $comp_ok, function($c) { return $c['has_faq']; } ) )    / count( $comp_ok );
		$pct_table  = count( array_filter( $comp_ok, function($c) { return $c['has_table']; } ) )  / count( $comp_ok );
		$pct_schema = count( array_filter( $comp_ok, function($c) { return $c['has_schema']; } ) ) / count( $comp_ok );

		// - All competitor H2s - build frequency map -------------
		// A topic that appears in multiple competitors is a strong signal.
		$h2_freq = []; // normalised_h2 => count
		foreach ( $comp_ok as $c ) {
			foreach ( $c['h2s'] as $h2 ) {
				$key = mb_strtolower( trim( $h2 ) );
				if ( mb_strlen( $key ) < 3 ) continue;
				$h2_freq[ $key ] = ( $h2_freq[ $key ] ?? 0 ) + 1;
			}
		}

		// Deduplicate H2 topics by similarity
		$unique_comp_h2s = [];
		foreach ( array_keys( $h2_freq ) as $h2 ) {
			$is_dup = false;
			foreach ( $unique_comp_h2s as $existing ) {
				similar_text( $h2, $existing, $sim );
				if ( $sim > 70 ) { $is_dup = true; break; }
			}
			if ( ! $is_dup ) $unique_comp_h2s[] = $h2;
		}

		// - Reference H2s: yours OR empty (compare against nothing) -----
		$your_h2s_lc = $has_your_page
			? array_map( 'mb_strtolower', $your_page['h2s'] )
			: [];

		// - Find missing H2 topics ----------------------
		// Without your page: every topic covered by 2+ competitors is a gap.
		// With your page: topics not covered by your page.
		$min_comp_coverage = $has_your_page ? 1 : 2; // stricter without own page
		$missing_topics    = [];

		foreach ( $unique_comp_h2s as $comp_h2 ) {
			$freq = $h2_freq[ $comp_h2 ] ?? 1;
			if ( $freq < $min_comp_coverage ) continue;

			$found_in_yours = false;
			foreach ( $your_h2s_lc as $your_h2 ) {
				similar_text( $comp_h2, $your_h2, $sim );
				if ( $sim > 55 ) { $found_in_yours = true; break; }
			}

			if ( ! $found_in_yours ) {
				$missing_topics[] = [ 'topic' => $comp_h2, 'freq' => $freq ];
			}
		}

		// Sort by frequency desc (most-covered topics first)
		usort( $missing_topics, function( $a, $b ) { return $b['freq'] - $a['freq']; } );

		if ( count( $missing_topics ) >= 1 ) {
			$sample      = array_slice( $missing_topics, 0, 5 );
			$sample_strs = array_map( function($t) { return ucfirst( $t['topic'] ); }, $sample );
			$count       = count( $missing_topics );
			$context     = $has_your_page ? 'missing from your page' : 'not yet covered on your site';

			$gaps[] = [
				'type'        => 'missing_h2',
				'severity'    => $count >= 5 ? 'high' : ( $count >= 3 ? 'medium' : 'low' ),
				'description' => $count . ' topics covered by competitors but ' . $context . '.',
				'action'      => 'Consider creating content about: ' . implode( ', ', $sample_strs ) . '.',
			];
		}

		// - Gaps that require your page for comparison ------------
		if ( $has_your_page ) {
			// Thin content
			if ( $your_page['word_count'] < $avg_words * 0.7 ) {
				$gaps[] = [
					'type'        => 'thin_content',
					'severity'    => $your_page['word_count'] < $avg_words * 0.5 ? 'high' : 'medium',
					'description' => "Your page has {$your_page['word_count']} words - competitors average {$avg_words}.",
					'action'      => 'Expand content to at least ' . (int)( $avg_words * 0.9 ) . ' words.',
				];
			}

			// Missing FAQ
			if ( ! $your_page['has_faq'] && $pct_faq >= 0.5 ) {
				$gaps[] = [
					'type'        => 'missing_element',
					'severity'    => $pct_faq >= 0.8 ? 'high' : 'medium',
					'description' => round( $pct_faq * 100 ) . '% of competitors have a FAQ section - your page does not.',
					'action'      => 'Add a FAQ section with 4-6 questions relevant to "' . $keyword . '".',
				];
			}

			// Missing table
			if ( ! $your_page['has_table'] && $pct_table >= 0.6 ) {
				$gaps[] = [
					'type'        => 'missing_element',
					'severity'    => 'medium',
					'description' => round( $pct_table * 100 ) . '% of competitors use comparison tables.',
					'action'      => 'Add a comparison or data table to improve scannability.',
				];
			}

			// Missing schema
			if ( ! $your_page['has_schema'] && $pct_schema >= 0.5 ) {
				$schema_types = array_unique( array_merge( ...array_map( function($c) { return $c['schema_types']; }, $comp_ok ) ) );
				$gaps[] = [
					'type'        => 'missing_schema',
					'severity'    => 'medium',
					'description' => 'Competitors use structured data (' . implode( ', ', array_slice( $schema_types, 0, 3 ) ) . ') - your page has none.',
					'action'      => 'Add relevant schema markup (Article, FAQ, HowTo) to your page.',
				];
			}

			// Images
			if ( $your_page['image_count'] < $avg_images * 0.5 && $avg_images >= 3 ) {
				$gaps[] = [
					'type'        => 'missing_element',
					'severity'    => 'low',
					'description' => "Your page has {$your_page['image_count']} images - competitors average {$avg_images}.",
					'action'      => 'Add more visuals to improve engagement and dwell time.',
				];
			}
		} else {
			// - Without your page: signal element gaps from competitor consensus -
			if ( $pct_faq >= 0.6 ) {
				$gaps[] = [
					'type'        => 'missing_element',
					'severity'    => 'medium',
					'description' => round( $pct_faq * 100 ) . '% of competitors include a FAQ section.',
					'action'      => 'Include a FAQ section when writing about "' . $keyword . '".',
				];
			}
			if ( $pct_schema >= 0.5 ) {
				$schema_types = array_unique( array_merge( ...array_map( function($c) { return $c['schema_types']; }, $comp_ok ) ) );
				$gaps[] = [
					'type'        => 'missing_schema',
					'severity'    => 'low',
					'description' => 'Competitors use schema markup (' . implode( ', ', array_slice( $schema_types, 0, 3 ) ) . ').',
					'action'      => 'Add structured data when publishing content about "' . $keyword . '".',
				];
			}
			if ( $avg_words >= 500 && $avg_words <= 2500 ) {
				$gaps[] = [
					'type'        => 'thin_content',
					'severity'    => 'low',
					'description' => "Competitors average {$avg_words} words on this topic.",
					'action'      => "Aim for at least {$avg_words} words when writing about the topic.",
				];
			}
		}

		// Sort by severity
		$order = [ 'high' => 0, 'medium' => 1, 'low' => 2 ];
		usort( $gaps, function( $a, $b ) use ( $order ) { return ( $order[ $a['severity'] ] ?? 3 ) - ( $order[ $b['severity'] ] ?? 3 ); } );

		return $gaps;
	}

	/**
	 * Build a ranked recommendation list from the gap analysis.
	 */
	private function build_recommendations( string $keyword, ?array $your_page, array $competitors, array $gaps ): array {
		$recs    = [];
		$comp_ok = array_filter( $competitors, function($c) { return empty($c['error']); } );
		if ( empty($comp_ok) ) return $recs;

		$max_words = max( array_column( $comp_ok, 'word_count' ) );
		if ( $your_page && $your_page['word_count'] < $max_words * 0.8 ) {
			$recs[] = "Increase word count to roughly {$max_words} words and use the extra space for evidence, subtopic coverage, and reader questions already answered by top competitors.";
		}

		$avg_h2s = (int)( array_sum( array_map( function($c) { return count($c['h2s']); }, $comp_ok ) ) / count($comp_ok) );
		if ( $your_page && count($your_page['h2s']) < $avg_h2s ) {
			$recs[] = "Add more H2 sections - competitors average {$avg_h2s} headings. Use those extra sections to cover missing definitions, comparisons, FAQs, and implementation details.";
		}

		$avg_images = (int)( array_sum( array_column($comp_ok, 'image_count') ) / count($comp_ok) );
		if ( $your_page && $your_page['image_count'] < $avg_images * 0.5 ) {
			$recs[] = "Add more images or diagrams - competitors average {$avg_images} visuals. Use visuals to explain difficult concepts and increase engagement.";
		}

		$avg_internal = (int)( array_sum( array_column($comp_ok, 'internal_links') ) / count($comp_ok) );
		if ( $your_page && $your_page['internal_links'] < $avg_internal * 0.5 ) {
			$recs[] = "Add more internal links - competitors average {$avg_internal}. Link to related clusters, glossaries, comparisons, and practical guides to strengthen topical authority.";
		}

		if ( $your_page ) {
			$fresh_dates = array_filter( array_column($comp_ok, 'freshness') );
			if ( ! empty($fresh_dates) ) {
				$latest_comp = max( array_map('strtotime', $fresh_dates) );
				$your_date   = $your_page['freshness'] ? strtotime($your_page['freshness']) : 0;
				if ( $your_date && $your_date < $latest_comp - (180 * DAY_IN_SECONDS) ) {
					$recs[] = 'Refresh the content with newer examples, terminology, statistics, and product references so the page no longer feels older than the most recently updated competitors.';
				}
			}
		}

		foreach ( $gaps as $gap ) {
			if ( ! in_array( $gap['action'], $recs, true ) ) {
				$recs[] = $gap['action'];
			}
		}

		return array_slice( array_unique($recs), 0, 10 );
	}

	// - Indexation Monitor -------------------------â"€

	/**
	 * GET /gsc/indexation
	 * Returns cached indexation summary. Uses GSC impressions as proxy for
	 * indexation status (no URL Inspection API quota used on load).
	 */
	public function get_gsc_indexation( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();
		if ( ! $gsc->is_connected() ) {
			return new WP_Error( 'not_connected', 'GSC not connected.', [ 'status' => 422 ] );
		}

		$cache_key = 'cgm_indexation_' . get_current_blog_id();
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		return rest_ensure_response( $this->build_indexation_data( $gsc ) );
	}

	/**
	 * POST /gsc/indexation/scan
	 * Forces a fresh scan, bypassing cache.
	 */
	public function post_gsc_indexation_scan( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();
		if ( ! $gsc->is_connected() ) {
			return new WP_Error( 'not_connected', 'GSC not connected.', [ 'status' => 422 ] );
		}

		delete_transient( 'cgm_indexation_' . get_current_blog_id() );
		return rest_ensure_response( $this->build_indexation_data( $gsc ) );
	}

	/**
	 * Core indexation logic.
	 *
	 * Strategy (no URL Inspection API quota):
	 *  - Fetch GSC page-level impressions for last 90 days
	 *  - A page with impressions â‰¥ 1 is treated as "indexed"
	 *  - A page with 0 impressions but published â‰¥ 14 days ago â†' "not_indexed" (likely)
	 *  - Published < 14 days ago â†' "unknown" (too soon to tell)
	 *
	 * Alerts:
	 *  - Published â‰¥ 14 days, 0 impressions â†' "not indexed" alert
	 *  - Published â‰¥ 7 days, impressions > 0 but very low (< 10) â†' "no impressions" alert
	 *
	 * Workflow stages:
	 *  - published:        post_status = publish
	 *  - inspected:        impressions > 0
	 *  - first_impression: impressions >= 10
	 *  - optimized:        impressions >= 100
	 */
	private function build_indexation_data( CGM_GSC_Connector $gsc ): array {
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );

		// Get page-level impressions from GSC (last 90 days)
		$gsc_pages = [];
		if ( ! empty( $site_url ) ) {
			$end_date   = gmdate( 'Y-m-d' );
			$start_date = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
			$rows       = $this->gsc_query( $gsc, $site_url, $start_date, $end_date, [ 'page' ], 5000 );
			foreach ( $rows as $row ) {
				$url               = rtrim( $row['keys'][0] ?? '', '/' );
				$gsc_pages[ $url ] = (int) ( $row['impressions'] ?? 0 );
			}
			$this->sync_gsc_post_signals( $gsc );
		}

		// Get all published posts with cluster info
		$cluster_terms_raw = json_decode( (string) get_option( 'contentgem_cluster_terms', '{}' ), true );
		$cluster_terms_raw = is_array( $cluster_terms_raw ) ? $cluster_terms_raw : [];

		$posts = get_posts( [
			'numberposts' => -1,
			'post_status' => 'publish',
			'post_type'   => 'post',
		] );

		$now     = time();
		$results = [];
		$alerts  = [];

		$total       = 0;
		$indexed     = 0;
		$not_indexed = 0;
		$unknown     = 0;

		foreach ( $posts as $post ) {
			$permalink     = get_permalink( $post->ID );
			$permalink_key = rtrim( $permalink, '/' );
			$published_ago = $now - strtotime( $post->post_date_gmt );
			$impressions   = $gsc_pages[ $permalink_key ] ?? $gsc_pages[ $permalink ] ?? 0;

			// Determine indexation status
			if ( $impressions >= 1 ) {
				$status  = 'indexed';
				$verdict = 'Has GSC impressions';
				$indexed++;
			} elseif ( $published_ago > 14 * DAY_IN_SECONDS ) {
				$status  = 'not_indexed';
				$verdict = 'No impressions after 14+ days';
				$not_indexed++;
			} else {
				$status  = 'unknown';
				$verdict = 'Too soon to tell (< 14 days old)';
				$unknown++;
			}

			// Determine workflow stage
			if ( $impressions >= 100 ) {
				$workflow = 'optimized';
			} elseif ( $impressions >= 10 ) {
				$workflow = 'first_impression';
			} elseif ( $impressions >= 1 ) {
				$workflow = 'inspected';
			} else {
				$workflow = 'published';
			}

			// Resolve cluster
			$categories   = wp_get_post_categories( $post->ID, [ 'fields' => 'names' ] );
			$cluster_name = '';
			foreach ( $cluster_terms_raw as $cn => $terms ) {
				if ( in_array( $cn, $categories, true ) ) {
					$cluster_name = $cn;
					break;
				}
			}

			// Alerts
			if ( $status === 'not_indexed' && $published_ago > 14 * DAY_IN_SECONDS ) {
				$alerts[] = [
					'type'    => 'not_indexed',
					'post_id' => $post->ID,
					'title'   => $post->post_title,
					'url'     => $permalink,
					'message' => 'Published but no GSC impressions after ' . round( $published_ago / DAY_IN_SECONDS ) . ' days',
				];
			} elseif ( $impressions > 0 && $impressions < 10 && $published_ago > 7 * DAY_IN_SECONDS ) {
				$alerts[] = [
					'type'    => 'no_impressions',
					'post_id' => $post->ID,
					'title'   => $post->post_title,
					'url'     => $permalink,
					'message' => 'Very few impressions (' . $impressions . ') - consider optimizing title/meta',
				];
			}

			$total++;
			$results[] = [
				'post_id'        => $post->ID,
				'title'          => $post->post_title,
				'url'            => $permalink,
				'status'         => $status,
				'verdict'        => $verdict,
				'cluster'        => $cluster_name,
				'impressions'    => $impressions,
				'workflow_stage' => $workflow,
			];
		}

		// Sort: not_indexed first, then by impressions desc
		usort( $results, function ( $a, $b ) {
			$status_order = [ 'not_indexed' => 0, 'unknown' => 1, 'indexed' => 2 ];
			$sa = $status_order[ $a['status'] ] ?? 3;
			$sb = $status_order[ $b['status'] ] ?? 3;
			if ( $sa !== $sb ) return $sa - $sb;
			return $b['impressions'] - $a['impressions'];
		} );

		$data = [
			'total'       => $total,
			'indexed'     => $indexed,
			'not_indexed' => $not_indexed,
			'unknown'     => $unknown,
			'alerts'      => array_slice( $alerts, 0, 10 ),
			'posts'       => $results,
			'generated_at' => gmdate( 'c' ),
		];

		set_transient( 'cgm_indexation_' . get_current_blog_id(), $data, 6 * HOUR_IN_SECONDS );

		return $data;
	}

	// - GSC Query Cannibalization ----------------------

	/**
	 * GET /cannibalization/gsc
	 *
	 * Detects URL pairs that rank for the same GSC queries.
	 * Groups queries by URL and finds overlapping sets.
	 * Cached for 6 hours.
	 */
	public function get_gsc_cannibalization( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();
		if ( ! $gsc->is_connected() ) {
			return new WP_Error( 'not_connected', 'GSC is not connected.', [ 'status' => 422 ] );
		}
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );
		if ( empty( $site_url ) ) {
			return new WP_Error( 'no_property', 'No GSC property selected.', [ 'status' => 422 ] );
		}

		$cache_key = 'cgm_gsc_cannibalization_' . md5( $site_url );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		// Fetch last 90 days, grouped by query + page
		$end_date   = gmdate( 'Y-m-d' );
		$start_date = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		$rows       = $this->gsc_query( $gsc, $site_url, $start_date, $end_date, [ 'query', 'page' ], 5000 );

		// Build map: query â†' [ url => [ clicks, impressions ] ]
		$query_url_map = [];
		foreach ( $rows as $row ) {
			$query = mb_strtolower( $row['keys'][0] ?? '' );
			$page  = $row['keys'][1] ?? '';
			if ( empty( $query ) || empty( $page ) ) continue;
			if ( ! isset( $query_url_map[ $query ] ) ) $query_url_map[ $query ] = [];
			$query_url_map[ $query ][ $page ] = [
				'clicks'      => (int) ( $row['clicks'] ?? 0 ),
				'impressions' => (int) ( $row['impressions'] ?? 0 ),
			];
		}

		// Find queries where 2+ URLs compete
		// Build per-URL query sets
		$url_queries = []; // url => [ query => [ clicks, impressions ] ]
		foreach ( $query_url_map as $query => $urls ) {
			if ( count( $urls ) < 2 ) continue; // no competition
			foreach ( $urls as $url => $stats ) {
				if ( ! isset( $url_queries[ $url ] ) ) $url_queries[ $url ] = [];
				$url_queries[ $url ][ $query ] = $stats;
			}
		}

		// Find URL pairs with shared queries
		$urls    = array_keys( $url_queries );
		$pairs   = [];
		$seen    = [];

		for ( $i = 0; $i < count( $urls ); $i++ ) {
			for ( $j = $i + 1; $j < count( $urls ); $j++ ) {
				$url_a = $urls[ $i ];
				$url_b = $urls[ $j ];
				$pair_key = $url_a < $url_b ? "$url_a|||$url_b" : "$url_b|||$url_a";
				if ( isset( $seen[ $pair_key ] ) ) continue;
				$seen[ $pair_key ] = true;

				$shared = array_intersect_key( $url_queries[ $url_a ], $url_queries[ $url_b ] );
				if ( count( $shared ) < 2 ) continue; // min 2 shared queries

				// Determine winner by total clicks
				$clicks_a = array_sum( array_column( $url_queries[ $url_a ], 'clicks' ) );
				$clicks_b = array_sum( array_column( $url_queries[ $url_b ], 'clicks' ) );
				$impr_a   = array_sum( array_column( $url_queries[ $url_a ], 'impressions' ) );
				$impr_b   = array_sum( array_column( $url_queries[ $url_b ], 'impressions' ) );

				$winner = $clicks_a >= $clicks_b ? $url_a : $url_b;
				$loser  = $winner === $url_a ? $url_b : $url_a;

				// Resolve titles
				$post_id_a = url_to_postid( $url_a );
				$post_id_b = url_to_postid( $url_b );

				$pairs[] = [
					'url_1'          => $url_a,
					'url_2'          => $url_b,
					'title_1'        => $post_id_a ? get_the_title( $post_id_a ) : '',
					'title_2'        => $post_id_b ? get_the_title( $post_id_b ) : '',
					'shared_queries' => array_keys( $shared ),
					'clicks_1'       => $clicks_a,
					'clicks_2'       => $clicks_b,
					'impressions_1'  => $impr_a,
					'impressions_2'  => $impr_b,
					'winner_url'     => $winner,
					'loser_url'      => $loser,
				];
			}
		}

		// Sort by number of shared queries desc
		usort( $pairs, function( $a, $b ) { return count( $b['shared_queries'] ) - count( $a['shared_queries'] ); } );
		$pairs = array_slice( $pairs, 0, 30 );

		$data = [ 'pairs' => $pairs, 'total' => count( $pairs ), 'generated_at' => gmdate( 'c' ) ];
		set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );

		return rest_ensure_response( $data );
	}

	// - GSC Intelligence --------------------------â"€

	public function get_gsc_intelligence( WP_REST_Request $request ) {
		$gsc = new CGM_GSC_Connector();
		if ( ! $gsc->is_connected() ) {
			return rest_ensure_response( [
				'connected'     => false,
				'configured'    => false,
				'near_wins'     => [],
				'ctr_leaks'     => [],
				'refresh_decay' => [],
				'generated_at'  => gmdate( 'c' ),
				'code'          => 'not_connected',
				'message'       => __( 'GSC is not connected.', 'contentgem' ),
			] );
		}
		$site_url = (string) get_option( 'contentgem_gsc_site_url', '' );
		if ( empty( $site_url ) ) {
			return rest_ensure_response( [
				'connected'     => true,
				'configured'    => false,
				'near_wins'     => [],
				'ctr_leaks'     => [],
				'refresh_decay' => [],
				'generated_at'  => gmdate( 'c' ),
				'code'          => 'no_property',
				'message'       => __( 'No GSC property selected.', 'contentgem' ),
			] );
		}
		$cache_key = 'cgm_gsc_intelligence_' . md5( $site_url );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}
		$end_date   = gmdate( 'Y-m-d' );
		$start_date = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		$mid_date   = gmdate( 'Y-m-d', strtotime( '-45 days' ) );
		$rows_recent  = $this->gsc_query( $gsc, $site_url, $mid_date,   $end_date, [ 'query', 'page' ], 5000 );
		$pages_recent = $this->gsc_query( $gsc, $site_url, $mid_date,   $end_date, [ 'page' ], 2000 );
		$pages_prev   = $this->gsc_query( $gsc, $site_url, $start_date, $mid_date, [ 'page' ], 2000 );
		$expected_ctr = [ 1=>28.5, 2=>15.7, 3=>11.0, 4=>8.0, 5=>6.3, 6=>5.1, 7=>4.1, 8=>3.4, 9=>2.9, 10=>2.5, 11=>2.0, 12=>1.8, 13=>1.6, 14=>1.4, 15=>1.2 ];
		$near_wins = [];
		foreach ( $rows_recent as $row ) {
			$pos = (float)($row['position']??0); $imp = (int)($row['impressions']??0);
			if ( $pos < 4 || $pos > 15 || $imp < 50 ) continue;
			$near_wins[] = [ 'query'=>$row['keys'][0]??'', 'page'=>$row['keys'][1]??'', 'position'=>round($pos,1), 'impressions'=>$imp, 'clicks'=>(int)($row['clicks']??0), 'ctr'=>round((float)($row['ctr']??0)*100,1) ];
		}
		usort( $near_wins, function($a,$b) { return $b['impressions']-$a['impressions']; } );
		$near_wins = array_slice( $near_wins, 0, 25 );
		$ctr_leaks = [];
		foreach ( $rows_recent as $row ) {
			$imp = (int)($row['impressions']??0); if ($imp<100) continue;
			$act = round((float)($row['ctr']??0)*100,1);
			$pk  = min(15,max(1,(int)round((float)($row['position']??1))));
			$exp = $expected_ctr[$pk]??1.0; $gap = round($exp-$act,1);
			if ($gap<2.0) continue;
			$ctr_leaks[] = [ 'query'=>$row['keys'][0]??'', 'page'=>$row['keys'][1]??'', 'impressions'=>$imp, 'clicks'=>(int)($row['clicks']??0), 'ctr'=>$act, 'expected_ctr'=>round($exp,1), 'ctr_gap'=>$gap ];
		}
		usort( $ctr_leaks, function($a,$b) { return (int)($b['impressions']-$a['impressions']); } );
		$ctr_leaks = array_slice( $ctr_leaks, 0, 25 );
		$prev_by_page = [];
		foreach ( $pages_prev as $row ) { $prev_by_page[$row['keys'][0]??''] = $row; }
		$refresh_decay = [];
		foreach ( $pages_recent as $row ) {
			$page=$row['keys'][0]??''; $ir=(int)($row['impressions']??0); $pr=(float)($row['position']??0);
			if (!isset($prev_by_page[$page])) continue;
			$prev=$prev_by_page[$page]; $ip=(int)($prev['impressions']??0); $pp=(float)($prev['position']??0);
			if ($ip<100) continue;
			$id=$ip>0?round((($ip-$ir)/$ip)*100,1):0; $pd=round($pr-$pp,1);
			if ($id<15&&$pd<1.5) continue;
			$ds=round(($id*0.7)+(max(0,$pd)*5),1);
			$pid=url_to_postid($page);
			$refresh_decay[] = [ 'page'=>$page, 'title'=>$pid?get_the_title($pid):'', 'impressions_recent'=>$ir, 'impressions_prev'=>$ip, 'clicks_recent'=>(int)($row['clicks']??0), 'clicks_prev'=>(int)($prev['clicks']??0), 'position_recent'=>round($pr,1), 'position_prev'=>round($pp,1), 'decay_score'=>$ds ];
		}
		usort( $refresh_decay, function($a,$b) { return (int)($b['decay_score']-$a['decay_score']); } );
		$refresh_decay = array_slice( $refresh_decay, 0, 25 );
		$data = [ 'connected'=>true, 'configured'=>true, 'near_wins'=>$near_wins, 'ctr_leaks'=>$ctr_leaks, 'refresh_decay'=>$refresh_decay, 'generated_at'=>gmdate('c') ];
		set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );
		return rest_ensure_response( $data );
	}


	private function get_analysis_language_label(): string {
		$language_service = new CGM_Language_Service();
		return $language_service->get_language_label( $language_service->get_language_code() );
	}

	private function sanitize_cluster_list( $clusters ): array {
		$clusters = is_array( $clusters ) ? $clusters : [];
		$normalized = [];
		$seen = [];
		foreach ( $clusters as $cluster ) {
			$cluster = sanitize_text_field( trim( wp_strip_all_tags( (string) $cluster ) ) );
			if ( '' === $cluster ) {
				continue;
			}
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $cluster ) : strtolower( $cluster );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$normalized[] = $cluster;
		}
		return array_slice( $normalized, 0, 200 );
	}

	private function get_saved_competitor_urls(): array {
		$primary = get_option( 'contentgem_competitors', [] );
		if ( empty( $primary ) ) {
			$primary = get_option( 'contentgem_competitor_domains', [] );
		}
		$primary = is_array( $primary ) ? $primary : [];
		$primary = array_values( array_unique( array_filter( array_map( 'esc_url_raw', $primary ) ) ) );
		return array_slice( $primary, 0, 20 );
	}

	private function build_plugin_analysis_context( int $site_id ): array {
		$clusters = $this->get_saved_clusters();
		$cluster_keywords = get_option( 'cgm_cluster_keywords', [] );
		$cluster_keywords = is_array( $cluster_keywords ) ? $cluster_keywords : [];
		$pillar_pages = get_option( 'contentgem_pillar_pages', [] );
		$pillar_pages = is_array( $pillar_pages ) ? $pillar_pages : [];
		$competitors = $this->get_saved_competitor_urls();
		$niche = sanitize_text_field( (string) get_option( 'contentgem_niche', get_bloginfo( 'name' ) ) );
		$description = sanitize_textarea_field( (string) get_option( 'contentgem_niche_description', '' ) );
		$language_code = $this->get_preferred_language_code();
		$language_label = $this->get_analysis_language_label();
		$gsc_queries = [];
		try {
			$gsc = new CGM_GSC_Connector();
			if ( $gsc->is_connected() ) {
				$rows = $gsc->get_top_queries( 100 );
				foreach ( (array) $rows as $row ) {
					$query = sanitize_text_field( (string) ( $row['query'] ?? '' ) );
					if ( '' !== $query ) {
						$gsc_queries[] = $query;
					}
				}
			}
		} catch ( \Throwable $e ) {
			$gsc_queries = [];
		}
		$latest_competitor = get_option( 'contentgem_latest_competitor_analysis', [] );
		$latest_competitor = is_array( $latest_competitor ) ? $latest_competitor : [];
		if ( ! empty( $latest_competitor['keyword'] ) ) {
			$gsc_queries[] = sanitize_text_field( (string) $latest_competitor['keyword'] );
		}
		foreach ( array_slice( (array) ( $latest_competitor['gaps'] ?? [] ), 0, 12 ) as $gap_row ) {
			$desc = sanitize_text_field( (string) ( $gap_row['description'] ?? $gap_row['action'] ?? '' ) );
			if ( '' !== $desc ) { $gsc_queries[] = $desc; }
		}
		foreach ( array_slice( (array) ( $latest_competitor['competitors'] ?? [] ), 0, 6 ) as $comp_row ) {
			foreach ( array_slice( (array) ( $comp_row['h2s'] ?? [] ), 0, 8 ) as $h2 ) {
				$h2 = sanitize_text_field( (string) $h2 );
				if ( '' !== $h2 ) { $gsc_queries[] = $h2; }
			}
		}
		return [
			'site_id' => $site_id,
			'clusters' => $clusters,
			'cluster_keywords' => $cluster_keywords,
			'pillar_pages' => $pillar_pages,
			'competitors' => $competitors,
			'niche' => $niche,
			'description' => $description,
			'language_code' => $language_code,
			'language_label' => $language_label,
			'gsc_queries' => array_values( array_unique( $gsc_queries ) ),
			'latest_competitor_analysis' => $latest_competitor,
		];
	}

	private function sync_topics_from_saved_clusters( int $site_id, array $clusters ): array {
		global $wpdb;
		$clusters = $this->sanitize_cluster_list( $clusters );
		$wpdb->delete( $wpdb->prefix . 'cgm_topics', [ 'site_id' => $site_id ], [ '%d' ] );
		$topic_map = [];
		foreach ( $clusters as $cluster_name ) {
			$wpdb->insert(
				$wpdb->prefix . 'cgm_topics',
				[
					'site_id' => $site_id,
					'cluster_name' => $cluster_name,
					'coverage_score' => 0,
					'post_ids' => wp_json_encode( [] ),
					'post_count' => 0,
				],
				[ '%d', '%s', '%f', '%s', '%d' ]
			);
			$topic_map[ $cluster_name ] = (int) $wpdb->insert_id;
		}
		return $topic_map;
	}

	private function query_matches_cluster( string $query, string $cluster ): bool {
		$cluster_words = array_keys( $this->words_for_overlap( $cluster ) );
		if ( empty( $cluster_words ) ) {
			return false;
		}
		$query_words = array_keys( $this->words_for_overlap( $query ) );
		return count( array_intersect( $cluster_words, $query_words ) ) > 0;
	}

	private function cgm_humanize_phrase( string $phrase ): string {
		$phrase = trim( preg_replace( '/[\-_]+/', ' ', sanitize_text_field( $phrase ) ) );
		if ( '' === $phrase ) {
			return '';
		}
		$words = preg_split( '/\s+/', $phrase ) ?: [];
		$acronyms = [ 'seo', 'ai', 'nlp', 'gsc', 'serp', 'faq', 'etf', 'ipo' ];
		$normalized = [];
		foreach ( $words as $word ) {
			$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( $word ) : strtolower( $word );
			if ( in_array( $lower, $acronyms, true ) ) {
				$normalized[] = strtoupper( $lower );
			} else {
				$normalized[] = function_exists( 'mb_convert_case' ) ? mb_convert_case( $lower, MB_CASE_TITLE, 'UTF-8' ) : ucwords( $lower );
			}
		}
		return trim( implode( ' ', $normalized ) );
	}

	private function cgm_build_gap_seed_phrases( string $cluster, array $keywords, array $queries, string $niche = '' ): array {
		$seed_map = [];
		foreach ( array_merge( $queries, $keywords, [ $cluster ] ) as $candidate ) {
			$candidate = $this->cgm_humanize_phrase( (string) $candidate );
			if ( '' === $candidate ) {
				continue;
			}
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $candidate ) : strtolower( $candidate );
			$seed_map[ $key ] = $candidate;
		}
		if ( empty( $seed_map ) && '' !== $niche ) {
			$seed_map[ strtolower( $niche ) ] = $this->cgm_humanize_phrase( $niche );
		}
		return array_values( $seed_map );
	}

	private function cgm_is_generic_gap_title( string $title, string $cluster = '' ): bool {
		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $title ) ) : strtolower( trim( $title ) );
		$cluster_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $cluster ) ) : strtolower( trim( $cluster ) );
		if ( preg_match( '/^\d+\s+for\s+/i', $title_lc ) ) {
			return true;
		}
		if ( preg_match( '/^(practical strategies for|complete guide to|wat je moet weten over|praktische strategie[eë]n voor)/i', $title_lc ) ) {
			return true;
		}
		if ( '' !== $cluster_lc && $title_lc === $cluster_lc ) {
			return true;
		}
		return false;
	}

	private function cgm_special_gap_titles( string $seed, string $language_code, string $niche = '' ): array {
		$seed_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $seed ) : strtolower( $seed );
		$year = gmdate( 'Y' );
		$topic = $this->cgm_humanize_phrase( $seed );
		$map_en = [
			'keyword gap' => [
				'How to Find Keyword Gaps Your Competitors Already Rank For',
				'Keyword Gap Analysis: Tools, Workflow and Real Examples',
			],
			'competitive content analysis' => [
				'How to Run a Competitive Content Analysis That Reveals Quick Wins',
				'Competitive Content Analysis: Framework, Metrics and Example Workflow',
			],
			'content strategy optimization' => [
				'How to Improve Your Content Strategy With Topic and Gap Data',
				'Content Strategy Optimization: A Practical Workflow for Better Coverage',
			],
			'ai content generation' => [
				'How to Use AI Content Generation Without Losing Quality or Search Intent',
				'AI Content Generation: Best Practices, Risks and Workflow Tips',
			],
			'semantic content gap analysis' => [
				'How to Use Semantic Content Gap Analysis to Find Missing Topics',
				'Semantic Content Gap Analysis: A Practical Guide to Better Topical Coverage',
			],
			'content gap solutions' => [
				'How to Fix Content Gaps That Hold Back Organic Growth',
				'Content Gap Solutions: Practical Ways to Prioritize Missing Pages',
			],
			'semantic seo tools' => [
				'Best Semantic SEO Tools for Topic Mapping and Content Planning in ' . $year,
				'How to Choose Semantic SEO Tools for Better Content Research',
			],
			'ai seo enhancement' => [
				'How AI Can Improve SEO Workflows Without Replacing Strategy',
				'AI for SEO: Practical Enhancements for Research, Briefs and Optimization',
			],
		];
		$map_nl = [
			'keyword gap' => [
				'Hoe je keyword gaps vindt waar concurrenten al op scoren',
				'Keyword gap analyse: tools, werkwijze en voorbeelden',
			],
			'competitive content analysis' => [
				'Hoe je een concurrentieanalyse van content uitvoert en snelle kansen vindt',
				'Competitive content analysis: framework, metrics en voorbeeldworkflow',
			],
			'content strategy optimization' => [
				'Hoe je je contentstrategie verbetert met topic- en gapdata',
				'Contentstrategie optimaliseren: een praktische workflow voor betere dekking',
			],
			'ai content generation' => [
				'Hoe je AI-contentgeneratie inzet zonder kwaliteit of zoekintentie te verliezen',
				'AI-contentgeneratie: best practices, risico’s en workflowtips',
			],
			'semantic content gap analysis' => [
				'Hoe je semantische content gap analyse gebruikt om gemiste onderwerpen te vinden',
				'Semantische content gap analyse: een praktische gids voor betere topical coverage',
			],
			'content gap solutions' => [
				'Hoe je content gaps oplost die organische groei afremmen',
				'Content gap oplossingen: praktische manieren om missende pagina’s te prioriteren',
			],
			'semantic seo tools' => [
				'Beste semantic SEO tools voor topic mapping en contentplanning in ' . $year,
				'Hoe kies je semantic SEO tools voor beter contentonderzoek',
			],
			'ai seo enhancement' => [
				'Hoe AI SEO-workflows kan verbeteren zonder strategie te vervangen',
				'AI voor SEO: praktische verbeteringen voor research, briefs en optimalisatie',
			],
		];
		$map = 'nl' === $language_code ? $map_nl : $map_en;
		foreach ( $map as $needle => $titles ) {
			if ( false !== strpos( $seed_lc, $needle ) ) {
				return $titles;
			}
		}
		return [];
	}

	private function cgm_build_gap_title_blueprints( string $seed, string $cluster, string $language_code, string $niche = '', bool $has_competitors = false ): array {
		$seed = $this->cgm_humanize_phrase( $seed );
		$variants = [];
		foreach ( $this->cgm_special_gap_titles( $seed, $language_code, $niche ) as $title ) {
			$variants[] = [ 'title' => $title, 'intent' => 'informational', 'priority' => 92.0 ];
		}
		if ( 'nl' === $language_code ) {
			$variants[] = [ 'title' => 'Hoe gebruik je ' . $seed . ' om betere contentkansen te vinden?', 'intent' => 'informational', 'priority' => 89.0 ];
			$variants[] = [ 'title' => $seed . ': praktische uitleg, tools en voorbeelden', 'intent' => 'informational', 'priority' => 87.0 ];
			if ( $has_competitors ) {
				$variants[] = [ 'title' => 'Wat concurrenten je kunnen leren over ' . $seed, 'intent' => 'commercial', 'priority' => 85.0 ];
			}
			if ( '' !== trim( $niche ) ) {
				$variants[] = [ 'title' => $seed . ' toepassen binnen ' . $this->cgm_humanize_phrase( $niche ), 'intent' => 'informational', 'priority' => 83.0 ];
			}
		} else {
			$variants[] = [ 'title' => 'How to Use ' . $seed . ' to Find Better Content Opportunities', 'intent' => 'informational', 'priority' => 89.0 ];
			$variants[] = [ 'title' => $seed . ': Tools, Examples and a Step-by-Step Process', 'intent' => 'informational', 'priority' => 87.0 ];
			if ( $has_competitors ) {
				$variants[] = [ 'title' => 'What Competitor Data Can Teach You About ' . $seed, 'intent' => 'commercial', 'priority' => 85.0 ];
			}
			if ( '' !== trim( $niche ) ) {
				$variants[] = [ 'title' => 'How to Apply ' . $seed . ' in ' . $this->cgm_humanize_phrase( $niche ), 'intent' => 'informational', 'priority' => 83.0 ];
			}
		}
		return $variants;
	}

	private function build_contextual_title_variants( string $cluster, array $keywords, array $queries, bool $has_pillar, string $language_code, string $niche = '', bool $has_competitors = false ): array {
		$variants = [];
		$seeds = $this->cgm_build_gap_seed_phrases( $cluster, $keywords, $queries, $niche );
		foreach ( array_slice( $seeds, 0, 3 ) as $seed ) {
			foreach ( $this->cgm_build_gap_title_blueprints( $seed, $cluster, $language_code, $niche, $has_competitors ) as $variant ) {
				$variants[] = $variant;
			}
		}
		if ( ! $has_pillar ) {
			$pillar_seed = $this->cgm_humanize_phrase( $keywords[0] ?? $cluster );
			if ( '' !== $pillar_seed ) {
				$variants[] = [
					'title' => 'nl' === $language_code ? ( $pillar_seed . ': complete gids voor beginners en gevorderden' ) : ( $pillar_seed . ': A Complete Guide for Beginners and Practitioners' ),
					'intent' => 'informational',
					'priority' => 94.0,
				];
			}
		}
		$clean = [];
		$seen = [];
		foreach ( $variants as $variant ) {
			$title = sanitize_text_field( trim( (string) ( $variant['title'] ?? '' ) ) );
			if ( '' === $title || $this->cgm_is_generic_gap_title( $title, $cluster ) ) {
				continue;
			}
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title ) : strtolower( $title );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$clean[] = [
				'title' => $title,
				'intent' => in_array( (string) ( $variant['intent'] ?? '' ), [ 'informational', 'commercial', 'navigational' ], true ) ? (string) $variant['intent'] : 'informational',
				'priority' => (float) ( $variant['priority'] ?? 80 ),
			];
			if ( count( $clean ) >= 4 ) {
				break;
			}
		}
		return $clean;
	}

	/**
	 * v4.7 — Get/set the strict keyword match toggle for the current site.
	 * When enabled, Content Gaps title generation discards titles that don't
	 * contain at least one cluster keyword (or stem variant).
	 */
	public function get_gap_strict_match( WP_REST_Request $request ) {
		$site_id = $this->get_site_id();
		if ( $site_id <= 0 ) {
			return new WP_Error( 'no_site', 'No active site.', [ 'status' => 400 ] );
		}
		return rest_ensure_response( [
			'success' => true,
			'enabled' => (bool) get_option( 'cgm_strict_keyword_match_' . $site_id, false ),
		] );
	}

	public function set_gap_strict_match( WP_REST_Request $request ) {
		$site_id = $this->get_site_id();
		if ( $site_id <= 0 ) {
			return new WP_Error( 'no_site', 'No active site.', [ 'status' => 400 ] );
		}
		$raw = $request->get_param( 'enabled' );
		$enabled = filter_var( $raw, FILTER_VALIDATE_BOOLEAN );
		update_option( 'cgm_strict_keyword_match_' . $site_id, $enabled ? 1 : 0, false );
		return rest_ensure_response( [ 'success' => true, 'enabled' => $enabled ] );
	}

	public function get_gap_keyword_only( WP_REST_Request $request ) {
		$site_id = $this->get_site_id();
		if ( $site_id <= 0 ) {
			return new WP_Error( 'no_site', 'No active site.', [ 'status' => 400 ] );
		}
		return rest_ensure_response( [
			'success' => true,
			'enabled' => (bool) get_option( 'cgm_gap_keyword_only_' . $site_id, false ),
		] );
	}

	public function set_gap_keyword_only( WP_REST_Request $request ) {
		$site_id = $this->get_site_id();
		if ( $site_id <= 0 ) {
			return new WP_Error( 'no_site', 'No active site.', [ 'status' => 400 ] );
		}
		$raw = $request->get_param( 'enabled' );
		$enabled = filter_var( $raw, FILTER_VALIDATE_BOOLEAN );
		update_option( 'cgm_gap_keyword_only_' . $site_id, $enabled ? 1 : 0, false );
		return rest_ensure_response( [ 'success' => true, 'enabled' => $enabled ] );
	}

	private function cgm_keyword_gap_title_for_intent( string $keyword, string $intent, int $index = 0 ): string {
		$keyword = trim( sanitize_text_field( $keyword ) );
		if ( '' === $keyword ) {
			return '';
		}

		$intent = sanitize_key( $intent ?: 'informational' );
		$templates = [
			'informational' => [
				'What Is %s and How Does It Work?',
				'%s Explained: Strategy, Examples and Best Practices',
				'How to Use %s Without Common Mistakes',
			],
			'commercial' => [
				'Best %s Strategies and Tools Compared',
				'Is %s Worth It? Benefits, Limits and Use Cases',
				'How to Choose the Right %s Approach for Better Results',
			],
			'navigational' => [
				'%s Resources, Tools and Templates Worth Using',
				'Where to Find the Best %s Guides and Examples',
				'%s Checklist, Templates and Next Steps',
			],
		];

		if ( ! isset( $templates[ $intent ] ) ) {
			$intent = 'informational';
		}

		$list = $templates[ $intent ];
		$template = $list[ $index % count( $list ) ];
		return sprintf( $template, $keyword );
	}

	private function cgm_build_keyword_only_gaps( string $cluster_filter, string $intent_filter, array $cluster_keywords_map, array $cluster_terms, int $site_id ): array {
		$clusters = '' !== $cluster_filter ? [ $cluster_filter ] : $this->cgm_get_all_cluster_names();
		$clusters = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $clusters ) ) ) );
		if ( empty( $clusters ) && ! empty( $cluster_keywords_map ) ) {
			$clusters = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', array_keys( $cluster_keywords_map ) ) ) ) );
		}

		$intent = '' !== $intent_filter ? sanitize_key( $intent_filter ) : 'informational';
		$rows = [];
		$priority = 99;
		$seen_titles = [];

		foreach ( $clusters as $cluster_name ) {
			$keywords = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $cluster_keywords_map[ $cluster_name ] ?? [] ) ) ) );
			if ( empty( $keywords ) && '' !== $cluster_name ) {
				$keywords[] = $cluster_name;
			}

			$category_id = (int) ( $cluster_terms[ $cluster_name ]['category_id'] ?? 0 );
			$category_slug = (string) ( $cluster_terms[ $cluster_name ]['category_slug'] ?? sanitize_title( $cluster_name ) );

			foreach ( array_values( $keywords ) as $index => $keyword ) {
				$title = $this->cgm_keyword_gap_title_for_intent( $keyword, $intent, $index );
				if ( '' === $title ) {
					continue;
				}
				$title_key = strtolower( $title );
				if ( isset( $seen_titles[ $title_key ] ) ) {
					continue;
				}
				$seen_titles[ $title_key ] = true;

				$row = (object) [
					'id' => -1 * abs( crc32( $cluster_name . '|' . $keyword . '|' . $intent ) ),
					'suggested_title' => $title,
					'search_intent' => $intent,
					'priority_score' => max( 1, $priority ),
					'status' => 'open',
					'topic_id' => 0,
					'fixes_broken_link' => false,
					'broken_url' => null,
					'cluster_name' => $cluster_name,
					'category_id' => $category_id > 0 ? $category_id : null,
					'category_slug' => '' !== $category_slug ? $category_slug : null,
					'semantic_tags' => $this->build_gap_semantic_tags( $title, $cluster_name, array_values( array_unique( array_filter( array_merge( [ $keyword ], $keywords ) ) ) ) ),
					'is_keyword_only' => true,
				];
				$length_meta = $this->get_gap_length_recommendation( $title, $intent );
				$row->suggested_length = (int) ( $length_meta['words'] ?? 0 );
				$row->suggested_length_label = (string) ( $length_meta['label'] ?? '' );
				$row->length_reason = (string) ( $length_meta['reason'] ?? '' );
				$matches = $this->cgm_find_existing_keyword_matches( $title, $cluster_name );
				$row->already_written = ! empty( $matches );
				$row->already_written_titles = array_map( static fn( $m ) => (string) $m['title'], $matches );
				$row->already_written_matches = $matches;
				$rows[] = $row;
				$priority--;
			}
		}

		usort( $rows, static function ( $a, $b ) {
			return (int) ( $b->priority_score ?? 0 ) <=> (int) ( $a->priority_score ?? 0 );
		} );

		return $rows;
	}

	private function cgm_gap_matches_keyword_only_filter( $row, array $cluster_keywords_map ): bool {
		$title = trim( (string) ( $row->suggested_title ?? '' ) );
		if ( '' === $title ) {
			return false;
		}
		$cluster = sanitize_text_field( (string) ( $row->cluster_name ?? '' ) );
		$keywords = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $cluster_keywords_map[ $cluster ] ?? [] ) ) ) );
		if ( empty( $keywords ) && '' !== $cluster ) {
			$keywords[] = $cluster;
		}
		if ( empty( $keywords ) ) {
			return true;
		}

		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( wp_strip_all_tags( $title ) ) : strtolower( wp_strip_all_tags( $title ) );
		$title_tokens = $this->cgm_normalize_keyword_text( $title_lc );
		$semantic_tags = is_array( $row->semantic_tags ?? null ) ? array_map( 'sanitize_title', (array) $row->semantic_tags ) : [];

		foreach ( $keywords as $keyword ) {
			$keyword = trim( (string) $keyword );
			if ( '' === $keyword ) {
				continue;
			}
			$keyword_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $keyword ) : strtolower( $keyword );
			if ( false !== mb_strpos( $title_lc, $keyword_lc ) ) {
				return true;
			}
			$keyword_tokens = $this->cgm_normalize_keyword_text( $keyword_lc );
			if ( ! empty( $keyword_tokens ) ) {
				$overlap = count( array_intersect( $title_tokens, $keyword_tokens ) );
				$required = count( $keyword_tokens ) <= 1 ? 1 : min( 2, count( $keyword_tokens ) );
				if ( $overlap >= $required ) {
					return true;
				}
			}
			$slug = sanitize_title( $keyword );
			if ( '' !== $slug ) {
				foreach ( $semantic_tags as $tag ) {
					if ( $tag === $slug || false !== strpos( $tag, $slug ) || false !== strpos( $slug, $tag ) ) {
						return true;
					}
				}
			}
		}

		return false;
	}

	private function create_plugin_context_gaps( int $site_id, array $context, bool $replace_existing = false ): int {
		global $wpdb;
		$clusters = $this->sanitize_cluster_list( $context['clusters'] ?? [] );
		if ( empty( $clusters ) ) {
			return 0;
		}
		$topic_map = $this->sync_topics_from_saved_clusters( $site_id, $clusters );
		if ( $replace_existing ) {
			$wpdb->delete( $wpdb->prefix . 'cgm_gaps', [ 'site_id' => $site_id ], [ '%d' ] );
		}
		$existing_titles = $wpdb->get_col( $wpdb->prepare( "SELECT suggested_title FROM {$wpdb->prefix}cgm_gaps WHERE site_id = %d", $site_id ) );
		$context['existing_titles'] = array_map( 'sanitize_text_field', (array) $existing_titles );
		// v4.7 — strict keyword match toggle (per-site option set from the Content Gaps UI).
		$context['strict_keyword_match'] = (bool) get_option( 'cgm_strict_keyword_match_' . $site_id, false );
		$engine = new CGM_Gap_Engine();
		$normalized_context = $engine->build_gap_context( $context );
		$inserted = 0;
		$used_signatures = [];
		$used_openings = [];
		foreach ( $clusters as $cluster_name ) {
			$topic_id = (int) ( $topic_map[ $cluster_name ] ?? 0 );
			if ( $topic_id <= 0 ) {
				continue;
			}
			$normalized_context['cluster_keywords'][ $cluster_name ] = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', array_merge(
				(array) ( $normalized_context['cluster_keywords'][ $cluster_name ] ?? [] ),
				$this->derive_semantic_keywords( $cluster_name, $cluster_name, $site_id )
			) ) ) ) );
			$seeds = $engine->extract_seed_queries( $normalized_context, $cluster_name );
			$expanded = $engine->expand_seed_queries_by_intent( $seeds, $normalized_context );
			$candidates = $engine->generate_title_candidates( $expanded, $normalized_context, $cluster_name );
			$filtered = $engine->filter_low_quality_titles( $candidates, $normalized_context, $cluster_name );
			$scored = $engine->score_gap_candidates( $filtered, $normalized_context, $cluster_name );
			foreach ( $scored as $variant ) {
				$title = sanitize_text_field( (string) ( $variant['title'] ?? '' ) );
				if ( '' === $title || in_array( $title, $normalized_context['existing_titles'], true ) ) {
					continue;
				}
				$signature = strtolower( preg_replace( '/\b(?:how|what|when|which|where|best|guide|explained|comparison|mistakes|beginners|tools|compared|strategy|approach|fits|smartest|useful|resources|place|actually|value|de|het|een|hoe|wat|wanneer|welke|waar|beste|gids|uitgelegd|vergeleken|fouten|beginners|tools|aanpak|past|bronnen|waarde)\b/iu', ' ', $title ) );
				$signature = preg_replace( '/\s+/', ' ', trim( (string) $signature ) );
				if ( '' !== $signature && isset( $used_signatures[ $signature ] ) ) {
					continue;
				}
				$opening_bucket = $this->cgm_gap_opening_bucket( $title );
				if ( '' !== $opening_bucket && (int) ( $used_openings[ $opening_bucket ] ?? 0 ) >= 4 ) {
					continue;
				}
				$wpdb->insert(
					$wpdb->prefix . 'cgm_gaps',
					[
						'site_id' => $site_id,
						'topic_id' => $topic_id,
						'suggested_title' => $title,
						'search_intent' => (string) ( $variant['intent'] ?? 'informational' ),
						'gsc_impressions' => 0,
						'gsc_clicks' => 0,
						'priority_score' => (float) ( $variant['priority'] ?? 80 ),
						'status' => 'open',
					],
					[ '%d', '%d', '%s', '%s', '%d', '%d', '%f', '%s' ]
				);
				if ( $wpdb->insert_id ) {
					$normalized_context['existing_titles'][] = $title;
					if ( '' !== $signature ) {
						$used_signatures[ $signature ] = true;
					}
					if ( '' !== $opening_bucket ) {
						$used_openings[ $opening_bucket ] = (int) ( $used_openings[ $opening_bucket ] ?? 0 ) + 1;
					}
					$inserted++;
				}
			}
		}
		return $inserted;
	}

	private function cgm_gap_opening_bucket( string $title ): string {
		$title = strtolower( trim( preg_replace( '/[^\p{L}\p{N}\s]+/u', ' ', (string) $title ) ) );
		$title = preg_replace( '/\s+/', ' ', (string) $title );
		if ( '' === $title ) {
			return '';
		}
		$words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		$opening = implode( ' ', array_slice( $words, 0, 2 ) );
		return sanitize_key( str_replace( ' ', '_', trim( $opening ) ) );
	}

	private function run_plugin_context_analysis( int $site_id ): array {
		$context = $this->build_plugin_analysis_context( $site_id );
		$clusters = $this->sanitize_cluster_list( $context['clusters'] ?? [] );
		$gaps_count = $this->create_plugin_context_gaps( $site_id, $context, true );
		return [
			'clusters' => $clusters,
			'gaps' => $gaps_count,
			'posts_analyzed' => 0,
			'posts_total' => 0,
			'baseline_from_settings' => true,
			'context_sources' => [
				'clusters' => ! empty( $clusters ),
				'cluster_keywords' => ! empty( $context['cluster_keywords'] ),
				'competitors' => ! empty( $context['competitors'] ),
				'gsc' => ! empty( $context['gsc_queries'] ),
				'pillar_pages' => ! empty( $context['pillar_pages'] ),
				'niche' => ! empty( $context['niche'] ),
			],
		];
	}

	private function augment_analysis_with_plugin_context( int $site_id, array $clusters_found ): int {
		$context = $this->build_plugin_analysis_context( $site_id );
		if ( ! empty( $clusters_found ) ) {
			$context['clusters'] = $this->sanitize_cluster_list( array_merge( (array) $context['clusters'], (array) $clusters_found ) );
		}
		return $this->create_plugin_context_gaps( $site_id, $context, false );
	}

	private function get_gap_length_recommendation( string $title, string $intent = 'informational' ): array {
		$title_lc = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title ) : strtolower( $title );
		$label = 'Medium';
		$words = 1100;
		$reason = 'Balanced depth for a standard article.';
		if ( preg_match( '/complete guide|gids|strategie|analysis|analyse|vergelijk|comparison|basics|fundamentals|beginners/i', $title_lc ) ) {
			$label = 'Long';
			$words = 1800;
			$reason = 'Broad topic with strong educational or comparison intent.';
		}
		if ( 'commercial' === $intent ) {
			$label = 'Medium';
			$words = max( $words, 1200 );
			$reason = 'Commercial pages need enough detail to compare options without becoming bloated.';
		}
		if ( preg_match( '/complete guide|gids/i', $title_lc ) ) {
			$label = 'Pillar';
			$words = 2600;
			$reason = 'Pillar-style topic that should cover the subject end-to-end.';
		}
		return [ 'label' => $label, 'words' => $words, 'reason' => $reason ];
	}

	private function gsc_query( CGM_GSC_Connector $gsc, string $site_url, string $start_date, string $end_date, array $dimensions, int $row_limit = 1000 ): array {
		$token = $this->get_gsc_token();
		if ( empty($token) ) return [];
		$response = wp_remote_post( 'https://www.googleapis.com/webmasters/v3/sites/' . rawurlencode($site_url) . '/searchAnalytics/query', [
			'timeout' => 30,
			'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [ 'startDate'=>$start_date, 'endDate'=>$end_date, 'dimensions'=>$dimensions, 'rowLimit'=>$row_limit ] ),
		] );
		if ( is_wp_error($response) ) return [];
		$data = json_decode( wp_remote_retrieve_body($response), true );
		return $data['rows'] ?? [];
	}

	private function get_gsc_token(): string {
		$token = (string) get_option('contentgem_gsc_access_token','');
		$expires = (int) get_option('contentgem_gsc_token_expires',0);
		if ( empty($token) ) return '';
		if ( $expires > 0 && time() >= $expires ) {
			$gsc = new CGM_GSC_Connector();
			if ( !$gsc->refresh_access_token() ) return '';
			$token = (string) get_option('contentgem_gsc_access_token','');
		}
		return $token;
	}

	private function words_for_overlap( string $text ): array {
		$tokens = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $text ), -1, PREG_SPLIT_NO_EMPTY );
		$set    = [];
		foreach ( $tokens ?? [] as $token ) {
			if ( mb_strlen( $token ) >= 3 ) {
				$set[ $token ] = true;
			}
		}
		return $set;
	}
}