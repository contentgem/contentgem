<?php
/**
 * Class CGM_Admin_Menu
 *
 * Registreert het Contentgem admin-menu en enqueues het React dashboard.
 *
 * @package Contentgem
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class CGM_Admin_Menu {

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'admin_init', [ $this, 'maybe_handle_gsc_callback' ] );
		add_filter( 'admin_body_class', [ $this, 'add_admin_body_classes' ] );
	}


	public function maybe_handle_gsc_callback(): void {
		if ( ! is_admin() ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : '';
		$has_code = isset( $_GET['code'] ) || isset( $_GET['error'] );
		if ( 'contentgem' !== $page || ( ! isset( $_GET['gsc_callback'] ) && ! $has_code ) ) {
			return;
		}

		// Keep OAuth code/state raw enough for token exchange.
		$code  = isset( $_GET['code'] ) ? (string) wp_unslash( $_GET['code'] ) : '';
		$state = isset( $_GET['state'] ) ? (string) wp_unslash( $_GET['state'] ) : '';
		$error = isset( $_GET['error'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['error'] ) ) : '';

		if ( '' === $code && '' === $error ) {
			return;
		}

		$redirect = admin_url( 'admin.php?page=contentgem&view=settings&settings_tab=style&focus=gsc' );
		if ( '' !== $error ) {
			wp_safe_redirect( add_query_arg( 'gsc_error', rawurlencode( $error ), $redirect ) );
			exit;
		}

		$gsc = new CGM_GSC_Connector();
		$ok  = $gsc->handle_callback( $code, $state );
		wp_safe_redirect( add_query_arg( $ok ? 'gsc_connected' : 'gsc_error', $ok ? '1' : 'token_exchange_failed', $redirect ) );
		exit;
	}


	public function add_admin_body_classes( string $classes ): string {
		$page = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : '';
		if ( 'contentgem' !== $page ) {
			return $classes;
		}

		$view = isset( $_GET['view'] ) ? sanitize_key( (string) wp_unslash( $_GET['view'] ) ) : 'dashboard';
		$map  = [
			'dashboard'   => 'cgm-page-dashboard',
			'gaps'        => 'cgm-page-content-gaps',
			'content-gaps'=> 'cgm-page-content-gaps',
			'optimizer'   => 'cgm-page-optimizer',
			'assistant'   => 'cgm-page-ai-assistant',
			'competitor'  => 'cgm-page-competitor',
			'drafts'      => 'cgm-page-drafts',
			'settings'    => 'cgm-page-settings',
		];

		$extra = ' cgm-admin cgm-theme-purple ';
		$extra .= $map[ $view ] ?? 'cgm-page-dashboard';

		return trim( $classes . ' ' . $extra );
	}

	public function register_menu(): void {
		// Zorg dat Freemius submenu items zichtbaar zijn.
		add_filter( 'contentgem_fs_show_account', '__return_true' );

		$gem_svg = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 9l10 13L22 9z" fill="currentColor"/><path d="M2 9h20M7 9L12 2l5 7" stroke="currentColor" stroke-width="0.5" opacity="0.5" fill="none"/></svg>';
		$icon    = 'data:image/svg+xml;base64,' . base64_encode( $gem_svg );

		add_menu_page(
			__( 'Contentgem', 'contentgem' ),
			__( 'Contentgem', 'contentgem' ),
			'edit_posts',
			'contentgem',
			[ $this, 'render_page' ],
			$icon,
			30
		);

		// Diagnostic submenu — admin-only, not shown in the menu (hidden via null parent
		// page-slug style: passing an empty-string parent hides it). Access via
		// /wp-admin/admin.php?page=contentgem-plan-diagnostic
		add_submenu_page(
			'', // No parent = hidden from menu.
			__( 'ContentGem Plan Diagnostic', 'contentgem' ),
			__( 'Plan Diagnostic', 'contentgem' ),
			'manage_options',
			'contentgem-plan-diagnostic',
			[ $this, 'render_plan_diagnostic_page' ]
		);

	}

	/**
	 * Render the plan-diagnostic admin page. Admin-only via capability check in
	 * register_menu() plus a second runtime check below.
	 */
	public function render_plan_diagnostic_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'contentgem' ) );
		}

		$data = [
			'resolved_plan'       => function_exists( 'cgm_get_plan' ) ? cgm_get_plan() : 'unknown',
			'resolved_plan_label' => function_exists( 'cgm_get_plan_label' ) ? cgm_get_plan_label() : 'unknown',
			'cluster_limit'       => function_exists( 'cgm_get_limit' ) ? cgm_get_limit( 'clusters' ) : 'unknown',
			'is_premium'          => function_exists( 'cgm_is_premium' ) ? cgm_is_premium() : false,
			'has_paid_plan'       => function_exists( 'cgm_user_has_paid_plan' ) ? cgm_user_has_paid_plan() : false,
			'plugin_version'      => defined( 'CONTENTGEM_VERSION' ) ? CONTENTGEM_VERSION : 'unknown',
			'wp_debug'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'dev_override'        => (string) get_user_meta( get_current_user_id(), 'contentgem_tier', true ),
			'freemius'            => [],
		];

		if ( function_exists( 'contentgem_fs' ) ) {
			try {
				$fs = contentgem_fs();
				if ( is_object( $fs ) ) {
					$data['freemius']['loaded']       = true;
					$data['freemius']['is_paying']    = method_exists( $fs, 'is_paying' ) ? (bool) $fs->is_paying() : null;
					$data['freemius']['is_trial']     = method_exists( $fs, 'is_trial' ) ? (bool) $fs->is_trial() : null;
					$data['freemius']['is_free_plan'] = method_exists( $fs, 'is_free_plan' ) ? (bool) $fs->is_free_plan() : null;
					$data['freemius']['plan_name']    = method_exists( $fs, 'get_plan_name' ) ? (string) $fs->get_plan_name() : '';
					$data['freemius']['plan_title']   = method_exists( $fs, 'get_plan_title' ) ? (string) $fs->get_plan_title() : '';

					if ( method_exists( $fs, 'is_plan' ) ) {
						$data['freemius']['is_plan'] = [
							'free'      => (bool) $fs->is_plan( 'free', true ),
							'starter'   => (bool) $fs->is_plan( 'starter', true ),
							'growth'    => (bool) $fs->is_plan( 'growth', true ),
							'pro'       => (bool) $fs->is_plan( 'pro', true ),
							'unlimited' => (bool) $fs->is_plan( 'unlimited', true ),
							'agency'    => (bool) $fs->is_plan( 'agency', true ),
						];
					}

					if ( method_exists( $fs, '_get_license' ) ) {
						$license = $fs->_get_license();
						if ( $license && is_object( $license ) ) {
							$data['freemius']['license'] = [
								'id'           => $license->id ?? null,
								'plan_id'      => $license->plan_id ?? null,
								'quota'        => $license->quota ?? null,
								'is_cancelled' => $license->is_cancelled ?? null,
								'expiration'   => $license->expiration ?? null,
							];
						} else {
							$data['freemius']['license'] = null;
						}
					}
				} else {
					$data['freemius']['loaded'] = false;
				}
			} catch ( \Throwable $e ) {
				$data['freemius']['error'] = $e->getMessage();
			}
		} else {
			$data['freemius']['loaded'] = false;
			$data['freemius']['note']   = 'contentgem_fs() function not defined';
		}

		// Render the page.
		echo '<div class="wrap" style="max-width:900px;">';
		echo '<h1>ContentGem Plan Diagnostic</h1>';
		echo '<p style="color:#666;max-width:680px;">Use this page to debug plan resolution issues. Copy the entire block below and share it with support.</p>';

		echo '<textarea readonly style="width:100%;height:520px;font-family:monospace;font-size:12px;padding:14px;background:#1a1a2e;color:#a5b4fc;border:1px solid #7c3aed;border-radius:8px;">';
		echo esc_textarea( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
		echo '</textarea>';

		echo '<p style="margin-top:24px;"><strong>Quick actions:</strong></p>';
		echo '<ul style="list-style:disc;margin-left:20px;color:#555;">';

		// Dev override removal.
		if ( ! empty( $data['dev_override'] ) ) {
			$nonce = wp_create_nonce( 'cgm_clear_dev_override' );
			$url   = add_query_arg(
				[
					'page'             => 'contentgem-plan-diagnostic',
					'cgm_clear_override' => 1,
					'_wpnonce'         => $nonce,
				],
				admin_url( 'admin.php' )
			);
			echo '<li>Developer override detected: <code>' . esc_html( $data['dev_override'] ) . '</code> — <a href="' . esc_url( $url ) . '">Remove override</a></li>';
		}

		// Freemius sync hint.
		if ( isset( $data['freemius']['is_paying'] ) && false === $data['freemius']['is_paying'] ) {
			echo '<li>Freemius reports <code>is_paying: false</code>. Try: WP admin → ContentGem → Account → Sync License.</li>';
		}

		echo '</ul>';
		echo '</div>';

		// Handle override clear action.
		if ( isset( $_GET['cgm_clear_override'] ) && ! empty( $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'cgm_clear_dev_override' ) ) {
			delete_user_meta( get_current_user_id(), 'contentgem_tier' );
			echo '<div class="notice notice-success" style="margin-top:20px;"><p>Developer override removed. Reload this page.</p></div>';
		}
	}

	public function render_page(): void {
		echo '<div class="wrap cgm-admin-wrap cgm-shell"><div id="contentgem-dashboard" class="cgm-dashboard-root cgm-admin-app" data-cgm-design-system="v1" data-cgm-app="1" data-cgm-ui="design-system" data-cgm-version="5.0.8.17"></div></div>';
	}


	public function enqueue_assets( string $hook ): void {
		if ( ! str_contains( $hook, 'contentgem' ) ) {
			return;
		}

		wp_enqueue_style( 'contentgem-admin', CONTENTGEM_URL . 'assets/css/admin.css', [], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-admin-fonts', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@700;800&family=DM+Sans:wght@400;500;700&display=swap', [], null );
		wp_enqueue_style( 'contentgem-paywall', CONTENTGEM_URL . 'assets/css/cgm-paywall.css', [ 'contentgem-admin' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ui-components', CONTENTGEM_URL . 'assets/css/cg-ui-components.css', [ 'contentgem-paywall' ], CONTENTGEM_VERSION );

		wp_enqueue_style( 'contentgem-v62-hardfix', CONTENTGEM_URL . 'assets/css/admin-v62-v6-hardfix.css', [ 'contentgem-admin', 'contentgem-ui-components' ], CONTENTGEM_VERSION );


		$manifest = CONTENTGEM_DIR . 'assets/js/dist/.vite/manifest.json';
		$entry    = 'src/main.tsx';

		if ( file_exists( $manifest ) ) {
			$data    = json_decode( file_get_contents( $manifest ), true );
			$js_file = $data[ $entry ]['file'] ?? 'main.js';

			wp_enqueue_script(
				'contentgem-dashboard',
				CONTENTGEM_URL . 'assets/js/dist/' . $js_file,
				[ 'wp-hooks', 'heartbeat' ],
				CONTENTGEM_VERSION,
				true
			);

			// Enqueue Vite-generated CSS from manifest (required for React components)
			$css_files = $data[ $entry ]['css'] ?? [];
			foreach ( $css_files as $i => $css_file ) {
				wp_enqueue_style(
					'contentgem-vite-' . $i,
					CONTENTGEM_URL . 'assets/js/dist/' . $css_file,
					[],
					CONTENTGEM_VERSION
				);
			}
		}

		wp_enqueue_style( 'contentgem-admin-upgrade', CONTENTGEM_URL . 'assets/css/admin-v23-upgrade.css', [ 'contentgem-admin' ], CONTENTGEM_VERSION );
		wp_add_inline_script( 'contentgem-dashboard', 'window.__CONTENTGEM_BIG_UPGRADE__ = true;', 'before' );
		wp_add_inline_script(
			'contentgem-dashboard',
			"(function(){if(window.__CGMKeywordOnlyBootstrap){return;}window.__CGMKeywordOnlyBootstrap=true;var key='cgm-gap-keyword-only';function enabled(){try{return localStorage.getItem(key)==='1';}catch(e){return false;}}function isGapsUrl(url){try{var u=new URL(String(url||''),window.location.origin);return /\/gaps$/.test(u.pathname);}catch(e){return false;}}function withFlag(url){try{var u=new URL(String(url||''),window.location.origin);u.searchParams.set('keyword_only','true');return u.toString();}catch(e){return url;}}var nativeFetch=window.fetch;if(typeof nativeFetch==='function'){window.fetch=function(input,init){try{var raw=typeof input==='string'?input:((input&&input.url)||'');var method=String((init&&init.method)||(input&&input.method)||'GET').toUpperCase();if(method==='GET'&&enabled()&&isGapsUrl(raw)){var next=withFlag(raw);input=typeof input==='string'?next:new Request(next,input);}}catch(e){}return nativeFetch.call(this,input,init);};}var nativeOpen=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(method,url){var next=url;try{if(String(method||'GET').toUpperCase()==='GET'&&enabled()&&isGapsUrl(url)){next=withFlag(url);}}catch(e){}return nativeOpen.apply(this,[method,next].concat(Array.prototype.slice.call(arguments,2)));};})();",
			'before'
		);
		$keyword_only_visible_toggle = <<<'CGMJS'
(function(){
	if(window.__CGMKeywordOnlyVisibleToggle){return;}
	window.__CGMKeywordOnlyVisibleToggle=true;
	var KEY='cgm-gap-keyword-only';
	var BAR='cgm-gap-keyword-only-inline-bar';
	function qs(s,r){return (r||document).querySelector(s);}
	function qsa(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));}
	function txt(v){return String(v||'').replace(/\s+/g,' ').trim();}
	function enabled(){try{return localStorage.getItem(KEY)==='1';}catch(e){return false;}}
	function setEnabled(v){try{localStorage.setItem(KEY,v?'1':'0');}catch(e){}}
	function restBase(){return String((window.contentgemData||{}).restUrl||'/wp-json/contentgem/v1/').replace(/\/$/,'');}
	function nonce(){return (window.contentgemData||{}).nonce||'';}
	function api(method,path,body){
		return fetch(restBase()+path,{
			method:method,
			headers:{'Content-Type':'application/json','X-WP-Nonce':nonce()},
			body:body?JSON.stringify(body):undefined,
			credentials:'same-origin'
		}).then(function(r){return r.json();});
	}
	function heading(){
		var root=qs('#contentgem-dashboard')||document;
		var nodes=qsa('h1,h2,h3,.cgm-page__title,[class*=title]',root);
		for(var i=0;i<nodes.length;i++){ if(txt(nodes[i].textContent)==='Content Gaps') return nodes[i]; }
		return null;
	}
	function filterRow(){
		var root=qs('#contentgem-dashboard')||document;
		var rows=qsa('div,section,article',root);
		for(var i=0;i<rows.length;i++){
			var t=txt(rows[i].textContent);
			if(t.indexOf('Filter:')!==-1 && t.indexOf('All clusters')!==-1 && t.indexOf('All intents')!==-1){ return rows[i]; }
		}
		return null;
	}
	function isContentGapsActive(){ return !!heading(); }
	function build(){
		var wrap=document.createElement('div');
		wrap.id=BAR;
		wrap.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:16px;margin:0 0 14px;padding:14px 16px;border:1px solid rgba(139,92,246,.32);border-radius:14px;background:linear-gradient(180deg, rgba(38,20,94,.95), rgba(17,10,58,.96));box-shadow:0 0 0 1px rgba(139,92,246,.06) inset;';
		wrap.innerHTML='<div style="display:flex;flex-direction:column;gap:4px;min-width:0;"><strong style="font-size:13px;line-height:1.2;color:#f5f3ff;">Keyword-only gaps</strong><span style="font-size:12px;line-height:1.45;color:#c4b5fd;">Show only content gaps with titles generated from your saved keywords.</span></div><label style="display:inline-flex;align-items:center;gap:10px;cursor:pointer;user-select:none;flex:0 0 auto;"><input type="checkbox" style="position:absolute;opacity:0;pointer-events:none;" /><span data-role="track" style="position:relative;display:inline-block;width:48px;height:28px;border-radius:999px;background:rgba(91,33,182,.38);border:1px solid rgba(139,92,246,.45);transition:all .2s ease;"></span><span data-role="state" style="font-size:12px;font-weight:700;color:#f5f3ff;min-width:24px;text-align:right;">Off</span></label>';
		var input=qs('input',wrap);
		var track=qs('[data-role=track]',wrap);
		var state=qs('[data-role=state]',wrap);
		var knob=document.createElement('span');
		knob.style.cssText='position:absolute;top:4px;left:4px;width:18px;height:18px;border-radius:999px;background:#f5f3ff;box-shadow:0 2px 8px rgba(0,0,0,.25);transition:all .2s ease;';
		track.appendChild(knob);
		function paint(v){
			input.checked=!!v;
			state.textContent=v?'On':'Off';
			track.style.background=v?'linear-gradient(135deg, #8b5cf6, #a855f7)':'rgba(91,33,182,.38)';
			track.style.borderColor=v?'rgba(196,181,253,.65)':'rgba(139,92,246,.45)';
			knob.style.left=v?'26px':'4px';
		}
		paint(enabled());
		input.addEventListener('change',function(){
			var v=!!input.checked;
			setEnabled(v);
			paint(v);
			api('POST','/gaps/keyword-only',{enabled:v}).catch(function(){}).finally(function(){ window.location.reload(); });
		});
		api('GET','/gaps/keyword-only').then(function(r){
			if(r&&r.success){ setEnabled(!!r.enabled); paint(!!r.enabled); }
		}).catch(function(){});
		return wrap;
	}
	function ensure(){
		if(!isContentGapsActive()) return;
		var anchor=filterRow()||heading();
		if(!anchor||!anchor.parentNode) return;
		var existing=qs('#'+BAR);
		if(!existing){
			existing=build();
			anchor.parentNode.insertBefore(existing,anchor);
		}else if(existing.nextSibling!==anchor){
			anchor.parentNode.insertBefore(existing,anchor);
		}
		existing.style.display='flex';
	}
	function cleanup(){
		var existing=qs('#'+BAR);
		if(existing && !isContentGapsActive()){ existing.remove(); }
	}
	function tick(){ try{ ensure(); cleanup(); }catch(e){} }
	document.addEventListener('DOMContentLoaded',tick);
	window.addEventListener('load',tick);
	document.addEventListener('click',function(){ setTimeout(tick,80); },true);
	new MutationObserver(function(){ tick(); }).observe(document.documentElement,{childList:true,subtree:true});
	setInterval(tick,800);
})();
CGMJS;
		wp_add_inline_script( 'contentgem-dashboard', $keyword_only_visible_toggle, 'before' );
		wp_enqueue_script(
			'contentgem-admin-upgrade',
			CONTENTGEM_URL . 'assets/js/admin-v23-upgrade.js',
			[ 'contentgem-dashboard', 'wp-hooks', 'heartbeat' ],
			CONTENTGEM_VERSION,
			true
		);
		// Prevent noisy third-party admin scripts from breaking the Contentgem SPA.
		wp_dequeue_script( 'svg-painter' );
		wp_deregister_script( 'svg-painter' );
		wp_enqueue_script( 'heartbeat' );

		wp_enqueue_script(
			'contentgem-admin-enhancements',
			CONTENTGEM_URL . 'assets/js/admin-enhancements.js',
			[ 'contentgem-admin-upgrade' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-v62-hardfix',
			CONTENTGEM_URL . 'assets/js/admin-v62-v6-hardfix.js',
			[ 'contentgem-admin-enhancements', 'contentgem-dashboard' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_style( 'contentgem-admin-v43-intelligence-ui', CONTENTGEM_URL . 'assets/css/admin-v43-intelligence-ui.css', [ 'contentgem-admin-upgrade' ], CONTENTGEM_VERSION );
		wp_enqueue_script(
			'contentgem-admin-v43-intelligence-ui',
			CONTENTGEM_URL . 'assets/js/admin-v43-intelligence-ui.js',
			[ 'contentgem-admin-enhancements' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_style( 'contentgem-admin-v44-differentiation-ui', CONTENTGEM_URL . 'assets/css/admin-v44-differentiation-ui.css', [ 'contentgem-admin-v43-intelligence-ui' ], CONTENTGEM_VERSION );
		wp_enqueue_script(
			'contentgem-admin-v44-differentiation-ui',
			CONTENTGEM_URL . 'assets/js/admin-v44-differentiation-ui.js',
			[ 'contentgem-admin-v43-intelligence-ui' ],
			CONTENTGEM_VERSION,
			true
		);

		// Data voor React
		$token_manager = new CGM_Token_Manager( get_current_user_id() );

		wp_enqueue_style( 'contentgem-admin-v46-linking-ui', CONTENTGEM_URL . 'assets/css/admin-v46-linking-ui.css', [ 'contentgem-admin-v44-differentiation-ui' ], CONTENTGEM_VERSION );
		wp_enqueue_script(
			'contentgem-admin-v46-linking-ui',
			CONTENTGEM_URL . 'assets/js/admin-v46-linking-ui.js',
			[ 'contentgem-admin-v44-differentiation-ui' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_style( 'contentgem-admin-v47-clean-fixes', CONTENTGEM_URL . 'assets/css/admin-v47-clean-fixes.css', [ 'contentgem-admin-v46-linking-ui' ], CONTENTGEM_VERSION );

		$clusters = json_decode( (string) get_option( 'contentgem_clusters', '[]' ), true );
		$clusters = is_array( $clusters ) ? array_values( array_filter( array_map( 'sanitize_text_field', $clusters ) ) ) : [];
		$bootstrap_settings = [
			'niche'                 => (string) get_option( 'contentgem_niche', '' ),
			'niche_description'     => (string) get_option( 'contentgem_niche_description', '' ),
			'content_language'      => (string) get_option( 'contentgem_content_language', 'en' ),
			'content_language_custom' => (string) get_option( 'contentgem_content_language_custom', '' ),
			'ai_provider'           => (string) get_option( 'contentgem_ai_provider', 'claude' ),
			'clusters'              => $clusters,
			'cluster_keywords'      => get_option( 'cgm_cluster_keywords', [] ),
			'competitor_domains'    => (array) get_option( 'contentgem_competitor_domains', [] ),
			'tone_of_voice'         => (string) get_option( 'contentgem_tone_of_voice', '' ),
			'onboarding_complete'   => (bool) ( get_option( 'contentgem_onboarding_complete', false ) && ! get_option( 'contentgem_force_onboarding', false ) ),
			'preferred_builder_mode' => (string) get_option( 'contentgem_builder_preference', 'none' ),
		];

		wp_localize_script( 'contentgem-dashboard', 'contentgemData', [
			'restUrl'    => rest_url( CONTENTGEM_REST_NS . '/' ),
			'siteUrl'    => get_site_url(),
			'adminUrl'   => admin_url(),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'version'    => CONTENTGEM_VERSION,
			'userId'     => get_current_user_id(),
			'tier'       => $token_manager->get_tier(),
			'isPremium'  => function_exists( 'cgm_is_premium' ) ? cgm_is_premium() : false,
			'hasPaidPlan'=> function_exists( 'cgm_user_has_paid_plan' ) ? cgm_user_has_paid_plan() : false,
			'plan'       => function_exists( 'cgm_get_current_plan' ) ? cgm_get_current_plan() : 'free',
			'planLabel'  => function_exists( 'cgm_get_plan_label' ) ? cgm_get_plan_label() : 'Free',
			'limits'     => function_exists( 'cgm_get_current_plan_limits' ) ? cgm_get_current_plan_limits() : [],
			'clusterLimit' => function_exists( 'cgm_get_limit' ) ? cgm_get_limit( 'clusters' ) : 4,
			'features'   => [
				'basicDashboard'            => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'basic_dashboard' ) : true,
				'basicClusters'             => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'basic_clusters' ) : true,
				'basicSettings'             => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'basic_settings' ) : true,
				'aiAssistant'               => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'ai_assistant' ) : false,
				'contentGaps'               => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'content_gaps' ) : false,
				'competitorAnalysis'        => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'competitor_analysis' ) : false,
				'internalLinkingAutomation' => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'internal_linking_automation' ) : false,
				'gscIntegration'            => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'gsc_integration' ) : false,
				'optimizer'                 => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'optimizer' ) : false,
				'semanticDifferentiation'   => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'semantic_differentiation' ) : false,
				'savedReports'              => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'saved_reports' ) : false,
				'authorityDashboard'        => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'authority_dashboard' ) : false,
				'bulkAnalysis'              => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'bulk_analysis' ) : false,
				'indexationMonitor'         => function_exists( 'cgm_current_plan_has_feature' ) ? cgm_current_plan_has_feature( 'indexation_monitor' ) : false,
			],
			'freeGenerationsLeft'  => 9999,
			'freeGenerationsLimit' => -1,
			'hasAccess'  => function_exists( 'cgm_user_has_access' ) ? cgm_user_has_access() : false,
			'upgradeUrl' => function_exists( 'cgm_get_upgrade_url' ) ? cgm_get_upgrade_url() : admin_url( 'admin.php?page=contentgem' ),
			'accountUrl' => function_exists( 'cgm_get_account_url' ) ? cgm_get_account_url() : admin_url( 'admin.php?page=contentgem' ),
			'bootstrapSettings' => $bootstrap_settings,
			'preferredBuilderMode' => (string) get_option( 'contentgem_builder_preference', 'none' ),
			'i18n'       => [
				// Navigation
				'dashboard'                    => __( 'Dashboard', 'contentgem' ),
				'contentGaps'                  => __( 'Content Gaps', 'contentgem' ),
				'optimizer'                    => __( 'Optimizer', 'contentgem' ),
				'settings'                     => __( 'Settings', 'contentgem' ),
				'drafts'                       => __( 'Drafts', 'contentgem' ),

				// Actions
				'analyseSite'                  => __( 'Analyse site', 'contentgem' ),
				'analyseRunning'               => __( 'Analysing...', 'contentgem' ),
				'analyseComplete'              => __( 'Analysis complete', 'contentgem' ),
				'analyseFailed'                => __( 'Analysis failed', 'contentgem' ),
				'generateDraft'                => __( 'Generate draft', 'contentgem' ),
				'generating'                   => __( 'Generating...', 'contentgem' ),
				'suggestion'                   => __( 'Suggestion', 'contentgem' ),
				'save'                         => __( 'Save', 'contentgem' ),
				'saving'                       => __( 'Saving...', 'contentgem' ),
				'saved'                        => __( 'Saved!', 'contentgem' ),
				'delete'                       => __( 'Delete', 'contentgem' ),
				'deleting'                     => __( 'Deleting...', 'contentgem' ),
				'ignore'                       => __( 'Ignore', 'contentgem' ),
				'loading'                      => __( 'Loading...', 'contentgem' ),
				'upgrade'                      => __( 'Upgrade', 'contentgem' ),
				'busy'                         => __( 'Processing...', 'contentgem' ),
				'close'                        => __( 'Close', 'contentgem' ),
				'view'                         => __( 'View', 'contentgem' ),
				'previous'                     => __( 'Previous', 'contentgem' ),
				'next'                         => __( 'Next', 'contentgem' ),
				'selectAll'                    => __( 'Select all', 'contentgem' ),
				'goToSettings'                 => __( 'Go to Settings', 'contentgem' ),
				'viewPlans'                    => __( 'View plans', 'contentgem' ),
				'copy'                         => __( 'Copy', 'contentgem' ),
				'copied'                       => __( 'Copied!', 'contentgem' ),

				// Status labels
				'noGapsFound'                  => __( 'No gaps found', 'contentgem' ),
				'noOpenGaps'                   => __( 'No open gaps found.', 'contentgem' ),
				'noTokens'                     => __( 'No tokens available', 'contentgem' ),
				'upgradeRequired'              => __( 'Upgrade required', 'contentgem' ),
				'apiKeyRequired'               => __( 'API key required', 'contentgem' ),
				'notConnected'                 => __( 'Not connected', 'contentgem' ),
				'connected'                    => __( 'Connected', 'contentgem' ),
				'updated'                      => __( 'Updated', 'contentgem' ),
				'notAnalysed'                  => __( 'Not yet analysed', 'contentgem' ),
				'critical'                     => __( 'Critical', 'contentgem' ),

				// Dashboard notifications
				'analyseRunningMsg'            => __( 'Site is being analysed — posts are scanned for topics and clusters...', 'contentgem' ),
				'analyseCompleteMsg'           => __( 'Analysis complete — clusters and gaps have been updated.', 'contentgem' ),
				'analyseFailedMsg'             => __( 'Analysis failed. Check that the site has posts and try again.', 'contentgem' ),
				'noApiKeyMsg'                  => __( 'No API key set. Add your Anthropic API key in Settings to generate drafts.', 'contentgem' ),
				'runAnalysisFirst'             => __( 'Run a site analysis via the Dashboard first.', 'contentgem' ),

				// Dashboard labels
				'siteOverview'                 => __( 'Site overview', 'contentgem' ),
				'topicalCoverage'              => __( 'Topical Coverage', 'contentgem' ),
				'internalLinkNetwork'          => __( 'Internal link network', 'contentgem' ),
				'topicClusters'                => __( 'Topic clusters', 'contentgem' ),
				'openGaps'                     => __( 'Open gaps', 'contentgem' ),
				'avgCoverage'                  => __( 'Average coverage', 'contentgem' ),
				'openGapsFound'                => __( 'open gaps found', 'contentgem' ),
				'topKeywords'                  => __( 'Top keywords (GSC)', 'contentgem' ),
				'viewGscData'                  => __( 'View all GSC data', 'contentgem' ),

				// Token budget
				'tokenBudget'                  => __( 'AI credits this month', 'contentgem' ),
				'draftsRemaining'              => __( 'drafts remaining', 'contentgem' ),
				'reset'                        => __( 'Reset', 'contentgem' ),
				'used'                         => __( 'used', 'contentgem' ),
				'freePlanMsg'                  => __( 'Free plan: analyses included. Upgrade for unlimited draft generation.', 'contentgem' ),
				'budgetAlmostMsg'              => __( 'Token budget almost depleted.', 'contentgem' ),

				// Gap card
				'intentInformational'          => __( 'Informational', 'contentgem' ),
				'intentCommercial'             => __( 'Commercial', 'contentgem' ),
				'intentNavigational'           => __( 'Navigational', 'contentgem' ),
				'addApiKeyFirst'               => __( 'Add your API key first in', 'contentgem' ),
				'viewDraftInWp'                => __( 'View draft in WordPress', 'contentgem' ),
				'draftRequiresPlan'            => __( 'Draft generation requires a paid subscription.', 'contentgem' ),
				'cluster'                      => __( 'Cluster', 'contentgem' ),
				'coverage'                     => __( 'Coverage', 'contentgem' ),
				'posts'                        => __( 'Posts', 'contentgem' ),
				'pillar'                       => __( 'Pillar', 'contentgem' ),

				// Gaps page
				'selectFirstGaps'              => __( 'Select gaps first', 'contentgem' ),
				'gapSelected'                  => __( 'gap selected', 'contentgem' ),
				'gapsSelected'                 => __( 'gaps selected', 'contentgem' ),
				'viewInDrafts'                 => __( 'View in Drafts page', 'contentgem' ),

				// Drafts page
				'draftsGenerated'              => __( 'drafts generated', 'contentgem' ),
				'confirmDeleteDraft'           => __( 'Are you sure you want to delete this draft?', 'contentgem' ),
				'noDraftsFound'                => __( 'No drafts found.', 'contentgem' ),
				'generateDraftsViaGaps'        => __( 'Generate drafts via the Content Gaps page.', 'contentgem' ),
				'unknownCluster'               => __( 'Unknown cluster', 'contentgem' ),
				'words'                        => __( 'words', 'contentgem' ),
				'quality'                      => __( 'Quality', 'contentgem' ),
				'statusDraft'                  => __( 'Draft', 'contentgem' ),
				'statusPublish'                => __( 'Published', 'contentgem' ),
				'statusTrash'                  => __( 'Trash', 'contentgem' ),
				'statusPrivate'                => __( 'Private', 'contentgem' ),
				'publish'                      => __( 'Publish', 'contentgem' ),
				'published'                    => __( 'Published', 'contentgem' ),
				'viewArticle'                  => __( 'View article', 'contentgem' ),
				'articlePublished'             => __( 'Article published!', 'contentgem' ),
			'removeFromDashboard'          => __( 'Remove from dashboard', 'contentgem' ),
			'publishAllDrafts'             => __( 'Publish all drafts', 'contentgem' ),
			'publishingProgress'           => __( 'Publishing %d of %d...', 'contentgem' ),
			'allDraftsPublished'           => __( '%d drafts published successfully', 'contentgem' ),
			'confirmPublishAll'            => __( 'Publish all %d drafts? This cannot be undone.', 'contentgem' ),

				// Optimizer
				'contentOptimizer'             => __( 'Content Optimizer', 'contentgem' ),
				'categoriesTagsManagement'     => __( 'Categories & Tags management', 'contentgem' ),
				'autoCategorization'           => __( 'Auto-categorization', 'contentgem' ),
				'categorizePosts'              => __( 'Categorize uncategorized posts', 'contentgem' ),
				'keywordCannibalization'       => __( 'Keyword cannibalization', 'contentgem' ),
				'postsAnalyzed'                => __( '%d posts analyzed', 'contentgem' ),
				'noCannibalizationFound'       => __( 'No cannibalization found', 'contentgem' ),
				'highRisk'                     => __( 'High risk', 'contentgem' ),
				'mediumRisk'                   => __( 'Medium risk', 'contentgem' ),
				'lowRisk'                      => __( 'Low risk', 'contentgem' ),
				'noRisk'                       => __( 'No risk', 'contentgem' ),
				'deleteWeakest'                => __( 'Delete weakest', 'contentgem' ),
				'renameCategory'               => __( 'Rename category', 'contentgem' ),
				'renameTag'                    => __( 'Rename tag', 'contentgem' ),
				'categorized'                  => __( '%d posts categorized', 'contentgem' ),
				'categoryLabel'                => __( 'CATEGORY', 'contentgem' ),
				'tagLabel'                     => __( 'TAG', 'contentgem' ),
				'clustersFirstMsg'             => __( 'First save clusters in Settings to create categories and tags.', 'contentgem' ),
				'autoCategorizeDesc'           => __( 'Automatically assign uncategorized posts to the right clusters, categories and tags.', 'contentgem' ),
				'noRiskExplain'                => __( 'Low overlap — no action required.', 'contentgem' ),
				'lowRiskExplain'               => __( 'Light keyword overlap — keep an eye on this.', 'contentgem' ),
				'mediumRiskExplain'            => __( 'Moderate overlap — consider merging content.', 'contentgem' ),
				'highRiskExplain'              => __( 'High overlap — both articles compete for the same keyword.', 'contentgem' ),
				'criticalExplain'              => __( 'Critical cannibalization — immediate action required.', 'contentgem' ),
				'errorLoadingTerms'            => __( 'Could not load cluster terms.', 'contentgem' ),
				'errorLoadingCannibalization'  => __( 'Could not load cannibalization data.', 'contentgem' ),
				'errorMergeFailed'             => __( 'Merge failed.', 'contentgem' ),
				'errorIgnoreFailed'            => __( 'Ignore failed.', 'contentgem' ),
				'confirmDeleteCategory'        => __( 'Delete category "%s"?', 'contentgem' ),
				'confirmDeleteTag'             => __( 'Delete tag "%s"?', 'contentgem' ),
				'errorAutoCategorizeFailed'    => __( 'Auto-categorization failed.', 'contentgem' ),

				// Internal link scanner
				'useSuggestedLink'             => __( 'Use suggested link', 'contentgem' ),
				'linkReplaced'                 => __( 'Link replaced with', 'contentgem' ),
				'internalLinkScanner'          => __( 'Internal link scanner', 'contentgem' ),
				'scanInternalLinks'            => __( 'Scan internal links', 'contentgem' ),
				'brokenLinksFound'             => __( '%d broken links found', 'contentgem' ),
				'nobrokenLinks'                => __( 'No broken internal links found', 'contentgem' ),
				'fixLink'                      => __( 'Fix link', 'contentgem' ),
				'suggestion'                   => __( 'Suggestion', 'contentgem' ),
				'noSuggestionFound'            => __( 'No relevant page found', 'contentgem' ),
				'scanning'                     => __( 'Scanning...', 'contentgem' ),
				'linkFixed'                    => __( 'Link fixed', 'contentgem' ),
				'removeLink'                   => __( 'Remove link', 'contentgem' ),
				'replaceLink'                  => __( 'Replace link', 'contentgem' ),
				'editPost'                     => __( 'Edit post', 'contentgem' ),
				'brokenUrl'                    => __( 'Broken URL', 'contentgem' ),
				'anchorText'                   => __( 'Anchor text', 'contentgem' ),
				'promptRenameCategory'         => __( 'New name for category:', 'contentgem' ),
				'promptRenameTag'              => __( 'New name for tag:', 'contentgem' ),
				'expandSection'                => __( 'Show', 'contentgem' ),
				'collapseSection'              => __( 'Hide', 'contentgem' ),

				// Settings
				'settingsTitle'                => __( 'Settings', 'contentgem' ),
				'siteNiche'                    => __( 'Site niche & main topic', 'contentgem' ),
				'mainTopic'                    => __( 'Main topic', 'contentgem' ),
				'nicheDescription'             => __( 'Niche description', 'contentgem' ),
				'defineContentClusters'        => __( 'Define your content clusters', 'contentgem' ),
				'generateWithAI'               => __( 'Generate clusters with AI', 'contentgem' ),
				'addCluster'                   => __( '+ Add cluster', 'contentgem' ),
				'anthropicApiKey'              => __( 'Anthropic API Key', 'contentgem' ),
				'apiKeySet'                    => __( 'API key is set', 'contentgem' ),
				'googleSearchConsole'          => __( 'Google Search Console', 'contentgem' ),
				'connectGSC'                   => __( 'Connect Google Search Console', 'contentgem' ),
				'disconnectGSC'                => __( 'Disconnect', 'contentgem' ),
				'subscription'                 => __( 'Subscription', 'contentgem' ),
				'currentPlan'                  => __( 'Current plan', 'contentgem' ),
				'managePlan'                   => __( 'Manage subscription', 'contentgem' ),
				'saveAndConnect'               => __( 'Save and connect', 'contentgem' ),
				'characters'                   => __( 'characters', 'contentgem' ),
				'moreDetailBetterAI'           => __( 'more detail = better AI suggestions', 'contentgem' ),
				'nicheDesc'                    => __( 'Set the main topic and niche of your website. Contentgem uses this to focus gap analyses on relevant clusters.', 'contentgem' ),
				'nichePlaceholder'             => __( 'e.g. running, nutrition, SEO', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'nicheDescriptionPlaceholder'  => __( "Describe your website in detail. Answer these questions:\n\n- Who do you write for? (e.g. recreational runners aged 25–45)\n- What is the goal of your website?\n- What level does your audience have?\n- What makes your website unique?\n- What topics do you NOT want to cover?", 'contentgem' ),
				'clustersDesc'                 => __( "Manually define your website's content clusters. Contentgem uses these as the basis for analysis and gap detection.", 'contentgem' ),
				'clustersSaved'                => __( 'Clusters saved. Run a new analysis to update gaps.', 'contentgem' ),
				'apiKeyDesc'                   => __( 'Enter your Anthropic API key. It is stored encrypted and never shown in the frontend.', 'contentgem' ),
				'apiKeyPlaceholder'            => __( 'Enter your API key', 'contentgem' ),
				'gscDesc'                      => __( 'Connect GSC for real search data in gap detection and prioritization.', 'contentgem' ),
				'gscProperty'                  => __( 'Connected property', 'contentgem' ),
				'gscSelectProperty'            => __( 'Select a property...', 'contentgem' ),
				'gscActiveProperty'            => __( 'Active property:', 'contentgem' ),
				'gscRedirectUri'               => __( 'Your redirect URI', 'contentgem' ),
				'gscRedirectUriHint'           => __( '(copy this to Google Cloud Console)', 'contentgem' ),
				'gscCredentialsSet'            => __( 'Credentials are already set. Fill in again to update.', 'contentgem' ),
				'subscriptionDesc'             => __( 'Manage your Contentgem subscription and token limits.', 'contentgem' ),
				'tierFreeLimits'               => __( 'Token limit: 50,000 tokens/month — analyses included, no draft generation.', 'contentgem' ),
				'tierStarterLimits'            => __( 'Token limit: 200,000 tokens/month.', 'contentgem' ),
				'tierGrowthLimits'             => __( 'Token limit: 600,000 tokens/month.', 'contentgem' ),
				'tierAgencyLimits'             => __( 'Token limit: 1,500,000 tokens/month.', 'contentgem' ),
				'hideInstructions'             => __( 'Hide instructions', 'contentgem' ),
				'gscSetupGuide'                => __( 'How to set up Google Search Console (one-time, ~5 minutes)', 'contentgem' ),
				'gscStep1Title'                => __( 'Create a project', 'contentgem' ),
				'gscStep2Title'                => __( 'Enable the Search Console API', 'contentgem' ),
				'gscStep3Title'                => __( 'Configure OAuth consent screen', 'contentgem' ),
				'gscStep4Title'                => __( 'Create credentials', 'contentgem' ),
				'gscStep5Title'                => __( 'Fill in and connect', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'gscStep1Body'                 => __( 'Go to <a href="https://console.cloud.google.com" target="_blank" rel="noreferrer" style="color:#8B5CF6">console.cloud.google.com</a> and sign in with your Google account.<br>Click the project menu at the top and choose <strong>New project</strong>.<br>Give the project a name (e.g. <em>My Website GSC</em>) and click <strong>Create</strong>.', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'gscStep2Body'                 => __( 'Go to <strong>APIs &amp; Services &gt; Library</strong>.<br>Search for <strong>Google Search Console API</strong> and click it.<br>Click the blue <strong>Enable</strong> button.', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'gscStep3Body'                 => __( 'Go to <strong>APIs &amp; Services &gt; OAuth consent screen</strong>.<br>Choose <strong>External</strong> and click <strong>Create</strong>.<br>Enter your app name (e.g. <em>Contentgem</em>), add your email under contact info.<br>Click through to <strong>Save and continue</strong> on all steps.<br>Go to <strong>Test users</strong> and add your own Google email address.', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'gscStep4Body'                 => __( 'Go to <strong>APIs &amp; Services &gt; Credentials</strong>.<br>Click <strong>+ Create credentials &gt; OAuth client ID</strong>.<br>Choose <strong>Web application</strong> as the type.<br>Under <em>Authorised redirect URIs</em>, add the redirect URI you copied above.<br>Click <strong>Create</strong>. Copy the <strong>Client ID</strong> and <strong>Client secret</strong>.', 'contentgem' ),
				// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappingTags
				'gscStep5Body'                 => __( 'Paste the Client ID and Client secret in the fields below and click <strong>Save and connect</strong>.', 'contentgem' ),

				// AI Assistant
				'assistant'                    => __( 'AI Assistant', 'contentgem' ),
				'metaDescription'              => __( 'Meta description', 'contentgem' ),
				'titleOptimization'            => __( 'Title optimization', 'contentgem' ),
				'excerptGenerator'             => __( 'Excerpt generator', 'contentgem' ),
				'generateMetaDesc'             => __( 'Generate meta description', 'contentgem' ),
				'optimizeTitle'                => __( 'Optimize title', 'contentgem' ),
				'generateExcerpt'              => __( 'Generate excerpt', 'contentgem' ),
				'saveToYoast'                  => __( 'Save to Yoast/RankMath', 'contentgem' ),
				'selectPost'                   => __( 'Select a post...', 'contentgem' ),
				'generateAlternatives'         => __( 'Generate alternatives', 'contentgem' ),
				'focusKeyword'                 => __( 'Focus keyword', 'contentgem' ),
				'additionalContext'            => __( 'Additional context', 'contentgem' ),
				'selectGap'                    => __( 'Select a content gap...', 'contentgem' ),
				'orEnterTopic'                 => __( 'Or enter your own topic', 'contentgem' ),
				'tokensRemaining'              => __( 'tokens remaining', 'contentgem' ),
				'draftCreated'                 => __( 'Draft created!', 'contentgem' ),
				'existingTitle'                => __( 'Existing title...', 'contentgem' ),

				// ── TokenBudget ──────────────────────────────────────────────
				'aiCreditsThisMonth'           => __( 'AI credits this month', 'contentgem' ),
				'tierFree'                     => __( 'Free', 'contentgem' ),
				'tierStarter'                  => __( 'Pro Starter', 'contentgem' ),
				'tierAgency'                   => __( 'Pro Agency', 'contentgem' ),
				'used'                         => __( 'used', 'contentgem' ),
				'draftsRemaining'              => __( 'drafts remaining', 'contentgem' ),
				'reset'                        => __( 'Reset', 'contentgem' ),
				'freePlanUpsell'               => __( 'Free plan: analyses included. Upgrade for unlimited draft generation.', 'contentgem' ),
				'tokenBudgetAlmostFull'        => __( 'Token budget almost full. Resets on %s.', 'contentgem' ),

				// ── Dashboard ────────────────────────────────────────────────
				'noApiKeyDashboard'            => __( 'No API key set. Add your Anthropic API key in Settings to generate drafts.', 'contentgem' ),
				'analyseRunningDetail'         => __( 'Analysing site — scanning posts for topics and clusters...', 'contentgem' ),
				'siteOverview'                 => __( 'Site overview', 'contentgem' ),
				'updated'                      => __( 'Updated', 'contentgem' ),
				'notYetAnalysed'               => __( 'Not yet analysed', 'contentgem' ),
				'topicClusters'                => __( 'Topic clusters', 'contentgem' ),
				'openGaps'                     => __( 'Open gaps', 'contentgem' ),
				'averageCoverage'              => __( 'Average coverage', 'contentgem' ),
				'topKeywordsGsc'               => __( 'Top keywords (GSC)', 'contentgem' ),
				'viewAllGscData'               => __( 'View all GSC data', 'contentgem' ),
				'keyword'                      => __( 'Keyword', 'contentgem' ),
				'impressions'                  => __( 'Impressions', 'contentgem' ),
				'clicks'                       => __( 'Clicks', 'contentgem' ),
				'ctr'                          => __( 'CTR', 'contentgem' ),

				// ── GapCard ──────────────────────────────────────────────────
				'cluster'                      => __( 'Cluster', 'contentgem' ),
				'tags'                         => __( 'Tags', 'contentgem' ),
				'addApiKeyFirst'               => __( 'Add your API key first in', 'contentgem' ),
				'suggestionFailed'             => __( 'Could not load suggestion.', 'contentgem' ),
				'draftFailed'                  => __( 'Draft generation failed.', 'contentgem' ),
				'connectionLost'               => __( 'Connection lost during generation.', 'contentgem' ),
				'viewDraftInWordPress'         => __( 'View draft in WordPress', 'contentgem' ),
				'draftRequiresPaidPlan'        => __( 'Draft generation requires a paid plan.', 'contentgem' ),
				'noTokensAvailable'            => __( 'No tokens available', 'contentgem' ),
				'intent_informational'         => __( 'Informational', 'contentgem' ),
				'intent_commercial'            => __( 'Commercial', 'contentgem' ),
				'intent_navigational'          => __( 'Navigational', 'contentgem' ),

				// ── Drafts ───────────────────────────────────────────────────
				'confirmDelete'                => __( 'Are you sure you want to delete this draft?', 'contentgem' ),
				'deleteFailed'                 => __( 'Delete failed for "%s".', 'contentgem' ),
				'publishFailed'                => __( 'Publish failed for "%s".', 'contentgem' ),
				'removeFromDashboardFailed'    => __( 'Remove from dashboard failed.', 'contentgem' ),
				'confirmPublishAll'            => __( 'Publish all %d drafts? This cannot be undone.', 'contentgem' ),
				'draftsPublished'              => __( '%d drafts published.', 'contentgem' ),
				'noDraftsFound'                => __( 'No drafts found.', 'contentgem' ),
				'generateDraftsViaGaps'        => __( 'Generate drafts via the Content Gaps page.', 'contentgem' ),
				'draftsGenerated'              => __( '%d drafts generated', 'contentgem' ),
				'publishAllDrafts'             => __( 'Publish all %d drafts', 'contentgem' ),
				'publish'                      => __( 'Publish', 'contentgem' ),
				'removeFromDashboard'          => __( 'Remove from dashboard', 'contentgem' ),
				'viewArticle'                  => __( 'View article', 'contentgem' ),
				'words'                        => __( 'words', 'contentgem' ),
				'status_draft'                 => __( 'Draft', 'contentgem' ),
				'status_publish'               => __( 'Published', 'contentgem' ),
				'status_trash'                 => __( 'Trash', 'contentgem' ),
				'status_private'               => __( 'Private', 'contentgem' ),

				// ── Gaps ─────────────────────────────────────────────────────
				'openGapsFound'                => __( '%d open gaps found', 'contentgem' ),
				'noOpenGaps'                   => __( 'No open gaps found.', 'contentgem' ),
				'runAnalysisFirst'             => __( 'Run a site analysis first via the Dashboard.', 'contentgem' ),
				'gapsSelected'                 => __( '%d gap(s) selected', 'contentgem' ),
				'selectGapsFirst'              => __( 'Select gaps first', 'contentgem' ),
				'generateDraftsCount'          => __( 'Generate %s drafts', 'contentgem' ),
				'unknownError'                 => __( 'Unknown error', 'contentgem' ),
				'pageOf'                       => __( 'Page %d of %d', 'contentgem' ),
				'generatingDraftsProgress'     => __( 'Generating drafts... (%d/%d)', 'contentgem' ),
				'draftsCreated'                => __( '%d of %d drafts created', 'contentgem' ),
				'viewInDrafts'                 => __( 'View in Drafts', 'contentgem' ),

				// ── Onboarding ───────────────────────────────────────────────
				'onboardingStep1Title'         => __( 'Step 1 of 3: Setup', 'contentgem' ),
				'onboardingStep1Sub'           => __( 'Choose your AI provider, enter your API key, and tell Contentgem about your website.', 'contentgem' ),
				'onboardingStep2Title'         => __( 'Step 2 of 3: Content clusters', 'contentgem' ),
				'onboardingStep2Sub'           => __( 'Clusters determine how Contentgem organises your content.', 'contentgem' ),
				'contentLanguage'              => __( 'Content language', 'contentgem' ),
				'contentLanguageAuto'          => __( 'Auto detect', 'contentgem' ),
				'contentLanguageDutch'         => __( 'Dutch', 'contentgem' ),
				'contentLanguageEnglish'       => __( 'English', 'contentgem' ),
				'contentLanguageGerman'        => __( 'German', 'contentgem' ),
				'contentLanguageFrench'        => __( 'French', 'contentgem' ),
				'contentLanguageSpanish'       => __( 'Spanish', 'contentgem' ),
				'contentLanguageItalian'       => __( 'Italian', 'contentgem' ),
				'contentLanguagePortuguese'    => __( 'Portuguese', 'contentgem' ),
				'contentLanguageHelp'          => __( 'Choose the language Contentgem should use for clusters, gaps and drafts.', 'contentgem' ),
				'onboardingStep3Title'         => __( 'Step 3 of 3: Analyse your website', 'contentgem' ),
				'onboardingStep3Sub'           => __( 'Review your settings and start the analysis.', 'contentgem' ),
				'openaiApiKey'                 => __( 'OpenAI API Key', 'contentgem' ),
				'apiKeyDescClaude'             => __( 'Required for generating content suggestions and articles. Cost: ~$5–15/month.', 'contentgem' ),
				'apiKeyDescOpenAI'             => __( 'Required for generating content suggestions and articles. Cost: ~$5–20/month.', 'contentgem' ),
				'apiKeyFilled'                 => __( 'API key entered', 'contentgem' ),
				'howToGetApiKey'               => __( 'How do I get an API key?', 'contentgem' ),
				'apiKeyStep1Claude'            => __( 'Go to', 'contentgem' ),
				'apiKeyStep1OpenAI'            => __( 'Go to', 'contentgem' ),
				'apiKeyStep2'                  => __( 'Create a free account or log in', 'contentgem' ),
				'apiKeyStep3Claude'            => __( 'Go to \'API Keys\' and click \'Create Key\'', 'contentgem' ),
				'apiKeyStep3OpenAI'            => __( 'Go to \'API Keys\' and click \'+ Create new secret key\'', 'contentgem' ),
				'apiKeyStep4Claude'            => __( 'Copy the key (starts with', 'contentgem' ),
				'apiKeyStep4OpenAI'            => __( 'Copy the key (starts with', 'contentgem' ),
				'apiKeyStep5'                  => __( 'Paste the key above', 'contentgem' ),
				'costs'                        => __( 'Costs', 'contentgem' ),
				'costsClaude'                  => __( 'approx. $5–15 per month for an average website.', 'contentgem' ),
				'costsOpenAI'                  => __( 'approx. $5–20 per month for an average website.', 'contentgem' ),
				'mainTopic'                    => __( 'Main topic', 'contentgem' ),
				'websiteDescription'           => __( 'Website description', 'contentgem' ),
				'apiKeyTip'                    => __( 'Tip: add your API key to use AI-generated clusters and drafts. You can also do this later in Settings.', 'contentgem' ),
				'aiThinking'                   => __( 'AI is thinking...', 'contentgem' ),
				'generateClustersWithAI'       => __( 'Generate clusters with AI', 'contentgem' ),
				'clusterSelectHint'            => __( 'Click to select, double-click to rename (%d selected):', 'contentgem' ),
				'clustersEditLater'            => __( 'You can edit clusters later in Settings.', 'contentgem' ),
				'newClusterPlaceholder'        => __( 'Add new cluster...', 'contentgem' ),
				'clusterGenerationFailed'      => __( 'Could not generate clusters. Check your API key and try again.', 'contentgem' ),
				'back'                         => __( 'Back', 'contentgem' ),
				'apiKey'                       => __( 'API key', 'contentgem' ),
				'set'                          => __( 'Set', 'contentgem' ),
				'notSet'                       => __( 'Not set', 'contentgem' ),
				'clusters'                     => __( 'Clusters', 'contentgem' ),
				'noApiKeyWarning'              => __( 'No API key set. The analysis will run, but you cannot generate content. Add your key later in Settings.', 'contentgem' ),
				'startSetup'                   => __( 'Start setup', 'contentgem' ),
				'setupComplete'                => __( 'Setup complete!', 'contentgem' ),
				'setupCompleteDesc'            => __( 'Your website has been analysed. Find your content gaps and clusters in the dashboard.', 'contentgem' ),
				'goToDashboard'                => __( 'Go to Dashboard', 'contentgem' ),
				'savingApiKey'                 => __( 'Saving API key...', 'contentgem' ),
				'savingNiche'                  => __( 'Saving niche...', 'contentgem' ),
				'creatingClusters'             => __( 'Creating clusters...', 'contentgem' ),
				'analysingWebsite'             => __( 'Analysing website...', 'contentgem' ),
				'finishing'                    => __( 'Finishing...', 'contentgem' ),
				'done'                         => __( 'Done!', 'contentgem' ),
				'setupFailed'                  => __( 'Setup failed. Check your API key and try again.', 'contentgem' ),
			],
		] );

		wp_enqueue_style( 'contentgem-admin-v47.1-diff-fixes', CONTENTGEM_URL . 'assets/css/admin-v47.1-diff-fixes.css', [ 'contentgem-admin-v47-clean-fixes' ], CONTENTGEM_VERSION );

		wp_enqueue_style( 'contentgem-admin-v48-authority-priority-ui', CONTENTGEM_URL . 'assets/css/admin-v48-authority-priority-ui.css', [ 'contentgem-admin-v47.1-diff-fixes' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-admin-v49.8.1-reports-integration', CONTENTGEM_URL . 'assets/css/admin-v49.8.1-reports-integration.css', [ 'contentgem-admin-v48-authority-priority-ui' ], CONTENTGEM_VERSION );

		// Design system foundation (v5.0.8.0)
		wp_enqueue_style( 'contentgem-ds-tokens', CONTENTGEM_URL . 'assets/css/cgm-tokens.css', [ 'contentgem-admin-v49.8.1-reports-integration' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-foundations', CONTENTGEM_URL . 'assets/css/cgm-foundations.css', [ 'contentgem-ds-tokens' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-layout', CONTENTGEM_URL . 'assets/css/cgm-layout.css', [ 'contentgem-ds-foundations' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-components', CONTENTGEM_URL . 'assets/css/cgm-components.css', [ 'contentgem-ds-layout' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-states', CONTENTGEM_URL . 'assets/css/cgm-states.css', [ 'contentgem-ds-components' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-utilities', CONTENTGEM_URL . 'assets/css/cgm-utilities.css', [ 'contentgem-ds-states' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-dashboard', CONTENTGEM_URL . 'assets/css/cgm-page-dashboard.css', [ 'contentgem-ds-utilities' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-content-gaps', CONTENTGEM_URL . 'assets/css/cgm-page-content-gaps.css', [ 'contentgem-ds-page-dashboard' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-optimizer', CONTENTGEM_URL . 'assets/css/cgm-page-optimizer.css', [ 'contentgem-ds-page-content-gaps' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-ai-assistant', CONTENTGEM_URL . 'assets/css/cgm-page-ai-assistant.css', [ 'contentgem-ds-page-optimizer' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-competitor', CONTENTGEM_URL . 'assets/css/cgm-page-competitor.css', [ 'contentgem-ds-page-ai-assistant' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-drafts', CONTENTGEM_URL . 'assets/css/cgm-page-drafts.css', [ 'contentgem-ds-page-competitor' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-page-settings', CONTENTGEM_URL . 'assets/css/cgm-page-settings.css', [ 'contentgem-ds-page-drafts' ], CONTENTGEM_VERSION );
		wp_enqueue_style( 'contentgem-ds-legacy-cleanup', CONTENTGEM_URL . 'assets/css/cgm-legacy-cleanup.css', [ 'contentgem-ds-page-settings' ], CONTENTGEM_VERSION );

		wp_enqueue_style( 'contentgem-builder-ui', CONTENTGEM_URL . 'assets/css/cgm-builder-ui.css', [ 'contentgem-ds-page-settings', 'contentgem-ds-page-ai-assistant' ], CONTENTGEM_VERSION );
		wp_enqueue_script(
			'contentgem-admin-v48-authority-priority-ui',
			CONTENTGEM_URL . 'assets/js/admin-v48-authority-priority-ui.js',
			[ 'contentgem-admin-v47.1-diff-fixes' ],
			CONTENTGEM_VERSION,
			true
		);

		// v4.7 — Strict keyword match toggle on Content Gaps page.
		wp_enqueue_script(
			'contentgem-admin-v47.2-strict-keyword',
			CONTENTGEM_URL . 'assets/js/admin-v47.2-strict-keyword.js',
			[ 'contentgem-admin-v48-authority-priority-ui' ],
			CONTENTGEM_VERSION,
			true
		);

		// v5.1 — DOM dark-mode patcher + keyword toggle (merged).
		wp_enqueue_script(
			'contentgem-dark-patcher',
			CONTENTGEM_URL . 'assets/js/cgm-dark-patcher.js',
			[ 'contentgem-admin-v47.2-strict-keyword' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-gap-keyword-toggle',
			CONTENTGEM_URL . 'assets/js/admin-v50-gap-keyword-toggle.js',
			[ 'contentgem-dark-patcher' ],
			CONTENTGEM_VERSION,
			true
		);


		wp_enqueue_script(
			'contentgem-gap-keyword-only-ui',
			CONTENTGEM_URL . 'assets/js/admin-v51-gap-keyword-only-ui.js',
			[ 'contentgem-dark-patcher' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-gap-keyword-only-force-ui',
			CONTENTGEM_URL . 'assets/js/admin-v52-gap-keyword-only-force-ui.js',
			[ 'contentgem-gap-keyword-only-ui' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-gap-keyword-toggle-visible-v53',
			CONTENTGEM_URL . 'assets/js/admin-v53-gap-keyword-toggle-visible.js',
			[ 'contentgem-gap-keyword-only-force-ui' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-gap-keyword-toggle-hardmount-v54',
			CONTENTGEM_URL . 'assets/js/admin-v54-gap-keyword-toggle-hardmount.js',
			[ 'contentgem-gap-keyword-toggle-visible-v53' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-dashboard-progress-top-v59',
			CONTENTGEM_URL . 'assets/js/admin-v59-dashboard-progress-top.js',
			[ 'contentgem-gap-keyword-toggle-hardmount-v54' ],
			CONTENTGEM_VERSION,
			true
		);

		// Design system bridge scripts (class-based UI normalisation).
		wp_enqueue_script(
			'contentgem-ui-dom-bridge',
			CONTENTGEM_URL . 'assets/js/cgm-ui-dom-bridge.js',
			[ 'contentgem-dashboard-progress-top-v59' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_script(
			'contentgem-ui-state-manager',
			CONTENTGEM_URL . 'assets/js/cgm-ui-state-manager.js',
			[ 'contentgem-ui-dom-bridge' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_script(
			'contentgem-ui-progress-manager',
			CONTENTGEM_URL . 'assets/js/cgm-ui-progress-manager.js',
			[ 'contentgem-ui-state-manager' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_script(
			'contentgem-ui-filterbar-manager',
			CONTENTGEM_URL . 'assets/js/cgm-ui-filterbar-manager.js',
			[ 'contentgem-ui-progress-manager' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_script(
			'contentgem-ui-table-manager',
			CONTENTGEM_URL . 'assets/js/cgm-ui-table-manager.js',
			[ 'contentgem-ui-filterbar-manager' ],
			CONTENTGEM_VERSION,
			true
		);
		wp_enqueue_script(
			'contentgem-ui-page-polish',
			CONTENTGEM_URL . 'assets/js/cgm-ui-page-polish.js',
			[ 'contentgem-ui-table-manager' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-builder-ui',
			CONTENTGEM_URL . 'assets/js/cgm-builder-ui.js',
			[ 'contentgem-ui-page-polish' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-admin-v56-builder-progress-suggestion-hardfix',
			CONTENTGEM_URL . 'assets/js/admin-v56-builder-progress-suggestion-hardfix.js',
			[ 'contentgem-builder-ui' ],
			CONTENTGEM_VERSION,
			true
		);

		wp_enqueue_script(
			'contentgem-admin-v57-builder-progress-hardfix',
			CONTENTGEM_URL . 'assets/js/admin-v57-builder-progress-hardfix.js',
			[ 'contentgem-admin-v56-builder-progress-suggestion-hardfix' ],
			CONTENTGEM_VERSION,
			true
		);

		// Free-tier paywall UI: badges locked nav items + click-intercept
		// modal. No-op for paid users (checks window.contentgemData.plan).
		wp_enqueue_script(
			'contentgem-paywall',
			CONTENTGEM_URL . 'assets/js/cgm-paywall.js',
			[ 'contentgem-dashboard' ],
			CONTENTGEM_VERSION,
			true
		);

	}
}
