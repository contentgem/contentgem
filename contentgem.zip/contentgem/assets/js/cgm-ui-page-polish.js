(function(){
  if (window.__CGMUIPagePolish) return;
  window.__CGMUIPagePolish = true;
  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim(); }
  function setSpan(el, n){
    ['3','4','5','6','7','8','9','12'].forEach(function(v){ el.classList.remove('cgm-ds-span-'+v); });
    el.classList.add('cgm-ds-span-' + String(n));
  }
  function polishDashboard(root){
    var shell = qs('.contentgem-main > .cgm-page, .contentgem-main > div', root);
    if (!shell) return;
    qsa(':scope > .cgm-card, :scope > [data-cgm-card="1"]', shell).forEach(function(card){
      var t = txt(card).toLowerCase();
      if (card.classList.contains('cgm-dashboard-progress')) { setSpan(card, 12); return; }
      if (card.classList.contains('cgm-card--metric') || /ai credits this month|open content gap|topic clusters|internal link network/.test(t)) setSpan(card, 3);
      else if (card.classList.contains('cgm-card--table') || /topical coverage|topical authority overview|gsc intelligence|indexation monitor/.test(t)) setSpan(card, 6);
      else setSpan(card, 12);
    });
  }
  function polishGaps(root){
    var shell = qs('.contentgem-main > .cgm-page, .contentgem-main > div', root);
    if (!shell) return;
    var pagination = qsa(':scope > div', shell).find(function(el){ return /page \d+ of \d+/i.test(txt(el)) && qsa('button', el).length >= 2; });
    if (pagination) pagination.classList.add('cgm-pagination');
    var list = qs(':scope > .cgm-gap-list', shell);
    if (list) list.classList.add('cgm-gap-grid');
  }
  function apply(){
    var root = qs('#contentgem-dashboard');
    if (!root) return;
    if (root.classList.contains('cgm-page--dashboard')) polishDashboard(root);
    if (root.classList.contains('cgm-page--content-gaps')) polishGaps(root);
  }
  document.addEventListener('DOMContentLoaded', apply);
  window.addEventListener('load', apply);
  new MutationObserver(function(){ apply(); }).observe(document.documentElement,{childList:true,subtree:true});
})();
