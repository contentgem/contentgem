
(function(){
  if (!window.contentgemData || !location.href.includes('page=contentgem')) return;
  const restBase = String(window.contentgemData.restUrl || '').replace(/\/$/, '');
  const nonce = (window.contentgemData && window.contentgemData.nonce) || '';
  let clusterCache = null;

  function pageTitle(page){
    return (page && page.querySelector('.cgm-page__title') && page.querySelector('.cgm-page__title').textContent || '').trim();
  }
  function getPageRootByTitle(pattern){
    return Array.from(document.querySelectorAll('.cgm-page')).find(page => pattern.test(pageTitle(page))) || null;
  }
  function fetchJSON(path){
    return fetch(restBase + path, { headers: { 'X-WP-Nonce': nonce } }).then(r => r.json());
  }
  function fmt(num){ return typeof num === 'number' ? num.toFixed(1).replace('.0','') : num; }

  async function loadClusters(){
    if (clusterCache) return clusterCache;
    try{
      const res = await fetchJSON('/authority/clusters?limit=12');
      clusterCache = (res && res.success && Array.isArray(res.data)) ? res.data : [];
    } catch(e){
      clusterCache = [];
    }
    return clusterCache;
  }

  function cardHTML(title, subtitle, body){
    return `<section class="cgm-intel-card"><div class="cgm-intel-card__head"><h3>${title}</h3><p>${subtitle}</p></div>${body}</section>`;
  }

  function injectDashboardCard(root, clusters){
    if (!root || root.querySelector('.cgm-intel-authority-overview')) return;
    const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
    const rows = clusters.slice(0,6).map(c => {
      const a = c.authority || {};
      return `<tr>
        <td>${c.name || 'Cluster'}</td>
        <td><span class="cgm-intel-score">${fmt(a.authority_score || 0)}/100</span></td>
        <td>${fmt(a.coverage_score || 0)}%</td>
        <td>${fmt(a.entity_score || 0)}%</td>
        <td>${fmt(a.internal_link_score || 0)}%</td>
      </tr>`;
    }).join('');
    const best = clusters[0] || null;
    const priorities = (best && best.priority_articles || []).slice(0,3).map(item => `<li>${typeof item === 'string' ? item : (item.title || item.keyword || 'Opportunity')}</li>`).join('');
    const body = `
      <div class="cgm-intel-authority-overview">
        <div class="cgm-intel-grid">
          <div class="cgm-intel-panel">
            <div class="cgm-intel-kpis">
              <div class="cgm-intel-kpi"><span>Top cluster</span><strong>${best ? (best.name || '—') : '—'}</strong></div>
              <div class="cgm-intel-kpi"><span>Best score</span><strong>${best ? fmt(best.authority.authority_score || 0) + '/100' : '0/100'}</strong></div>
              <div class="cgm-intel-kpi"><span>Tracked clusters</span><strong>${clusters.length}</strong></div>
            </div>
            <table class="cgm-intel-table">
              <thead><tr><th>Cluster</th><th>Authority</th><th>Coverage</th><th>Entities</th><th>Links</th></tr></thead>
              <tbody>${rows || '<tr><td colspan="5">No clusters available yet.</td></tr>'}</tbody>
            </table>
          </div>
          <div class="cgm-intel-panel">
            <h4>Priority queue</h4>
            <p>Start with the highest-impact gaps to grow topical authority faster.</p>
            <ol class="cgm-intel-priority">${priorities || '<li>No priority articles available yet.</li>'}</ol>
          </div>
        </div>
      </div>`;
    const wrap = document.createElement('div');
    wrap.className = 'cgm-intel-mount';
    wrap.innerHTML = cardHTML('Topical authority overview', 'Cluster-wide authority, coverage and priority signals.', body);
    target.insertAdjacentElement('afterend', wrap);
  }

  function injectContentGapsCard(root, clusters){
    return; // v4.7 — Authority priority queue removed from Content Gaps page (no user value).
    if (!root || root.querySelector('.cgm-intel-priority-board')) return;
    const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
    const items = [];
    clusters.forEach(cluster => {
      (cluster.priority_articles || []).slice(0,2).forEach(item => {
        items.push({
          cluster: cluster.name || 'Cluster',
          label: typeof item === 'string' ? item : (item.title || item.keyword || 'Opportunity'),
          score: typeof item === 'object' ? (item.impact_score || 0) : 0
        });
      });
    });
    const list = items.slice(0,6).map((item, index) => `
      <li class="cgm-intel-priority-item">
        <span class="cgm-intel-priority-rank">#${index + 1}</span>
        <div>
          <strong>${item.label}</strong>
          <small>${item.cluster}</small>
        </div>
        <span class="cgm-intel-priority-badge">${item.score ? fmt(item.score) : 'High impact'}</span>
      </li>`).join('');
    const body = `<div class="cgm-intel-priority-board"><ul class="cgm-intel-priority-list">${list || '<li class="cgm-intel-priority-item"><div><strong>No priority opportunities yet.</strong><small>Run more analyses to populate this queue.</small></div></li>'}</ul></div>`;
    const wrap = document.createElement('div');
    wrap.className = 'cgm-intel-mount';
    wrap.innerHTML = cardHTML('Authority priority queue', 'Recommended next articles based on current coverage gaps.', body);
    target.insertAdjacentElement('afterend', wrap);
  }

  function applyPriorityHints(clusters){
    const cards = Array.from(document.querySelectorAll('.cgm-gap-card, [data-cgm-gap-card], .cgm-content-gap-card'));
    if (!cards.length) return;
    cards.forEach(card => {
      if (card.querySelector('.cgm-intel-inline-badge')) return;
      const text = (card.textContent || '').toLowerCase();
      const match = clusters.find(cluster => (cluster.name || '').toLowerCase() && text.includes((cluster.name || '').toLowerCase()));
      if (!match) return;
      const badge = document.createElement('div');
      badge.className = 'cgm-intel-inline-badge';
      badge.textContent = `Authority ${fmt(match.authority.authority_score || 0)}/100`;
      const anchor = card.querySelector('h3, h4, strong, .cgm-card__title') || card.firstElementChild || card;
      anchor.insertAdjacentElement('afterend', badge);
    });
  }

  async function renderV43(){
    const clusters = await loadClusters();
    if (!clusters.length) return;
    injectDashboardCard(getPageRootByTitle(/Dashboard/i), clusters);
    injectContentGapsCard(getPageRootByTitle(/Content Gaps/i), clusters);
    applyPriorityHints(clusters);
  }

  const boot = () => { renderV43(); };
  document.addEventListener('DOMContentLoaded', boot);
  setTimeout(boot, 1200);
  const mo = new MutationObserver(() => { renderV43(); });
  (function(){var d=document.getElementById("contentgem-dashboard");if(d){mo.observe(d,{childList:true,subtree:true});}else{setTimeout(function(){var d2=document.getElementById("contentgem-dashboard");if(d2)mo.observe(d2,{childList:true,subtree:true});},600);}})();
})();
