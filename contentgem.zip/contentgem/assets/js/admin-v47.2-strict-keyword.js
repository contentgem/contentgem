/**
 * v47.2 strict keyword — NO-OP (consolidated)
 * This was already a 1-line stub. Kept empty to preserve
 * wp_enqueue dependency chain during v5.0.9.0 stabilisation.
 */
(function(){ /* intentionally empty */ })();
