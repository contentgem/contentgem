/**
 * v52 gap-keyword-only-force-ui — NO-OP (consolidated into v54)
 * See admin-v50-gap-keyword-toggle.js for the full explanation.
 * Handle kept to preserve wp_enqueue dependency chain.
 */
(function(){ /* intentionally empty */ })();
