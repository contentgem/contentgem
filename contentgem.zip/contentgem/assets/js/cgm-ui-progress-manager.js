(function(){
  if (window.__CGMUIProgressManagerV2) return;
  window.__CGMUIProgressManagerV2 = true;

  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim().toLowerCase(); }
  function hasProgress(node){
    return !!(node && (qs('progress', node) || qs('[role="progressbar"]', node) || qsa('div', node).some(function(el){
      var st = String(el.getAttribute('style') || '');
      return /width\s*:\s*\d+%/.test(st) && /height\s*:\s*(6|7|8|9|10)px/.test(st);
    })));
  }
  function isProgressNode(node){
    var t = txt(node);
    return /detecting content gaps|analysing|analyzing|analysis|analyse site|analyse running/.test(t) && (/%/.test(t) || hasProgress(node));
  }
  function isAuthorityNode(node){
    return /topical authority overview/.test(txt(node));
  }
  function findDashboardShell(){
    var main = qs('#contentgem-dashboard .contentgem-main') || qs('.contentgem-main');
    if (!main) return null;
    return qsa('.cgm-page, .contentgem-main > div, .contentgem-main > section, .contentgem-main > article', main).find(function(node){
      var heading = qs('.cgm-page__title, h1, h2', node);
      return heading && /dashboard/.test(txt(heading));
    }) || main;
  }
  function nearestDirectChild(node, container){
    var current = node;
    while (current && current.parentNode && current.parentNode !== container) current = current.parentNode;
    return current && current.parentNode === container ? current : null;
  }
  function move(){
    var shell = findDashboardShell();
    if (!shell) return;
    var body = qs('.cgm-page__body', shell) || shell;
    var progressLeaf = qsa('div,section,article', body).find(isProgressNode);
    if (!progressLeaf) return;
    var progress = nearestDirectChild(progressLeaf, body) || progressLeaf.closest('.cgm-card, .cgm-section, section, article, div') || progressLeaf;
    var authorityLeaf = qsa('div,section,article', body).find(isAuthorityNode);
    var authority = authorityLeaf ? (nearestDirectChild(authorityLeaf, body) || authorityLeaf.closest('.cgm-card, .cgm-section, section, article, div') || authorityLeaf) : null;
    progress.classList.add('cgm-dashboard-progress','cgm-section','cgm-section--progress','cgm-progress-surface');
    if (authority && authority.parentNode === body) {
      if (authority.previousSibling !== progress) body.insertBefore(progress, authority);
      return;
    }
    var header = qs('.cgm-page__header', shell);
    if (header && header.parentNode === shell) {
      if (body === shell) {
        if (header.nextSibling !== progress) shell.insertBefore(progress, header.nextSibling);
      } else if (body.firstChild !== progress) {
        body.insertBefore(progress, body.firstChild || null);
      }
      return;
    }
    if (body.firstChild !== progress) body.insertBefore(progress, body.firstChild || null);
  }
  var scheduled = false;
  function schedule(){ if (scheduled) return; scheduled = true; window.requestAnimationFrame(function(){ scheduled = false; move(); }); }
  document.addEventListener('DOMContentLoaded', schedule);
  window.addEventListener('load', schedule);
  document.addEventListener('click', function(){ setTimeout(schedule, 80); }, true);
  new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true});
  setInterval(schedule, 1200);
})();
