(function(){
  'use strict';
  if (window.__CGMV62V6Hardfix) return;
  window.__CGMV62V6Hardfix = true;

  // ------------------------------------------------------------
  // ContentGem v62 hardfix — v3 (React-safe, no duplicate cluster UI)
  // ------------------------------------------------------------
  // Ctrl+F: CGM_V62_REST_CONFIG
  var REST = String((window.contentgemData||{}).restUrl || '/wp-json/contentgem/v1/').replace(/\/$/, '');
  var NONCE = (window.contentgemData||{}).nonce || '';
  var BUILDER_KEY = 'cgm-v62-builder-mode';
  var GAP_KEY = 'cgm-gap-keyword-only';

  // Ctrl+F: CGM_V62_UTILS
  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(v){ return String((v && v.textContent) || v || '').replace(/\s+/g,' ').trim(); }
  function visible(el){ return !!(el && el.isConnected && (el.offsetParent !== null || getComputedStyle(el).position === 'fixed')); }
  function slug(v){ v = String(v||'none').toLowerCase(); if (v==='standard'||v==='wordpress'||v==='wp') return 'none'; return ['none','elementor','divi'].indexOf(v)!==-1?v:'none'; }
  function api(method,path,body){ return fetch(REST + path, { method:method, credentials:'same-origin', headers:{ 'Content-Type':'application/json', 'X-WP-Nonce':NONCE }, body:body?JSON.stringify(body):undefined }).then(function(r){ return r.json(); }); }

  // Ctrl+F: CGM_V62_PAGE_RESOLVERS
  // We look up top-level page containers by their visible title. The SPA
  // (React) and the v23 admin-upgrade (plain DOM) both use .cgm-page__title.
  function pageRootByTitle(re){ return qsa('#contentgem-dashboard .cgm-page, #contentgem-dashboard .contentgem-main > div, #contentgem-dashboard .contentgem-main > section, #contentgem-dashboard .contentgem-main > article').find(function(node){ var h=qs('.cgm-page__title,h1,h2,h3',node); return h && re.test(txt(h)); }) || null; }
  function settingsRoot(){ return pageRootByTitle(/^settings$/i); }
  function assistantRoot(){ return pageRootByTitle(/^ai\s*assistant$/i) || qsa('#contentgem-dashboard .cgm-page').find(function(node){ return /build drafts with title suggestions/i.test(txt(node)); }) || null; }
  function onboardingRoot(){
    var dash = document.getElementById('contentgem-dashboard');
    if (!dash) return null;
    return qsa('div,section,article', dash).find(function(node){
      var t = txt(node);
      return /welcome to contentgem|continue setup|onboarding/i.test(t) && t.length < 2500;
    }) || null;
  }

  // Ctrl+F: CGM_V62_BUILDER_VALUE
  function builderValue(){ try { return slug(localStorage.getItem(BUILDER_KEY) || (window.contentgemData||{}).preferredBuilderMode || 'none'); } catch(e){ return 'none'; } }
  function setBuilderValue(v){ try { localStorage.setItem(BUILDER_KEY, slug(v)); } catch(e){} }
  function builderCard(id,title,desc,saveRemote){
    var current = builderValue();
    var wrap = document.createElement('div');
    wrap.id = id;
    wrap.className = 'cgm-v62-builder-card';
    wrap.innerHTML = '<div class="cgm-v62-card-title">'+title+'</div><div class="cgm-v62-card-desc">'+desc+'</div><div class="cgm-v62-row"><label class="cgm-v62-field"><span>Output mode</span><select><option value="none">Standard WordPress</option><option value="elementor">Elementor</option><option value="divi">Divi</option></select></label><div class="cgm-v62-status">Current: '+(current==='elementor'?'Elementor':(current==='divi'?'Divi':'Standard WordPress'))+'</div></div>';
    var select = qs('select', wrap);
    select.value = current;
    select.addEventListener('change', function(){
      var mode = slug(select.value);
      setBuilderValue(mode);
      var status = qs('.cgm-v62-status', wrap);
      status.textContent = saveRemote ? 'Saving default…' : 'Saved for this draft.';
      if (saveRemote) {
        api('POST','/settings/builder-mode',{mode:mode}).then(function(res){ status.textContent = 'Default: ' + (mode==='elementor'?'Elementor':(mode==='divi'?'Divi':'Standard WordPress')); }).catch(function(){ status.textContent='Could not save builder mode.'; });
      } else {
        status.textContent = 'Draft output: ' + (mode==='elementor'?'Elementor':(mode==='divi'?'Divi':'Standard WordPress'));
      }
    });
    return wrap;
  }

  // Ctrl+F: CGM_V62_PLACE_AFTER_HEADER
  // Only used for non-Settings pages (AI Assistant, Onboarding) where no
  // existing builder control is present.
  function placeAfterHeader(root, card){
    if (!root || !card) return;
    var existing = qs('#'+card.id, root);
    if (existing) existing.replaceWith(card);
    else {
      var header = qs('.cgm-page__header', root) || qsa('h1,h2,h3',root).find(function(h){ return /settings|assistant/i.test(txt(h)); });
      if (header && header.parentNode) header.parentNode.insertBefore(card, header.nextSibling || null);
      else root.insertBefore(card, root.firstChild || null);
    }
  }

  // Ctrl+F: CGM_V62_RENDER_BUILDER_UI
  // NOTE: the Settings "Default page builder" card was removed here in v2
  // because the v23 "AI & clusters" tab already ships a builder-mode select
  // (#cgm-set-builder-mode). Showing a second one caused layout clutter
  // directly under the Settings header.
  function renderBuilderUi(){
    // v5.0.9.7 — DISABLED. The native Settings tab in admin-v23-upgrade.js
    // already ships a Default-page-builder <select> in the AI & clusters
    // sub-tab (#cgm-set-builder-mode). All extra builder cards from
    // hardfix scripts produced misplaced / sticky / duplicate UI.
    //
    // We additionally clean up any orphaned cards that previous versions
    // of this script inserted into the page so the user does not need to
    // hard-refresh to clear the residue.
    qsa('#cgm-v62-builder-onboarding, #cgm-v62-builder-ai, #cgm-v62-builder-settings').forEach(function(el){
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  // Ctrl+F: CGM_V62_PATCH_REQUESTS
  function patchRequests(){
    if (window.__CGMV62PatchedRequests) return;
    window.__CGMV62PatchedRequests = true;
    function shouldPatch(url){ return /\/(draft|assistant\/draft|assistant\/draft-run|assistant\/generate|ai-assistant\/generate|ai-assistant\/save-draft)$/.test(String(url||'')); }
    function patchBody(body){
      try {
        var mode = builderValue();
        if (body && typeof body === 'string' && body.charAt(0)==='{') { var obj = JSON.parse(body); if (!obj.builder_mode || obj.builder_mode==='auto') obj.builder_mode = mode; return JSON.stringify(obj); }
        if (body && typeof body === 'object' && !(body instanceof FormData)) { if (!body.builder_mode || body.builder_mode==='auto') body.builder_mode = mode; return body; }
      } catch(e){}
      return body;
    }
    var nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') {
      window.fetch = function(input, init){
        var url = typeof input === 'string' ? input : ((input && input.url) || '');
        if (init && String((init.method||'GET')).toUpperCase()==='POST' && shouldPatch(url)) {
          init = Object.assign({}, init, { body: patchBody(init.body) });
        }
        return nativeFetch.call(this, input, init);
      };
    }
    var nativeOpen = XMLHttpRequest.prototype.open, nativeSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method,url){ this.__cgmUrl=url; this.__cgmMethod=method; return nativeOpen.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(body){ try { if (String(this.__cgmMethod||'GET').toUpperCase()==='POST' && shouldPatch(this.__cgmUrl)) body = patchBody(body); } catch(e){} return nativeSend.call(this, body); };
  }

  // Ctrl+F: CGM_V62_AI_TAB_PANEL
  // Resolves the Settings → "AI & clusters" tab panel. The v23 admin-upgrade
  // script builds that panel as plain DOM (insertAdjacentHTML), so mounting
  // inside it is safe and does not fight with React's reconciliation.
  function aiTabPanel(){
    var settings = settingsRoot();
    if (!settings) return null;
    return settings.querySelector('.cgm-tab-panel[data-tab="ai"]') || null;
  }

  // Ctrl+F: CGM_V62_REMOVE_LEGACY_CLUSTER_TOOLS
  // v3 change: the v62 Cluster tools card has been REMOVED. The v23
  // "AI & clusters" tab already ships native buttons for this:
  //   #cgm-clusters-suggest-one       → "Suggest new cluster"
  //   #cgm-clusters-add-suggested     → "Add suggested cluster"
  //   #cgm-suggest-single-cluster-keywords → keyword suggestions (Keywords tab)
  // Users were seeing two rows of the same action. This function only
  // sweeps up stale v62 nodes left over from older installs.
  function removeLegacyClusterTools(){
    var settings = settingsRoot();
    if (!settings) return;
    qsa('#cgm-v62-cluster-tools, #cgm-v62-builder-settings', settings).forEach(function(node){
      if (node && node.parentNode) node.parentNode.removeChild(node);
    });
  }

  // Ctrl+F: CGM_V62_GAP_KEYWORD_TOGGLE
  function keywordToggleUi(){
    // v5.0.9.8 — DISABLED. The native Content Gaps page already renders a
    // Keyword-only toggle via cgm-ui-filterbar-manager.js + server-side
    // inline bar (#cgm-gap-keyword-only-inline-bar). Two toggles were
    // showing up above each other.
    // Cleanup any orphan v62 toggles that previous versions left behind.
    qsa('#cgm-v62-gap-toggle').forEach(function(node){
      if (node && node.parentNode) node.parentNode.removeChild(node);
    });
  }

  // Ctrl+F: CGM_V62_GAP_DRAFTS
  function mapVisibleGaps(callback){
    var root = pageRootByTitle(/^content\s*gaps$/i) || document;
    var cards = qsa('article,div', root).filter(function(node){ var t=txt(node); return /generate draft/i.test(t) && /authority/i.test(t) && /cluster:/i.test(t); });
    if (!cards.length) return Promise.resolve([]);
    return api('GET','/gaps?page=1&per_page=200').then(function(res){
      var rows = (res && res.rows) || (res && res.data && res.data.rows) || [];
      var mapped=[];
      cards.forEach(function(card){
        var titleEl = qsa('h2,h3,h4,strong,div,span', card).find(function(el){ var t=txt(el); return t && t.length>12 && !/^informational|commercial|navigational|authority/i.test(t); });
        var title = txt(titleEl);
        var row = rows.find(function(r){ return txt(r.suggested_title || r.title) === title; });
        if (row) mapped.push({card:card, gap:row});
      });
      return mapped;
    }).then(callback || function(x){ return x; });
  }

  function parseSSE(text){
    var lines = String(text||'').split(/\n+/), data=[];
    lines.forEach(function(line){ if (/^data:\s*/.test(line)) data.push(line.replace(/^data:\s*/,'')); });
    var done = null;
    data.forEach(function(chunk){ try { var obj = JSON.parse(chunk); if (obj && obj.type === 'done') done = obj; } catch(e){} });
    return done;
  }

  function bindGapDrafts(){
    var root = pageRootByTitle(/^content\s*gaps$/i); if (!root) return;
    qsa('button', root).forEach(function(btn){
      var label = txt(btn);
      if (btn.__cgmV62Bound) return;
      if (/^generate draft$/i.test(label)) {
        btn.__cgmV62Bound = true;
        btn.addEventListener('click', function(ev){
          ev.preventDefault(); ev.stopPropagation();
          var card = btn.closest('article,div');
          mapVisibleGaps(function(items){
            var match = items.find(function(it){ return it.card === card || (card && card.contains(it.card)); });
            if (!match || !match.gap || !match.gap.id) return;
            btn.disabled = true; btn.textContent = 'Generating…';
            fetch(REST + '/draft', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json', 'X-WP-Nonce':NONCE }, body: JSON.stringify({ gap_id: match.gap.id, builder_mode: builderValue() }) })
              .then(function(r){ return r.text(); })
              .then(function(t){ var done = parseSSE(t); if (done && done.wp_post_id) window.location.href = '/wp-admin/post.php?post=' + done.wp_post_id + '&action=edit'; else { btn.disabled=false; btn.textContent='Generate draft'; } })
              .catch(function(){ btn.disabled=false; btn.textContent='Generate draft'; });
          });
        }, true);
      }
    });
  }

  // Ctrl+F: CGM_V62_SCHEDULER
  // v2 change: we no longer mutate React-owned DOM nor observe
  // document.documentElement. Wide-scope MutationObservers fought React's
  // reconciler and triggered "Failed to execute 'removeChild' on 'Node'"
  // errors after every analyse/render.
  //
  // The new approach:
  //   - Fire once on DOMContentLoaded/load.
  //   - Debounce schedule() to 250ms so bursts of React renders don't
  //     cascade into dozens of tick() calls.
  //   - Observe only #contentgem-dashboard (the plugin's mount), not the
  //     whole document.
  //   - Listen for Settings tab switches via a capturing click on
  //     .cgm-tab-btn so our panel-scoped UI is re-mounted when the user
  //     flips to "AI & clusters".
  function tick(){
    try { patchRequests(); } catch(e){}
    try { renderBuilderUi(); } catch(e){}
    try { removeLegacyClusterTools(); } catch(e){}
    try { keywordToggleUi(); } catch(e){}
    try { bindGapDrafts(); } catch(e){}
  }

  var debounceTimer = null;
  function schedule(){
    if (debounceTimer) return;
    debounceTimer = setTimeout(function(){
      debounceTimer = null;
      try { tick(); } catch(e){}
    }, 250);
  }

  function startObservers(){
    var mount = document.getElementById('contentgem-dashboard');
    if (!mount) { setTimeout(startObservers, 400); return; }
    try {
      new MutationObserver(schedule).observe(mount, { childList: true, subtree: true });
    } catch(e){}
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest && ev.target.closest('.cgm-tab-btn[data-tab]');
      if (btn) setTimeout(schedule, 0);
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ schedule(); startObservers(); });
  } else {
    schedule();
    startObservers();
  }
  window.addEventListener('load', schedule);
})();
