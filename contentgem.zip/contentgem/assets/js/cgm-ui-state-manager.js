(function(){
  if (window.__CGMUIStateManager) return;
  window.__CGMUIStateManager = true;
  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim(); }
  function apply(){
    var root = qs('#contentgem-dashboard');
    if (!root) return;
    qsa('button', root).forEach(function(btn){
      var t = txt(btn).toLowerCase();
      btn.classList.toggle('is-loading', /loading|saving|generating|processing|scanning|analysing/.test(t));
    });
    qsa('div,p,section,article', root).forEach(function(el){
      var t = txt(el);
      if (!t) return;
      if (/^No .*found\.?$/.test(t) || t === 'No gaps found' || t === 'No open gaps found.') {
        el.classList.add('cgm-empty-state','is-empty');
      }
      if (/No results match current filters/i.test(t) || /^0 of \d+ gaps$/i.test(t)) {
        el.classList.add('cgm-empty-state','is-filtered-empty');
      }
    });
  }
  document.addEventListener('DOMContentLoaded', apply);
  window.addEventListener('load', apply);
  new MutationObserver(function(){ apply(); }).observe(document.documentElement,{childList:true,subtree:true});
})();
