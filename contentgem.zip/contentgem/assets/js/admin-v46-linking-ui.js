(function(){
if(!window.contentgemData || !location.href.includes('page=contentgem')) return;
const restBase=String(window.contentgemData.restUrl||'').replace(/\/$/,'');
const nonce=window.contentgemData.nonce||'';
const SEGMENTS = 5;

function pageTitle(page){
  return (page && page.querySelector('.cgm-page__title') && page.querySelector('.cgm-page__title').textContent || '').trim();
}
function getPageRootByTitle(pattern){
  return Array.from(document.querySelectorAll('.cgm-page')).find(page => pattern.test(pageTitle(page))) || null;
}
async function postJSON(path,payload){
  const res = await fetch(restBase+path,{
    method:'POST',
    headers:{'Content-Type':'application/json','X-WP-Nonce':nonce},
    body:JSON.stringify(payload||{})
  });
  return res.json();
}
async function getJSON(path){
  const res = await fetch(restBase+path,{headers:{'X-WP-Nonce':nonce}});
  return res.json();
}

// --- Client-side insertion (mirrors PHP CGM_Linking_Service::insert_anchor_in_segment) ---
// We insert into the unsaved draft textarea, so we can't round-trip through the server.
function escapeRegex(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }

function isInsideAnchorTag(content, offset){
  const before = content.slice(0, offset).toLowerCase();
  const lastOpen = Math.max(before.lastIndexOf('<a '), before.lastIndexOf('<a>'));
  if(lastOpen < 0) return false;
  const lastClose = before.lastIndexOf('</a>');
  return lastClose < lastOpen;
}

function insertAnchorInSegment(content, anchor, url, segment){
  if(!anchor || !url) return null;
  // Already linked to this URL?
  const existing = new RegExp('href=["\']' + escapeRegex(url) + '["\']', 'i');
  if(existing.test(content)) return null;

  // Whole-word, case-insensitive, not inside another tag's text.
  const re = new RegExp('(?<![>\\w])(' + escapeRegex(anchor) + ')(?![\\w<])', 'gi');
  const matches = [];
  let m;
  while((m = re.exec(content)) !== null){
    if(!isInsideAnchorTag(content, m.index)){
      matches.push({ index: m.index, text: m[0] });
    }
    if(m.index === re.lastIndex) re.lastIndex++;
  }
  if(!matches.length) return null;

  const len = content.length;
  const target = (segment >= 0)
    ? Math.floor(len * ((segment + 0.5) / SEGMENTS))
    : Math.floor(len * 0.5);

  let chosen = matches[0];
  let bestDist = Infinity;
  for(const hit of matches){
    const d = Math.abs(hit.index - target);
    if(d < bestDist){ bestDist = d; chosen = hit; }
  }

  const replacement = '<a href="' + url + '">' + chosen.text + '</a>';
  return content.slice(0, chosen.index) + replacement + content.slice(chosen.index + chosen.text.length);
}

function getDraftTextarea(){
  return document.getElementById('cgm-ai-output');
}

function mountDraftLinking(root){
  if(!root) return;
  const textarea = getDraftTextarea() || root.querySelector('textarea');
  if(!textarea) return;
  if(root.querySelector('.cgm-linking-card')) return;

  const card=document.createElement('section');
  card.className='cgm-linking-card';
  card.innerHTML=`<div class="cgm-linking-card__head">
      <div><h3>Internal linking automation</h3><p>Detect relevant internal links, suggested anchors and insertion points.</p></div>
      <div class="cgm-linking-actions">
        <button type="button" class="button cgm-linking-insert-all" disabled>Insert all</button>
        <button type="button" class="button button-primary cgm-linking-run">Refresh suggestions</button>
      </div>
    </div>
    <div class="cgm-linking-status"><span class="cgm-linking-pill">Ready</span><span class="cgm-linking-copy">Generate a draft first, then refresh suggestions.</span></div>
    <div class="cgm-linking-list"><div class="cgm-linking-empty">No suggestions yet.</div></div>`;
  const target = textarea.closest('div, section, fieldset') || textarea.parentElement || root.firstElementChild || root;
  target.insertAdjacentElement('beforebegin', card);

  const list = card.querySelector('.cgm-linking-list');
  const pill = card.querySelector('.cgm-linking-pill');
  const copy = card.querySelector('.cgm-linking-copy');
  const insertAllBtn = card.querySelector('.cgm-linking-insert-all');

  // Holds the latest suggestions so insert handlers can read fresh data.
  let currentSuggestions = [];

  function setStatus(state, message){
    pill.textContent = state;
    copy.textContent = message;
  }

  function insertOne(suggestion, button){
    const ta = getDraftTextarea() || textarea;
    const updated = insertAnchorInSegment(ta.value || '', suggestion.anchor_text, suggestion.url, (typeof suggestion.segment === 'number' ? suggestion.segment : -1));
    if(updated === null){
      if(button){ button.textContent = 'Not found'; button.disabled = true; }
      setStatus('Notice', 'Anchor not found in the draft. Try editing the draft or refreshing suggestions.');
      return false;
    }
    ta.value = updated;
    // Notify any framework listening to the textarea (the SPA may track value).
    ta.dispatchEvent(new Event('input', {bubbles:true}));
    ta.dispatchEvent(new Event('change', {bubbles:true}));
    if(button){ button.textContent = 'Inserted'; button.disabled = true; button.classList.add('is-inserted'); }
    return true;
  }

  function insertAll(){
    let inserted = 0;
    const buttons = list.querySelectorAll('.cgm-linking-insert');
    currentSuggestions.forEach((s, i) => {
      const btn = buttons[i];
      if(btn && btn.disabled) return;
      if(insertOne(s, btn)) inserted++;
    });
    setStatus('Done', inserted + ' link' + (inserted === 1 ? '' : 's') + ' inserted into the draft.');
  }

  insertAllBtn.addEventListener('click', insertAll);

  function renderItems(items){
    currentSuggestions = items || [];
    if(!currentSuggestions.length){
      list.innerHTML='<div class="cgm-linking-empty">No strong matches yet.</div>';
      insertAllBtn.disabled = true;
      return;
    }
    list.innerHTML = currentSuggestions.map((item, i) => `
      <div class="cgm-linking-item" data-idx="${i}">
        <div class="cgm-linking-item__main">
          <strong>${item.title || 'Suggested page'}</strong>
          <small>Anchor: <em>${item.anchor_text || item.title || '—'}</em> • ${item.placement_hint || 'Section —'}</small>
        </div>
        <div class="cgm-linking-item__meta">
          <span class="cgm-linking-score">${item.score || 0}</span>
          <button type="button" class="button button-primary cgm-linking-insert">Insert</button>
          <a class="button cgm-linking-ghost" href="${item.url || '#'}" target="_blank" rel="noopener">Open</a>
        </div>
      </div>`).join('');
    insertAllBtn.disabled = false;

    // Wire up per-item insert buttons.
    list.querySelectorAll('.cgm-linking-item').forEach(row => {
      const idx = parseInt(row.getAttribute('data-idx'), 10);
      const btn = row.querySelector('.cgm-linking-insert');
      if(!btn) return;
      btn.addEventListener('click', () => {
        const s = currentSuggestions[idx];
        if(s) insertOne(s, btn);
      });
    });
  }

  async function run(){
    const ta = getDraftTextarea() || textarea;
    const content = (ta && ta.value) || '';
    if(!content.trim()){
      list.innerHTML='<div class="cgm-linking-empty">No draft content yet. Generate a draft first.</div>';
      insertAllBtn.disabled = true;
      setStatus('Waiting', 'Generate a draft, then click Refresh suggestions.');
      return;
    }
    setStatus('Scanning', 'Finding internal pages that strengthen this draft.');
    try{
      const res = await postJSON('/linking/suggest',{content, limit:6});
      const items = (res && res.success && Array.isArray(res.data)) ? res.data : [];
      if(!items.length){
        renderItems([]);
        setStatus('Ready', 'Add more topic detail to surface linking opportunities.');
        return;
      }
      renderItems(items);
      setStatus('Ready', 'Click Insert next to a suggestion, or Insert all to apply the whole list.');
    }catch(e){
      setStatus('Error', 'Suggestions could not be loaded.');
    }
  }

  card.querySelector('.cgm-linking-run').addEventListener('click',run);

  // Auto-refresh when the draft output changes.
  let timer=null;
  const schedule=()=>{ clearTimeout(timer); timer=setTimeout(run,900); };
  textarea.addEventListener('input',schedule);
  try{
    const obs=new MutationObserver(schedule);
    obs.observe(textarea,{characterData:true,childList:true,subtree:true,attributes:true,attributeFilter:['value']});
  }catch(e){}
  let lastVal = textarea.value || '';
  setInterval(()=>{
    const cur = (getDraftTextarea()||textarea).value || '';
    if(cur !== lastVal){
      lastVal = cur;
      schedule();
    }
  }, 1500);
}

async function mountOptimizer(root){
  if(!root || root.querySelector('.cgm-linking-orphans')) return;
  const card=document.createElement('section');
  card.className='cgm-linking-card cgm-linking-orphans';
  card.innerHTML=`<div class="cgm-linking-card__head">
    <div><h3>Orphan page detector</h3><p>Published pages without internal links are surfaced here so you can strengthen topical flow.</p></div>
  </div>
  <div class="cgm-linking-list"><div class="cgm-linking-empty">Loading orphan pages…</div></div>`;
  const target=root.querySelector('.cgm-page__header') || root.firstElementChild || root;
  target.insertAdjacentElement('afterend',card);
  try{
    const res=await getJSON('/linking/orphans');
    const items=(res&&res.success&&Array.isArray(res.data))?res.data:[];
    const list=card.querySelector('.cgm-linking-list');
    if(!items.length){
      list.innerHTML='<div class="cgm-linking-empty">No orphan pages detected.</div>';
      return;
    }
    list.innerHTML=items.map(item=>`<div class="cgm-linking-item">
      <div class="cgm-linking-item__main"><strong>${item.title || 'Untitled page'}</strong><small>No internal links detected.</small></div>
      <div class="cgm-linking-item__meta"><a class="button cgm-linking-ghost" href="${item.edit_url || '#'}">Open editor</a></div>
    </div>`).join('');
  }catch(e){
    card.querySelector('.cgm-linking-list').innerHTML='<div class="cgm-linking-empty">Orphan page data could not be loaded.</div>';
  }
}

function boot(){
  mountDraftLinking(getPageRootByTitle(/AI Assistant/i));
  mountOptimizer(getPageRootByTitle(/Optimizer/i));
}
document.addEventListener('DOMContentLoaded',boot);
setTimeout(boot,1200);
(function(){var _obs=new MutationObserver(()=>boot());var _attach=function(){var d=document.getElementById("contentgem-dashboard");if(d){_obs.observe(d,{childList:true,subtree:true});}else{setTimeout(_attach,600);}};_attach();})();
})();
