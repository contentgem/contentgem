(function(){
  if (window.__CGMUITableManager) return;
  window.__CGMUITableManager = true;
  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim(); }
  function apply(){
    var root = qs('#contentgem-dashboard');
    if (!root || !root.classList.contains('cgm-page--dashboard')) return;
    qsa('table', root).forEach(function(table){
      table.classList.add('cgm-table');
      var parent = table.parentElement;
      if (parent && !parent.classList.contains('cgm-table-wrap')) {
        if (/^(div|section|article)$/i.test(parent.tagName)) parent.classList.add('cgm-table-wrap');
      }
      qsa('thead th', table).forEach(function(th){ th.classList.add('cgm-table__head'); });
      qsa('tbody tr', table).forEach(function(tr, index){
        tr.classList.add('cgm-table__row');
        if (index % 2 === 1) tr.classList.add('is-alt-row');
      });
      qsa('td', table).forEach(function(td){
        td.classList.add('cgm-table__cell');
        var t = txt(td);
        if (/^[\d,.%#-]+$/.test(t)) td.setAttribute('data-cgm-metric-value','1');
      });
      var card = table.closest('.cgm-card, [data-cgm-card="1"], div');
      if (card) {
        card.classList.add('cgm-card','cgm-card--table','cgm-dashboard-card');
        var title = txt(qs('h2,h3,strong', card)).toLowerCase();
        if (/topical coverage/.test(title)) card.classList.add('cgm-dashboard-card--coverage');
        if (/topical authority overview/.test(title)) card.classList.add('cgm-dashboard-card--authority');
        if (/gsc intelligence/.test(title)) card.classList.add('cgm-dashboard-card--gsc');
        if (/indexation monitor/.test(title)) card.classList.add('cgm-dashboard-card--indexation');
      }
    });
  }
  document.addEventListener('DOMContentLoaded', apply);
  window.addEventListener('load', apply);
  new MutationObserver(function(){ apply(); }).observe(document.documentElement,{childList:true,subtree:true});
})();
