/**
 * v57 builder-progress hardfix — DISABLED in v5.0.9.7
 * ---------------------------------------------------------------
 * The native Settings tab in admin-v23-upgrade.js already ships a
 * Default-page-builder <select> in the AI & clusters sub-tab. All
 * the hardfix scripts that try to inject additional builder cards
 * produced misplaced / sticky / duplicate UI in screenshots from
 * production users. Decision: keep only the native select.
 *
 * Cleanup pass below removes any cgm-v57-builder-* cards that the
 * previous, active version of this script left behind, so users
 * don't need to hard-refresh to clear the residue.
 *
 * Handle kept to preserve wp_enqueue dependency chain.
 */
(function(){
  if (window.__CGMV57Hardfix) return;
  window.__CGMV57Hardfix = true;

  function cleanup(){
    var ids = ['#cgm-v57-builder-settings','#cgm-v57-builder-ai','#cgm-v57-builder-onboarding'];
    document.querySelectorAll(ids.join(',')).forEach(function(el){
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
    document.querySelectorAll('.cgm-v57-builder-card').forEach(function(el){
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  document.addEventListener('DOMContentLoaded', cleanup);
  window.addEventListener('load', cleanup);
  // Late cleanup in case React renders cards back in via cached state.
  setTimeout(cleanup, 500);
  setTimeout(cleanup, 2000);
  setInterval(cleanup, 5000);
})();
