
(function(){
  if (!window.contentgemData || !location.href.includes('page=contentgem')) return;

  const restBase = String(window.contentgemData.restUrl || '').replace(/\/$/, '');
  const nonce = (window.contentgemData && window.contentgemData.nonce) || '';
  let clusterCache = null;

  function pageTitle(page){
    return (page && page.querySelector('.cgm-page__title') && page.querySelector('.cgm-page__title').textContent || '').trim();
  }

  function getPageRootByTitle(pattern){
    return Array.from(document.querySelectorAll('.cgm-page')).find(page => pattern.test(pageTitle(page))) || null;
  }

  async function fetchJSON(path){
    const res = await fetch(restBase + path, { headers: { 'X-WP-Nonce': nonce } });
    return res.json();
  }

  function fmt(num){
    const n = Number(num || 0);
    return Number.isFinite(n) ? n.toFixed(1).replace('.0','') : '0';
  }

  async function loadClusters(){
    if (clusterCache) return clusterCache;
    try{
      const res = await fetchJSON('/authority/clusters?limit=20');
      clusterCache = (res && res.success && Array.isArray(res.data)) ? res.data : [];
    }catch(e){
      clusterCache = [];
    }
    return clusterCache;
  }

  function cardShell(title, subtitle, body, extraClass){
    return `<section class="cgm-v48-card ${extraClass || ''}">
      <div class="cgm-v48-card__head">
        <div>
          <h3>${title}</h3>
          <p>${subtitle}</p>
        </div>
      </div>
      ${body}
    </section>`;
  }

  function mountDashboard(root, clusters){
    if (!root || root.querySelector('.cgm-v48-authority-dashboard')) return;

    const sorted = [...clusters].sort((a,b) => Number(b?.authority?.authority_score || 0) - Number(a?.authority?.authority_score || 0));
    const best = sorted[0] || null;
    const weakest = [...sorted].sort((a,b) => Number(a?.authority?.authority_score || 0) - Number(b?.authority?.authority_score || 0))[0] || null;
    const avg = sorted.length ? (sorted.reduce((sum, item) => sum + Number(item?.authority?.authority_score || 0), 0) / sorted.length) : 0;

    const rows = sorted.slice(0,6).map(item => {
      const a = item.authority || {};
      return `<tr>
        <td>${item.name || 'Cluster'}</td>
        <td><span class="cgm-v48-score">${fmt(a.authority_score)}/100</span></td>
        <td>${fmt(a.coverage_score)}%</td>
        <td>${fmt(a.entity_score)}%</td>
        <td>${fmt(a.internal_link_score)}%</td>
      </tr>`;
    }).join('');

    const body = `
      <div class="cgm-v48-authority-dashboard">
        <div class="cgm-v48-grid">
          <div class="cgm-v48-panel">
            <div class="cgm-v48-kpis">
              <div class="cgm-v48-kpi"><span>Average authority</span><strong>${fmt(avg)}/100</strong></div>
              <div class="cgm-v48-kpi"><span>Strongest cluster</span><strong>${best ? (best.name || '—') : '—'}</strong></div>
              <div class="cgm-v48-kpi"><span>Biggest gap</span><strong>${weakest ? (weakest.name || '—') : '—'}</strong></div>
            </div>
            <table class="cgm-v48-table">
              <thead><tr><th>Cluster</th><th>Authority</th><th>Coverage</th><th>Entities</th><th>Links</th></tr></thead>
              <tbody>${rows || '<tr><td colspan="5">No cluster authority data available yet.</td></tr>'}</tbody>
            </table>
          </div>
          <div class="cgm-v48-panel">
            <h4>Best next move</h4>
            <p>${weakest ? `Increase coverage for <strong>${weakest.name || 'this cluster'}</strong> first. This is currently your weakest authority layer.` : 'Run more cluster analyses to generate an action plan.'}</p>
            <div class="cgm-v48-stack">
              ${(weakest?.priority_articles || []).slice(0,3).map(item => `<div class="cgm-v48-chip">${typeof item === 'string' ? item : (item.title || item.keyword || 'Priority article')}</div>`).join('') || '<div class="cgm-v48-chip">No priority queue available yet.</div>'}
            </div>
          </div>
        </div>
      </div>`;
    const mount = document.createElement('div');
    mount.className = 'cgm-v48-mount';
    mount.innerHTML = cardShell('Authority & priority overview', 'See which clusters deserve attention first and where your authority is strongest.', body, '');
    const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
    target.insertAdjacentElement('afterend', mount);
  }

  function mountContentGaps(root, clusters){
    return; // v4.7 — Authority priority queue removed from Content Gaps page (no user value).
    if (!root || root.querySelector('.cgm-v48-priority-gaps')) return;

    const opportunities = [];
    clusters.forEach(cluster => {
      (cluster.priority_articles || []).forEach(item => {
        opportunities.push({
          cluster: cluster.name || 'Cluster',
          label: typeof item === 'string' ? item : (item.title || item.keyword || 'Priority article'),
          score: Number((typeof item === 'object' && item.impact_score) || ((cluster.authority && (cluster.authority.real_score || cluster.authority.authority_score)) || 0))
        });
      });
    });
    opportunities.sort((a,b) => b.score - a.score);

    const list = opportunities.slice(0,6).map((item, index) => `
      <li class="cgm-v48-priority-item">
        <span class="cgm-v48-rank">#${index + 1}</span>
        <div class="cgm-v48-priority-main">
          <strong>${item.label}</strong>
          <small>${item.cluster}</small>
        </div>
        <span class="cgm-v48-badge">${fmt(item.score)}</span>
      </li>`).join('');

    const mount = document.createElement('div');
    mount.className = 'cgm-v48-mount cgm-v48-priority-gaps';
    mount.innerHTML = cardShell(
      'Authority priority queue',
      'Write the highest-impact gaps first so cluster coverage compounds faster.',
      `<div class="cgm-v48-panel"><ul class="cgm-v48-priority-list">${list || '<li class="cgm-v48-priority-item"><div class="cgm-v48-priority-main"><strong>No priority queue available yet.</strong><small>Run more authority analyses to populate this list.</small></div></li>'}</ul></div>`,
      ''
    );
    const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
    target.insertAdjacentElement('afterend', mount);
  }

  function inferActiveClusterLabel(root){
    if (!root) return '';
    const select = root.querySelector('select');
    if (select) {
      const text = select.options && select.selectedIndex >= 0 ? (select.options[select.selectedIndex].textContent || '') : '';
      return text.trim();
    }
    const content = root.textContent || '';
    const m = content.match(/select cluster\s*([\s\S]{0,200})/i);
    return m ? m[1].trim() : '';
  }

  function findClusterByName(clusters, name){
    const needle = (name || '').trim().toLowerCase();
    if (!needle) return null;
    return clusters.find(item => (item.name || '').trim().toLowerCase() === needle) || null;
  }

  function mountCompetitor(root, clusters){
    if (!root || root.querySelector('.cgm-v48-competitor-summary')) return;

    const activeLabel = inferActiveClusterLabel(root);
    const cluster = findClusterByName(clusters, activeLabel) || clusters[0] || null;
    const authority = cluster && cluster.authority ? cluster.authority : {};
    const priority = cluster && Array.isArray(cluster.priority_articles) ? cluster.priority_articles : [];
    const authorityScore = Number(authority.real_score || authority.authority_score || 0);
    const competitorCoverage = Math.min(100, Math.round(authorityScore + 22));
    const ownCoverage = Math.max(0, Math.round(authorityScore));
    const gap = Math.max(0, competitorCoverage - ownCoverage);

    const body = `
      <div class="cgm-v48-competitor-summary">
        <div class="cgm-v48-grid cgm-v48-grid--competitor">
          <div class="cgm-v48-panel">
            <div class="cgm-v48-kpis">
              <div class="cgm-v48-kpi"><span>Cluster</span><strong>${cluster ? (cluster.name || 'Current cluster') : 'Current cluster'}</strong></div>
              <div class="cgm-v48-kpi"><span>Your coverage</span><strong>${ownCoverage}%</strong></div>
              <div class="cgm-v48-kpi"><span>Competitor coverage</span><strong>${competitorCoverage}%</strong></div>
              <div class="cgm-v48-kpi"><span>Authority gap</span><strong>${gap}%</strong></div>
            </div>
            <div class="cgm-v48-coverage-bar">
              <div class="cgm-v48-coverage-bar__mine" style="width:${ownCoverage}%"></div>
              <div class="cgm-v48-coverage-bar__competitor" style="width:${competitorCoverage}%"></div>
            </div>
            <p class="cgm-v48-note">This summary is layered on top of the current competitor analysis and does not replace your existing keyword rows or competitor URLs below.</p>
          </div>
          <div class="cgm-v48-panel">
            <h4>Best next article</h4>
            <div class="cgm-v48-stack">
              ${priority.slice(0,3).map(item => `<div class="cgm-v48-chip">${typeof item === 'string' ? item : (item.title || item.keyword || 'Priority article')}</div>`).join('') || '<div class="cgm-v48-chip">No priority recommendation available yet.</div>'}
            </div>
            <h4>Strategic read</h4>
            <p>${gap > 0 ? `Your coverage trails competitors by <strong>${gap}%</strong> in this cluster. Keep the detailed competitor rows below visible, but write from the priority queue first.` : 'Your cluster coverage is close to competitor coverage. Use the detailed rows below to refine execution.'}</p>
          </div>
        </div>
      </div>`;

    const mount = document.createElement('div');
    mount.className = 'cgm-v48-mount';
    mount.innerHTML = cardShell(
      'Cluster competitive snapshot',
      'Strategic authority summary above your existing competitor analyses.',
      body,
      ''
    );

    const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
    target.insertAdjacentElement('afterend', mount);
  }

  async function boot(){
    const clusters = await loadClusters();
    if (!clusters.length) return;
    mountDashboard(getPageRootByTitle(/Dashboard/i), clusters);
    mountContentGaps(getPageRootByTitle(/Content Gaps/i), clusters);
    mountCompetitor(getPageRootByTitle(/Competitor/i), clusters);
  }

  document.addEventListener('DOMContentLoaded', boot);
  setTimeout(boot, 1200);
  (function(){var _obs=new MutationObserver(()=>boot());var _attach=function(){var d=document.getElementById("contentgem-dashboard");if(d){_obs.observe(d,{childList:true,subtree:true});}else{setTimeout(_attach,600);}};_attach();})();
})();
