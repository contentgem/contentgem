(function(){
  window.__CONTENTGEM_BIG_UPGRADE__ = true;
  if (!window.contentgemData || !String(location.href).includes('page=contentgem')) return;

  const restBase = String((window.contentgemData && window.contentgemData.restUrl) || '/wp-json/contentgem/v1/').replace(/\/$/, '');
  const nonce = (window.contentgemData && window.contentgemData.nonce) || (window.wpApiSettings && window.wpApiSettings.nonce) || '';
  const state = {
    settings: null,
    assistant: {
      output: '',
      status: '',
      error: '',
      suggestions: [],
      competitorContext: '',
      competitorEnabled: false,
      savedToneEnabled: false,
      semanticEnabled: false,
      pillarEnabled: false,
      semanticKeywords: [],
      semanticUnchecked: [],
      semanticCustomKeywords: [],
      history: [],
    },
    competitorHistory: [],
    competitorHistoryByCluster: {},
    competitorHistoryFilter: '',
  };

  const languageOptions = [
    { value:'nl', label:'Dutch' },
    { value:'en', label:'English' },
    { value:'de', label:'German' },
    { value:'fr', label:'French' },
    { value:'es', label:'Spanish' },
    { value:'it', label:'Italiano' },
    { value:'pt', label:'Portuguese' },
    { value:'custom', label:'Custom language' },
    { value:'auto', label:'Auto detect' },
  ];

  async function api(path, options = {}) {
    const rawPath = String(path || '').replace(/^\//,'');
    const url = new URL(restBase + '/' + rawPath, window.location.origin);
    if (nonce && !url.searchParams.has('_wpnonce')) url.searchParams.set('_wpnonce', nonce);
    const res = await fetch(url.toString(), {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        ...(nonce ? { 'X-WP-Nonce': nonce } : {}),
        ...(options.body && !(options.body instanceof FormData) ? { 'Content-Type':'application/json' } : {}),
        ...(options.headers || {}),
      },
      body: options.body === undefined ? undefined : (typeof options.body === 'string' || options.body instanceof FormData ? options.body : JSON.stringify(options.body)),
      cache: 'no-store',
      redirect: 'follow',
    });
    let data = null;
    try { data = await res.json(); } catch(e) {}
    if (!res.ok) throw new Error((data && data.message) || `Request failed (${res.status})`);
    return data || {};
  }

  async function wpApi(path) {
    const res = await fetch(path, { credentials:'same-origin', cache:'no-store' });
    if (!res.ok) throw new Error('WordPress request failed.');
    return res.json();
  }

  async function loadSettings(force = false) {
    if (state.settings && !force) return state.settings;
    try {
      const data = await api('settings');
      data.clusters = Array.isArray(data.clusters) ? data.clusters : [];
      data.cluster_keywords = data.cluster_keywords && typeof data.cluster_keywords === 'object' ? data.cluster_keywords : {};
      data.competitor_domains = Array.isArray(data.competitor_domains) ? data.competitor_domains : [];
      state.settings = data;
      return state.settings;
    } catch (err) {
      const fallback = Object.assign({ clusters: [], cluster_keywords: {}, competitor_domains: [], site_structure: { nodes: [] }, site_pages: [], show_source_list:false, enable_token_optimization:true, enable_full_source_grounding:false, openai_default_model:'gpt-5.4-mini', openai_show_token_stats:false, openai_enable_batch:false, openai_enable_flex:false, openai_reasoning_profile:'balanced', codebase_status:{ available:false, built_at:'', version:'', file_count:0 } }, (window.contentgemData && window.contentgemData.bootstrapSettings) || {});
      fallback.clusters = Array.isArray(fallback.clusters) ? fallback.clusters : [];
      fallback.cluster_keywords = fallback.cluster_keywords && typeof fallback.cluster_keywords === 'object' ? fallback.cluster_keywords : {};
      fallback.competitor_domains = Array.isArray(fallback.competitor_domains) ? fallback.competitor_domains : [];
      state.settings = fallback;
      return state.settings;
    }
  }

  function normalizeClusterKey(cluster) {
    const raw = String(cluster || '').trim().toLowerCase();
    if (!raw) return '_unclustered';
    return raw.normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-');
  }

  function mergeHistoryItems(remoteItems, localItems) {
    const merged = [];
    const seen = new Set();
    [...(Array.isArray(remoteItems) ? remoteItems : []), ...(Array.isArray(localItems) ? localItems : [])].forEach(item => {
      if (!item || typeof item !== 'object') return;
      const key = String(item.id || `${item.cluster || ''}|${item.keyword || ''}|${item.captured_at || ''}`);
      if (seen.has(key)) return;
      seen.add(key);
      merged.push(item);
    });
    return merged;
  }

  function localHistorySnapshot(cluster = '') {
    try {
      const raw = localStorage.getItem('cgm_competitor_reports_by_cluster');
      const parsed = JSON.parse(raw || '{}');
      const grouped = parsed && typeof parsed === 'object' ? parsed : {};
      if (!cluster) return Object.values(grouped).flat().filter(Boolean);
      return Array.isArray(grouped[normalizeClusterKey(cluster)]) ? grouped[normalizeClusterKey(cluster)] : [];
    } catch (e) {
      try {
        const flat = JSON.parse(localStorage.getItem('cgm_competitor_reports') || '[]');
        return Array.isArray(flat) ? flat : [];
      } catch (_) {
        return [];
      }
    }
  }

  function saveLocalCompetitorReport(item) {
    try {
      const raw = localStorage.getItem('cgm_competitor_reports_by_cluster');
      const grouped = JSON.parse(raw || '{}') || {};
      const clusterKey = normalizeClusterKey(item.cluster || '');
      const current = Array.isArray(grouped[clusterKey]) ? grouped[clusterKey] : [];
      const merged = mergeHistoryItems([item], current).slice(0, 25);
      grouped[clusterKey] = merged;
      localStorage.setItem('cgm_competitor_reports_by_cluster', JSON.stringify(grouped));
      state.competitorHistoryByCluster[clusterKey] = merged;
      state.competitorHistory = Object.values(grouped).flat().filter(Boolean);
      try { window.dispatchEvent(new CustomEvent('cgm:competitorReportSaved', { detail: item })); } catch (e) {}
    } catch (e) {}
  }

  async function loadCompetitorHistory(cluster = '', force = false) {
    const clusterKey = normalizeClusterKey(cluster || '');
    if (!force && cluster && Array.isArray(state.competitorHistoryByCluster[clusterKey])) return state.competitorHistoryByCluster[clusterKey];
    if (!force && !cluster && state.competitorHistory.length) return state.competitorHistory;
    try {
      const query = cluster ? `competitor/history?cluster=${encodeURIComponent(cluster)}` : 'competitor/history';
      const data = await api(query);
      const remoteItems = Array.isArray(data.items) ? data.items : [];
      const localItems = localHistorySnapshot(cluster);
      const merged = mergeHistoryItems(remoteItems, localItems);
      if (cluster) { state.competitorHistoryByCluster[clusterKey] = merged; return merged; }
      state.competitorHistory = merged;
      return merged;
    } catch (e) {
      return localHistorySnapshot(cluster);
    }
  }


  async function loadLatestCompetitorAnalysis(cluster = '') {
    try {
      const query = cluster ? `competitor/latest-analysis?cluster=${encodeURIComponent(cluster)}` : 'competitor/latest-analysis';
      const data = await api(query);
      return data && data.item && typeof data.item === 'object' ? data.item : null;
    } catch (e) {
      return null;
    }
  }

  function getRoot() {
    return document.getElementById('contentgem-dashboard');
  }

  function pageRootByMatcher(matcher) {
    return Array.from(document.querySelectorAll('.cgm-page')).find(page => {
      const t = page.querySelector('.cgm-page__title');
      const text = t ? String(t.textContent || '').trim() : '';
      return typeof matcher === 'string' ? text.toLowerCase() === matcher.toLowerCase() : matcher(text);
    }) || null;
  }

  function onboardingFallbackVisible() {
    const root = getRoot();
    if (!root) return false;
    return /Welcome to ContentGem/i.test(root.textContent || '') && /Continue to dashboard/i.test(root.textContent || '');
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function normalizeList(text) {
    return String(text || '').split(/\n|,/).map(v => v.trim()).filter(Boolean);
  }

  function languageLabel(code, custom) {
    if (code === 'custom' && custom) return custom;
    const found = languageOptions.find(o => o.value === code);
    return found ? found.label : (code || 'Auto');
  }

  function ensurePageHeader(root, title, subtitle) {
    root.innerHTML = `
      <div class="cgm-page__header cgm-upgrade-header">
        <div>
          <h1 class="cgm-page__title">${escapeHtml(title)}</h1>
          ${subtitle ? `<p class="cgm-upgrade-subtitle">${escapeHtml(subtitle)}</p>` : ''}
        </div>
      </div>
    `;
  }

  function card(title, bodyHtml, extraClass = '') {
    return `
      <section class="cgm-card cgm-upgrade-card ${extraClass}">
        ${title ? `<div class="cgm-card__header"><h2>${escapeHtml(title)}</h2></div>` : ''}
        <div class="cgm-card__body">${bodyHtml}</div>
      </section>
    `;
  }

  function badge(text, kind='neutral') {
    return `<span class="cgm-badge cgm-badge--${kind}">${escapeHtml(text)}</span>`;
  }

  function renderStatus(el, message, ok = true) {
    if (!el) return;
    el.textContent = message || '';
    el.className = ok ? 'cgm-upgrade-status is-success' : 'cgm-upgrade-status is-error';
  }

  function renderProgress(el, current, total, label) {
    if (!el) return;
    const safeTotal = Math.max(1, Number(total) || 1);
    const safeCurrent = Math.max(0, Math.min(safeTotal, Number(current) || 0));
    const pct = Math.round((safeCurrent / safeTotal) * 100);
    el.innerHTML = `<div class="cgm-progress"><div class="cgm-progress__bar" style="width:${pct}%"></div></div><div class="cgm-progress__label">${escapeHtml(label || 'Processing…')} · ${pct}%</div>`;
  }

  function clearProgress(el) { if (el) el.innerHTML = ''; }

  function friendlyErrorMessage(err, fallback) {
    const message = String((err && err.message) || fallback || 'Something went wrong.').trim();
    if (/must start with/i.test(message) || /invalid_api_key/i.test(message)) {
      return 'The API key format looks invalid. Paste the full key again and try once more.';
    }
    if (/Could not save onboarding state/i.test(message)) {
      return 'The onboarding state could not be saved yet. Try again once more.';
    }
    return message || fallback || 'Something went wrong.';
  }

  function dashboardUrl() {
    const url = new URL(window.location.href);
    url.searchParams.set('page', 'contentgem');
    url.searchParams.set('contentgem_view', 'dashboard');
    url.hash = '';
    return url.toString();
  }

  function redirectToDashboard(delay = 250) {
    window.setTimeout(() => { window.location.assign(dashboardUrl()); }, delay);
  }

  function bindTabButtons(root, buttonSelector, panelSelector, activeValue) {
    const buttons = Array.from(root.querySelectorAll(buttonSelector));
    const panels = Array.from(root.querySelectorAll(panelSelector));
    if (!buttons.length) return;
    let storageKey = '';
    if (root.matches && root.matches('.cgm-page')) {
      const title = (root.querySelector('.cgm-page__title')?.textContent || '').trim().toLowerCase();
      if (title === 'settings') storageKey = 'cgm_active_tab_settings';
      else if (title.includes('competitor')) storageKey = 'cgm_active_tab_competitor';
    }
    function activate(value) {
      buttons.forEach(btn => btn.classList.toggle('is-active', btn.dataset.tab === value));
      panels.forEach(panel => panel.hidden = panel.dataset.tab !== value);
      if (storageKey) {
        try { localStorage.setItem(storageKey, value || ''); } catch (e) {}
      }
    }
    buttons.forEach(btn => btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      activate(btn.dataset.tab);
    }));
    let initial = activeValue || (buttons[0] && buttons[0].dataset.tab);
    if (storageKey) {
      try {
        const saved = localStorage.getItem(storageKey);
        if (saved && buttons.some(btn => btn.dataset.tab === saved)) initial = saved;
      } catch (e) {}
    }
    activate(initial);
  }

  function bind(root, selector, eventName, handler) {
    const el = root.querySelector(selector);
    if (!el) return null;
    el.addEventListener(eventName, handler);
    return el;
  }

  function localHistorySnapshot(cluster = '') {
    try {
      const raw = localStorage.getItem('cgm_competitor_reports_by_cluster');
      const parsed = JSON.parse(raw || '{}');
      const grouped = parsed && typeof parsed === 'object' ? parsed : {};
      if (!cluster) return Object.values(grouped).flat().filter(Boolean);
      return Array.isArray(grouped[normalizeClusterKey(cluster)]) ? grouped[normalizeClusterKey(cluster)] : [];
    } catch (e) {
      try {
        const parsed = JSON.parse(localStorage.getItem('cgm_competitor_reports') || '[]');
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) {
        return [];
      }
    }
  }


  function saveLocalCompetitorReport(item) {
    try {
      const raw = localStorage.getItem('cgm_competitor_reports_by_cluster');
      const grouped = JSON.parse(raw || '{}') || {};
      const clusterKey = normalizeClusterKey(item.cluster || '');
      const current = Array.isArray(grouped[clusterKey]) ? grouped[clusterKey] : [];
      const merged = mergeHistoryItems([item], current).slice(0, 25);
      grouped[clusterKey] = merged;
      localStorage.setItem('cgm_competitor_reports_by_cluster', JSON.stringify(grouped));
      state.competitorHistoryByCluster[clusterKey] = merged;
      state.competitorHistory = Object.values(grouped).flat().filter(Boolean);
      try { window.dispatchEvent(new CustomEvent('cgm:competitorReportSaved', { detail: item })); } catch (e) {}
    } catch (e) {}
  }

  const nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  if (nativeFetch && !window.__cgmCompetitorFetchWrapped) {
    window.__cgmCompetitorFetchWrapped = true;
    window.fetch = async function(...args) {
      const response = await nativeFetch(...args);
      try {
        const url = String((args[0] && args[0].url) || args[0] || '');
        if (/contentgem\/v1\/competitor\/(?:analyze|analyze-bulk)/i.test(url) && response && response.ok) {
          const clone = response.clone();
          clone.json().then(payload => {
            if (payload && typeof payload === 'object') {
              const item = {
                id: payload.id || `local_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
                keyword: payload.keyword || '',
                cluster: payload.cluster || '',
                captured_at: payload.captured_at || new Date().toISOString(),
                captured_at_human: payload.captured_at ? '' : '',
                competitors: Array.isArray(payload.competitors) ? payload.competitors : [],
                gaps: Array.isArray(payload.gaps) ? payload.gaps : [],
                recommendations: Array.isArray(payload.detailed_recommendations) ? payload.detailed_recommendations : (Array.isArray(payload.recommendations) ? payload.recommendations : []),
                avg_words: Array.isArray(payload.competitors) && payload.competitors.length ? Math.round(payload.competitors.reduce((sum, comp) => sum + Number(comp.word_count || 0), 0) / payload.competitors.length) : 0,
                common_h2s: Array.isArray(payload.competitors) ? payload.competitors.flatMap(comp => Array.isArray(comp.h2s) ? comp.h2s.slice(0, 4) : []).slice(0, 12) : [],
                report_summary: payload.report_summary || ''
              };
              saveLocalCompetitorReport(item);
            }
          }).catch(() => {});
        }
      } catch (e) {}
      return response;
    };
  }

  function mergeCompetitorInsights(cluster, remoteSummary, historyItems) {
    const list = (historyItems || []).filter(item => String(item.cluster || '').toLowerCase() === String(cluster || '').toLowerCase());
    const topActions = new Map();
    const topGaps = new Map();
    const topTopics = new Map();
    const topBenefits = new Map();
    const domains = new Map();
    let avgWordsTotal = 0;
    let avgWordsCount = 0;

    list.slice(0, 8).forEach(item => {
      (item.competitors || []).forEach(comp => {
        const host = comp.host || comp.url || '';
        if (host) domains.set(host, (domains.get(host) || 0) + 1);
      });
      if (item.avg_words) { avgWordsTotal += Number(item.avg_words) || 0; avgWordsCount++; }
      (item.gaps || []).slice(0, 6).forEach(gap => {
        const desc = String(gap.description || gap.action || '').trim();
        if (desc) topGaps.set(desc, (topGaps.get(desc) || 0) + 1);
      });
      (item.recommendations || []).slice(0, 8).forEach(rec => {
        const desc = String(rec.action || rec.description || '').trim();
        if (desc) topActions.set(desc, (topActions.get(desc) || 0) + 1);
        const benefit = String(rec.benefit || '').trim();
        if (benefit) topBenefits.set(benefit, (topBenefits.get(benefit) || 0) + 1);
      });
      (item.common_h2s || []).slice(0, 10).forEach(h => {
        if (h) topTopics.set(h, (topTopics.get(h) || 0) + 1);
      });
    });

    const lines = [];
    if (remoteSummary) lines.push(String(remoteSummary).trim());
    if (avgWordsCount) lines.push(`Average competitor length across recent analyses: ~${Math.round(avgWordsTotal / avgWordsCount)} words.`);
    if (domains.size) lines.push(`Frequently analyzed competitors: ${Array.from(domains.entries()).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([host])=>host).join(', ')}.`);
    if (topTopics.size) lines.push(`Recurring competitor topics and section angles: ${Array.from(topTopics.entries()).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([topic])=>topic).join(', ')}.`);
    if (topGaps.size) lines.push(`Most repeated content gaps: ${Array.from(topGaps.entries()).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([text])=>text).join(' | ')}.`);
    if (topActions.size) lines.push(`Highest-value content actions: ${Array.from(topActions.entries()).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([text])=>text).join(' | ')}.`);
    if (topBenefits.size) lines.push(`Why these changes improve your page: ${Array.from(topBenefits.entries()).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([text])=>text).join(' | ')}.`);
    return lines.filter(Boolean).join('\n\n').trim();
  }

  function competitorInsightHtml(context) {
    if (!context) return '<p class="cgm-empty-note">No competitor insights stored for this cluster yet. Run competitor analysis first.</p>';
    const sections = String(context).split(/\n\n+/).map(v => v.trim()).filter(Boolean);
    return `<ul class="cgm-insight-list">${sections.map(line => `<li>${escapeHtml(line)}</li>`).join('')}</ul>`;
  }

  function saveAssistantDraftPayload(settings, cluster, title, html, contentType = 'post', wpPostId = 0, includeSvgVisuals = false) {
    return {
      title: title || 'AI Assistant Draft',
      content: html,
      cluster: cluster,
      language: settings.content_language || 'nl',
      content_type: contentType === 'page' ? 'page' : 'post',
      wp_post_id: Number(wpPostId || 0),
      include_svg_visuals: !!includeSvgVisuals
    };
  }


  function buildKeywordMapFromText(text) {
    const map = {};
    String(text || '').split('\n').map(v => v.trim()).filter(Boolean).forEach(row => {
      const parts = row.split(':');
      if (parts.length < 2) return;
      const cluster = parts.shift().trim();
      const kws = parts.join(':').split(',').map(v => v.trim()).filter(Boolean);
      if (cluster && kws.length) map[cluster] = kws;
    });
    return map;
  }

  function normalizeBuilderMode(value) {
    const mode = String(value || '').toLowerCase();
    if (mode === 'standard' || mode === 'wordpress') return 'none';
    return ['none', 'elementor', 'divi'].includes(mode) ? mode : 'none';
  }

  function builderLabel(value) {
    const mode = normalizeBuilderMode(value);
    return mode === 'elementor' ? 'Elementor' : (mode === 'divi' ? 'Divi' : 'Standard WordPress');
  }

  function builderSelectOptions(settings) {
    const available = settings && settings.available_builders && typeof settings.available_builders === 'object'
      ? settings.available_builders
      : { standard: true, elementor: false, divi: false };
    const current = normalizeBuilderMode((settings && settings.preferred_builder_mode) || 'none');
    return `
      <option value="none" ${current === 'none' ? 'selected' : ''}>Standard WordPress</option>
      <option value="elementor" ${current === 'elementor' ? 'selected' : ''} ${available.elementor ? '' : 'disabled'}>Elementor${available.elementor ? '' : ' (plugin inactive)'}</option>
      <option value="divi" ${current === 'divi' ? 'selected' : ''} ${available.divi ? '' : 'disabled'}>Divi${available.divi ? '' : ' (plugin inactive)'}</option>`;
  }

  async function saveBuilderModeViaApi(mode) {
    return api('settings/builder-mode', { method:'POST', body:{ mode: normalizeBuilderMode(mode) } });
  }

  function upsertKeywordLine(textarea, cluster, keywords) {
    if (!textarea || !cluster) return;
    const map = buildKeywordMapFromText(textarea.value || '');
    map[cluster] = Array.isArray(keywords) ? keywords.filter(Boolean) : [];
    textarea.value = Object.entries(map).map(([name, list]) => `${name}: ${(Array.isArray(list) ? list : []).join(', ')}`).join('\n');
  }

  function onboardingCompleteLikely(settings) {
    return !!(settings && settings.onboarding_complete && settings.niche && (settings.clusters || []).length);
  }

  function renderOnboardingWizard(settings) {
    const root = getRoot();
    if (!root) return;
    if (root.dataset.cgmUpgradeMode === 'onboarding-v32' && root.querySelector('#cgm-ob-tabs')) return;
    root.dataset.cgmUpgradeMode = 'onboarding-v32';
    root.innerHTML = `
      <div class="cgm-onboarding-wrap">
        <div class="cgm-onboarding-shell">
          <div class="cgm-onboarding-hero">
            <div>
              <h1>Set up Contentgem</h1>
              <p>Configure your niche, AI connection and writing preferences in a compact flow that matches the main app.</p><div class="cgm-onboarding-hero-note">Use the onboarding below to connect OpenAI or Claude, define your first clusters and set the writing style for Contentgem.</div>
            </div>
          </div>
          <div class="cgm-step-tabs" id="cgm-ob-tabs">
            <button type="button" class="cgm-tab-btn" data-tab="profile">1 · Site profile</button>
            <button type="button" class="cgm-tab-btn" data-tab="ai">2 · AI & clusters</button>
            <button type="button" class="cgm-tab-btn" data-tab="style">3 · Style & competitors</button>
          </div>
          ${card('', `
            <div class="cgm-tab-panel" data-tab="profile">
              <div class="cgm-field-grid two-col compact">
                <div class="cgm-field"><label>Niche</label><input id="cgm-ob-niche" type="text" value="${escapeHtml(settings.niche || '')}" placeholder="e.g. AI content marketing"></div>
                <div class="cgm-field"><label>Default content language</label>
                  <select id="cgm-ob-language">${languageOptions.filter(o => o.value !== 'auto').map(opt => `<option value="${opt.value}" ${String(settings.content_language||'en')===opt.value?'selected':''}>${escapeHtml(opt.label)}</option>`).join('')}</select>
                  <input id="cgm-ob-language-custom" type="text" value="${escapeHtml(settings.content_language_custom || '')}" placeholder="Custom language" ${String(settings.content_language||'') === 'custom' ? '' : 'style="display:none"'}>
                </div>
              </div>
              <div class="cgm-field"><label>Niche description</label><textarea id="cgm-ob-description" rows="4" placeholder="Describe your site, audience, topics and commercial goals.">${escapeHtml(settings.niche_description || '')}</textarea></div>
              <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-ob-next-profile">Continue</button></div>
            </div>
            <div class="cgm-tab-panel" data-tab="ai" hidden>
              <div class="cgm-field-grid two-col compact">
                <div class="cgm-field"><label>AI provider</label><select id="cgm-ob-provider"><option value="claude" ${String(settings.ai_provider||'claude')==='claude'?'selected':''}>Anthropic Claude</option><option value="openai" ${String(settings.ai_provider||'claude')==='openai'?'selected':''}>OpenAI</option></select></div>
                <div class="cgm-field"><label>API key</label><input id="cgm-ob-api-key" type="password" autocomplete="new-password" spellcheck="false" placeholder="Paste your API key"></div>
              </div>
              <div class="cgm-field-grid two-col compact">
                <div class="cgm-field"><label>Default page builder output</label><select id="cgm-ob-builder-mode">${builderSelectOptions(settings)}</select><div class="cgm-upgrade-note">Used by generated posts and pages unless you override it later.</div></div>
                <div class="cgm-field"><label>Suggested new cluster</label><input id="cgm-ob-new-cluster" type="text" placeholder="Use AI to suggest one extra cluster"></div>
              </div>
              <div class="cgm-inline-actions">
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-save-api">Save AI connection</button>
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-save-builder">Save builder preference</button>
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-auto-clusters">Auto-generate clusters</button>
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-suggest-new-cluster">Suggest new cluster</button>
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-add-suggested-cluster">Add suggested cluster</button>
              </div>
              <div class="cgm-help-plain cgm-onboarding-api-help"><strong>How to get your API key</strong><div class="cgm-provider-guides"><div class="cgm-provider-guide"><h4>OpenAI</h4><ol class="cgm-api-steps"><li>Sign in to your OpenAI account.</li><li>Open the API keys page in your OpenAI dashboard.</li><li>Create a new secret key and copy it immediately.</li><li>Paste the key into Contentgem and save the AI connection.</li></ol><p><a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer">Open OpenAI API keys ↗</a></p></div><div class="cgm-provider-guide"><h4>Claude (Anthropic)</h4><ol class="cgm-api-steps"><li>Sign in to your Anthropic Console account.</li><li>Go to API Keys in the Console.</li><li>Create a new key and copy it immediately.</li><li>Paste the key into Contentgem and save the AI connection.</li></ol><p><a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener noreferrer">Open Claude API keys ↗</a></p></div></div><p class="cgm-upgrade-note">Keep your API key secret. Contentgem stores the key in your WordPress settings so the plugin can generate analyses and drafts.</p></div>
              <div class="cgm-field">
                <label>Clusters <span class="cgm-ob-cluster-meta"><span id="cgm-ob-cluster-count">0</span><span id="cgm-ob-cluster-limit"></span></span></label>
                <textarea id="cgm-ob-clusters" rows="7" placeholder="One cluster per line">${escapeHtml((settings.clusters || []).join('\n'))}</textarea>
                <div class="cgm-upgrade-note" id="cgm-ob-cluster-hint" style="display:none"></div>
              </div>
              <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-prev-ai">Back</button><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-ob-next-ai">Continue</button></div>
            </div>
            <div class="cgm-tab-panel" data-tab="style" hidden>
              <div class="cgm-inline-actions">
                <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-suggest-keywords">Suggest keywords per cluster</button>
              </div>
              <div class="cgm-field-grid two-col compact">
                <div class="cgm-field"><label>Cluster for keyword suggestion</label><input id="cgm-ob-keyword-cluster" type="text" placeholder="Enter a new cluster or reuse the suggested one"></div>
                <div class="cgm-field"><label>&nbsp;</label><div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-suggest-keywords-single">Suggest keywords for new cluster</button></div></div>
              </div>
              <div class="cgm-field"><label>Cluster keywords</label><textarea id="cgm-ob-cluster-keywords" rows="6" placeholder="Format: Cluster: keyword 1, keyword 2">${escapeHtml(Object.entries(settings.cluster_keywords || {}).map(([k,v]) => `${k}: ${(Array.isArray(v)?v:[]).join(', ')}`).join('\n'))}</textarea></div>
              <div class="cgm-field-grid two-col compact">
                <div class="cgm-field"><label>Tone of voice</label><textarea id="cgm-ob-tone" rows="6" placeholder="Describe the writing style Contentgem should use.">${escapeHtml(settings.tone_of_voice || '')}</textarea></div>
                <div class="cgm-field"><label>Competitor domains</label><textarea id="cgm-ob-competitors" rows="6" placeholder="One domain per line">${escapeHtml((settings.competitor_domains || []).join('\n'))}</textarea></div>
              </div>
              <div class="cgm-inline-actions is-spread">
                <div>
                  <div class="cgm-upgrade-status" id="cgm-ob-status"></div>
                  <div id="cgm-ob-progress" class="cgm-progress-wrap"></div>
                </div>
                <div class="cgm-inline-actions">
                  <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-prev-style">Back</button>
                  <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ob-save-all">Save onboarding data</button>
                  <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-ob-complete">Complete onboarding</button>
                </div>
              </div>
            </div>
          `)}
        </div>
      </div>
    `;

    bindTabButtons(root, '#cgm-ob-tabs .cgm-tab-btn', '.cgm-tab-panel', 'profile');
    const langSelect = root.querySelector('#cgm-ob-language');
    const customInput = root.querySelector('#cgm-ob-language-custom');
    if (langSelect && customInput) langSelect.addEventListener('change', () => { customInput.style.display = langSelect.value === 'custom' ? '' : 'none'; });
    const statusEl = root.querySelector('#cgm-ob-status');
    const progressEl = root.querySelector('#cgm-ob-progress');
    const onboardingButtons = ['#cgm-ob-prev-style','#cgm-ob-save-all','#cgm-ob-complete','#cgm-ob-prev-ai','#cgm-ob-next-ai','#cgm-ob-next-profile'].map(sel => root.querySelector(sel)).filter(Boolean);
    const activate = value => root.querySelector(`#cgm-ob-tabs .cgm-tab-btn[data-tab="${value}"]`).click();
    function lockOnboarding(locked) { onboardingButtons.forEach(btn => { btn.disabled = !!locked; btn.classList.toggle('is-loading', !!locked); }); }

    // Cluster-limit UI for onboarding. Uses contentgemData.clusterLimit which
    // the PHP side populates from cg-limits.php (Free → 4, Growth/Unlimited → -1).
    (function wireClusterLimit() {
      const clustersField = root.querySelector('#cgm-ob-clusters');
      const countEl  = root.querySelector('#cgm-ob-cluster-count');
      const limitEl  = root.querySelector('#cgm-ob-cluster-limit');
      const hintEl   = root.querySelector('#cgm-ob-cluster-hint');
      if (!clustersField || !countEl || !limitEl || !hintEl) return;

      const data      = (window.contentgemData || {});
      // Live state — will be overwritten by the /plan-state REST call below.
      // This avoids the bug where a user activates a paid license after the
      // page already loaded with contentgemData.clusterLimit = 4 cached in.
      let limit       = typeof data.clusterLimit === 'number' ? data.clusterLimit : 4;
      let planLabel   = data.planLabel || 'Free';
      let upgradeUrl  = data.upgradeUrl || '';
      let isUnlimited = limit < 0;

      function updateLimitLabel() {
        limitEl.textContent = isUnlimited ? ' clusters (unlimited)' : ` of ${limit} clusters`;
        limitEl.style.marginLeft = '4px';
      }
      updateLimitLabel();

      // Refresh plan state from the server in case a license was just
      // activated. This is the fix for: "user activates Growth license
      // during onboarding, but the cluster-cap still says 4".
      (async function refreshPlanState() {
        try {
          const restBase = String(data.restUrl || '').replace(/\/$/, '');
          if (!restBase) return;
          const res = await fetch(restBase + '/plan-state', {
            credentials: 'same-origin',
            headers: { 'X-WP-Nonce': data.nonce || '' }
          });
          if (!res.ok) return;
          const json = await res.json();
          if (!json || typeof json !== 'object') return;
          // Only update if the server reports a different/better limit than
          // what we had. -1 (unlimited) always wins over a finite cap.
          const newLimit = typeof json.clusterLimit === 'number' ? json.clusterLimit : limit;
          if (newLimit !== limit) {
            limit       = newLimit;
            isUnlimited = limit < 0;
            planLabel   = json.planLabel || planLabel;
            upgradeUrl  = json.upgradeUrl || upgradeUrl;
            // Also update contentgemData so other code paths that read it
            // (e.g. Settings tab cluster-counter) pick up the fresh value.
            if (window.contentgemData) {
              window.contentgemData.clusterLimit = limit;
              window.contentgemData.plan         = json.plan || window.contentgemData.plan;
              window.contentgemData.planLabel    = planLabel;
            }
            updateLimitLabel();
            render();
          }
        } catch (e) {
          // Silent fail — we keep the cached value from page load.
        }
      })();

      function countLines(v) {
        return String(v || '')
          .split('\n')
          .map(s => s.trim())
          .filter(Boolean).length;
      }

      function render() {
        const n = countLines(clustersField.value);
        countEl.textContent = String(n);

        // Enforce cap by trimming the textarea live when Free users paste
        // more than the cap. We keep the first N lines (same rule as the
        // backend applies in post_onboarding_complete).
        if (!isUnlimited && n > limit) {
          const lines = clustersField.value.split('\n');
          const kept = [];
          let keptCount = 0;
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) { kept.push(line); continue; }
            if (keptCount >= limit) continue;
            kept.push(line);
            keptCount += 1;
          }
          clustersField.value = kept.join('\n');
          countEl.textContent = String(limit);
        }

        const current = countLines(clustersField.value);
        const atCap   = !isUnlimited && current >= limit;

        countEl.style.color = atCap ? '#f59e0b' : '';
        if (atCap) {
          const upgradeHtml = upgradeUrl
            ? ` <a href="${upgradeUrl}" target="_blank" rel="noopener noreferrer">Upgrade to Growth</a>`
            : '';
          hintEl.innerHTML = `<strong>${planLabel} plan limit reached.</strong> You can save up to ${limit} clusters on the ${planLabel} plan.${upgradeHtml}`;
          hintEl.style.display = '';
        } else if (!isUnlimited) {
          hintEl.innerHTML = `The ${planLabel} plan includes up to ${limit} clusters. Upgrade to add more.`;
          hintEl.style.display = '';
          hintEl.style.opacity = '0.75';
        } else {
          hintEl.style.display = 'none';
        }
      }

      clustersField.addEventListener('input', render);
      clustersField.addEventListener('paste', () => setTimeout(render, 0));
      // Also re-render after "Add suggested cluster" and "Suggest new cluster"
      // mutate the textarea programmatically.
      const suggestBtn = root.querySelector('#cgm-ob-suggest-new-cluster');
      const addBtn     = root.querySelector('#cgm-ob-add-suggested-cluster');
      if (suggestBtn) suggestBtn.addEventListener('click', () => setTimeout(render, 400));
      if (addBtn)     addBtn.addEventListener('click', () => setTimeout(render, 200));
      render();
    })();

    async function saveProfile() {
      await api('settings/niche', { method:'POST', body:{ niche: root.querySelector('#cgm-ob-niche').value, description: root.querySelector('#cgm-ob-description').value, language: langSelect.value, custom_language: customInput.value } });
    }
    async function saveApi() {
      const raw = root.querySelector('#cgm-ob-api-key').value || '';
      const apiKey = raw.trim().replace(/[•·●]+/g, '');
      if (!apiKey) return false;
      await api('settings/api-key', { method:'POST', body:{ api_key: apiKey, provider: root.querySelector('#cgm-ob-provider').value } });
      root.querySelector('#cgm-ob-api-key').value = '';
      return true;
    }
    async function saveClusters() {
      const clusters = normalizeList(root.querySelector('#cgm-ob-clusters').value.replace(/\n+/g,'\n'));
      await api('settings/clusters', { method:'POST', body:{ clusters, replace:true } });
      return clusters;
    }
    async function saveStyleBlock() {
      const keywordMap = buildKeywordMapFromText(root.querySelector('#cgm-ob-cluster-keywords').value);
      if (Object.keys(keywordMap).length) await api('settings/cluster-keywords', { method:'POST', body:{ cluster_keywords: keywordMap, replace:true } });
      await api('settings/tone-of-voice', { method:'POST', body:{ tone_of_voice: root.querySelector('#cgm-ob-tone').value } });
      await api('settings/competitor-domains', { method:'POST', body:{ competitor_domains: normalizeList(root.querySelector('#cgm-ob-competitors').value) } });
    }
    async function finalizeOnboarding(successMessage) {
      const clusters = await saveClusters();
      await saveStyleBlock();
      await api('onboarding/complete', { method:'POST', body:{ clusters, completed:true } });
      if (root) delete root.dataset.cgmUpgradeMode;
      state.settings = null;
      await loadSettings(true);
      renderStatus(statusEl, successMessage || 'Onboarding completed. Redirecting…');
      redirectToDashboard();
    }

    bind(root, '#cgm-ob-next-profile', 'click', async() => {
      activate('ai');
      try { await saveProfile(); renderStatus(statusEl, 'Site profile saved.'); } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not save the site profile yet. You can continue and save everything at the end.'), false); }
    });
    bind(root, '#cgm-ob-prev-ai', 'click', () => activate('profile'));
    bind(root, '#cgm-ob-next-ai', 'click', async() => {
      activate('style');
      try {
        await saveApi();
        const clusters = await saveClusters();
        const keywordField = root.querySelector('#cgm-ob-cluster-keywords');
        if (keywordField) {
          const current = buildKeywordMapFromText(keywordField.value || '');
          const filtered = (clusters || []).map(cluster => current[cluster] ? `${cluster}: ${current[cluster].join(', ')}` : '').filter(Boolean);
          keywordField.value = filtered.join('\n');
        }
        renderStatus(statusEl, 'AI setup saved.');
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not save the AI setup yet. You can continue and save everything at the end.'), false); }
    });
    bind(root, '#cgm-ob-prev-style', 'click', () => activate('ai'));
    bind(root, '#cgm-ob-save-api', 'click', async() => {
      try {
        const saved = await saveApi();
        renderStatus(statusEl, saved ? 'AI connection saved.' : 'No new API key was entered, so the existing connection was kept.');
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not save the AI connection.'), false); }
    });
    bind(root, '#cgm-ob-save-builder', 'click', async() => {
      try {
        const mode = root.querySelector('#cgm-ob-builder-mode')?.value || 'none';
        await saveBuilderModeViaApi(mode);
        renderStatus(statusEl, `Default builder set to ${builderLabel(mode)}.`);
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not save the default page builder.'), false); }
    });
    bind(root, '#cgm-ob-suggest-new-cluster', 'click', async() => {
      try {
        await saveProfile();
        const data = await api('settings/suggest-single-cluster', { method:'POST', body:{ niche: root.querySelector('#cgm-ob-niche')?.value || '', description: root.querySelector('#cgm-ob-description')?.value || '' } });
        const cluster = String(data.cluster || '').trim();
        if (!cluster) throw new Error('No cluster suggestion returned.');
        const clusterInput = root.querySelector('#cgm-ob-new-cluster');
        const keywordClusterInput = root.querySelector('#cgm-ob-keyword-cluster');
        if (clusterInput) clusterInput.value = cluster;
        if (keywordClusterInput) keywordClusterInput.value = cluster;
        renderStatus(statusEl, `Suggested cluster loaded: ${cluster}.`);
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not suggest a new cluster.'), false); }
    });
    bind(root, '#cgm-ob-add-suggested-cluster', 'click', async() => {
      try {
        const clusterInput = root.querySelector('#cgm-ob-new-cluster');
        const field = root.querySelector('#cgm-ob-clusters');
        const cluster = String(clusterInput?.value || '').trim();
        if (!cluster) throw new Error('Suggest or enter a cluster first.');
        const existing = normalizeList((field && field.value || '').replace(/\n+/g,'\n'));
        if (!existing.map(v => String(v).toLowerCase()).includes(cluster.toLowerCase())) {
          field.value = existing.concat([cluster]).join('\n');
        }
        const keywordClusterInput = root.querySelector('#cgm-ob-keyword-cluster');
        if (keywordClusterInput && !keywordClusterInput.value) keywordClusterInput.value = cluster;
        renderStatus(statusEl, `Added cluster: ${cluster}`);
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not add the suggested cluster.'), false); }
    });
    bind(root, '#cgm-ob-auto-clusters', 'click', async() => {
      try {
        await saveProfile();
        const data = await api('suggest-clusters', { method:'POST', body:{} });
        root.querySelector('#cgm-ob-clusters').value = (data.clusters || []).join('\n');
        renderStatus(statusEl, `Generated ${Array.isArray(data.clusters) ? data.clusters.length : 0} clusters.`);
        activate('ai');
      } catch (err) {
        renderStatus(statusEl, friendlyErrorMessage(err, 'Could not generate clusters.'), false);
      }
    });
    bind(root, '#cgm-ob-add-cluster', 'click', async() => {
      try {
        await saveProfile();
        const field = root.querySelector('#cgm-ob-clusters');
        const existing = normalizeList((field && field.value || '').replace(/\n+/g,'\n'));
        let nextCluster = '';
        try {
          const data = await api('suggest-clusters', { method:'POST', body:{} });
          const suggestions = Array.isArray(data.clusters) ? data.clusters : [];
          const existingLower = new Set(existing.map(v => String(v).toLowerCase()));
          nextCluster = suggestions.find(v => !existingLower.has(String(v).toLowerCase())) || '';
        } catch (innerErr) {}
        if (!nextCluster) {
          const niche = String(root.querySelector('#cgm-ob-niche')?.value || '').trim();
          const seed = niche ? niche.split(/\s+/).slice(0, 3).join(' ') : 'Related Topic';
          nextCluster = existing.length ? `${seed} ${existing.length + 1}` : seed;
        }
        if (field) {
          field.value = existing.concat([nextCluster]).filter(Boolean).join('\n');
        }
        renderStatus(statusEl, `Added cluster: ${nextCluster}`);
      } catch (err) {
        renderStatus(statusEl, friendlyErrorMessage(err, 'Could not add another cluster.'), false);
      }
    });
    bind(root, '#cgm-ob-suggest-keywords', 'click', async() => {
      try {
        await saveProfile();
        const clusters = await saveClusters();
        if (!Array.isArray(clusters) || !clusters.length) {
          renderStatus(statusEl, 'Add at least one cluster in step 2 before suggesting keywords.', false);
          return;
        }
        const data = await api('settings/suggest-cluster-keywords', {
          method:'POST',
          body:{
            clusters,
            niche: root.querySelector('#cgm-ob-niche')?.value || '',
            description: root.querySelector('#cgm-ob-description')?.value || ''
          }
        });
        const map = data.cluster_keywords || data.keywords || {};
        const lines = Object.entries(map).map(([k,v]) => `${k}: ${(Array.isArray(v)?v:[]).join(', ')}`);
        root.querySelector('#cgm-ob-cluster-keywords').value = lines.join('\n');
        renderStatus(statusEl, lines.length ? 'Keyword suggestions loaded for the current onboarding clusters.' : 'No keyword suggestions were returned for the current onboarding clusters.', !!lines.length);
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not suggest keywords for the current onboarding clusters.'), false); }
    });
    bind(root, '#cgm-ob-suggest-keywords-single', 'click', async() => {
      try {
        await saveProfile();
        const cluster = String(root.querySelector('#cgm-ob-keyword-cluster')?.value || root.querySelector('#cgm-ob-new-cluster')?.value || '').trim();
        if (!cluster) {
          renderStatus(statusEl, 'Enter or suggest a cluster first.', false);
          return;
        }
        const data = await api('settings/suggest-cluster-keywords', {
          method:'POST',
          body:{
            clusters:[cluster],
            niche: root.querySelector('#cgm-ob-niche')?.value || '',
            description: root.querySelector('#cgm-ob-description')?.value || ''
          }
        });
        const map = data.cluster_keywords || data.keywords || {};
        const keywords = map[cluster] || map[Object.keys(map)[0]] || [];
        upsertKeywordLine(root.querySelector('#cgm-ob-cluster-keywords'), cluster, keywords);
        renderStatus(statusEl, Array.isArray(keywords) && keywords.length ? `Keyword suggestions loaded for ${cluster}.` : `No keyword suggestions were returned for ${cluster}.`, !!(Array.isArray(keywords) && keywords.length));
      } catch (err) { renderStatus(statusEl, friendlyErrorMessage(err, 'Could not suggest keywords for the selected cluster.'), false); }
    });
    async function runOnboardingFinalize(modeLabel) {
      const totalSteps = 6;
      try {
        lockOnboarding(true);
        clearProgress(progressEl);
        renderProgress(progressEl, 0, totalSteps, 'Starting');
        renderStatus(statusEl, `${modeLabel} in progress…`);
        await saveProfile();
        renderProgress(progressEl, 1, totalSteps, 'Saved site profile');
        await saveApi();
        await saveBuilderModeViaApi(root.querySelector('#cgm-ob-builder-mode')?.value || 'none');
        renderProgress(progressEl, 2, totalSteps, 'Saved AI connection and builder preference');
        const clusters = await saveClusters();
        renderProgress(progressEl, 3, totalSteps, 'Saved clusters');
        await saveStyleBlock();
        renderProgress(progressEl, 4, totalSteps, 'Saved keywords, tone and competitors');
        await api('onboarding/complete', { method:'POST', body:{ clusters, completed:true } });
        renderProgress(progressEl, 5, totalSteps, 'Marked onboarding complete');
        if (root) delete root.dataset.cgmUpgradeMode;
        state.settings = null;
        await loadSettings(true);
        renderProgress(progressEl, 6, totalSteps, 'Redirecting to dashboard');
        renderStatus(statusEl, `${modeLabel} completed. Redirecting to the dashboard…`);
        redirectToDashboard(500);
      } catch (err) {
        clearProgress(progressEl);
        renderStatus(statusEl, friendlyErrorMessage(err, `Could not ${modeLabel.toLowerCase()}.`), false);
      } finally {
        lockOnboarding(false);
      }
    }

    bind(root, '#cgm-ob-save-all', 'click', async() => { await runOnboardingFinalize('Onboarding data save'); });
    bind(root, '#cgm-ob-complete', 'click', async() => { await runOnboardingFinalize('Onboarding'); });
  }


  function structureEntryRow(entry = {}, kind = 'list') {
    const title = escapeHtml(entry.title || '');
    const url = escapeHtml(entry.url || '');
    return `
      <div class="cgm-structure-manual-row">
        <input type="text" class="cgm-structure-manual-title" placeholder="Page title" value="${title}">
        <input type="url" class="cgm-structure-manual-url" placeholder="https://example.com/page/" value="${url}">
        <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-remove">Remove</button>
      </div>`;
  }

  function bindStructureManualList(container) {
    if (!container || container.dataset.bound === '1') return;
    container.dataset.bound = '1';
    container.addEventListener('click', (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.classList.contains('cgm-structure-remove')) {
        const row = target.closest('.cgm-structure-manual-row');
        if (row) row.remove();
      }
    });
  }

  function addStructureManualRow(container, entry = {}, kind = 'list') {
    if (!container) return;
    bindStructureManualList(container);
    container.insertAdjacentHTML('beforeend', structureEntryRow(entry, kind));
  }

  function collectStructureManualRows(container) {
    if (!container) return [];
    return Array.from(container.querySelectorAll('.cgm-structure-manual-row')).map(row => ({
      page_id: 0,
      title: String((row.querySelector('.cgm-structure-manual-title') || {}).value || '').trim(),
      url: String((row.querySelector('.cgm-structure-manual-url') || {}).value || '').trim(),
      priority: 80
    })).filter(item => item.title || item.url);
  }

  function firstStructureManualRow(container, fallbackPriority = 90) {
    const rows = collectStructureManualRows(container);
    if (!rows.length) return { page_id: 0, title: '', url: '', priority: fallbackPriority };
    return Object.assign({ page_id: 0, priority: fallbackPriority }, rows[0]);
  }


  const SITE_STRUCTURE_TEMPLATES = {
    custom: [],
    saas: [
      { id:'home', type:'homepage', title:'Home', url:'/', parent:'', priority:100 },
      { id:'features', type:'group', title:'Features', url:'', parent:'home', priority:90 },
      { id:'service-1', type:'service', title:'Feature page', url:'', parent:'features', priority:85 },
      { id:'use-cases', type:'group', title:'Use cases', url:'', parent:'home', priority:82 },
      { id:'case-1', type:'case', title:'Case study', url:'', parent:'use-cases', priority:76 },
      { id:'about', type:'about', title:'About us', url:'', parent:'home', priority:70 },
    ],
    agency: [
      { id:'home', type:'homepage', title:'Home', url:'/', parent:'', priority:100 },
      { id:'services', type:'group', title:'Services', url:'', parent:'home', priority:92 },
      { id:'service-seo', type:'service', title:'SEO service page', url:'', parent:'services', priority:86 },
      { id:'service-ads', type:'service', title:'Ads service page', url:'', parent:'services', priority:84 },
      { id:'cases', type:'group', title:'Case studies', url:'', parent:'home', priority:80 },
      { id:'case-1', type:'case', title:'Case study', url:'', parent:'cases', priority:78 },
      { id:'about', type:'about', title:'About us', url:'', parent:'home', priority:72 },
    ],
    affiliate: [
      { id:'home', type:'homepage', title:'Home', url:'/', parent:'', priority:100 },
      { id:'best-guides', type:'group', title:'Best X guides', url:'', parent:'home', priority:88 },
      { id:'comparisons', type:'category', title:'Comparisons', url:'', parent:'home', priority:84 },
      { id:'reviews', type:'category', title:'Reviews', url:'', parent:'home', priority:82 },
      { id:'pillar', type:'pillar', title:'Pillar page', url:'', parent:'home', priority:80 },
      { id:'about', type:'about', title:'About us', url:'', parent:'home', priority:68 },
    ],
    publisher: [
      { id:'home', type:'homepage', title:'Home', url:'/', parent:'', priority:100 },
      { id:'categories', type:'group', title:'Categories', url:'', parent:'home', priority:90 },
      { id:'category-1', type:'category', title:'Category page', url:'', parent:'categories', priority:84 },
      { id:'pillar', type:'pillar', title:'Pillar page', url:'', parent:'home', priority:82 },
      { id:'about', type:'about', title:'About us', url:'', parent:'home', priority:66 },
    ]
  };

  function makeStructureNode(overrides = {}) {
    return Object.assign({ id:`node_${Date.now()}_${Math.random().toString(36).slice(2,7)}`, type:'custom', title:'', url:'', parent:'', priority:60, page_id:0 }, overrides || {});
  }

  function flattenSiteStructureTargets(structure) {
    const out = [];
    if (structure && structure.homepage && (structure.homepage.url || structure.homepage.title)) out.push(Object.assign({ type:'homepage', parent:'' }, structure.homepage));
    if (structure && structure.about_page && (structure.about_page.url || structure.about_page.title)) out.push(Object.assign({ type:'about', parent:'' }, structure.about_page));
    (Array.isArray(structure?.service_pages) ? structure.service_pages : []).forEach(item => out.push(Object.assign({ type:'service', parent:'' }, item)));
    (Array.isArray(structure?.case_studies) ? structure.case_studies : []).forEach(item => out.push(Object.assign({ type:'case', parent:'' }, item)));
    (Array.isArray(structure?.nodes) ? structure.nodes : []).forEach(item => out.push(item));
    return out;
  }

  function renderStructureTree(container, nodes, sitePages) {
    if (!container) return;
    const list = Array.isArray(nodes) ? nodes.slice() : [];
    const byParent = new Map();
    list.forEach((node, index) => {
      if (typeof node.order_index !== 'number' || Number.isNaN(node.order_index)) node.order_index = index;
      const parent = String(node.parent || '');
      if (!byParent.has(parent)) byParent.set(parent, []);
      byParent.get(parent).push(node);
    });
    byParent.forEach(arr => arr.sort((a,b) => Number(a.order_index||0) - Number(b.order_index||0)));
    const pageOptions = (Array.isArray(sitePages) ? sitePages : []).map(p => ({ id:String(p.id), title:p.title || ('Page ' + p.id), url:p.url || '' }));
    const renderPageSelect = (node) => `<select class="cgm-structure-inline-select" data-inline-key="page_id" data-node-id="${escapeHtml(node.id)}"><option value="">Structure only</option>${pageOptions.map(opt => `<option value="${escapeHtml(opt.id)}" ${String(node.page_id||'')===String(opt.id)?'selected':''}>${escapeHtml(opt.title)}</option>`).join('')}</select>`;
    const renderBranch = (parent = '', level = 0) => {
      const items = byParent.get(String(parent)) || [];
      if (!items.length) return '';
      return `<div class="cgm-structure-tree-level" data-parent-id="${escapeHtml(String(parent))}">${items.map(node => {
        const linkedPage = pageOptions.find(opt => String(opt.id) === String(node.page_id || ''));
        const helper = linkedPage ? `Linked page: ${escapeHtml(linkedPage.title)}` : 'This is a structure-only page until you link it.';
        return `
        <div class="cgm-structure-tree-node" draggable="true" data-node-id="${escapeHtml(node.id)}" data-parent-id="${escapeHtml(String(node.parent||''))}" data-level="${level}">
          <div class="cgm-structure-tree-row">
            <div class="cgm-structure-node-main">
              <input class="cgm-structure-inline-title" data-inline-key="title" data-node-id="${escapeHtml(node.id)}" type="text" value="${escapeHtml(node.title || '')}" placeholder="Page title">
              <div class="cgm-structure-node-meta">${helper}</div>
            </div>
            <div class="cgm-structure-node-link">${renderPageSelect(node)}</div>
            <div class="cgm-structure-tree-node__actions">
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-move-up" data-node-id="${escapeHtml(node.id)}">Up</button>
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-move-down" data-node-id="${escapeHtml(node.id)}">Down</button>
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-make-child" data-node-id="${escapeHtml(node.id)}">Make child</button>
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-move-top" data-node-id="${escapeHtml(node.id)}">Top level</button>
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-add-child" data-parent-id="${escapeHtml(node.id)}">Add child</button>
              <button type="button" class="cgm-btn cgm-btn--secondary cgm-structure-remove-node" data-node-id="${escapeHtml(node.id)}">Delete</button>
            </div>
          </div>
          ${renderBranch(node.id, level + 1)}
        </div>`;
      }).join('')}</div>`;
    };
    const roots = renderBranch('', 0);
    container.innerHTML = `
      <div class="cgm-help-plain"><strong>Your structure</strong><p>Keep this simple: create top-level pages first, then add child pages underneath them. You can drag items, but the buttons are the easiest way to build the hierarchy.</p></div>
      ${roots || '<p class="cgm-empty-note">No pages in your structure yet. Apply a recommended structure or add your first top-level page.</p>'}
      <div class="cgm-structure-dropzone" data-parent-id="">Drop here to move a page back to top level</div>`;
  }

  function renderSettingsPage(page, settings) {
    if (page.dataset.cgmUpgrade === 'settings-v39') return;
    page.dataset.cgmUpgrade = 'settings-v39';
    ensurePageHeader(page, 'Settings', 'Control your full Contentgem setup from one compact workspace.');
    const clusters = Array.isArray(settings.clusters) ? settings.clusters : [];
    const clusterKeywordLines = Object.entries(settings.cluster_keywords || {}).map(([k,v]) => `${k}: ${(Array.isArray(v)?v:[]).join(', ')}`).join('\n');
    const indexNow = settings.indexnow_status && typeof settings.indexnow_status === 'object'
      ? settings.indexnow_status
      : {
          active: false,
          key: '',
          key_url: '',
          last_ping_url: '',
          last_ping_time: '',
          recent_log: [],
          public_base_url: String((window.contentgemData && window.contentgemData.siteUrl) || '').replace(/\/$/, ''),
          verification_path: '',
        };
    const indexNowLogs = Array.isArray(indexNow.recent_log) ? indexNow.recent_log : [];
    const indexNowLogHtml = indexNowLogs.length
      ? `<div class="cgm-indexnow-log-list">${indexNowLogs.map((entry) => `<div class="cgm-indexnow-log-item ${entry && entry.success ? 'is-success' : 'is-error'}"><div><strong>${entry && entry.success ? 'Ping accepted' : 'Ping failed'}</strong><span>${escapeHtml(String((entry && entry.url) || ''))}</span></div><small>${escapeHtml(String((entry && entry.time) || ''))}</small></div>`).join('')}</div>`
      : '<div class="cgm-indexnow-empty">No IndexNow pings logged yet.</div>';
    page.insertAdjacentHTML('beforeend', card('', `
      <div class="cgm-step-tabs cgm-settings-tabs">
        <button type="button" class="cgm-tab-btn" data-tab="profile">Profile</button>
        <button type="button" class="cgm-tab-btn" data-tab="ai">AI & clusters</button>
        <button type="button" class="cgm-tab-btn" data-tab="keywords">Keywords</button>
        <button type="button" class="cgm-tab-btn" data-tab="style">Tone & competitors</button>
        <button type="button" class="cgm-tab-btn" data-tab="structure">Site structure</button>
        <button type="button" class="cgm-tab-btn" data-tab="advanced">Advanced</button>
      </div>
      <div class="cgm-tab-panel" data-tab="profile">
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>Niche</label><input id="cgm-set-niche" type="text" value="${escapeHtml(settings.niche || '')}"></div>
          <div class="cgm-field"><label>Default content language</label><select id="cgm-set-language">${languageOptions.filter(o=>o.value!=='auto').map(opt => `<option value="${opt.value}" ${String(settings.content_language||'en')===opt.value?'selected':''}>${escapeHtml(opt.label)}</option>`).join('')}</select><input id="cgm-set-language-custom" type="text" value="${escapeHtml(settings.content_language_custom || '')}" placeholder="Custom language" ${String(settings.content_language||'')==='custom' ? '' : 'style="display:none"'}></div>
        </div>
        <div class="cgm-field"><label>Niche description</label><textarea id="cgm-set-description" rows="4">${escapeHtml(settings.niche_description || '')}</textarea></div>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-profile">Save profile</button><div class="cgm-upgrade-status" id="cgm-set-status-profile"></div></div>
      </div>
      <div class="cgm-tab-panel" data-tab="ai" hidden>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>AI provider</label><select id="cgm-set-provider"><option value="claude" ${String(settings.ai_provider||'claude')==='claude'?'selected':''}>Anthropic Claude</option><option value="openai" ${String(settings.ai_provider||'claude')==='openai'?'selected':''}>OpenAI</option></select></div>
          <div class="cgm-field"><label>API key</label><input id="cgm-set-api-key" type="password" autocomplete="new-password" spellcheck="false" placeholder="Paste a new API key to update the connection"></div>
        </div>
        <div class="cgm-upgrade-note">Current status: ${settings.api_key_set ? 'Connected' : 'No API key saved'} · Provider: ${escapeHtml(settings.ai_provider || 'claude')}</div>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>Default page builder output</label><select id="cgm-set-builder-mode">${builderSelectOptions(settings)}</select><div class="cgm-upgrade-note">This default is used for generated posts and pages.</div></div>
          <div class="cgm-field"><label>Suggested new cluster</label><input id="cgm-set-new-cluster" type="text" placeholder="Use AI to suggest one extra cluster"></div>
        </div>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-api">Save AI connection</button><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-save-builder">Save builder preference</button><div class="cgm-upgrade-status" id="cgm-set-status-api"></div></div>
        <div class="cgm-inline-actions">
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-clusters-auto">Auto-detect existing clusters</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-clusters-ai">Auto-generate clusters</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-clusters-suggest-one">Suggest new cluster</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-clusters-add-suggested">Add suggested cluster</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-clusters-revert">Revert clusters</button>
        </div>
        <div class="cgm-field">
          <label>Clusters <span class="cgm-ob-cluster-meta"><span id="cgm-set-cluster-count">0</span><span id="cgm-set-cluster-limit"></span></span></label>
          <textarea id="cgm-set-clusters" rows="7">${escapeHtml(clusters.join('\n'))}</textarea>
          <div class="cgm-upgrade-note" id="cgm-set-cluster-hint" style="display:none"></div>
        </div>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-clusters">Save clusters</button><div class="cgm-upgrade-status" id="cgm-set-status-clusters"></div></div>
      </div>
      <div class="cgm-tab-panel" data-tab="keywords" hidden>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-suggest-cluster-keywords">Suggest keywords for all clusters</button></div>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>Cluster for keyword suggestion</label><input id="cgm-set-keyword-cluster" type="text" placeholder="Enter a new or existing cluster"></div>
          <div class="cgm-field"><label>&nbsp;</label><div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-suggest-single-cluster-keywords">Suggest keywords for new cluster</button></div></div>
        </div>
        <div class="cgm-field"><label>Keywords per cluster</label><textarea id="cgm-set-cluster-keywords" rows="10">${escapeHtml(clusterKeywordLines)}</textarea></div>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-cluster-keywords">Save keywords</button><div class="cgm-upgrade-status" id="cgm-set-status-keywords"></div></div>
      </div>
      <div class="cgm-tab-panel" data-tab="style" hidden>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>Tone of voice</label><textarea id="cgm-set-tone" rows="8">${escapeHtml(settings.tone_of_voice || '')}</textarea></div>
          <div class="cgm-field"><label>Competitor domains</label><textarea id="cgm-set-competitors" rows="8">${escapeHtml((settings.competitor_domains || []).join('\n'))}</textarea></div>
        </div>
        <div class="cgm-inline-actions">
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-analyze-tone">Analyze latest 5 posts</button>
          <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-tone">Save tone of voice</button>
          <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-competitors">Save competitor domains</button>
          <div class="cgm-upgrade-status" id="cgm-set-status-tone"></div>
          <div class="cgm-upgrade-status" id="cgm-set-status-competitors"></div>
        </div>
        <div class="cgm-field-grid two-col compact" style="margin-top:16px">
          <div class="cgm-field">
            <label>Google Search Console Client ID</label>
            <input id="cgm-gsc-client-id" type="text" value="${escapeHtml(settings.gsc_client_id || '')}" placeholder="Paste your Google OAuth Client ID">
            <div class="cgm-upgrade-note">Saved: ${settings.gsc_client_id_set ? 'Yes' : 'No'}</div>
          </div>
          <div class="cgm-field">
            <label>Google Search Console Client Secret</label>
            <input id="cgm-gsc-client-secret" type="password" value="${escapeHtml(settings.gsc_client_secret_mask || '')}" autocomplete="new-password" placeholder="Paste your Google OAuth Client Secret">
            <div class="cgm-upgrade-note">Connection status: ${settings.gsc_connected ? 'Connected' : 'Not connected'}</div>
          </div>
        </div>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field">
            <label>Selected GSC property</label>
            <select id="cgm-gsc-site"><option value="${escapeHtml(settings.gsc_site_url || '')}">${escapeHtml(settings.gsc_site_url || 'Select property after connecting')}</option></select>
          </div>
          <div class="cgm-field">
            <label>&nbsp;</label>
            <div class="cgm-inline-actions">
              <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-gsc-creds">Save GSC credentials</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-connect-gsc">Connect GSC</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-load-gsc-sites">Load properties</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-save-gsc-site">Save property</button>
            </div>
          </div>
        </div>
        <div class="cgm-inline-actions"><div class="cgm-upgrade-status" id="cgm-set-status-gsc"></div></div>
        <div class="cgm-gsc-wizard-note">
          <details class="cgm-help-accordion" open>
            <summary>How to find your Google Cloud Client ID and Client Secret</summary>
            <div class="cgm-help-accordion__content">
              <p>Open Google Cloud Console and select the project connected to this Search Console integration.</p>
              <ol class="cgm-gsc-steps"><li>Go to <strong>APIs &amp; Services</strong> → <strong>Credentials</strong>.</li><li>Open your <strong>OAuth 2.0 Client ID</strong> and make sure the type is <strong>Web application</strong>.</li><li>Copy the <strong>Client ID</strong> and paste it into Contentgem.</li><li>Create or reveal a <strong>Client Secret</strong> and paste it into Contentgem.</li><li>Make sure the <strong>Authorized redirect URI</strong> in Google Cloud exactly matches the one below.</li><li>Save the credentials in Contentgem, then click <strong>Connect GSC</strong>.</li></ol>
            </div>
          </details>
          <div class="cgm-upgrade-note">Authorized redirect URI: <code id="cgm-gsc-redirect-uri">${escapeHtml(settings.gsc_redirect_uri || "")}</code> <button type="button" class="cgm-btn cgm-btn--ghost" id="cgm-copy-gsc-uri">Copy</button></div>
          <details class="cgm-help-accordion">
            <summary>Last OAuth debug</summary>
            <pre class="cgm-help-accordion__content" id="cgm-gsc-debug">${escapeHtml(JSON.stringify(settings.gsc_debug || { redirect_uri: settings.gsc_redirect_uri || '' }, null, 2))}</pre>
          </details>
        </div>
      </div>
      <div class="cgm-tab-panel" data-tab="structure" hidden>
        <div class="cgm-structure-intro">
          <h3>Ideal structure</h3>
          <p class="cgm-upgrade-note">Use this feature to define the most important pages on your website. Contentgem uses these pages as priority internal link targets together with your pillar pages and clusters.</p>
        </div>
        <div class="cgm-field-grid two-col compact">
          <div class="cgm-field"><label>Recommended structure</label><select id="cgm-structure-template"><option value="custom">Custom</option><option value="saas">SaaS website</option><option value="agency">Agency website</option><option value="affiliate">Affiliate SEO site</option><option value="publisher">Blog / publisher</option></select><div class="cgm-upgrade-note">Start from the recommended structure and then adjust it for your own website.</div></div>
          <div class="cgm-field"><label>&nbsp;</label><div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-apply-structure-template">Apply recommended structure</button><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-reset-structure-template">Start from scratch</button></div></div>
        </div>
        <div class="cgm-field"><label>Your structure</label><div class="cgm-upgrade-note">Build your main pages first, then create child pages underneath them. The hierarchy buttons are the easiest way to structure your site.</div><div id="cgm-structure-tree" class="cgm-structure-tree"></div><div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-add-structure-node">Add top-level page</button></div></div>
        <div class="cgm-help-plain"><strong>How Contentgem uses your structure</strong><p>These pages are treated as your core website pages. Contentgem will prioritize them when suggesting and inserting internal links together with your pillar pages and topic clusters.</p></div>
        <div class="cgm-inline-actions"><button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-structure">Save site structure</button><div class="cgm-upgrade-status" id="cgm-set-status-structure"></div></div>
      </div>
      <div class="cgm-tab-panel" data-tab="advanced" hidden>
        <div class="cgm-upgrade-note">Onboarding complete: <strong>${settings.onboarding_complete ? 'Yes' : 'No'}</strong></div>
        <div class="cgm-advanced-grid" style="margin-top:16px">
          <div class="cgm-setting-card">
            <label class="cgm-toggle-row" for="cgm-set-show-sources">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-show-sources" ${settings.show_source_list ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy">
                <strong>Show source list in AI outputs</strong>
                <small>Show compact citations or code file references when supported by the task.</small>
              </span>
            </label>
          </div>
          <div class="cgm-setting-card">
            <label class="cgm-toggle-row" for="cgm-set-token-opt">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-token-opt" ${settings.enable_token_optimization !== false ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy">
                <strong>Enable token optimization</strong>
                <small>Uses model routing, compact outputs and prompt-cache-friendly request structures.</small>
              </span>
            </label>
          </div>
          <div class="cgm-setting-card">
            <label class="cgm-toggle-row" for="cgm-set-fact-check">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-fact-check" ${settings.enable_fact_check ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy">
                <strong>Enable fact-check validation</strong>
                <small>Runs a cautious verification pass to reduce unsupported claims in generated output. May increase token usage.</small>
              </span>
            </label>
          </div>
          <div class="cgm-setting-card">
            <label class="cgm-toggle-row" for="cgm-set-grounding">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-grounding" ${settings.enable_full_source_grounding ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy">
                <strong>Integrate analyses with the full codebase</strong>
                <small>Recommended for technical analysis, patch plans and architecture work. May use more tokens.</small>
              </span>
            </label>
          </div>
          <div class="cgm-setting-card">
            <label for="cgm-set-openai-model">Preferred OpenAI model</label>
            <select id="cgm-set-openai-model">
              <option value="gpt-5.4-mini" ${String(settings.openai_default_model||'gpt-5.4-mini')==='gpt-5.4-mini'?'selected':''}>gpt-5.4-mini</option>
              <option value="gpt-5.4" ${String(settings.openai_default_model||'')==='gpt-5.4'?'selected':''}>gpt-5.4</option>
              <option value="gpt-5.4-nano" ${String(settings.openai_default_model||'')==='gpt-5.4-nano'?'selected':''}>gpt-5.4-nano</option>
            </select>
          </div>
          <div class="cgm-setting-card">
            <label for="cgm-set-reasoning-profile">Reasoning profile</label>
            <select id="cgm-set-reasoning-profile">
              <option value="minimal" ${String(settings.openai_reasoning_profile||'')==='minimal'?'selected':''}>Minimal</option>
              <option value="balanced" ${String(settings.openai_reasoning_profile||'balanced')==='balanced'?'selected':''}>Balanced</option>
              <option value="deep" ${String(settings.openai_reasoning_profile||'')==='deep'?'selected':''}>Deep</option>
            </select>
          </div>
          <div class="cgm-setting-card cgm-setting-card--stack">
            <label class="cgm-toggle-row" for="cgm-set-show-token-stats">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-show-token-stats" ${settings.openai_show_token_stats ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy"><strong>Show token stats in advanced outputs</strong></span>
            </label>
            <label class="cgm-toggle-row" for="cgm-set-enable-flex">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-enable-flex" ${settings.openai_enable_flex ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy"><strong>Allow flex processing</strong></span>
            </label>
            <label class="cgm-toggle-row" for="cgm-set-enable-batch">
              <span class="cgm-toggle-switch">
                <input type="checkbox" id="cgm-set-enable-batch" ${settings.openai_enable_batch ? 'checked' : ''}>
                <span class="cgm-toggle-ui" aria-hidden="true"></span>
              </span>
              <span class="cgm-toggle-copy"><strong>Allow batch processing for non-urgent tasks</strong></span>
            </label>
          </div>
        </div>
        <div class="cgm-settings-duo" style="margin-top:16px">
          <div class="cgm-help-plain cgm-settings-surface">
            <strong>Codebase grounding status</strong>
            <div id="cgm-codebase-status">${settings.codebase_status && settings.codebase_status.available ? `Indexed files: <strong>${settings.codebase_status.file_count || 0}</strong> · Last refresh: <strong>${escapeHtml(settings.codebase_status.built_at || 'Unknown')}</strong>` : 'No current codebase index available yet.'}</div>
            <div class="cgm-inline-actions" style="margin-top:12px">
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-reindex-codebase">Refresh code index</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-preview-grounding">Preview technical context</button>
            </div>
            <pre id="cgm-codebase-preview" class="cgm-code-preview" hidden></pre>
          </div>
          <div class="cgm-help-plain cgm-settings-surface cgm-indexnow-surface">
            <div class="cgm-settings-surface__head">
              <strong>IndexNow</strong>
              <span class="cgm-indexnow-pill ${indexNow.active ? 'is-active' : ''}" id="cgm-indexnow-active">${indexNow.active ? 'Active' : 'Inactive'}</span>
            </div>
            <p class="cgm-upgrade-note">Submit newly published or updated URLs directly to IndexNow-compatible search engines and verify that your public key file is reachable.</p>
            <div class="cgm-indexnow-summary">
              <div class="cgm-indexnow-stat"><span>Verification file</span><strong id="cgm-indexnow-path">${escapeHtml(indexNow.verification_path || 'Not generated yet')}</strong></div>
              <div class="cgm-indexnow-stat"><span>Last ping</span><strong id="cgm-indexnow-last-time">${escapeHtml(indexNow.last_ping_time || 'Not yet')}</strong></div>
            </div>
            <div class="cgm-field">
              <label>Verification file URL</label>
              <input id="cgm-indexnow-key-url" type="text" readonly value="${escapeHtml(indexNow.key_url || '')}" placeholder="Generate or refresh the key first">
            </div>
            <div class="cgm-field-grid two-col compact">
              <div class="cgm-field"><label>Homepage ping target</label><input id="cgm-indexnow-home-url" type="text" readonly value="${escapeHtml((window.contentgemData && window.contentgemData.siteUrl) || indexNow.public_base_url || '')}"></div>
              <div class="cgm-field"><label>Manual URL ping</label><input id="cgm-indexnow-manual-url" type="url" value="${escapeHtml((window.contentgemData && window.contentgemData.siteUrl) || indexNow.public_base_url || '')}" placeholder="https://example.com/page/"></div>
            </div>
            <div class="cgm-inline-actions">
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-indexnow-refresh">Refresh status</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-indexnow-copy">Copy key URL</button>
              <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-indexnow-regenerate">Regenerate key</button>
              <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-indexnow-ping-home">Ping homepage</button>
              <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-indexnow-ping-manual">Ping manual URL</button>
            </div>
            <div class="cgm-upgrade-status" id="cgm-set-status-indexnow"></div>
            <div id="cgm-indexnow-log" class="cgm-indexnow-log">${indexNowLogHtml}</div>
          </div>
        </div>
        <div class="cgm-inline-actions" style="margin-top:16px">
          <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-save-ai-system">Save AI system settings</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-mark-onboarding">Mark onboarding complete</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-hard-reset">Hard reset plugin suggestions</button>
          <div class="cgm-upgrade-status" id="cgm-set-status-extra"></div>
        </div>
      </div>
    `, 'cgm-settings-shell'));

    bindTabButtons(page, '.cgm-settings-tabs .cgm-tab-btn', '.cgm-tab-panel', 'profile');
    const langSelect = page.querySelector('#cgm-set-language');
    const customInput = page.querySelector('#cgm-set-language-custom');
    if (langSelect && customInput) langSelect.addEventListener('change', () => { customInput.style.display = langSelect.value === 'custom' ? '' : 'none'; });
    const saveStatus = (id, msg, ok = true) => renderStatus(page.querySelector(id), msg, ok);
    const setIndexNowStatus = (msg, ok = true) => saveStatus('#cgm-set-status-indexnow', msg, ok);

    // Settings AI & clusters — same cluster-cap UX as onboarding.
    // Reads contentgemData.clusterLimit (Free → 4, Growth/Unlimited → -1),
    // and refreshes it via /plan-state on mount so a just-activated license
    // is picked up without a full page reload.
    (function wireSettingsClusterLimit() {
      const clustersField = page.querySelector('#cgm-set-clusters');
      const countEl  = page.querySelector('#cgm-set-cluster-count');
      const limitEl  = page.querySelector('#cgm-set-cluster-limit');
      const hintEl   = page.querySelector('#cgm-set-cluster-hint');
      if (!clustersField || !countEl || !limitEl || !hintEl) return;

      const data       = (window.contentgemData || {});
      let limit        = typeof data.clusterLimit === 'number' ? data.clusterLimit : 4;
      let planLabel    = data.planLabel || 'Free';
      let upgradeUrl   = data.upgradeUrl || '';
      let isUnlimited  = limit < 0;

      function updateLimitLabel() {
        limitEl.textContent = isUnlimited ? ' clusters (unlimited)' : ` of ${limit} clusters`;
        limitEl.style.marginLeft = '4px';
      }
      updateLimitLabel();

      // Refresh plan state from server. See admin-v23-upgrade.js wireClusterLimit
      // in onboarding for the same fix. This one covers the Settings tab.
      (async function refreshPlanState() {
        try {
          const restBase = String(data.restUrl || '').replace(/\/$/, '');
          if (!restBase) return;
          const res = await fetch(restBase + '/plan-state', {
            credentials: 'same-origin',
            headers: { 'X-WP-Nonce': data.nonce || '' }
          });
          if (!res.ok) return;
          const json = await res.json();
          if (!json || typeof json !== 'object') return;
          const newLimit = typeof json.clusterLimit === 'number' ? json.clusterLimit : limit;
          if (newLimit !== limit) {
            limit       = newLimit;
            isUnlimited = limit < 0;
            planLabel   = json.planLabel || planLabel;
            upgradeUrl  = json.upgradeUrl || upgradeUrl;
            if (window.contentgemData) {
              window.contentgemData.clusterLimit = limit;
              window.contentgemData.plan         = json.plan || window.contentgemData.plan;
              window.contentgemData.planLabel    = planLabel;
            }
            updateLimitLabel();
            render();
          }
        } catch (e) {
          // Silent fail — we keep the cached value from page load.
        }
      })();

      function countLines(v) {
        return String(v || '').split('\n').map(s => s.trim()).filter(Boolean).length;
      }

      function render() {
        const n = countLines(clustersField.value);
        countEl.textContent = String(n);

        if (!isUnlimited && n > limit) {
          const lines = clustersField.value.split('\n');
          const kept = [];
          let keptCount = 0;
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) { kept.push(line); continue; }
            if (keptCount >= limit) continue;
            kept.push(line);
            keptCount += 1;
          }
          clustersField.value = kept.join('\n');
          countEl.textContent = String(limit);
        }

        const current = countLines(clustersField.value);
        const atCap   = !isUnlimited && current >= limit;

        countEl.style.color = atCap ? '#f59e0b' : '';
        if (atCap) {
          const upgradeHtml = upgradeUrl
            ? ` <a href="${upgradeUrl}" target="_blank" rel="noopener noreferrer">Upgrade to Growth</a>`
            : '';
          hintEl.innerHTML = `<strong>${planLabel} plan limit reached.</strong> You can save up to ${limit} clusters on the ${planLabel} plan.${upgradeHtml}`;
          hintEl.style.display = '';
          hintEl.style.opacity = '1';
        } else if (!isUnlimited) {
          hintEl.innerHTML = `The ${planLabel} plan includes up to ${limit} clusters. Upgrade to add more.`;
          hintEl.style.display = '';
          hintEl.style.opacity = '0.75';
        } else {
          hintEl.style.display = 'none';
        }
      }

      clustersField.addEventListener('input', render);
      clustersField.addEventListener('paste', () => setTimeout(render, 0));
      // Re-render after buttons that mutate the textarea programmatically.
      [
        '#cgm-clusters-auto',
        '#cgm-clusters-ai',
        '#cgm-clusters-suggest-one',
        '#cgm-clusters-add-suggested',
        '#cgm-clusters-revert',
      ].forEach(sel => {
        const btn = page.querySelector(sel);
        if (btn) btn.addEventListener('click', () => setTimeout(render, 400));
      });
      render();
    })();

    function renderIndexNowLog(logEntries) {
      const logRoot = page.querySelector('#cgm-indexnow-log');
      if (!logRoot) return;
      const items = Array.isArray(logEntries) ? logEntries : [];
      if (!items.length) {
        logRoot.innerHTML = '<div class="cgm-indexnow-empty">No IndexNow pings logged yet.</div>';
        return;
      }
      logRoot.innerHTML = `<div class="cgm-indexnow-log-list">${items.map((entry) => `<div class="cgm-indexnow-log-item ${entry && entry.success ? 'is-success' : 'is-error'}"><div><strong>${entry && entry.success ? 'Ping accepted' : 'Ping failed'}</strong><span>${escapeHtml(String((entry && entry.url) || ''))}</span></div><small>${escapeHtml(String((entry && entry.time) || ''))}</small></div>`).join('')}</div>`;
    }

    function applyIndexNowState(data) {
      if (!data || typeof data !== 'object') return;
      const pill = page.querySelector('#cgm-indexnow-active');
      const path = page.querySelector('#cgm-indexnow-path');
      const lastTime = page.querySelector('#cgm-indexnow-last-time');
      const keyUrl = page.querySelector('#cgm-indexnow-key-url');
      const manualUrl = page.querySelector('#cgm-indexnow-manual-url');
      const homeUrl = page.querySelector('#cgm-indexnow-home-url');
      if (pill) {
        pill.textContent = data.active ? 'Active' : 'Inactive';
        pill.classList.toggle('is-active', !!data.active);
      }
      if (path) path.textContent = String(data.verification_path || 'Not generated yet');
      if (lastTime) lastTime.textContent = String(data.last_ping_time || 'Not yet');
      if (keyUrl) keyUrl.value = String(data.key_url || '');
      if (homeUrl && !homeUrl.value) homeUrl.value = String((window.contentgemData && window.contentgemData.siteUrl) || data.public_base_url || '');
      if (manualUrl && !manualUrl.value) manualUrl.value = String((window.contentgemData && window.contentgemData.siteUrl) || data.public_base_url || '');
      renderIndexNowLog(data.recent_log || []);
      if (state.settings && typeof state.settings === 'object') {
        state.settings.indexnow_status = data;
      }
    }

    async function refreshIndexNowStatus(message = '') {
      try {
        const data = await api('indexnow/status');
        applyIndexNowState(data);
        if (message) setIndexNowStatus(message, true);
      } catch (err) {
        setIndexNowStatus(friendlyErrorMessage(err, 'Could not load IndexNow status.'), false);
      }
    }

    applyIndexNowState(indexNow);

    const sitePages = Array.isArray(settings.site_pages) ? settings.site_pages : [];
    const siteStructure = settings.site_structure || { template:'custom', homepage:{}, about_page:{}, service_pages:[], case_studies:[], nodes:[] };
    let structureNodes = Array.isArray(siteStructure.nodes) ? siteStructure.nodes.map(node => makeStructureNode(node)) : [];
    if (!structureNodes.length) {
      const legacyTargets = flattenSiteStructureTargets(siteStructure);
      structureNodes = legacyTargets.map((node, index) => makeStructureNode({
        id: String(node.id || `legacy_${index}`),
        type: String(node.type || 'custom'),
        title: String(node.title || ''),
        url: String(node.url || ''),
        parent: String(node.parent || ''),
        page_id: Number(node.page_id || 0),
        priority: Number(node.priority || 60),
        order_index: index
      }));
    }
    function selectedIdMap(items) { const map = new Map(); (Array.isArray(items)?items:[]).forEach(item => map.set(String(item.page_id || ''), item)); return map; }
    function renderStructureSelect(selectEl, selectedId) {
      if (!selectEl) return;
      selectEl.innerHTML = `<option value="">Select page</option>${sitePages.map(p => `<option value="${String(p.id)}" ${String(selectedId||'')===String(p.id)?'selected':''}>${escapeHtml(p.title || ('Page ' + p.id))}</option>`).join('')}`;
    }
    function renderStructureChecklist(container, selectedItems) {
      if (!container) return;
      const selected = selectedIdMap(selectedItems);
      container.innerHTML = sitePages.length ? sitePages.map(p => {
        const active = selected.has(String(p.id));
        const entry = selected.get(String(p.id)) || {};
        return `<label class="cgm-structure-item"><input type="checkbox" data-page-id="${String(p.id)}" ${active ? 'checked' : ''}><span>${escapeHtml(p.title || ('Page ' + p.id))}</span><input type="number" class="cgm-structure-priority" data-priority-for="${String(p.id)}" min="1" max="100" value="${escapeHtml(String(entry.priority || 80))}" ${active ? '' : 'disabled'}></label>`;
      }).join('') : '<p class="cgm-empty-note">No pages found yet. Create pages in WordPress first.</p>';
      container.querySelectorAll('input[type="checkbox"]').forEach(box => box.addEventListener('change', () => {
        const priority = container.querySelector(`[data-priority-for="${box.getAttribute('data-page-id')}"]`);
        if (priority) priority.disabled = !box.checked;
      }));
    }
    function collectStructureEntries(container) {
      if (!container) return [];
      return Array.from(container.querySelectorAll('input[type="checkbox"]:checked')).map(box => {
        const pageId = Number(box.getAttribute('data-page-id') || 0);
        const page = sitePages.find(p => Number(p.id) === pageId) || {};
        const priorityInput = container.querySelector(`[data-priority-for="${String(pageId)}"]`);
        return { page_id: pageId, title: page.title || '', url: page.url || '', priority: Number(priorityInput && priorityInput.value ? priorityInput.value : 80) };
      });
    }

    function normalizeStructureOrder(parentId = '') {
      let order = 0;
      structureNodes.filter(node => String(node.parent || '') === String(parentId)).forEach(node => {
        node.order_index = order++;
      });
    }
    function syncStructureNodeEditors() {
      normalizeStructureOrder('');
      structureNodes.forEach(node => normalizeStructureOrder(String(node.id)));
      renderStructureTree(page.querySelector('#cgm-structure-tree'), structureNodes, sitePages);
    }
    function moveStructureNode(nodeId, direction) {
      const node = structureNodes.find(item => String(item.id) === String(nodeId));
      if (!node) return;
      const siblings = structureNodes.filter(item => String(item.parent || '') === String(node.parent || '')).sort((a,b) => Number(a.order_index||0)-Number(b.order_index||0));
      const idx = siblings.findIndex(item => String(item.id) === String(nodeId));
      if (idx === -1) return;
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (!siblings[swapIdx]) return;
      const other = siblings[swapIdx];
      const temp = node.order_index || 0;
      node.order_index = other.order_index || 0;
      other.order_index = temp;
      syncStructureNodeEditors();
    }
    function makeStructureChild(nodeId) {
      const siblings = structureNodes.filter(item => !String(item.parent || '')).sort((a,b) => Number(a.order_index||0)-Number(b.order_index||0));
      const idx = siblings.findIndex(item => String(item.id) === String(nodeId));
      if (idx > 0) {
        const node = structureNodes.find(item => String(item.id) === String(nodeId));
        node.parent = siblings[idx - 1].id;
        node.order_index = structureNodes.filter(item => String(item.parent||'') === String(node.parent)).length;
        syncStructureNodeEditors();
      }
    }
    syncStructureNodeEditors();

    page.querySelector('#cgm-save-profile').addEventListener('click', async() => {
      try {
        await api('settings/niche', { method:'POST', body:{ niche: page.querySelector('#cgm-set-niche').value, description: page.querySelector('#cgm-set-description').value, language: langSelect.value, custom_language: customInput.value } });
        state.settings = null; await loadSettings(true); saveStatus('#cgm-set-status-profile', 'Profile saved.');
      } catch(err) { saveStatus('#cgm-set-status-profile', friendlyErrorMessage(err, 'Could not save profile.'), false); }
    });
    page.querySelector('#cgm-save-api').addEventListener('click', async() => {
      try {
        const key = (page.querySelector('#cgm-set-api-key').value || '').trim().replace(/[•·●]+/g, '');
        if (!key) throw new Error('Enter an API key first.');
        await api('settings/api-key', { method:'POST', body:{ provider: page.querySelector('#cgm-set-provider').value, api_key: key } });
        state.settings = null; await loadSettings(true); page.querySelector('#cgm-set-api-key').value=''; saveStatus('#cgm-set-status-api', 'AI connection saved.');
      } catch(err) { saveStatus('#cgm-set-status-api', friendlyErrorMessage(err, 'Could not save AI connection.'), false); }
    });
    page.querySelector('#cgm-save-builder').addEventListener('click', async() => {
      try { await saveBuilderModeViaApi(page.querySelector('#cgm-set-builder-mode').value); saveStatus('#cgm-set-status-api', `Default builder set to ${builderLabel(page.querySelector('#cgm-set-builder-mode').value)}.`); state.settings = null; await loadSettings(true); } catch(err) { saveStatus('#cgm-set-status-api', friendlyErrorMessage(err, 'Could not save the default page builder.'), false); }
    });
    page.querySelector('#cgm-clusters-suggest-one').addEventListener('click', async() => {
      try { const data = await api('settings/suggest-single-cluster', { method:'POST', body:{ niche: page.querySelector('#cgm-set-niche').value, description: page.querySelector('#cgm-set-description').value } }); const cluster = String(data.cluster || '').trim(); if (!cluster) throw new Error('No cluster suggestion returned.'); page.querySelector('#cgm-set-new-cluster').value = cluster; const keywordInput = page.querySelector('#cgm-set-keyword-cluster'); if (keywordInput) keywordInput.value = cluster; saveStatus('#cgm-set-status-clusters', `Suggested cluster loaded: ${cluster}.`); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not suggest a new cluster.'), false); }
    });
    page.querySelector('#cgm-clusters-add-suggested').addEventListener('click', async() => {
      try { const cluster = String(page.querySelector('#cgm-set-new-cluster').value || '').trim(); if (!cluster) throw new Error('Suggest or enter a cluster first.'); const field = page.querySelector('#cgm-set-clusters'); const existing = normalizeList(field.value); if (!existing.map(v => String(v).toLowerCase()).includes(cluster.toLowerCase())) field.value = existing.concat([cluster]).join('\n'); if (!page.querySelector('#cgm-set-keyword-cluster').value) page.querySelector('#cgm-set-keyword-cluster').value = cluster; saveStatus('#cgm-set-status-clusters', `Added cluster: ${cluster}`); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not add the suggested cluster.'), false); }
    });
    page.querySelector('#cgm-clusters-auto').addEventListener('click', async() => {
      try { const data = await api('settings/auto-detect-clusters', { method:'POST', body:{ replace:true } }); page.querySelector('#cgm-set-clusters').value = (data.clusters || []).join('\n'); saveStatus('#cgm-set-status-clusters', 'Existing clusters detected.'); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not update clusters.'), false); }
    });
    page.querySelector('#cgm-clusters-ai').addEventListener('click', async() => {
      try { await api('settings/niche', { method:'POST', body:{ niche: page.querySelector('#cgm-set-niche').value, description: page.querySelector('#cgm-set-description').value, language: langSelect.value, custom_language: customInput.value } }); const data = await api('suggest-clusters', { method:'POST', body:{} }); page.querySelector('#cgm-set-clusters').value = (data.clusters || []).join('\n'); saveStatus('#cgm-set-status-clusters', 'AI cluster suggestions loaded.'); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not update clusters.'), false); }
    });
    page.querySelector('#cgm-clusters-revert').addEventListener('click', async() => {
      try { const data = await api('settings/revert-clusters', { method:'POST', body:{} }); page.querySelector('#cgm-set-clusters').value = (data.clusters || []).join('\n'); saveStatus('#cgm-set-status-clusters', 'Clusters reverted.'); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not update clusters.'), false); }
    });
    page.querySelector('#cgm-save-clusters').addEventListener('click', async() => {
      try { await api('settings/clusters', { method:'POST', body:{ clusters: normalizeList(page.querySelector('#cgm-set-clusters').value), replace:true } }); state.settings = null; await loadSettings(true); saveStatus('#cgm-set-status-clusters', 'Clusters saved.'); } catch(err) { saveStatus('#cgm-set-status-clusters', friendlyErrorMessage(err, 'Could not update clusters.'), false); }
    });
    page.querySelector('#cgm-suggest-cluster-keywords').addEventListener('click', async() => {
      try { const data = await api('settings/suggest-cluster-keywords', { method:'POST', body:{ clusters: normalizeList(page.querySelector('#cgm-set-clusters').value), niche: page.querySelector('#cgm-set-niche').value, description: page.querySelector('#cgm-set-description').value } }); const map = data.cluster_keywords || data.keywords || {}; const lines = Object.entries(map).map(([k,v]) => `${k}: ${(Array.isArray(v)?v:[]).join(', ')}`); page.querySelector('#cgm-set-cluster-keywords').value = lines.join('\n'); saveStatus('#cgm-set-status-keywords', 'Keyword suggestions loaded.'); } catch(err) { saveStatus('#cgm-set-status-keywords', friendlyErrorMessage(err, 'Could not update keywords.'), false); }
    });
    page.querySelector('#cgm-suggest-single-cluster-keywords').addEventListener('click', async() => {
      try { const cluster = String(page.querySelector('#cgm-set-keyword-cluster').value || page.querySelector('#cgm-set-new-cluster').value || '').trim(); if (!cluster) throw new Error('Enter or suggest a cluster first.'); const data = await api('settings/suggest-cluster-keywords', { method:'POST', body:{ clusters:[cluster], niche: page.querySelector('#cgm-set-niche').value, description: page.querySelector('#cgm-set-description').value } }); const map = data.cluster_keywords || data.keywords || {}; const keywords = map[cluster] || map[Object.keys(map)[0]] || []; upsertKeywordLine(page.querySelector('#cgm-set-cluster-keywords'), cluster, keywords); saveStatus('#cgm-set-status-keywords', Array.isArray(keywords) && keywords.length ? `Keyword suggestions loaded for ${cluster}.` : `No keyword suggestions were returned for ${cluster}.`, !!(Array.isArray(keywords) && keywords.length)); } catch(err) { saveStatus('#cgm-set-status-keywords', friendlyErrorMessage(err, 'Could not update keywords.'), false); }
    });
    page.querySelector('#cgm-save-cluster-keywords').addEventListener('click', async() => {
      try { const map = buildKeywordMapFromText(page.querySelector('#cgm-set-cluster-keywords').value); await api('settings/cluster-keywords', { method:'POST', body:{ cluster_keywords: map, replace:true } }); state.settings = null; await loadSettings(true); saveStatus('#cgm-set-status-keywords', 'Cluster keywords saved.'); } catch(err) { saveStatus('#cgm-set-status-keywords', friendlyErrorMessage(err, 'Could not update keywords.'), false); }
    });
    page.querySelector('#cgm-analyze-tone').addEventListener('click', async() => {
      try {
        const posts = await wpApi('/wp-json/wp/v2/posts?per_page=5&_fields=id');
        const postIds = Array.isArray(posts) ? posts.map(item => Number(item.id)).filter(Boolean) : [];
        if (!postIds.length) throw new Error('Publish at least one post first.');
        const data = await api('settings/analyze-writing-style', { method:'POST', body:{ post_ids: postIds } });
        page.querySelector('#cgm-set-tone').value = data.tone_of_voice || data.tone || '';
        saveStatus('#cgm-set-status-tone', 'Tone of voice analyzed from recent posts.');
      } catch(err) { saveStatus('#cgm-set-status-tone', friendlyErrorMessage(err, 'Could not update tone of voice.'), false); }
    });
    page.querySelector('#cgm-save-tone').addEventListener('click', async() => {
      try { await api('settings/tone-of-voice', { method:'POST', body:{ tone_of_voice: page.querySelector('#cgm-set-tone').value } }); saveStatus('#cgm-set-status-tone', 'Tone of voice saved.'); } catch(err) { saveStatus('#cgm-set-status-tone', friendlyErrorMessage(err, 'Could not update tone of voice.'), false); }
    });
    page.querySelector('#cgm-save-competitors').addEventListener('click', async() => {
      try { const saved = await api('settings/competitor-domains', { method:'POST', body:{ competitor_domains: normalizeList(page.querySelector('#cgm-set-competitors').value) } }); page.querySelector('#cgm-set-competitors').value = (Array.isArray(saved.domains) ? saved.domains : []).join('\n'); saveStatus('#cgm-set-status-competitors', 'Competitor domains saved.'); state.settings = null; await loadSettings(true); } catch(err) { saveStatus('#cgm-set-status-competitors', friendlyErrorMessage(err, 'Could not save competitor domains.'), false); }
    });
    const copyGscBtn = page.querySelector('#cgm-copy-gsc-uri');
    if (copyGscBtn) copyGscBtn.addEventListener('click', async() => {
      const text = (page.querySelector('#cgm-gsc-redirect-uri')?.textContent || '').trim();
      if (!text) return;
      try { await navigator.clipboard.writeText(text); renderSettingsStatus('gsc', 'Redirect URI copied.', true); } catch (e) { renderSettingsStatus('gsc', 'Could not copy the redirect URI.', false); }
    });

    page.querySelector('#cgm-save-gsc-creds').addEventListener('click', async() => {
      try {
        const client_id = String(page.querySelector('#cgm-gsc-client-id').value || '').trim();
        const client_secret = String(page.querySelector('#cgm-gsc-client-secret').value || '').trim();
        if (!client_id || !client_secret) throw new Error('Client ID and Client Secret are required.');
        const saved = await api('settings/gsc-credentials', { method:'POST', body:{ client_id, client_secret } });
        page.querySelector('#cgm-gsc-client-id').value = saved.client_id || client_id;
        page.querySelector('#cgm-gsc-client-secret').value = saved.client_secret_mask || '••••••••••••••••••••••••';
        saveStatus('#cgm-set-status-gsc', `GSC credentials saved. Use this EXACT redirect URI in Google Cloud: ${saved.redirect_uri || ''}`);
        state.settings = null;
        await loadSettings(true);
      } catch(err) { saveStatus('#cgm-set-status-gsc', friendlyErrorMessage(err, 'Could not save GSC credentials.'), false); }
    });
    page.querySelector('#cgm-connect-gsc').addEventListener('click', async() => {
      try {
        const client_id = String(page.querySelector('#cgm-gsc-client-id').value || '').trim();
        const client_secret = String(page.querySelector('#cgm-gsc-client-secret').value || '').trim();
        if (client_id && client_secret) {
          await api('settings/gsc-credentials', { method:'POST', body:{ client_id, client_secret } });
          state.settings = null;
        }
        const data = await api('gsc/connect');
        if (!data.auth_url) throw new Error('No authorization URL was returned.');
        const debug = data.debug || {};
        saveStatus('#cgm-set-status-gsc', `Opening Google OAuth. Redirect URI in use: ${data.redirect_uri || ''}`);
        const dbg = page.querySelector('#cgm-gsc-debug'); if (dbg) { dbg.textContent = JSON.stringify(debug && Object.keys(debug).length ? debug : { redirect_uri: (data.redirect_uri || '') }, null, 2); }
        window.location.href = data.auth_url;
      } catch(err) { saveStatus('#cgm-set-status-gsc', friendlyErrorMessage(err, 'Could not start the GSC connection.'), false); }
    });
    page.querySelector('#cgm-load-gsc-sites').addEventListener('click', async() => {
      try {
        const data = await api('gsc/sites');
        const select = page.querySelector('#cgm-gsc-site');
        const entries = Array.isArray(data.site_entries) ? data.site_entries : [];
        const sites = Array.isArray(data.sites) ? data.sites : entries.map(site => typeof site === 'string' ? site : String(site.url || '')).filter(Boolean);
        select.innerHTML = '<option value="">Select property</option>' + sites.map(site => `<option value="${escapeHtml(site)}" ${String(settings.gsc_site_url||'')===String(site)?'selected':''}>${escapeHtml(site)}</option>`).join('');
        saveStatus('#cgm-set-status-gsc', sites.length ? 'Properties loaded.' : 'No properties found for this account.');
      } catch(err) { saveStatus('#cgm-set-status-gsc', friendlyErrorMessage(err, 'Could not load GSC properties.'), false); }
    });
    page.querySelector('#cgm-save-gsc-site').addEventListener('click', async() => {
      try {
        const site_url = String(page.querySelector('#cgm-gsc-site').value || '').trim();
        if (!site_url) throw new Error('Choose a Search Console property first.');
        await api('gsc/select-site', { method:'POST', body:{ site_url } });
        saveStatus('#cgm-set-status-gsc', 'GSC property saved.');
        settings.gsc_site_url = site_url;
      } catch(err) { saveStatus('#cgm-set-status-gsc', friendlyErrorMessage(err, 'Could not save the GSC property.'), false); }
    });
    page.querySelector('#cgm-apply-structure-template').addEventListener('click', () => {
      const key = String((page.querySelector('#cgm-structure-template').value || 'custom'));
      const templateNodes = (SITE_STRUCTURE_TEMPLATES[key] || []).map((node, index) => makeStructureNode(Object.assign({}, node, { order_index:index })));
      structureNodes = templateNodes;
      syncStructureNodeEditors();
      saveStatus('#cgm-set-status-structure', key === 'custom' ? 'Switched to custom structure.' : 'Recommended structure applied. Adjust the hierarchy and save when ready.');
    });
    const resetStructureBtn = page.querySelector('#cgm-reset-structure-template');
    if (resetStructureBtn) resetStructureBtn.addEventListener('click', () => {
      structureNodes = [];
      syncStructureNodeEditors();
      saveStatus('#cgm-set-status-structure', 'Started from scratch. Add your most important pages and build the hierarchy you want.');
    });
    page.querySelector('#cgm-add-structure-node').addEventListener('click', () => {
      structureNodes.push(makeStructureNode({ title:'New page', type:'custom', priority:60, order_index: structureNodes.filter(node => !String(node.parent||'')).length }));
      syncStructureNodeEditors();
    });
    page.addEventListener('click', (event) => {
      const moveUpBtn = event.target.closest('.cgm-structure-move-up');
      if (moveUpBtn) { moveStructureNode(String(moveUpBtn.getAttribute('data-node-id') || ''), 'up'); return; }
      const moveDownBtn = event.target.closest('.cgm-structure-move-down');
      if (moveDownBtn) { moveStructureNode(String(moveDownBtn.getAttribute('data-node-id') || ''), 'down'); return; }
      const makeChildBtn = event.target.closest('.cgm-structure-make-child');
      if (makeChildBtn) { makeStructureChild(String(makeChildBtn.getAttribute('data-node-id') || '')); return; }
      const moveTopBtn = event.target.closest('.cgm-structure-move-top');
      if (moveTopBtn) { const node = structureNodes.find(item => String(item.id) === String(moveTopBtn.getAttribute('data-node-id') || '')); if (node) { node.parent = ''; syncStructureNodeEditors(); } return; }
      const addChildBtn = event.target.closest('.cgm-structure-add-child');
      if (addChildBtn) {
        const parentId = String(addChildBtn.getAttribute('data-parent-id') || '');
        structureNodes.push(makeStructureNode({ title:'New child page', parent:parentId, type:'custom', priority:55 }));
        syncStructureNodeEditors();
        return;
      }
      const removeBtn = event.target.closest('.cgm-structure-remove-node');
      if (removeBtn) {
        const nodeId = String(removeBtn.getAttribute('data-node-id') || '');
        structureNodes = structureNodes.filter(node => String(node.id) !== nodeId && String(node.parent||'') !== nodeId);
        syncStructureNodeEditors();
      }
    });
    page.addEventListener('change', (event) => {
      const nodeId = String(event.target.getAttribute('data-node-id') || '');
      const key = String(event.target.getAttribute('data-inline-key') || event.target.getAttribute('data-key') || '');
      if (!nodeId || !key) return;
      structureNodes = structureNodes.map(node => {
        if (String(node.id) !== nodeId) return node;
        const value = key === 'page_id' ? Number(event.target.value || 0) : String(event.target.value || '');
        return Object.assign({}, node, { [key]: value });
      });
      syncStructureNodeEditors();
    });


    page.addEventListener('dragstart', (event) => {
      const nodeEl = event.target.closest('.cgm-structure-tree-node');
      if (!nodeEl) return;
      event.dataTransfer.setData('text/plain', String(nodeEl.getAttribute('data-node-id') || ''));
    });
    page.addEventListener('dragover', (event) => {
      if (event.target.closest('.cgm-structure-tree-node') || event.target.closest('.cgm-structure-dropzone')) event.preventDefault();
    });
    page.addEventListener('drop', (event) => {
      const draggedId = event.dataTransfer.getData('text/plain');
      if (!draggedId) return;
      const targetNode = event.target.closest('.cgm-structure-tree-node');
      const topDrop = event.target.closest('.cgm-structure-dropzone');
      if (targetNode) {
        event.preventDefault();
        if (String(targetNode.getAttribute('data-node-id') || '') === String(draggedId)) return;
        const node = structureNodes.find(item => String(item.id) === String(draggedId));
        if (!node) return;
        node.parent = String(targetNode.getAttribute('data-node-id') || '');
        node.order_index = structureNodes.filter(item => String(item.parent||'') === String(node.parent)).length;
        syncStructureNodeEditors();
      } else if (topDrop) {
        event.preventDefault();
        const node = structureNodes.find(item => String(item.id) === String(draggedId));
        if (!node) return;
        node.parent = '';
        syncStructureNodeEditors();
      }
    });

    page.querySelector('#cgm-save-structure').addEventListener('click', async() => {
      try {
        const normalizedNodes = structureNodes.map((node, index) => ({
          id: String(node.id || ''),
          type: String(node.type || 'custom'),
          title: String(node.title || ''),
          url: String(node.url || ''),
          parent: String(node.parent || ''),
          priority: Number(node.priority || (String(node.type||'') === 'homepage' ? 90 : String(node.type||'') === 'about' ? 70 : String(node.type||'') === 'service' ? 80 : String(node.type||'') === 'case' ? 75 : 60)),
          page_id: Number(node.page_id || 0),
          order_index: Number(node.order_index || index)
        })).filter(node => node.title || node.url || node.page_id);
        const homepageNode = normalizedNodes.find(node => String(node.type) === 'homepage') || {};
        const aboutNode = normalizedNodes.find(node => String(node.type) === 'about') || {};
        const servicePages = normalizedNodes.filter(node => String(node.type) === 'service').map(node => ({ page_id: Number(node.page_id || 0), title: String(node.title || ''), url: String(node.url || ''), priority: Number(node.priority || 80) }));
        const caseStudies = normalizedNodes.filter(node => String(node.type) === 'case').map(node => ({ page_id: Number(node.page_id || 0), title: String(node.title || ''), url: String(node.url || ''), priority: Number(node.priority || 75) }));
        const site_structure = {
          template: String((page.querySelector('#cgm-structure-template').value || 'custom')),
          homepage: homepageNode.id ? { page_id: Number(homepageNode.page_id || 0), title: String(homepageNode.title || ''), url: String(homepageNode.url || ''), priority: Number(homepageNode.priority || 90) } : { page_id:0, title:'', url:'', priority:90 },
          about_page: aboutNode.id ? { page_id: Number(aboutNode.page_id || 0), title: String(aboutNode.title || ''), url: String(aboutNode.url || ''), priority: Number(aboutNode.priority || 70) } : { page_id:0, title:'', url:'', priority:70 },
          service_pages: servicePages,
          case_studies: caseStudies,
          nodes: normalizedNodes
        };
        await api('settings/site-structure', { method:'POST', body:{ site_structure } });
        saveStatus('#cgm-set-status-structure', 'Site structure saved.');
      } catch(err) { saveStatus('#cgm-set-status-structure', friendlyErrorMessage(err, 'Could not save site structure.'), false); }
    });

    page.querySelector('#cgm-mark-onboarding').addEventListener('click', async() => {
      try { await api('onboarding/complete', { method:'POST', body:{ clusters: normalizeList(page.querySelector('#cgm-set-clusters').value), completed:true } }); saveStatus('#cgm-set-status-extra', 'Onboarding marked complete. Reloading…'); location.reload(); } catch(err) { saveStatus('#cgm-set-status-extra', friendlyErrorMessage(err, 'Could not update this setting.'), false); }
    });
    page.querySelector('#cgm-save-ai-system').addEventListener('click', async() => {
      try {
        await api('settings/ai-system', { method:'POST', body:{
          show_source_list: !!page.querySelector('#cgm-set-show-sources')?.checked,
          enable_token_optimization: !!page.querySelector('#cgm-set-token-opt')?.checked,
          enable_fact_check: !!page.querySelector('#cgm-set-fact-check')?.checked,
          enable_full_source_grounding: !!page.querySelector('#cgm-set-grounding')?.checked,
          openai_default_model: page.querySelector('#cgm-set-openai-model')?.value || 'gpt-5.4-mini',
          openai_reasoning_profile: page.querySelector('#cgm-set-reasoning-profile')?.value || 'balanced',
          openai_show_token_stats: !!page.querySelector('#cgm-set-show-token-stats')?.checked,
          openai_enable_flex: !!page.querySelector('#cgm-set-enable-flex')?.checked,
          openai_enable_batch: !!page.querySelector('#cgm-set-enable-batch')?.checked,
        }});
        state.settings = null; await loadSettings(true); saveStatus('#cgm-set-status-extra', 'AI system settings saved.');
      } catch(err) { saveStatus('#cgm-set-status-extra', friendlyErrorMessage(err, 'Could not save AI system settings.'), false); }
    });
    page.querySelector('#cgm-reindex-codebase').addEventListener('click', async() => {
      try {
        const data = await api('codebase/reindex', { method:'POST', body:{} });
        const status = page.querySelector('#cgm-codebase-status');
        if (status) status.innerHTML = `Indexed files: <strong>${escapeHtml(String(data.file_count || 0))}</strong> · Last refresh: <strong>${escapeHtml(data.built_at || '')}</strong>`;
        saveStatus('#cgm-set-status-extra', 'Code index refreshed.');
      } catch(err) { saveStatus('#cgm-set-status-extra', friendlyErrorMessage(err, 'Could not refresh the code index.'), false); }
    });
    page.querySelector('#cgm-preview-grounding').addEventListener('click', async() => {
      try {
        const data = await api('codebase/task-context-preview?task=technical_build_plan');
        const pre = page.querySelector('#cgm-codebase-preview');
        if (pre) { pre.hidden = false; pre.textContent = JSON.stringify(data, null, 2); }
      } catch(err) { saveStatus('#cgm-set-status-extra', friendlyErrorMessage(err, 'Could not preview grounded context.'), false); }
    });

    page.querySelector('#cgm-indexnow-refresh')?.addEventListener('click', async() => {
      await refreshIndexNowStatus('IndexNow status refreshed.');
    });
    page.querySelector('#cgm-indexnow-copy')?.addEventListener('click', async() => {
      const value = String(page.querySelector('#cgm-indexnow-key-url')?.value || '');
      if (!value) {
        setIndexNowStatus('No key URL available yet.', false);
        return;
      }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(value);
        } else {
          const field = page.querySelector('#cgm-indexnow-key-url');
          if (field) {
            field.focus();
            field.select();
            document.execCommand('copy');
          }
        }
        setIndexNowStatus('IndexNow key URL copied.');
      } catch (err) {
        setIndexNowStatus('Could not copy the IndexNow key URL.', false);
      }
    });
    page.querySelector('#cgm-indexnow-regenerate')?.addEventListener('click', async() => {
      try {
        const data = await api('indexnow/regenerate-key', { method:'POST', body:{} });
        const existing = state.settings && state.settings.indexnow_status ? state.settings.indexnow_status : indexNow;
        applyIndexNowState(Object.assign({}, existing, { key_url: String(data.key_url || ''), verification_path: String(data.key_url || '').replace(/^https?:\/\/[^/]+/, '') }));
        await refreshIndexNowStatus('IndexNow key regenerated.');
      } catch (err) {
        setIndexNowStatus(friendlyErrorMessage(err, 'Could not regenerate the IndexNow key.'), false);
      }
    });
    page.querySelector('#cgm-indexnow-ping-home')?.addEventListener('click', async() => {
      const url = String(page.querySelector('#cgm-indexnow-home-url')?.value || '').trim();
      if (!url) {
        setIndexNowStatus('No homepage URL available to ping.', false);
        return;
      }
      try {
        await api('indexnow/ping', { method:'POST', body:{ url } });
        await refreshIndexNowStatus('Homepage submitted to IndexNow.');
      } catch (err) {
        setIndexNowStatus(friendlyErrorMessage(err, 'Could not ping the homepage with IndexNow.'), false);
      }
    });
    page.querySelector('#cgm-indexnow-ping-manual')?.addEventListener('click', async() => {
      const url = String(page.querySelector('#cgm-indexnow-manual-url')?.value || '').trim();
      if (!url) {
        setIndexNowStatus('Enter a full public URL to ping.', false);
        return;
      }
      try {
        await api('indexnow/ping', { method:'POST', body:{ url } });
        await refreshIndexNowStatus('Manual URL submitted to IndexNow.');
      } catch (err) {
        setIndexNowStatus(friendlyErrorMessage(err, 'Could not ping that URL with IndexNow.'), false);
      }
    });

    page.querySelector('#cgm-hard-reset').addEventListener('click', async() => {
      try { if (!confirm('This will remove suggested settings, clusters and competitor domains. Continue?')) return; await api('settings/hard-reset', { method:'POST', body:{} }); saveStatus('#cgm-set-status-extra', 'Plugin suggestions reset. Reloading…'); location.reload(); } catch(err) { saveStatus('#cgm-set-status-extra', friendlyErrorMessage(err, 'Could not update this setting.'), false); }
    });
  }

  async function renderAssistantPage(page, settings) {
    if (page.dataset.cgmUpgrade === 'assistant-v32') return;
    page.dataset.cgmUpgrade = 'assistant-v39';
    ensurePageHeader(page, 'AI Assistant', 'Build drafts with title suggestions, optional tone of voice, competitor insights and pillar-page mode in one focused workspace.');
    page.insertAdjacentHTML('beforeend', [
      card('', `
        <div class="cgm-assistant-steps">
          <span class="cgm-step-pill">1. Select cluster</span>
          <span class="cgm-step-pill">2. Select keyword</span>
          <span class="cgm-step-pill">3. Create title</span>
        </div>
        <div class="cgm-toolbar-grid assistant-grid">
          <div class="cgm-field"><label>Cluster</label><select id="cgm-ai-cluster"><option value="">Select cluster</option>${(settings.clusters||[]).map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')}</select></div>
          <div class="cgm-field"><label>Cluster keyword</label><select id="cgm-ai-cluster-keyword"><option value="">Select keyword from cluster</option></select></div>
          <div class="cgm-field"><label>Content title</label><input id="cgm-ai-title" type="text" placeholder="e.g. Complete guide to semantic search"></div>
          <div class="cgm-field"><label>Primary keyword</label><input id="cgm-ai-keyword" type="text" placeholder="e.g. semantic search optimization"></div>
          <div class="cgm-field"><label>Generate as</label><select id="cgm-ai-content-type"><option value="post">Post</option><option value="page">Page</option></select></div>
        </div>
        <div class="cgm-inline-actions cgm-ai-actions">
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ai-suggest">Suggest title + keyword</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ai-optimize-title">Optimize title</button>
          <div class="cgm-checkbox-row">
            <label class="cgm-check"><input type="checkbox" id="cgm-ai-use-tone"><span>Tone of voice saved</span></label>
            <label class="cgm-check"><input type="checkbox" id="cgm-ai-use-competitors"><span>Use competitor insights</span></label>
            <label class="cgm-check"><input type="checkbox" id="cgm-ai-use-semantics"><span>Use AI semantic keyword suggestions</span></label>
            <label class="cgm-check"><input type="checkbox" id="cgm-ai-pillar"><span>Create pillar page</span></label>
            <label class="cgm-check"><input type="checkbox" id="cgm-ai-include-svg"><span>Include SVG visuals in draft</span></label>
          </div>
        </div>
        <div id="cgm-ai-suggestion-list" class="cgm-upgrade-suggestion-list"></div>
        <div class="cgm-field"><label>Prompt / instructions</label><textarea id="cgm-ai-prompt" rows="7" placeholder="Describe the angle, structure, search intent, entities to include and conversion goals."></textarea></div>
        <div class="cgm-ai-context-panels semantic-only">
          <div class="cgm-ai-context-card cgm-ai-context-card--semantic">
            <div class="cgm-ai-context-title">AI semantic keyword suggestions</div>
            <div id="cgm-ai-semantic-preview"><p class="cgm-empty-note">Enable semantic keyword suggestions to load AI-generated support terms for this article.</p></div>
            <div class="cgm-ai-semantic-editor">
              <label for="cgm-ai-semantic-custom">Add or adjust extra semantic keywords</label>
              <textarea id="cgm-ai-semantic-custom" rows="3" placeholder="Add extra semantic keywords, comma separated"></textarea>
            </div>
          </div>
        </div>
        <div class="cgm-inline-actions cgm-ai-generate-row">
          <button type="button" class="cgm-btn cgm-btn--primary" id="cgm-ai-generate">Generate draft</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ai-save">Save current output</button>
          <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-ai-copy">Copy HTML</button>
        </div>
        <div class="cgm-upgrade-status" id="cgm-ai-status"></div>
      `),
      card('Output', `<textarea id="cgm-ai-output" rows="22" placeholder="Generate a draft to see the output here."></textarea><div id="cgm-ai-meta" class="cgm-help-plain" style="margin-top:12px" hidden></div><div id="cgm-ai-sources" class="cgm-help-plain" style="margin-top:12px" hidden></div>`)
    ].join(''));

    const clusterEl = page.querySelector('#cgm-ai-cluster');
    const clusterKeywordEl = page.querySelector('#cgm-ai-cluster-keyword');
    const titleEl = page.querySelector('#cgm-ai-title');
    const keywordEl = page.querySelector('#cgm-ai-keyword');
    const promptEl = page.querySelector('#cgm-ai-prompt');
    const outputEl = page.querySelector('#cgm-ai-output');
    const statusEl = page.querySelector('#cgm-ai-status');
    const metaEl = page.querySelector('#cgm-ai-meta');
    const sourcesEl = page.querySelector('#cgm-ai-sources');
    const semanticPreviewEl = page.querySelector('#cgm-ai-semantic-preview');
    const semanticCustomEl = page.querySelector('#cgm-ai-semantic-custom');
    const suggestionList = page.querySelector('#cgm-ai-suggestion-list');
    const toneCheckbox = page.querySelector('#cgm-ai-use-tone');
    const competitorCheckbox = page.querySelector('#cgm-ai-use-competitors');
    const semanticCheckbox = page.querySelector('#cgm-ai-use-semantics');
    const pillarCheckbox = page.querySelector('#cgm-ai-pillar');
    const svgCheckbox = page.querySelector('#cgm-ai-include-svg');
    const contentTypeEl = page.querySelector('#cgm-ai-content-type');
    [toneCheckbox, competitorCheckbox, semanticCheckbox, pillarCheckbox, svgCheckbox].filter(Boolean).forEach((checkbox) => {
      const wrapper = checkbox.closest('.cgm-check');
      if (!wrapper || wrapper.dataset.cgmCheckboxFixBound === '1') return;
      wrapper.dataset.cgmCheckboxFixBound = '1';
      wrapper.style.cursor = 'pointer';
      wrapper.style.pointerEvents = 'auto';
      wrapper.tabIndex = 0;
      checkbox.style.pointerEvents = 'auto';
      checkbox.style.position = 'absolute';
      checkbox.style.opacity = '0';
      checkbox.style.inset = '0';
      checkbox.style.margin = '0';
      checkbox.style.width = '40px';
      checkbox.style.height = '24px';
      checkbox.style.zIndex = '2';
      checkbox.removeAttribute('disabled');
      if (checkbox.nextElementSibling && checkbox.nextElementSibling.classList && checkbox.nextElementSibling.classList.contains('cgm-ai-toggle-ui') === false) {
        checkbox.insertAdjacentHTML('afterend', '<span class="cgm-ai-toggle-ui" aria-hidden="true"></span>');
      } else if (!checkbox.nextElementSibling) {
        checkbox.insertAdjacentHTML('afterend', '<span class="cgm-ai-toggle-ui" aria-hidden="true"></span>');
      }

      const toggleCheckbox = (event) => {
        if (event) {
          event.preventDefault();
          event.stopPropagation();
        }
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event('change', { bubbles: true }));
      };

      checkbox.addEventListener('click', (event) => {
        event.stopPropagation();
      });

      wrapper.addEventListener('click', (event) => {
        if (event.target === checkbox) return;
        toggleCheckbox(event);
      });

      wrapper.addEventListener('keydown', (event) => {
        if (event.key === ' ' || event.key === 'Enter') {
          toggleCheckbox(event);
        }
      });
    });
    const siteStructure = settings.site_structure || {};
    const clusterKeywordMap = settings.cluster_keywords || {};
    const history = await loadCompetitorHistory('', true);
    state.assistant.history = history;

    toneCheckbox.checked = false;
    competitorCheckbox.checked = false;
    semanticCheckbox.checked = false;
    pillarCheckbox.checked = false;
    svgCheckbox.checked = false;

    function renderAssistantStatus(message, ok = true) {
      renderStatus(statusEl, message, ok);
      state.assistant.error = ok ? '' : message;
      state.assistant.status = ok ? message : '';
    }

    function renderAssistantMeta(payload) {
      if (!metaEl || !sourcesEl) return;
      const usage = payload && payload.usage && typeof payload.usage === 'object' ? payload.usage : {};
      const model = payload && payload.model ? String(payload.model) : '';
      const sources = Array.isArray(payload && payload.sources) ? payload.sources : [];
      if (model || usage.total_tokens) {
        metaEl.hidden = false;
        metaEl.innerHTML = `<strong>AI meta</strong><div class="cgm-upgrade-note">${model ? `Model: <strong>${escapeHtml(model)}</strong>` : ''}${usage.total_tokens ? ` · Tokens: <strong>${escapeHtml(String(usage.total_tokens))}</strong>` : ''}${usage.cached_tokens ? ` · Cached tokens: <strong>${escapeHtml(String(usage.cached_tokens))}</strong>` : ''}</div>`;
      } else {
        metaEl.hidden = true; metaEl.innerHTML = '';
      }
      if (sources.length) {
        sourcesEl.hidden = false;
        sourcesEl.innerHTML = `<strong>Sources</strong><ul class="cgm-source-list">${sources.map(src => `<li>${escapeHtml(src.label || '')}${src.url ? ` — <code>${escapeHtml(src.url)}</code>` : ''}</li>`).join('')}</ul>`;
      } else {
        sourcesEl.hidden = true; sourcesEl.innerHTML = '';
      }
    }

    function normalizeKeywordArray(items) {
      const seen = new Set();
      return (Array.isArray(items) ? items : [])
        .map(item => String(item || '').trim().replace(/\s+/g, ' '))
        .filter(Boolean)
        .filter(item => item.length >= 3 && !/^\d+$/.test(item))
        .filter(item => {
          const key = item.toLowerCase();
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        }

    function parseSemanticCustomKeywords() {
      if (!semanticCustomEl) return [];
      return normalizeKeywordArray(String(semanticCustomEl.value || '').split(','));
    }

    function getSelectedSemanticKeywords() {
      const selected = Array.from(page.querySelectorAll('input[name="cgm-ai-semantic-item"]:checked')).map(input => input.value);
      return normalizeKeywordArray(selected.concat(parseSemanticCustomKeywords()));
    }

    function syncSemanticCustomInput() {
      if (!semanticCustomEl) return;
      semanticCustomEl.value = (state.assistant.semanticCustomKeywords || []).join(', ');
    }

    function renderSemanticPreview(items) {
      if (!semanticPreviewEl) return;
      const list = normalizeKeywordArray(items);
      const unchecked = new Set((state.assistant.semanticUnchecked || []).map(item => String(item).toLowerCase()));
      semanticPreviewEl.innerHTML = list.length
        ? `<div class="cgm-chip-cloud cgm-chip-cloud--toggle">${list.map(item => {
            const checked = !unchecked.has(String(item).toLowerCase());
            return `<label class="cgm-chip-toggle"><input type="checkbox" name="cgm-ai-semantic-item" value="${escapeHtml(item)}" ${checked ? 'checked' : ''}><span>${escapeHtml(item)}</span></label>`;
          }).join('')}</div>`
        : '<p class="cgm-empty-note">Enable semantic keyword suggestions to load AI-generated support terms for this article.</p>';
      semanticPreviewEl.querySelectorAll('input[name="cgm-ai-semantic-item"]').forEach(input => input.addEventListener('change', () => {
        state.assistant.semanticUnchecked = Array.from(semanticPreviewEl.querySelectorAll('input[name="cgm-ai-semantic-item"]:not(:checked)')).map(el => String(el.value || '').trim()).filter(Boolean);
        renderAssistantStatus(getSelectedSemanticKeywords().length ? 'Semantic keywords updated for this draft.' : 'No semantic keywords selected right now.');
      }));
    }

    function syncClusterKeywordOptions() {
      if (!clusterKeywordEl) return;
      const options = Array.isArray(clusterKeywordMap[clusterEl.value]) ? clusterKeywordMap[clusterEl.value] : [];
      const currentKeyword = keywordEl.value.trim();
      clusterKeywordEl.innerHTML = `<option value="">${options.length ? 'Select keyword from cluster' : 'No saved keywords for this cluster'}</option>${options.map(keyword => `<option value="${escapeHtml(keyword)}">${escapeHtml(keyword)}</option>`).join('')}`;
      if (currentKeyword && options.includes(currentKeyword)) {
        clusterKeywordEl.value = currentKeyword;
      } else {
        clusterKeywordEl.value = '';
      }
    }

    async function ensureSemanticKeywords() {
      const cluster = clusterEl.value.trim();
      const topic = keywordEl.value.trim() || titleEl.value.trim();
      if (!topic) throw new Error('Enter or select a keyword first.');
      const data = await api('assistant/semantic-keywords', { method:'POST', body:{ topic, keyword: keywordEl.value.trim(), title: titleEl.value.trim(), cluster } });
      const items = Array.isArray(data.keywords) ? data.keywords : [];
      state.assistant.semanticKeywords = items;
      renderSemanticPreview(items);
      return items;
    }

    function languageInstruction() {
      return `Write the draft in ${languageLabel(settings.content_language || 'en', settings.content_language_custom || '')}. Do not switch language. Return clean WordPress-ready HTML only, without markdown fences.`;
    }

    async function ensureCompetitorContext() {
      const cluster = clusterEl.value.trim();
      if (!cluster) throw new Error('Choose a cluster first.');
      const remote = await api(`settings/competitor-insights?cluster=${encodeURIComponent(cluster)}`);
      const merged = mergeCompetitorInsights(cluster, remote.insights || '', state.assistant.history);
      state.assistant.competitorContext = merged;
      return merged;
    }

    function buildPrompt() {
      const parts = [];
      if (clusterEl.value) parts.push(`Cluster: ${clusterEl.value}`);
      if (titleEl.value) parts.push(`Working title: ${titleEl.value}`);
      if (keywordEl.value) parts.push(`Primary keyword: ${keywordEl.value}`);
      if (Array.isArray(clusterKeywordMap[clusterEl.value]) && clusterKeywordMap[clusterEl.value].length) {
        parts.push(`Cluster support keywords: ${clusterKeywordMap[clusterEl.value].join(', ')}`);
      }
      if (toneCheckbox.checked && settings.tone_of_voice) parts.push(`Tone of voice instructions:\n${settings.tone_of_voice}`);
      if (competitorCheckbox.checked && state.assistant.competitorContext) parts.push(`Competitor insights:
${state.assistant.competitorContext}`);
      const selectedSemanticKeywords = semanticCheckbox.checked ? getSelectedSemanticKeywords() : [];
      if (semanticCheckbox.checked && selectedSemanticKeywords.length) parts.push(`AI semantic support keywords (use naturally as optional context, do not force them): ${selectedSemanticKeywords.join(', ')}`);
      if (pillarCheckbox.checked) parts.push('Draft type: pillar page. Build a central long-form cornerstone page for this cluster that can act as the main hub for related subtopics. Use a broad strategic introduction, a logical parent-to-child section hierarchy, detailed explanatory sections that support future cluster articles, internal-link-ready anchor phrasing, a concise FAQ section, and a short conversion-oriented closing section. Make the page authoritative, comprehensive and clearly positioned as the primary reference page within the cluster.');
      parts.push(`Content type: ${contentTypeEl && contentTypeEl.value === 'page' ? 'page' : 'post'}. If page, write with evergreen page structure and do not frame it as a dated blog article.`);
      const structureLines = [];
      if (siteStructure.homepage && siteStructure.homepage.url) structureLines.push(`Homepage: ${siteStructure.homepage.title || 'Homepage'} — ${siteStructure.homepage.url}`);
      if (siteStructure.about_page && siteStructure.about_page.url) structureLines.push(`About us: ${siteStructure.about_page.title || 'About us'} — ${siteStructure.about_page.url}`);
      (siteStructure.service_pages || []).forEach(item => { if (item && item.url) structureLines.push(`Service page: ${item.title || 'Service page'} — ${item.url}`); });
      (siteStructure.case_studies || []).forEach(item => { if (item && item.url) structureLines.push(`Case study: ${item.title || 'Case study'} — ${item.url}`); });
      if (structureLines.length) parts.push(`Important internal link targets:
${structureLines.join('\n')}
Link frequently and naturally to these pages when relevant. Prioritize service pages for commercial intent and about/case study pages for trust-building sections.`);
      parts.push(languageInstruction());
      if (promptEl.value.trim()) parts.push(`Writer instructions:\n${promptEl.value.trim()}`);
      parts.push('Structure: start with a concise introduction, use descriptive H2 and H3 headings where useful, answer the search intent directly, and end with a short conclusion or next step.');
      return parts.join('\n\n');
    }

    page.querySelector('#cgm-ai-suggest').addEventListener('click', async() => {
      try {
        renderAssistantStatus('Creating title suggestions…');
        const data = await api('assistant/title-keyword-suggestions', { method:'POST', body:{ title: titleEl.value.trim(), keyword: keywordEl.value.trim(), cluster: clusterEl.value.trim(), pillar_page: pillarCheckbox.checked } });
        const items = Array.isArray(data.suggestions) ? data.suggestions : [];
        suggestionList.innerHTML = items.map((item, idx) => `
          <button type="button" class="cgm-suggestion-chip" data-index="${idx}">
            <strong>${escapeHtml(item.title || 'Untitled suggestion')}</strong>
            <span>${escapeHtml(item.keyword || '')}</span>
            <em>${escapeHtml(item.rationale || '')}</em>
          </button>
        `).join('');
        suggestionList.querySelectorAll('.cgm-suggestion-chip').forEach(btn => btn.addEventListener('click', () => {
          const item = items[Number(btn.getAttribute('data-index'))] || {};
          if (item.title) titleEl.value = item.title;
          if (item.keyword) keywordEl.value = item.keyword;
          syncClusterKeywordOptions();
        }));
        renderAssistantStatus(items.length ? 'Suggestions loaded.' : 'No suggestions returned.', !!items.length);
      } catch(err) { renderAssistantStatus(err.message || 'Could not create suggestions.', false); }
    });

    page.querySelector('#cgm-ai-optimize-title').addEventListener('click', async() => {
      try {
        if (!titleEl.value.trim()) throw new Error('Enter a title first.');
        renderAssistantStatus('Optimizing title…');
        const data = await api('assistant/optimize-title', { method:'POST', body:{ title: titleEl.value.trim(), focus_keyword: keywordEl.value.trim() } });
        if (data.title) titleEl.value = data.title;
        renderAssistantStatus(data.rationale || 'Title optimized.');
      } catch(err) { renderAssistantStatus(err.message || 'Could not optimize title.', false); }
    });

    toneCheckbox.addEventListener('change', () => {
      renderAssistantStatus(toneCheckbox.checked ? 'Saved tone of voice will be applied to the draft.' : 'Saved tone of voice removed from this draft.');
    });

    competitorCheckbox.addEventListener('change', async() => {
      if (!competitorCheckbox.checked) {
        state.assistant.competitorContext = '';
        renderAssistantStatus('Competitor insights disabled for this draft.');
        return;
      }
      try {
        const merged = await ensureCompetitorContext();
        renderAssistantStatus(merged ? 'Competitor insights loaded for this cluster.' : 'No competitor insights found for this cluster.', !!merged);
      } catch(err) { competitorCheckbox.checked = false; renderAssistantStatus(err.message || 'Could not load competitor insights.', false); }
    });

    semanticCheckbox.addEventListener('change', async() => {
      if (!semanticCheckbox.checked) {
        state.assistant.semanticKeywords = [];
        state.assistant.semanticUnchecked = [];
        renderSemanticPreview([]);
        renderAssistantStatus('AI semantic keyword suggestions disabled for this draft.');
        return;
      }
      try {
        const items = await ensureSemanticKeywords();
        renderAssistantStatus(items.length ? 'AI semantic keyword suggestions loaded.' : 'No semantic support keywords found for this article.', !!items.length);
      } catch(err) { semanticCheckbox.checked = false; renderAssistantStatus(err.message || 'Could not load semantic keyword suggestions.', false); }
    });

    clusterEl.addEventListener('change', async() => {
      const keywords = clusterKeywordMap[clusterEl.value] || [];
      syncClusterKeywordOptions();
      if (keywords.length && !keywordEl.value.trim()) {
        keywordEl.value = keywords[0];
        clusterKeywordEl.value = keywords[0];
      }
      state.assistant.competitorContext = '';
      state.assistant.semanticKeywords = [];
      state.assistant.semanticUnchecked = [];
      renderSemanticPreview([]);
      if (competitorCheckbox.checked) {
        try { await ensureCompetitorContext(); } catch (e) {}
      }
      if (semanticCheckbox.checked) {
        try { await ensureSemanticKeywords(); } catch (e) {}
      }
    });

    clusterKeywordEl.addEventListener('change', async() => {
      if (clusterKeywordEl.value) keywordEl.value = clusterKeywordEl.value;
      if (semanticCheckbox.checked) {
        try { await ensureSemanticKeywords(); } catch (e) {}
      }
    });

    keywordEl.addEventListener('change', async() => {
      syncClusterKeywordOptions();
      if (semanticCheckbox.checked) {
        try { await ensureSemanticKeywords(); } catch (e) {}
      }
    });

    titleEl.addEventListener('change', async() => {
      if (semanticCheckbox.checked && !keywordEl.value.trim()) {
        try { await ensureSemanticKeywords(); } catch (e) {}
      }
    });

    if (semanticCustomEl) {
      syncSemanticCustomInput();
      semanticCustomEl.addEventListener('input', () => {
        state.assistant.semanticCustomKeywords = parseSemanticCustomKeywords();
      });
    }

    syncClusterKeywordOptions();

    page.querySelector('#cgm-ai-generate').addEventListener('click', async() => {
      try {
        if (competitorCheckbox.checked && !state.assistant.competitorContext) await ensureCompetitorContext();
        if (semanticCheckbox.checked && !(Array.isArray(state.assistant.semanticKeywords) && state.assistant.semanticKeywords.length)) await ensureSemanticKeywords();
        renderAssistantStatus('Starting draft generation…');
        const payload = {
          custom_topic: titleEl.value.trim() || keywordEl.value.trim(),
          focus_keyword: keywordEl.value.trim(),
          cluster: clusterEl.value.trim(),
          additional_instructions: buildPrompt(),
          content_type: contentTypeEl && contentTypeEl.value === 'page' ? 'page' : 'post',
          include_svg_visuals: !!(svgCheckbox && svgCheckbox.checked)
        };
        const start = await api('assistant/draft', { method:'POST', body: payload });
        if (!start.job_id) throw new Error('Could not start generation job.');
        const deadline = Date.now() + 8 * 60 * 1000;
        let finalData = null;
        while (Date.now() < deadline) {
          await new Promise(r => setTimeout(r, 3000));
          const status = await api(`assistant/draft-status?job_id=${encodeURIComponent(start.job_id)}`);
          const msg = status.message || 'Generating draft…';
          const progress = Number(status.progress || 0);
          renderAssistantStatus(`${msg}${progress ? ` (${progress}%)` : ''}`);
          if (status.status === 'done' || status.normalized_status === 'completed') {
            finalData = status;
            break;
          }
          if (status.status === 'failed' || status.normalized_status === 'failed' || status.error) {
            throw new Error(status.error || 'Draft generation failed.');
          }
        }
        if (!finalData) throw new Error('Generation timed out in the browser. The draft may still finish in the background. Check Drafts in a minute.');
        const html = String(finalData.post_content || '').trim();
        if (!html) {
          renderAssistantStatus('Draft generated in WordPress, but preview content was empty. Open Drafts to review it.', true);
          return;
        }
        outputEl.value = html;
        state.assistant.output = html;
        state.assistant.wpPostId = Number(finalData.wp_post_id || 0);
        state.assistant.editUrl = finalData.edit_url || '';
        if (finalData.post_title && !titleEl.value.trim()) titleEl.value = finalData.post_title;
        const saveBtn = page.querySelector('#cgm-ai-save');
        if (saveBtn && state.assistant.wpPostId) saveBtn.textContent = 'Update saved draft';
        renderAssistantStatus(finalData.edit_url ? 'Draft generated and saved to WordPress.' : 'Draft generated.');
      } catch(err) { renderAssistantStatus(err.message || 'Could not generate the draft.', false); }
    });

    page.querySelector('#cgm-ai-save').addEventListener('click', async() => {
      try {
        const html = outputEl.value.trim();
        if (!html) throw new Error('Generate a draft first.');
        const data = await api('ai-assistant/save-draft', { method:'POST', body: saveAssistantDraftPayload(settings, clusterEl.value.trim(), titleEl.value.trim() || keywordEl.value.trim(), html, contentTypeEl && contentTypeEl.value === 'page' ? 'page' : 'post', state.assistant.wpPostId || 0, !!(svgCheckbox && svgCheckbox.checked)) });
        state.assistant.wpPostId = Number(data.wp_post_id || state.assistant.wpPostId || 0);
        state.assistant.editUrl = data.edit_url || state.assistant.editUrl || '';
        const saveBtn = page.querySelector('#cgm-ai-save');
        if (saveBtn && state.assistant.wpPostId) saveBtn.textContent = 'Update saved draft';
        renderAssistantStatus(data.updated ? 'Draft updated successfully.' : (data.edit_url ? 'Draft saved successfully.' : 'Draft saved.'));
      } catch(err) { renderAssistantStatus(err.message || 'Could not save draft.', false); }
    });

    page.querySelector('#cgm-ai-copy').addEventListener('click', async() => {
      try { await navigator.clipboard.writeText(outputEl.value || ''); renderAssistantStatus('HTML copied to clipboard.'); } catch(err) { renderAssistantStatus('Could not copy the HTML.', false); }
    });
  }

  function renderHistoryListHtml(items) {
    return items.length ? items.map(historyCard).join('') : '<p class="cgm-empty-note">No stored competitor analyses yet. Run a competitor analysis to build history.</p>';
  }

  function historyCard(item) {
    const competitors = Array.isArray(item.competitors) ? item.competitors : [];
    const gaps = Array.isArray(item.gaps) ? item.gaps : [];
    const recommendations = Array.isArray(item.recommendations) ? item.recommendations : [];
    const commonH2s = Array.isArray(item.common_h2s) ? item.common_h2s : [];
    const benefits = recommendations.map(rec => String(rec.benefit || '').trim()).filter(Boolean);
    const itemId = escapeHtml(item.id || '');
    return `
      <article class="cgm-history-card" data-report-id="${itemId}">
        <div class="cgm-history-head">
          <div>
            <div class="cgm-history-kicker">${escapeHtml(item.cluster || 'No cluster')} · ${escapeHtml(item.captured_at_human || item.captured_at || '')}</div>
            <h3>${escapeHtml(item.keyword || 'Untitled analysis')}</h3>
          </div>
          <div class="cgm-history-stats">
            ${badge(`${competitors.length} competitors`, 'neutral')}
            ${badge(`${item.avg_words || 0} avg words`, 'neutral')}
            ${badge(`${item.gap_count || gaps.length} gaps`, gaps.some(g => g.severity === 'high') ? 'warning' : 'neutral')}
            <button type="button" class="cgm-btn cgm-btn--ghost cgm-history-delete" data-report-id="${itemId}">Delete</button>
          </div>
        </div>
        <div class="cgm-history-grid">
          <div>
            <div class="cgm-history-label">Top competitors</div>
            <ul class="cgm-mini-list">${competitors.slice(0,4).map(comp => `<li>${escapeHtml(comp.title || comp.host || comp.url || 'Competitor')} <span>${escapeHtml(comp.word_count ? `${comp.word_count} words` : '')}</span></li>`).join('') || '<li>No competitors stored.</li>'}</ul>
          </div>
          <div>
            <div class="cgm-history-label">Structural signals</div>
            <ul class="cgm-mini-list">${commonH2s.slice(0,5).map(h2 => `<li>${escapeHtml(h2)}</li>`).join('') || '<li>No repeated subtopics stored.</li>'}</ul>
          </div>
          <div>
            <div class="cgm-history-label">Most important gaps</div>
            <ul class="cgm-mini-list">${gaps.slice(0,4).map(gap => `<li>${escapeHtml(gap.description || gap.action || '')}</li>`).join('') || '<li>No stored gaps.</li>'}</ul>
          </div>
          <div>
            <div class="cgm-history-label">Content instructions</div>
            <ul class="cgm-mini-list">${recommendations.slice(0,4).map(rec => `<li><strong>${escapeHtml(rec.action || rec.description || '')}</strong>${rec.benefit ? `<span>${escapeHtml(rec.benefit)}</span>` : ''}</li>`).join('') || '<li>No recommendations stored.</li>'}</ul>
          </div>
          <div>
            <div class="cgm-history-label">How this improves your page</div>
            <ul class="cgm-mini-list">${benefits.slice(0,4).map(text => `<li>${escapeHtml(text)}</li>`).join('') || '<li>No explicit improvement notes stored.</li>'}</ul>
          </div>
        </div>
      </article>
    `;
  }


  function summarizeCompetitorHistory(items, cluster = '') {
    const rows = Array.isArray(items) ? items.filter(Boolean) : [];
    const normalizedCluster = String(cluster || '').trim().toLowerCase();
    const filtered = normalizedCluster ? rows.filter(item => String(item.cluster || '').trim().toLowerCase() === normalizedCluster) : rows;
    const reports = filtered.length;
    const competitors = new Map();
    const topics = new Map();
    const actions = new Map();
    let totalAvgWords = 0;
    let avgWordsCount = 0;
    let totalGaps = 0;
    let criticalGaps = 0;
    filtered.forEach(item => {
      totalGaps += Number(item.gap_count || (Array.isArray(item.gaps) ? item.gaps.length : 0) || 0);
      criticalGaps += Number(item.critical_gap_count || 0);
      const avgWords = Number(item.avg_words || 0);
      if (avgWords > 0) { totalAvgWords += avgWords; avgWordsCount += 1; }
      (Array.isArray(item.competitors) ? item.competitors : []).forEach(comp => {
        const host = String(comp.host || comp.url || '').trim();
        if (!host) return;
        competitors.set(host, (competitors.get(host) || 0) + 1);
      });
      (Array.isArray(item.common_h2s) ? item.common_h2s : []).forEach(h2 => {
        const key = String(h2 || '').trim();
        if (!key) return;
        topics.set(key, (topics.get(key) || 0) + 1);
      });
      (Array.isArray(item.recommendations) ? item.recommendations : []).forEach(rec => {
        const action = String(rec.action || rec.description || '').trim();
        if (!action) return;
        actions.set(action, (actions.get(action) || 0) + 1);
      });
    });
    const latest = filtered.slice().sort((a,b) => String(b.captured_at || '').localeCompare(String(a.captured_at || '')))[0] || null;
    return {
      cluster,
      reports,
      totalGaps,
      criticalGaps,
      avgWords: avgWordsCount ? Math.round(totalAvgWords / avgWordsCount) : 0,
      latestCapturedAt: latest ? (latest.captured_at_human || latest.captured_at || '') : '',
      latestSummary: latest ? String(latest.report_summary || '').trim() : '',
      competitors: Array.from(competitors.entries()).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([name])=>name),
      topics: Array.from(topics.entries()).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name])=>name),
      actions: Array.from(actions.entries()).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([name])=>name),
    };
  }

  function renderCompetitorMetaSummaryHtml(summary) {
    if (!summary || !summary.reports) {
      return `<div class="cgm-help-plain"><strong>Meta-analysis</strong><p>No saved competitor analyses for this cluster yet. Run Analyze cluster first.</p></div>`;
    }
    return `
      <div class="cgm-card cgm-upgrade-card cgm-competitor-meta-card">
        <div class="cgm-card__header"><h2>Cluster meta-analysis${summary.cluster ? ` · ${escapeHtml(summary.cluster)}` : ''}</h2></div>
        <div class="cgm-card__body">
          <div class="cgm-inline-actions" style="gap:8px;flex-wrap:wrap;margin-bottom:12px;">
            ${badge(`${summary.reports} saved reports`, 'neutral')}
            ${badge(`${summary.totalGaps} total gaps`, summary.criticalGaps ? 'warning' : 'neutral')}
            ${badge(`${summary.criticalGaps} critical`, summary.criticalGaps ? 'warning' : 'neutral')}
            ${badge(summary.avgWords ? `${summary.avgWords} avg words` : 'No avg words', 'neutral')}
          </div>
          <div class="cgm-history-grid">
            <div>
              <div class="cgm-history-label">Most analyzed competitors</div>
              <ul class="cgm-mini-list">${summary.competitors.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No competitor domains stored yet.</li>'}</ul>
            </div>
            <div>
              <div class="cgm-history-label">Recurring subtopics</div>
              <ul class="cgm-mini-list">${summary.topics.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No recurring subtopics stored yet.</li>'}</ul>
            </div>
            <div>
              <div class="cgm-history-label">Top writing actions</div>
              <ul class="cgm-mini-list">${summary.actions.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No recommendations stored yet.</li>'}</ul>
            </div>
          </div>
        </div>
      </div>`;
  }

  function buildCompetitorClusterSummaries(items = []) {
    const grouped = new Map();
    (Array.isArray(items) ? items : []).forEach(item => {
      const cluster = String(item.cluster || '').trim() || 'Unassigned';
      if (!grouped.has(cluster)) grouped.set(cluster, []);
      grouped.get(cluster).push(item);
    });
    return Array.from(grouped.entries())
      .map(([cluster, rows]) => summarizeCompetitorHistory(rows, cluster))
      .filter(summary => summary && summary.reports)
      .sort((a, b) => {
        if ((b.reports || 0) !== (a.reports || 0)) return (b.reports || 0) - (a.reports || 0);
        if ((b.totalGaps || 0) !== (a.totalGaps || 0)) return (b.totalGaps || 0) - (a.totalGaps || 0);
        return String(a.cluster || '').localeCompare(String(b.cluster || ''));
      });
  }

  function renderCompetitorReportsTabHtml(items = [], selectedCluster = '') {
    const normalizedFilter = String(selectedCluster || '').trim().toLowerCase();
    const summaries = buildCompetitorClusterSummaries(items).filter(summary => {
      return !normalizedFilter || String(summary.cluster || '').trim().toLowerCase() === normalizedFilter;
    });
    if (!summaries.length) {
      return '<div class="cgm-help-plain"><strong>No cluster reports yet</strong><p>Run Analyze whole cluster to build reusable meta-analyses per cluster.</p></div>';
    }
    return `<div class="cgm-cluster-report-grid">${summaries.map(summary => `
      <article class="cgm-card cgm-upgrade-card cgm-cluster-report-card" data-cluster-report="${escapeHtml(summary.cluster || '')}">
        <div class="cgm-card__header cgm-cluster-report-card__header">
          <div>
            <div class="cgm-history-kicker">Cluster report${summary.latestCapturedAt ? ` · ${escapeHtml(summary.latestCapturedAt)}` : ''}</div>
            <h2>${escapeHtml(summary.cluster || 'Unassigned')}</h2>
          </div>
          <div class="cgm-inline-actions cgm-cluster-report-badges" style="gap:8px;flex-wrap:wrap;justify-content:flex-end;">
            ${badge(`${summary.reports} saved reports`, 'neutral')}
            ${badge(`${summary.totalGaps} total gaps`, summary.criticalGaps ? 'warning' : 'neutral')}
            ${badge(summary.avgWords ? `${summary.avgWords} avg words` : 'No avg words', 'neutral')}
          </div>
        </div>
        <div class="cgm-card__body">
          ${summary.latestSummary ? `<p class="cgm-cluster-report-summary">${escapeHtml(summary.latestSummary)}</p>` : ''}
          <div class="cgm-cluster-report-card__grid">
            <div class="cgm-cluster-report-panel">
              <div class="cgm-history-label">Most analyzed competitors</div>
              <ul class="cgm-mini-list">${summary.competitors.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No competitor domains stored yet.</li>'}</ul>
            </div>
            <div class="cgm-cluster-report-panel">
              <div class="cgm-history-label">Recurring subtopics</div>
              <ul class="cgm-mini-list">${summary.topics.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No recurring subtopics stored yet.</li>'}</ul>
            </div>
            <div class="cgm-cluster-report-panel">
              <div class="cgm-history-label">Top writing actions</div>
              <ul class="cgm-mini-list">${summary.actions.map(item => `<li>${escapeHtml(item)}</li>`).join('') || '<li>No recommendations stored yet.</li>'}</ul>
            </div>
          </div>
          <div class="cgm-inline-actions cgm-cluster-report-actions">
            <button type="button" class="cgm-btn cgm-btn--secondary cgm-open-history-cluster" data-cluster="${escapeHtml(summary.cluster || '')}">Open saved reports</button>
            <button type="button" class="cgm-btn cgm-btn--ghost cgm-open-live-cluster" data-cluster="${escapeHtml(summary.cluster || '')}">Switch to live analysis</button>
          </div>
        </div>
      </article>`).join('')}</div>`;
  }

  function getCompetitorActiveCluster(host) {
    const candidates = [
      host && host.querySelector('#cgm-history-cluster-filter'),
      document.querySelector('select[name="cluster"]'),
      document.querySelector('#cgm-competitor-cluster'),
      document.querySelector('[data-cgm-competitor-cluster]'),
      ...Array.from(document.querySelectorAll('select')).filter(el => /cluster/i.test((el.name || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('aria-label') || '')))
    ].filter(Boolean);
    for (const el of candidates) {
      const value = String(el.value || '').trim();
      if (value) return value;
    }
    try {
      return String(localStorage.getItem('cgm_active_competitor_cluster') || '').trim();
    } catch (e) {
      return '';
    }
  }

  function bindCompetitorClusterPersistence(scope, refresh) {
    const controls = Array.from(scope.querySelectorAll('select,input')).filter(el => /cluster/i.test((el.name || '') + ' ' + (el.id || '') + ' ' + (el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || '')));
    controls.forEach(el => {
      if (el.dataset.cgmClusterBound === '1') return;
      el.dataset.cgmClusterBound = '1';
      el.addEventListener('change', () => {
        try { localStorage.setItem('cgm_active_competitor_cluster', String(el.value || '').trim()); } catch (e) {}
        if (typeof refresh === 'function') refresh(true).catch(() => {});
      });
    });
  }

  async function renderCompetitorPage(page) {
    const existingShell = page.querySelector('.cgm-competitor-history-shell');
    if (existingShell) {
      const rememberedCluster = getCompetitorActiveCluster(existingShell);
      const allItems = await loadCompetitorHistory('', true);
      let mergedAll = Array.isArray(allItems) ? allItems : [];
      const latest = await loadLatestCompetitorAnalysis(rememberedCluster || '');
      if (latest && Object.keys(latest).length) {
        mergedAll = mergeHistoryItems(mergedAll, [latest]);
      }
      const historyItems = rememberedCluster ? mergedAll.filter(item => String(item.cluster || '').trim().toLowerCase() === String(rememberedCluster || '').trim().toLowerCase()) : mergedAll;
      const countEls = existingShell.querySelectorAll('.cgm-history-count');
      countEls.forEach(el => { el.textContent = `(${historyItems.length})`; });
      const clusterReports = buildCompetitorClusterSummaries(mergedAll);
      const reportCountEl = existingShell.querySelector('.cgm-report-cluster-count');
      if (reportCountEl) reportCountEl.textContent = `(${clusterReports.length})`;
      const listEl = existingShell.querySelector('#cgm-history-list');
      if (listEl) listEl.innerHTML = renderHistoryListHtml(historyItems);
      const totalEl = existingShell.querySelector('.cgm-history-total');
      if (totalEl) totalEl.textContent = String(historyItems.length);
      const reportsFilterEl = existingShell.querySelector('#cgm-reports-cluster-filter');
      if (reportsFilterEl) {
        const current = reportsFilterEl.value || '';
        const clusters = clusterReports.map(item => String(item.cluster || '').trim()).filter(Boolean);
        reportsFilterEl.innerHTML = `<option value="">All clusters</option>${clusters.map(cluster => `<option value="${escapeHtml(cluster)}">${escapeHtml(cluster)}</option>`).join('')}`;
        if (clusters.includes(current)) reportsFilterEl.value = current;
      }
      const reportsListEl = existingShell.querySelector('#cgm-cluster-reports-list');
      if (reportsListEl) {
        reportsListEl.innerHTML = renderCompetitorReportsTabHtml(mergedAll, reportsFilterEl ? reportsFilterEl.value : '');
      }
      const reportsSummaryEl = existingShell.querySelector('.cgm-reports-summary-total');
      if (reportsSummaryEl) reportsSummaryEl.textContent = String(clusterReports.length);
      const liveSummary = existingShell.querySelector('.cgm-competitor-live-summary');
      if (liveSummary) { liveSummary.remove(); }
      return;
    }
    const body = page.querySelector('.cgm-page__body') || page;
    const history = await loadCompetitorHistory('', true);
    const originalChildren = Array.from(body.childNodes);
    const host = document.createElement('div');
    host.className = 'cgm-competitor-history-shell';
    const clusterReports = buildCompetitorClusterSummaries(history);
    host.innerHTML = `
      <div class="cgm-step-tabs cgm-competitor-tabs">
        <button type="button" class="cgm-tab-btn is-active" data-tab="live">Live analysis</button>
        <button type="button" class="cgm-tab-btn" data-tab="reports">Cluster reports <span class="cgm-report-cluster-count">(${clusterReports.length})</span></button>
        <button type="button" class="cgm-tab-btn" data-tab="history">Saved reports <span class="cgm-history-count">(${history.length})</span></button>
      </div>
      <div class="cgm-competitor-panel" data-tab="live"></div>
      <div class="cgm-competitor-panel" data-tab="reports" hidden>
        <div class="cgm-help-plain"><strong>Cluster reports</strong><p>This tab groups saved competitor analyses into reusable meta-analyses per cluster.</p></div>
        <div class="cgm-inline-actions is-spread cgm-history-toolbar">
          <div class="cgm-inline-actions">
            <label class="cgm-history-filter"><span>Cluster</span><select id="cgm-reports-cluster-filter"><option value="">All clusters</option></select></label>
            <div class="cgm-upgrade-note">Cluster reports: <strong class="cgm-reports-summary-total">${clusterReports.length}</strong></div>
          </div>
          <div class="cgm-inline-actions">
            <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-reports-refresh">Refresh reports</button>
          </div>
        </div>
        <div id="cgm-cluster-reports-list">${renderCompetitorReportsTabHtml(history)}</div>
      </div>
      <div class="cgm-competitor-panel" data-tab="history" hidden>
        
        <div class="cgm-inline-actions is-spread cgm-history-toolbar">
          <div class="cgm-inline-actions">
            <label class="cgm-history-filter"><span>Cluster</span><select id="cgm-history-cluster-filter"><option value="">All clusters</option></select></label>
            <div class="cgm-upgrade-note">Saved reports: <strong class="cgm-history-total">${history.length}</strong></div>
          </div>
          <div class="cgm-inline-actions">
            <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-history-refresh">Refresh</button>
            <button type="button" class="cgm-btn cgm-btn--secondary" id="cgm-history-clear">Reset all reports</button>
          </div>
        </div>
        <div id="cgm-history-list">${renderHistoryListHtml(history)}</div>
      </div>
    `;
    body.innerHTML = '';
    body.appendChild(host);
    const livePanel = host.querySelector('[data-tab="live"]');
    originalChildren.forEach(node => livePanel.appendChild(node));
    bindTabButtons(host, '.cgm-competitor-tabs .cgm-tab-btn', '.cgm-competitor-panel', 'live');
    const listEl = host.querySelector('#cgm-history-list');
    const totalEl = host.querySelector('.cgm-history-total');
    const clusterFilterEl = host.querySelector('#cgm-history-cluster-filter');
    const populateClusterFilter = (items = []) => {
      if (!clusterFilterEl) return;
      const clusters = [...new Set(items.map(item => String(item.cluster || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b));
      const current = clusterFilterEl.value || '';
      clusterFilterEl.innerHTML = `<option value="">All clusters</option>${clusters.map(cluster => `<option value="${escapeHtml(cluster)}">${escapeHtml(cluster)}</option>`).join('')}`;
      if (clusters.includes(current)) clusterFilterEl.value = current;
    };
    const reportsFilterEl = host.querySelector('#cgm-reports-cluster-filter');
    const reportsListEl = host.querySelector('#cgm-cluster-reports-list');
    const reportsSummaryEl = host.querySelector('.cgm-reports-summary-total');
    const refreshHistoryUi = async(force = false) => {
      const selectedCluster = clusterFilterEl ? clusterFilterEl.value : '';
      const rememberedCluster = getCompetitorActiveCluster(host);
      const activeCluster = selectedCluster || rememberedCluster || '';
      const allItemsBase = await loadCompetitorHistory('', force);
      let allItems = Array.isArray(allItemsBase) ? allItemsBase : [];
      const latest = await loadLatestCompetitorAnalysis(activeCluster || '');
      if (latest && Object.keys(latest).length) {
        allItems = mergeHistoryItems(allItems, [latest]);
      }
      populateClusterFilter(allItems);
      const clusterSummaries = buildCompetitorClusterSummaries(allItems);
      if (reportsFilterEl) {
        const currentReportCluster = reportsFilterEl.value || '';
        const clusters = clusterSummaries.map(item => String(item.cluster || '').trim()).filter(Boolean);
        reportsFilterEl.innerHTML = `<option value="">All clusters</option>${clusters.map(cluster => `<option value="${escapeHtml(cluster)}">${escapeHtml(cluster)}</option>`).join('')}`;
        if (clusters.includes(currentReportCluster)) reportsFilterEl.value = currentReportCluster;
      }
      if (clusterFilterEl && activeCluster && !clusterFilterEl.value) clusterFilterEl.value = activeCluster;
      const fresh = activeCluster ? allItems.filter(item => String(item.cluster || '').trim().toLowerCase() === String(activeCluster || '').trim().toLowerCase()) : allItems;
      if (activeCluster) {
        state.competitorHistoryByCluster[normalizeClusterKey(activeCluster)] = fresh;
      } else {
        state.competitorHistory = fresh;
      }
      host.querySelectorAll('.cgm-history-count').forEach(el => { el.textContent = `(${fresh.length})`; });
      const reportCountEl = host.querySelector('.cgm-report-cluster-count');
      if (reportCountEl) reportCountEl.textContent = `(${clusterSummaries.length})`;
      if (reportsSummaryEl) reportsSummaryEl.textContent = String(clusterSummaries.length);
      if (totalEl) totalEl.textContent = String(fresh.length);
      if (listEl) listEl.innerHTML = renderHistoryListHtml(fresh);
      if (reportsListEl) reportsListEl.innerHTML = renderCompetitorReportsTabHtml(allItems, reportsFilterEl ? reportsFilterEl.value : '');
      const liveSummaryMount = host.querySelector('.cgm-competitor-live-summary');
      if (liveSummaryMount) { liveSummaryMount.remove(); }
      bindHistoryDeleteButtons();
      bindClusterReportButtons();
    };
    const bindHistoryDeleteButtons = () => {
      host.querySelectorAll('.cgm-history-delete').forEach(btn => {
        if (btn.dataset.bound === '1') return;
        btn.dataset.bound = '1';
        btn.addEventListener('click', async() => {
          const id = btn.getAttribute('data-report-id') || '';
          if (!id) return;
          if (!confirm('Delete this competitor report?')) return;
          try {
            const res = await api('competitor/history/delete', { method:'POST', body:{ id } });
            state.competitorHistory = Array.isArray(res.items) ? res.items : [];
            state.competitorHistoryByCluster = {};
            await refreshHistoryUi(true);
          } catch (err) {
            alert(err.message || 'Could not delete the competitor report.');
          }
        });
      });
    };
    const bindClusterReportButtons = () => {
      host.querySelectorAll('.cgm-open-history-cluster').forEach(btn => {
        if (btn.dataset.bound === '1') return;
        btn.dataset.bound = '1';
        btn.addEventListener('click', async() => {
          const cluster = String(btn.getAttribute('data-cluster') || '').trim();
          if (clusterFilterEl) clusterFilterEl.value = cluster;
          try { localStorage.setItem('cgm_active_competitor_cluster', cluster); } catch (e) {}
          await refreshHistoryUi(true);
          const historyTab = host.querySelector('.cgm-competitor-tabs .cgm-tab-btn[data-tab="history"]');
          if (historyTab) historyTab.click();
        });
      });
      host.querySelectorAll('.cgm-open-live-cluster').forEach(btn => {
        if (btn.dataset.bound === '1') return;
        btn.dataset.bound = '1';
        btn.addEventListener('click', async() => {
          const cluster = String(btn.getAttribute('data-cluster') || '').trim();
          const controls = Array.from(page.querySelectorAll('select,input')).filter(el => /cluster/i.test((el.name || '') + ' ' + (el.id || '') + ' ' + (el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || '')));
          controls.forEach(el => {
            try { el.value = cluster; el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
          });
          try { localStorage.setItem('cgm_active_competitor_cluster', cluster); } catch (e) {}
          const liveTab = host.querySelector('.cgm-competitor-tabs .cgm-tab-btn[data-tab="live"]');
          if (liveTab) liveTab.click();
        });
      });
    };
    host.querySelector('#cgm-history-refresh').addEventListener('click', async() => { await refreshHistoryUi(true); });
    host.querySelector('#cgm-history-clear').addEventListener('click', async() => {
      if (!confirm('Delete all stored competitor reports?')) return;
      try {
        const selectedCluster = host.querySelector('#cgm-history-cluster-filter')?.value || '';
        await api('competitor/history/clear', { method:'POST', body:{ cluster: selectedCluster } });
        try { localStorage.removeItem('cgm_competitor_reports'); localStorage.removeItem('cgm_competitor_reports_by_cluster'); } catch (e) {}
        state.competitorHistory = [];
        state.competitorHistoryByCluster = {};
        await refreshHistoryUi(true);
      } catch (err) {
        alert(err.message || 'Could not clear competitor history.');
      }
    });
    if (clusterFilterEl) clusterFilterEl.addEventListener('change', async() => { await refreshHistoryUi(true); });
    if (reportsFilterEl) reportsFilterEl.addEventListener('change', async() => { await refreshHistoryUi(true); });
    const reportsRefreshBtn = host.querySelector('#cgm-reports-refresh');
    if (reportsRefreshBtn) reportsRefreshBtn.addEventListener('click', async() => { await refreshHistoryUi(true); });
    bindCompetitorClusterPersistence(page, refreshHistoryUi);
    bindHistoryDeleteButtons();
    bindClusterReportButtons();
    refreshHistoryUi(true).catch(() => {});
    window.addEventListener('cgm:competitorReportSaved', () => { refreshHistoryUi(true).catch(() => {}); });
  }

  function routeToGscSettings() {
    const settingsNav = Array.from(document.querySelectorAll('[data-page], .cgm-nav__link, a, button')).find(el => /settings/i.test((el.textContent || '').trim()));
    if (settingsNav && typeof settingsNav.click === 'function') {
      settingsNav.click();
      setTimeout(() => {
        const styleBtn = document.querySelector('.cgm-settings-tabs .cgm-tab-btn[data-tab="style"]');
        if (styleBtn && typeof styleBtn.click === 'function') styleBtn.click();
        const gscField = document.querySelector('#cgm-gsc-client-id');
        if (gscField && typeof gscField.scrollIntoView === 'function') gscField.scrollIntoView({ behavior:'smooth', block:'center' });
      }, 250);
      return true;
    }
    return false;
  }

  function hijackDashboardGscButtons() {
    const dashboardPage = pageRootByMatcher('Dashboard');
    if (!dashboardPage) return;
    dashboardPage.querySelectorAll('a,button').forEach(el => {
      const text = (el.textContent || '').trim().toLowerCase();
      if (!text || text !== 'connect gsc') return;
      if (el.dataset.cgmGscHijacked === '1') return;
      el.dataset.cgmGscHijacked = '1';
      el.addEventListener('click', (event) => {
        event.preventDefault();
        routeToGscSettings();
      });
    });
  }

  function removeOptimizerLengthControl() {
    const optimizerPage = pageRootByMatcher('Optimizer');
    if (!optimizerPage) return;
    const labels = Array.from(optimizerPage.querySelectorAll('label, .components-base-control, .cgm-field, .cgm-input-group'));
    labels.forEach((node) => {
      const text = (node.textContent || '').trim().toLowerCase();
      if (text.includes('word count') || text.includes('content length')) {
        node.remove();
      }
    });
    optimizerPage.querySelectorAll('input, select').forEach((el) => {
      const ph = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.id || '')).toLowerCase();
      if (ph.includes('word_count') || ph.includes('word count') || ph.includes('content_length') || ph.includes('content length')) {
        const wrap = el.closest('.components-base-control, .cgm-field, .cgm-input-group, label, div');
        if (wrap) wrap.remove();
      }
    });
  }

  function contentGemBrandMarkup() {
    return `
      <span class="cgm-brand-lockup" aria-label="ContentGem">
        <svg class="cgm-brand-lockup__gem" width="28" height="26" viewBox="0 0 60 56" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
          <defs>
            <linearGradient id="cg-admin-a" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C4B5FD"/><stop offset="100%" stop-color="#7C3AED"/></linearGradient>
            <linearGradient id="cg-admin-b" x1="0.5" y1="0" x2="0.5" y2="1"><stop offset="0%" stop-color="#EDE9FE"/><stop offset="100%" stop-color="#A78BFA"/></linearGradient>
            <linearGradient id="cg-admin-c" x1="1" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#C4B5FD"/><stop offset="100%" stop-color="#A855F7"/></linearGradient>
            <linearGradient id="cg-admin-p1" x1="0" y1="0" x2="0.6" y2="1"><stop offset="0%" stop-color="#6D28D9"/><stop offset="100%" stop-color="#1E1B4B"/></linearGradient>
            <linearGradient id="cg-admin-p2" x1="0.5" y1="0" x2="0.5" y2="1"><stop offset="0%" stop-color="#4C1D95"/><stop offset="100%" stop-color="#0F0E2B"/></linearGradient>
            <linearGradient id="cg-admin-p3" x1="1" y1="0" x2="0.4" y2="1"><stop offset="0%" stop-color="#8B5CF6"/><stop offset="100%" stop-color="#1E1B4B"/></linearGradient>
          </defs>
          <polygon points="0,22 3,10 15,22" fill="#1E1B4B" opacity="0.85"/>
          <polygon points="3,10 15,0 15,22" fill="url(#cg-admin-a)" opacity="0.95"/>
          <polygon points="15,0 30,0 15,22" fill="url(#cg-admin-b)" opacity="0.97"/>
          <polygon points="30,0 45,0 45,22" fill="url(#cg-admin-b)" opacity="0.90"/>
          <polygon points="45,0 57,10 45,22" fill="url(#cg-admin-c)" opacity="0.92"/>
          <polygon points="57,10 60,22 45,22" fill="#2D2369" opacity="0.85"/>
          <polygon points="0,22 15,22 30,56" fill="url(#cg-admin-p1)" opacity="0.97"/>
          <polygon points="15,22 30,22 30,56" fill="url(#cg-admin-p2)" opacity="0.90"/>
          <polygon points="30,22 45,22 30,56" fill="#2D2867" opacity="0.88"/>
          <polygon points="45,22 60,22 30,56" fill="url(#cg-admin-p3)" opacity="0.97"/>
          <circle cx="30" cy="55" r="1.4" fill="white" opacity="0.55"/>
        </svg>
        <span class="cgm-brand-lockup__text">ContentGem</span>
      </span>`;
  }

  function applySidebarBranding() {
    const sidebar = document.querySelector('#contentgem-dashboard .cgm-nav, #contentgem-dashboard .contentgem-app aside');
    if (!sidebar) return;
    const brand = sidebar.querySelector('.cgm-nav__brand') || sidebar.firstElementChild;
    if (!brand || brand.dataset.cgmBrandApplied === '1') return;
    brand.dataset.cgmBrandApplied = '1';
    brand.innerHTML = contentGemBrandMarkup();
  }

  function detectCurrentViewTitle() {
    const page = document.querySelector('#contentgem-dashboard .contentgem-main');
    if (!page) return '';
    const heading = page.querySelector('h1, .cgm-page__title, h2');
    return String((heading && heading.textContent) || '').trim();
  }

  function looksLikeLightCard(el) {
    if (!el || el.closest('aside')) return false;
    const style = window.getComputedStyle(el);
    const bg = String(style.backgroundColor || '').replace(/\s+/g, '');
    const lightBgs = new Set(['rgb(255,255,255)', 'rgba(255,255,255,1)', 'rgb(248,250,252)', 'rgba(248,250,252,1)', 'rgb(248,252,255)', 'rgba(248,252,255,1)', 'rgb(239,248,255)', 'rgba(239,248,255,1)', 'rgb(236,253,245)', 'rgba(236,253,245,1)', 'rgb(254,242,242)', 'rgba(254,242,242,1)']);
    const radius = parseFloat(style.borderRadius || '0');
    const rect = el.getBoundingClientRect();
    const hasContent = !!String(el.textContent || '').trim() || !!el.querySelector('input, select, textarea, button, table');
    return lightBgs.has(bg) && radius >= 8 && rect.width > 220 && hasContent;
  }

  function classifyButtons(root) {
    root.querySelectorAll('button, a.button, .cgm-btn').forEach((btn) => {
      const text = String(btn.textContent || '').trim().toLowerCase();
      btn.classList.remove('cgm-v40-btn-primary','cgm-v40-btn-secondary','cgm-v40-btn-danger','cgm-v40-btn-success');
      if (!text) return;
      if (/delete|remove|reset|discard/.test(text)) {
        btn.classList.add('cgm-v40-btn-danger');
      } else if (/publish|connected|complete|saved|continue/.test(text)) {
        btn.classList.add('cgm-v40-btn-success');
      } else if (/analy|generate|create|load|save|go to|find|scan|categorize|schedule|refresh|run all|suggest|optimize|show|view plans|connect|preview|start dry-run/.test(text)) {
        btn.classList.add('cgm-v40-btn-primary');
      } else {
        btn.classList.add('cgm-v40-btn-secondary');
      }
    });
  }

  function applyUnifiedLayoutV40() {
    const main = document.querySelector('#contentgem-dashboard .contentgem-main');
    const sidebar = document.querySelector('#contentgem-dashboard .contentgem-app aside');
    if (!main) return;

    if (sidebar) {
      const brand = sidebar.firstElementChild;
      if (brand) brand.classList.add('cgm-v40-sidebar-brand');
      sidebar.querySelectorAll('button[data-page]').forEach((btn) => {
        const isActive = String(btn.style.background || '').includes('linear-gradient') || btn.style.color === 'rgb(255, 255, 255)';
        btn.classList.toggle('is-active', !!isActive);
      });
    }

    const viewTitle = detectCurrentViewTitle().toLowerCase();
    if (!viewTitle || viewTitle === 'settings') return;

    const pageRoot = main.firstElementChild || main;
    pageRoot.dataset.cgmUpgradeMode = 'unified-v40';
    const heading = pageRoot.querySelector('h1, .cgm-page__title, h2');
    if (heading) heading.classList.add('cgm-v40-page-title');
    const lead = heading && heading.parentElement ? heading.parentElement.querySelector('p') : pageRoot.querySelector(':scope > p');
    if (lead) lead.classList.add('cgm-v40-subtitle');

    main.querySelectorAll('.cgm-card, .postbox, .components-card, div, section, article').forEach((el) => {
      if (el.classList.contains('cgm-v40-card')) return;
      if (el.classList.contains('cgm-card') || looksLikeLightCard(el)) {
        el.classList.add('cgm-v40-card');
      }
    });

    classifyButtons(main);
  }

  function cleanupContentGaps() {
    const page = pageRootByMatcher('Content Gaps');
    if (!page) return;
    page.querySelectorAll('button, a, span, div, p').forEach((el) => {
      const text = String(el.textContent || '').trim();
      if (/^suggestion$/i.test(text)) {
        el.remove();
      }
    });
    page.querySelectorAll('[data-action="suggest"], [data-cgm-action="suggest"]').forEach(el => el.remove());
  }


  function isLightBackground(color) {
    if (!color || color === 'transparent') return false;
    const rgb = String(color).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!rgb) return false;
    const r = Number(rgb[1] || 0), g = Number(rgb[2] || 0), b = Number(rgb[3] || 0);
    return (r + g + b) / 3 > 210;
  }

  function hardenIndexationCard() {
    const main = document.querySelector('#contentgem-dashboard .contentgem-main');
    if (!main) return;
    const headings = Array.from(main.querySelectorAll('h1, h2, h3, strong, p, div, span'));
    const label = headings.find((el) => /indexation monitor/i.test(String(el.textContent || '').trim()));
    if (!label) return;

    const loadBtn = Array.from(main.querySelectorAll('button')).find((btn) => /^(load|refresh)$/i.test(String(btn.textContent || '').trim()) || /loading/i.test(String(btn.textContent || '').trim()));
    let card = label.closest('.cgm-v40-card, .cgm-card, section, article, div');

    if (loadBtn) {
      const branch = loadBtn.closest('section, article, div');
      if (branch && (!card || (card.contains(branch) && branch !== card))) {
        card = branch;
      }
    }

    if (!card) return;

    const candidates = [card, card.parentElement, card.parentElement && card.parentElement.parentElement].filter(Boolean);
    const best = candidates.sort((a, b) => (b.getBoundingClientRect().width * b.getBoundingClientRect().height) - (a.getBoundingClientRect().width * a.getBoundingClientRect().height))[0] || card;
    best.classList.add('cgm-v40-card', 'cgm-v40-indexation-card');
    best.querySelectorAll('div, section, article').forEach((el) => {
      const txt = String(el.textContent || '').trim();
      if (/indexation monitor|track which posts google has indexed|click load to check indexation status|indexnow/i.test(txt)) {
        el.classList.add('cgm-v40-indexation-panel');
      }
      const cs = window.getComputedStyle(el);
      if (isLightBackground(cs.backgroundColor) && !el.matches('input, textarea, select, button')) {
        el.style.background = 'rgba(15,18,53,.72)';
        el.style.borderColor = 'rgba(124,58,237,.16)';
        el.style.color = '#F4F1FF';
      }
    });
    [best, best.parentElement].filter(Boolean).forEach((el) => {
      const cs = window.getComputedStyle(el);
      if (isLightBackground(cs.backgroundColor)) {
        el.style.background = 'linear-gradient(180deg, rgba(11,16,58,.96), rgba(9,13,48,.96))';
      }
    });
  }


  function polishLinkingPanels() {
    const pages = Array.from(document.querySelectorAll('.cgm-page'));
    pages.forEach((page) => {
      const headings = Array.from(page.querySelectorAll('h2'));
      headings.forEach((heading) => {
        const label = String(heading.textContent || '').trim();
        const section = heading.parentElement;
        if (!section) return;
        if (/Re-evaluate\s*&\s*Reinsert all internal links/i.test(label)) {
          section.classList.add('cgm-reinsert-panel');
          const stats = Array.from(section.querySelectorAll('div')).find((el) => /Posts to update/i.test(el.textContent || '') && /Links to insert/i.test(el.textContent || ''));
          if (stats) {
            stats.classList.add('cgm-reinsert-stats');
            Array.from(stats.children || []).forEach((card) => {
              card.style.borderRadius = '12px';
              card.style.border = '1px solid rgba(129,140,248,.22)';
            });
          }
          const tableWrap = Array.from(section.querySelectorAll('div')).find((el) => el.querySelector && el.querySelector('table'));
          if (tableWrap) {
            tableWrap.classList.add('cgm-reinsert-table-wrap');
            tableWrap.style.background = 'rgba(7,12,36,.96)';
            tableWrap.querySelectorAll('table,thead,tbody,tr,td,th,div,span').forEach((node) => { if (node && node.style) { node.style.background = 'transparent'; node.style.color = '#EAF2FF'; node.style.borderColor = 'rgba(129,140,248,.14)'; } });
            tableWrap.style.borderRadius = '12px';
            tableWrap.style.border = '1px solid rgba(129,140,248,.18)';
          }
          const danger = Array.from(section.querySelectorAll('div')).find((el) => /This will modify content/i.test(el.textContent || ''));
          if (danger) {
            danger.classList.add('cgm-reinsert-danger');
            danger.style.background = 'rgba(24,10,24,.96)';
            danger.style.border = '1px solid rgba(248,113,113,.28)';
            danger.style.borderRadius = '12px';
            Array.from(danger.querySelectorAll('*')).forEach((node) => {
              if (node && node.style) node.style.color = '#FFF2F2';
            });
            const input = danger.querySelector('input[type="text"]');
            const buttons = Array.from(danger.querySelectorAll('button'));
            const applyBtn = buttons.find((btn) => /apply changes/i.test(String(btn.textContent || '')) ) || buttons[0] || null;
            const cancelBtn = buttons.find((btn) => /cancel/i.test(String(btn.textContent || '')) ) || buttons[buttons.length - 1] || null;
            if (input) {
              input.classList.add('cgm-reinsert-confirm-input');
              input.setAttribute('autocomplete','off');
              input.setAttribute('spellcheck','false');
              input.style.background = 'rgba(10,15,52,.96)';
              input.style.color = 'rgba(12,15,48,.92)';
              input.style.border = '2px solid rgba(129,140,248,.65)';
            }
            const syncApplyState = () => {
              const confirmed = !!input && String(input.value || '').trim().toUpperCase() === 'CONFIRM';
              buttons.forEach((btn) => {
                btn.style.display = 'inline-flex';
                btn.style.alignItems = 'center';
                btn.style.justifyContent = 'center';
                btn.style.opacity = '1';
                btn.style.visibility = 'visible';
                btn.style.borderRadius = '10px';
                btn.style.fontWeight = '700';
                btn.style.minWidth = '120px';
              });
              if (applyBtn) {
                applyBtn.disabled = !confirmed;
                applyBtn.style.cursor = confirmed ? 'pointer' : 'not-allowed';
                applyBtn.style.background = confirmed ? 'linear-gradient(135deg,#7C3AED,#C084FC)' : 'rgba(148,163,184,.30)';
                applyBtn.style.color = confirmed ? 'rgba(12,15,48,.92)' : 'rgba(108,76,255,.20)';
                applyBtn.style.border = confirmed ? '1px solid rgba(56,189,248,.32)' : '1px solid rgba(148,163,184,.22)';
              }
              if (cancelBtn) {
                cancelBtn.style.background = 'rgba(15,23,42,.75)';
                cancelBtn.style.color = 'rgba(108,76,255,.20)';
                cancelBtn.style.border = '1px solid rgba(129,140,248,.22)';
              }
            };
            if (input && !input.dataset.cgmConfirmBound) {
              input.dataset.cgmConfirmBound = '1';
              ['input','change','keyup','paste'].forEach((evt) => input.addEventListener(evt, syncApplyState));
            }
            syncApplyState();
          }
        }
        if (/Internal Link Suggestions/i.test(label)) {
          section.classList.add('cgm-link-suggestions-panel');
          section.querySelectorAll('input, select, button').forEach((el) => {
            if (el.tagName === 'BUTTON') {
              el.style.borderRadius = '10px';
              el.style.fontWeight = '700';
            } else {
              el.style.background = 'rgba(10,15,52,.96)';
              el.style.color = '#F8FAFF';
              el.style.border = '1px solid rgba(129,140,248,.35)';
              el.style.borderRadius = '10px';
            }
          });
        }
      });
    });
  }


  let dashboardMetricsPromise = null;
  function enhanceDashboardLinkMetrics() {
    const page = pageRootByMatcher('Dashboard');
    if (!page || !window.contentgemData || page.dataset.cgmDashboardMetricsBound === '1') return;
    page.dataset.cgmDashboardMetricsBound = '1';
    const restUrl = String(window.contentgemData.restUrl || '');
    if (!restUrl) return;
    dashboardMetricsPromise = dashboardMetricsPromise || fetch(restUrl + 'authority/clusters?limit=50', {
      headers: { 'X-WP-Nonce': String(window.contentgemData.nonce || '') }
    }).then(r => r.json()).catch(() => null);
    dashboardMetricsPromise.then((payload) => {
      const rows = Array.from(page.querySelectorAll('tr'));
      const items = Array.isArray(payload?.data) ? payload.data : (Array.isArray(payload) ? payload : []);
      const map = new Map(items.map(item => [String(item.name || '').trim().toLowerCase(), item]));
      rows.forEach((row) => {
        const cells = row.querySelectorAll('td,th');
        if (!cells.length) return;
        const labelCell = cells[0];
        const key = String(labelCell.textContent || '').trim().toLowerCase();
        const item = map.get(key);
        if (!item || labelCell.querySelector('.cgm-dashboard-link-metrics')) return;
        const wrap = document.createElement('div');
        wrap.className = 'cgm-dashboard-link-metrics';
        wrap.innerHTML = `
          <span class="cgm-stat-chip">Cluster links: ${Number(item.links_within_cluster || 0)}</span>
          <span class="cgm-stat-chip">To pillar: ${Number(item.links_to_pillar_page || 0)}</span>
        `;
        labelCell.appendChild(wrap);
      });
    });
  }



  function closestPanelForHeading(heading, page) {
    if (!heading) return null;
    let el = heading.closest('.cgm-card, .cgm-intel-card, .cgm-v40-card, section, article, div');
    while (el && el !== page) {
      const rect = typeof el.getBoundingClientRect === 'function' ? el.getBoundingClientRect() : { width: 0, height: 0 };
      if (el.classList.contains('cgm-card') || el.classList.contains('cgm-intel-card') || el.classList.contains('cgm-v40-card')) return el;
      if (el.parentElement === page) return el;
      if (rect.width > 240 && el.children && el.children.length > 1) return el;
      el = el.parentElement;
    }
    return heading.parentElement || heading;
  }

  function cleanDashboardTable(table, mode) {
    if (!table || table.dataset.cgmCleanBound === '1') return;
    table.dataset.cgmCleanBound = '1';
    table.classList.add('cgm-dash-table');
    table.querySelectorAll('thead th').forEach((cell) => {
      cell.style.background = 'rgba(38,30,88,.94)';
      cell.style.color = '#DDD6FE';
      cell.style.borderBottom = '1px solid rgba(108,76,255,.24)';
      cell.style.textTransform = 'uppercase';
      cell.style.letterSpacing = '.04em';
    });
    table.querySelectorAll('tbody tr').forEach((row) => {
      row.style.background = 'transparent';
      row.style.borderBottom = '1px solid rgba(108,76,255,.10)';
    });
    table.querySelectorAll('tbody td').forEach((cell) => {
      cell.style.background = 'transparent';
      cell.style.color = '#F8FAFF';
      cell.style.borderBottom = '1px solid rgba(108,76,255,.10)';
    });
    if (mode === 'coverage') {
      table.querySelectorAll('tbody td button, tbody td a').forEach((action) => {
        const text = String(action.textContent || '').trim().toLowerCase();
        if (text.includes('view gaps')) {
          action.classList.add('cgm-btn', 'cgm-btn--secondary');
          action.style.background = 'rgba(76,29,149,.30)';
          action.style.border = '1px solid rgba(108,76,255,.24)';
          action.style.color = '#EDE9FE';
          action.style.borderRadius = '10px';
          action.style.padding = '6px 12px';
          action.style.textDecoration = 'none';
        }
        if (text.includes('set pillar')) {
          action.style.color = '#DDD6FE';
        }
      });
    }
  }

  function applyCleanDashboardRebuild() {
    const page = pageRootByMatcher('Dashboard');
    if (!page) return;
    page.classList.add('cgm-dashboard-clean');

    const headingMap = [
      ['Topical authority overview', 'cgm-dash-card cgm-dash-authority-card'],
      ['GSC Intelligence', 'cgm-dash-card cgm-dash-gsc-card'],
      ['Topical coverage', 'cgm-dash-card cgm-dash-coverage-card'],
      ['Indexation monitor', 'cgm-dash-card cgm-dash-indexation-card'],
      ['AI credits this month', 'cgm-dash-card cgm-dash-credits-card']
    ];

    page.querySelectorAll('h2, h3, h4').forEach((heading) => {
      const label = String(heading.textContent || '').trim();
      const matched = headingMap.find(([needle]) => label.toLowerCase().includes(needle.toLowerCase()));
      if (!matched) return;
      const block = closestPanelForHeading(heading, page);
      if (!block) return;
      matched[1].split(/\s+/).forEach((cls) => cls && block.classList.add(cls));
    });

    page.querySelectorAll('.cgm-intel-panel').forEach((panel) => panel.classList.add('cgm-dash-panel'));
    page.querySelectorAll('.cgm-intel-kpi').forEach((panel) => panel.classList.add('cgm-dash-panel'));
    page.querySelectorAll('.cgm-dashboard-link-metrics .cgm-stat-chip').forEach((chip) => chip.classList.add('cgm-dash-statbar'));

    page.querySelectorAll('table').forEach((table) => {
      const card = table.closest('.cgm-dash-coverage-card, .cgm-dash-authority-card, .cgm-intel-card, .cgm-v40-indexation-card');
      const mode = card && card.classList.contains('cgm-dash-coverage-card') ? 'coverage' : '';
      cleanDashboardTable(table, mode);
    });

    page.querySelectorAll('tr, td, th').forEach((node) => {
      if (node.tagName === 'TH') return;
      node.style.backgroundColor = 'transparent';
      if (node.tagName === 'TD') node.style.color = '#F8FAFF';
    });
  }

  function applyAssistantSurfaceCleanup() {
    const page = pageRootByMatcher('AI Assistant');
    if (!page) return;
    page.querySelectorAll('.cgm-toolbar-grid.assistant-grid > .cgm-field, .cgm-field').forEach((field) => {
      field.style.background = 'transparent';
      field.style.border = '0';
      field.style.boxShadow = 'none';
      field.style.padding = '0';
    });
    page.querySelectorAll('.cgm-field > label').forEach((label) => {
      label.style.background = 'transparent';
      label.style.border = '0';
      label.style.boxShadow = 'none';
      label.style.padding = '0';
    });
  }

  function applyOptimizerCleanRebuild() {
    const page = pageRootByMatcher('Optimizer');
    if (!page) return;
    page.classList.add('cgm-optimizer-clean');
    page.querySelectorAll(':scope > .cgm-card, .cgm-card').forEach((card) => card.classList.add('cgm-opt-card'));
    page.querySelectorAll('div, section, article').forEach((el) => {
      const text = String(el.textContent || '').trim();
      const cs = window.getComputedStyle(el);
      if ((/Re-evaluate\s*&\s*Reinsert all internal links/i.test(text) || /Internal Link Suggestions/i.test(text)) || /59, 130, 246|6, 182, 212/.test(String(cs.backgroundColor || ''))) {
        el.classList.add('cgm-opt-card');
        if (!el.matches('input, textarea, select, button')) {
          el.style.background = 'linear-gradient(180deg, rgba(12,14,56,.95), rgba(14,16,60,.94))';
          el.style.borderColor = 'rgba(108,76,255,.24)';
          el.style.color = '#F8FAFF';
        }
      }
    });
  }

  function runPostRenderHardfixes() {
    applySidebarBranding();
    cleanupContentGaps();
    applyUnifiedLayoutV40();
    hardenIndexationCard();
    polishLinkingPanels();
    enhanceDashboardLinkMetrics();
    applyCleanDashboardRebuild();
    applyAssistantSurfaceCleanup();
    applyOptimizerCleanRebuild();
  }

  let mounting = false;
  async function mount() {
    if (mounting) return;
    mounting = true;
    try {
      const settings = await loadSettings();
      if (!onboardingCompleteLikely(settings)) {
        renderOnboardingWizard(settings);
        return;
      }
      const shellRoot = getRoot();
      if (shellRoot && shellRoot.dataset.cgmUpgradeMode === 'onboarding-v32') delete shellRoot.dataset.cgmUpgradeMode;
      const settingsPage = pageRootByMatcher('Settings');
      if (settingsPage) renderSettingsPage(settingsPage, settings);
      const assistantPage = pageRootByMatcher('AI Assistant');
      if (assistantPage) await renderAssistantPage(assistantPage, settings);
      const competitorPage = pageRootByMatcher(t => /Competitor/i.test(t || ''));
      if (competitorPage) await renderCompetitorPage(competitorPage, settings);
      hijackDashboardGscButtons();
      if (typeof removeOptimizerLengthControl === 'function') removeOptimizerLengthControl();
      runPostRenderHardfixes();
    } catch(err) {
      console.warn('Contentgem upgrade layer failed', err);
    } finally {
      mounting = false;
    }
  }

  function scheduleMount(delay = 60) {
    window.clearTimeout(scheduleMount._timer);
    scheduleMount._timer = window.setTimeout(() => { mount(); }, delay);
  }

  window.removeOptimizerLengthControl = removeOptimizerLengthControl;
  document.addEventListener('DOMContentLoaded', () => {
    const url = new URL(window.location.href);
    if (url.searchParams.get('gsc_connected') || url.searchParams.get('gsc_error')) {
      state.settings = null;
    }
    scheduleMount(10);

    document.addEventListener('click', (event) => {
      const trigger = event.target && event.target.closest && event.target.closest(
        '.cgm-nav__item, .cgm-page-nav button, a[href*="page=contentgem"], [data-page]'
      );
      if (!trigger) return;
      scheduleMount(120);
    }, true);

    window.addEventListener('popstate', () => scheduleMount(50));
    window.addEventListener('load', () => setTimeout(runPostRenderHardfixes, 120));
    setTimeout(runPostRenderHardfixes, 500);
    setTimeout(runPostRenderHardfixes, 1400);
  });
})();
