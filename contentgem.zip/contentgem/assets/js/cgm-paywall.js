/**
 * cgm-paywall.js — Free-tier paywall visibility
 * ---------------------------------------------------------------
 * Makes it obvious to Free users which navigation items are locked
 * behind the Growth plan, and intercepts clicks on those items to
 * show an upgrade modal instead of navigating to a broken/empty
 * page.
 *
 * This script is intentionally minimal and defensive:
 *  - No-op if the user is on a paid plan (Growth or Unlimited).
 *  - Scoped to #contentgem-dashboard only.
 *  - Uses text-matching because the React SPA class names are
 *    minified and unstable across builds.
 *  - Works alongside the REST 402 gating as defence-in-depth.
 *
 * Locked features for Free users (from cg-features.php):
 *   Optimizer, Competitor
 *
 * NB: Content Gaps, AI Assistant, Drafts, Dashboard and Settings
 * are all Free-available and must NOT be locked.
 */
(function(){
  if (window.__CGMPaywallInit) return;
  window.__CGMPaywallInit = true;

  var data = window.contentgemData || {};

  // Only Free users see the paywall UI. Growth/Unlimited see nothing.
  function isFree() {
    var plan = String(data.plan || '').toLowerCase();
    if (plan === 'growth' || plan === 'unlimited' || plan === 'pro' || plan === 'agency') return false;
    // Fallback: if clusterLimit is unlimited (-1), treat as paid.
    if (typeof data.clusterLimit === 'number' && data.clusterLimit < 0) return false;
    return true;
  }

  // Locked features — matched against the React SPA's `data-page` attribute,
  // which is the most stable selector (independent of i18n, classnames or
  // DOM structure). Falls back to text content if no data-page is found.
  var LOCKED_PAGES = ['optimizer', 'competitor'];
  var LOCKED_LABELS = ['optimizer', 'competitor'];

  var UPGRADE_URL = 'https://checkout.freemius.com/product/26143/plan/45313/licenses/1/';

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function txt(n){ return String((n && n.textContent) || '').replace(/\s+/g,' ').trim(); }

  function findNavItems(){
    var dash = document.getElementById('contentgem-dashboard');
    if (!dash) return [];
    var matches = [];

    // Primary: match by data-page attribute (most stable).
    LOCKED_PAGES.forEach(function(page){
      qsa('[data-page="' + page + '"]', dash).forEach(function(el){
        matches.push({ el: el, label: page });
      });
    });

    // Fallback: text-content match for any nav-like element without data-page.
    if (matches.length === 0) {
      var candidates = qsa('button, a, [role="menuitem"], [role="tab"], [role="button"]', dash);
      candidates.forEach(function(el){
        if (el.hasAttribute('data-page')) return;
        var label = txt(el).toLowerCase();
        if (!label || label.length > 40) return;
        LOCKED_LABELS.forEach(function(locked){
          if (label === locked || label === locked + ' 🔒') {
            matches.push({ el: el, label: locked });
          }
        });
      });
    }

    return matches;
  }

  function badgeHtml(){
    return '<span class="cgm-paywall-badge" aria-label="Growth plan required">Growth</span>';
  }

  function injectBadge(el){
    if (!el || el.querySelector('.cgm-paywall-badge')) return;
    var badge = document.createElement('span');
    badge.className = 'cgm-paywall-badge';
    badge.setAttribute('aria-label', 'Growth plan required');
    badge.textContent = 'Growth';
    el.appendChild(badge);
  }

  function interceptClick(match){
    var el = match.el;
    if (el.__cgmPaywallBound) return;
    el.__cgmPaywallBound = true;
    el.addEventListener('click', function(ev){
      // Capture-phase prevent + stop, so React's router never sees it.
      ev.preventDefault();
      ev.stopPropagation();
      ev.stopImmediatePropagation();
      showUpgradeModal(match.label);
    }, true);
  }

  // ===== Modal =====

  function featureDescription(label){
    if (label === 'optimizer') {
      return 'The Optimizer runs full internal link rebuilds, pillar-page mapping, keyword cannibalization detection, auto-categorization, and internal link suggestions across your whole site.';
    }
    if (label === 'competitor') {
      return 'Competitor analysis pulls the SERP top-10 for each of your clusters, extracts their heading structure, and surfaces content gaps you can act on.';
    }
    return 'This feature is available on the Growth plan.';
  }

  function showUpgradeModal(label){
    // Remove any existing modal first.
    var existing = document.getElementById('cgm-paywall-modal');
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);

    var featureTitle = label.charAt(0).toUpperCase() + label.slice(1);

    var overlay = document.createElement('div');
    overlay.id = 'cgm-paywall-modal';
    overlay.className = 'cgm-paywall-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-labelledby', 'cgm-paywall-title');

    overlay.innerHTML = [
      '<div class="cgm-paywall-card">',
        '<button class="cgm-paywall-close" aria-label="Close">&times;</button>',
        '<div class="cgm-paywall-lock">🔒</div>',
        '<h2 class="cgm-paywall-title" id="cgm-paywall-title">',
          featureTitle + ' is a Growth feature',
        '</h2>',
        '<p class="cgm-paywall-desc">' + featureDescription(label) + '</p>',
        '<div class="cgm-paywall-price-row">',
          '<div class="cgm-paywall-price">',
            '<span class="cgm-paywall-price-amount">$9.95</span>',
            '<span class="cgm-paywall-price-unit">/month</span>',
          '</div>',
          '<div class="cgm-paywall-price-annual">or $99.95/year — save 16%</div>',
        '</div>',
        '<ul class="cgm-paywall-features">',
          '<li>Unlimited clusters and content gaps</li>',
          '<li>Competitor analysis (up to 20 tracked)</li>',
          '<li>Internal linking automation + optimizer</li>',
          '<li>Search Console integration</li>',
          '<li>Authority dashboard &amp; saved reports</li>',
        '</ul>',
        '<div class="cgm-paywall-actions">',
          '<a class="cgm-paywall-cta" href="' + UPGRADE_URL + '" target="_blank" rel="noopener noreferrer">Upgrade to Growth</a>',
          '<button class="cgm-paywall-cancel" type="button">Maybe later</button>',
        '</div>',
        '<p class="cgm-paywall-note">7-day refund policy · Secure checkout via Freemius</p>',
      '</div>'
    ].join('');

    document.body.appendChild(overlay);

    function close(){
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      document.removeEventListener('keydown', onKey);
    }
    function onKey(e){ if (e.key === 'Escape') close(); }

    overlay.querySelector('.cgm-paywall-close').addEventListener('click', close);
    overlay.querySelector('.cgm-paywall-cancel').addEventListener('click', close);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) close(); });
    document.addEventListener('keydown', onKey);
  }

  // ===== Styles =====

  function ensureStyles(){
    if (document.getElementById('cgm-paywall-style')) return;
    var s = document.createElement('style');
    s.id = 'cgm-paywall-style';
    s.textContent = [
      '.cgm-paywall-badge{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;background:linear-gradient(135deg,#8b5cf6,#6d28d9);color:#fff;vertical-align:middle;line-height:1.4;white-space:nowrap;}',
      '.cgm-paywall-overlay{position:fixed;inset:0;background:rgba(5,8,24,.82);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;z-index:100000;padding:20px;animation:cgmPaywallFade .18s ease-out;}',
      '@keyframes cgmPaywallFade{from{opacity:0}to{opacity:1}}',
      '.cgm-paywall-card{position:relative;max-width:480px;width:100%;background:linear-gradient(180deg,rgba(30,27,75,.98),rgba(15,10,44,.98));border:1px solid rgba(139,92,246,.4);border-radius:18px;padding:36px 32px 28px;box-shadow:0 30px 80px rgba(0,0,0,.5);color:#f5f3ff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;}',
      '.cgm-paywall-close{position:absolute;top:14px;right:14px;width:32px;height:32px;border-radius:50%;border:none;background:rgba(255,255,255,.06);color:#c4b5fd;font-size:22px;line-height:1;cursor:pointer;}',
      '.cgm-paywall-close:hover{background:rgba(255,255,255,.12);color:#fff;}',
      '.cgm-paywall-lock{font-size:34px;margin-bottom:12px;}',
      '.cgm-paywall-title{margin:0 0 10px;font-size:22px;font-weight:800;color:#f5f3ff;line-height:1.25;}',
      '.cgm-paywall-desc{margin:0 0 20px;font-size:14px;line-height:1.55;color:#c4b5fd;}',
      '.cgm-paywall-price-row{display:flex;flex-direction:column;gap:2px;margin-bottom:20px;padding:16px 18px;background:rgba(124,58,237,.12);border:1px solid rgba(124,58,237,.3);border-radius:12px;}',
      '.cgm-paywall-price{display:flex;align-items:baseline;gap:6px;}',
      '.cgm-paywall-price-amount{font-size:28px;font-weight:800;color:#f5f3ff;letter-spacing:-.01em;}',
      '.cgm-paywall-price-unit{font-size:14px;color:#c4b5fd;font-weight:600;}',
      '.cgm-paywall-price-annual{font-size:12px;color:#a5b4fc;}',
      '.cgm-paywall-features{margin:0 0 24px;padding:0;list-style:none;}',
      '.cgm-paywall-features li{padding:6px 0 6px 26px;position:relative;font-size:13px;color:#e0e7ff;line-height:1.5;}',
      '.cgm-paywall-features li::before{content:"✓";position:absolute;left:0;top:6px;color:#10b981;font-weight:800;}',
      '.cgm-paywall-actions{display:flex;gap:10px;align-items:center;}',
      '.cgm-paywall-cta{flex:1;display:inline-block;padding:13px 20px;border-radius:10px;background:linear-gradient(135deg,#8b5cf6,#6d28d9);color:#fff !important;font-weight:700;font-size:14px;text-align:center;text-decoration:none;transition:transform .12s;}',
      '.cgm-paywall-cta:hover{transform:translateY(-1px);color:#fff !important;}',
      '.cgm-paywall-cancel{padding:13px 18px;border-radius:10px;background:transparent;border:1px solid rgba(139,92,246,.35);color:#c4b5fd;font-weight:600;font-size:13px;cursor:pointer;}',
      '.cgm-paywall-cancel:hover{background:rgba(139,92,246,.1);color:#f5f3ff;}',
      '.cgm-paywall-note{margin:16px 0 0;font-size:11px;color:#a5b4fc;text-align:center;}'
    ].join('\n');
    document.head.appendChild(s);
  }

  // ===== Main loop =====

  var scheduled = false;
  function schedule(){
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function(){
      scheduled = false;
      // Re-check plan each schedule — if a license was activated after
      // page load, /plan-state fetch in admin-v23-upgrade.js will update
      // window.contentgemData, and we should stop badging.
      if (!isFree()) {
        // Remove any badges and unbind modal intercepts left from earlier.
        qsa('.cgm-paywall-badge').forEach(function(b){ if (b.parentNode) b.parentNode.removeChild(b); });
        return;
      }
      ensureStyles();
      findNavItems().forEach(function(match){
        injectBadge(match.el);
        interceptClick(match);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', schedule);
  window.addEventListener('load', schedule);
  // React re-renders the nav on route change — reschedule on clicks.
  document.addEventListener('click', function(){ setTimeout(schedule, 150); }, true);

  function attachObserver(){
    var dash = document.getElementById('contentgem-dashboard');
    if (!dash) { setTimeout(attachObserver, 500); return; }
    new MutationObserver(schedule).observe(dash, { childList: true, subtree: true });
  }
  attachObserver();
  setInterval(schedule, 3000);
})();
