(function(){
  if (window.__CGMUIFilterbarManager) return;
  window.__CGMUIFilterbarManager = true;
  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim(); }
  function syncSummary(shell, filterbar){
    var count = qsa('span', filterbar).find(function(el){ return /\d+ of \d+ gaps/i.test(txt(el)); });
    if (count) count.classList.add('cgm-results-summary__count');
    var chips = qsa('span', filterbar).filter(function(el){ return /×/.test(txt(el)); });
    chips.forEach(function(chip){ chip.classList.add('cgm-badge','cgm-badge--primary'); });
    var clear = qsa('button', filterbar).find(function(el){ return /clear filters/i.test(txt(el)); });
    if (clear) clear.classList.add('cgm-btn','cgm-btn--ghost');
  }
  function apply(){
    var root = qs('#contentgem-dashboard');
    if (!root || !root.classList.contains('cgm-page--content-gaps')) return;
    var shell = qs('.contentgem-main > .cgm-page, .contentgem-main > div', root);
    if (!shell) return;
    var filterbar = qs(':scope > .cgm-filterbar', shell);
    if (!filterbar) {
      filterbar = qsa(':scope > div', shell).find(function(el){ return qsa('select', el).length >= 2 && /all clusters/i.test(txt(el)) && /all intents/i.test(txt(el)); }) || null;
      if (filterbar) filterbar.classList.add('cgm-filterbar','cgm-filterbar--sticky');
    }
    if (!filterbar) return;
    var toggle = qs('#cgm-gap-keyword-only-inline-bar', root);
    if (toggle && toggle.parentNode !== filterbar) filterbar.appendChild(toggle);
    syncSummary(shell, filterbar);
    qsa('select', filterbar).forEach(function(sel){ sel.classList.add('cgm-select'); });
  }
  document.addEventListener('DOMContentLoaded', apply);
  window.addEventListener('load', apply);
  new MutationObserver(function(){ apply(); }).observe(document.documentElement,{childList:true,subtree:true});
})();
