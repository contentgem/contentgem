/**
 * v59.3 — NO-OP
 * ----------------------------------------------------------------
 * Previous versions (v59 / v59.2) moved the React-owned
 * `.cgm-dashboard-progress` element with a 500ms setInterval and a
 * document-wide MutationObserver. React re-renders during analysis
 * then called `parent.removeChild(expectedProgressNode)` which
 * threw "Failed to execute 'removeChild' on 'Node': The node to be
 * removed is not a child of this node." and tripped the error
 * boundary ("ContentGem recovered from a UI error").
 *
 * The React dashboard component already renders
 * `.cgm-dashboard-progress` immediately after `.cgm-page__header`,
 * so this script is no longer needed. It is kept as a no-op so the
 * WordPress script handle `contentgem-dashboard-progress-top-v59`
 * remains registered and downstream dependencies
 * (contentgem-ui-dom-bridge, etc.) keep enqueueing correctly.
 *
 * Positioning is handled by CSS in:
 *   assets/css/cgm-page-dashboard.css
 *   assets/css/cgm-components.css
 */
(function () { /* intentionally empty */ })();
