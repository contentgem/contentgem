(function(){
  if (window.__CGMBuilderUIV2) return;
  window.__CGMBuilderUIV2 = true;

  var REST_BASE = String((window.contentgemData || {}).restUrl || '/wp-json/contentgem/v1/').replace(/\/$/, '');
  var NONCE = (window.contentgemData || {}).nonce || '';
  var KEY_OVERRIDE = 'cgm-ai-builder-mode';
  var SELECTOR_IDS = ['cgm-builder-pref-settings','cgm-builder-pref-ai','cgm-builder-pref-onboarding'];
  var state = {
    preferred: String(((window.contentgemData||{}).bootstrapSettings||{}).preferred_builder_mode || (window.contentgemData||{}).preferredBuilderMode || 'none'),
    available: { standard: true, elementor: false, divi: false },
    loaded: false
  };

  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function text(v){ return String(v||'').replace(/\s+/g,' ').trim(); }
  function visible(el){ return !!(el && el.isConnected && (el.offsetParent !== null || getComputedStyle(el).position === 'fixed')); }
  function slug(v){ v = String(v || '').toLowerCase(); return (v === 'standard' || v === 'wordpress') ? 'none' : v; }
  function labelFor(v){ return v === 'elementor' ? 'Elementor' : (v === 'divi' ? 'Divi' : 'Standard WordPress'); }

  function api(method, path, body){
    return fetch(REST_BASE + path, {
      method: method,
      credentials: 'same-origin',
      headers: { 'Content-Type':'application/json', 'X-WP-Nonce': NONCE },
      body: body ? JSON.stringify(body) : undefined
    }).then(function(r){ return r.json(); });
  }

  function load(){
    if (state.loaded) return Promise.resolve(state);
    return api('GET', '/settings/builder-mode').then(function(res){
      if (res && res.success) {
        state.preferred = slug(res.mode || 'none');
        state.available = Object.assign({ standard:true, elementor:false, divi:false }, res.available_builders || {});
      }
      state.loaded = true;
      return state;
    }).catch(function(){ state.loaded = true; return state; });
  }

  function savePreferred(mode){
    mode = slug(mode);
    return api('POST', '/settings/builder-mode', { mode: mode }).then(function(res){
      if (res && res.success) {
        state.preferred = slug(res.mode || mode);
        state.available = Object.assign({ standard:true, elementor:false, divi:false }, res.available_builders || state.available || {});
      }
      try {
        if (window.contentgemData) {
          window.contentgemData.preferredBuilderMode = state.preferred;
          window.contentgemData.bootstrapSettings = window.contentgemData.bootstrapSettings || {};
          window.contentgemData.bootstrapSettings.preferred_builder_mode = state.preferred;
        }
      } catch(e){}
      return res;
    });
  }

  function getOverride(){ try { return slug(localStorage.getItem(KEY_OVERRIDE) || ''); } catch(e) { return ''; } }
  function setOverride(mode){ try { localStorage.setItem(KEY_OVERRIDE, slug(mode)); } catch(e){} }
  function getActiveBuilder(forAi){
    var override = forAi ? getOverride() : '';
    if (override && ['none','elementor','divi'].indexOf(override) !== -1) return override;
    return slug(state.preferred || 'none');
  }

  function findByTitle(re){
    return qsa('#contentgem-dashboard .cgm-page, #contentgem-dashboard .contentgem-main > div, #contentgem-dashboard .contentgem-main > section, #contentgem-dashboard .contentgem-main > article')
      .find(function(node){
        var heading = qs('.cgm-page__title, h1, h2', node);
        return heading && re.test(text(heading.textContent));
      }) || null;
  }

  function findSettingsRoot(){
    return findByTitle(/^settings$/i) || (function(){
      var btn = qsa('button', document).find(function(el){ return /save settings/i.test(text(el.textContent)); });
      return btn ? (btn.closest('.cgm-page') || btn.closest('div')) : null;
    })();
  }

  function findAiRoot(){
    return findByTitle(/^ai\s*assistant$/i) || qsa('#contentgem-dashboard .cgm-page, #contentgem-dashboard .contentgem-main > div, #contentgem-dashboard .contentgem-main > section, #contentgem-dashboard .contentgem-main > article').find(function(node){
      var heading = qs('.cgm-page__title, h1, h2', node);
      var t = text((heading && heading.textContent) || node.textContent || '').toLowerCase();
      return /ai\s*assistant/.test(t) || /build drafts with title suggestions/.test(t);
    }) || (function(){
      var btn = qsa('button', document).find(function(el){ return /generate draft/i.test(text(el.textContent)); });
      if (!btn) return null;
      return btn.closest('.cgm-page') || qsa('#contentgem-dashboard .cgm-page, #contentgem-dashboard .contentgem-main > div, #contentgem-dashboard .contentgem-main > section, #contentgem-dashboard .contentgem-main > article').find(function(node){ return node.contains(btn); }) || btn.closest('div');
    })();
  }

  function findOnboardingRoot(){
    return qs('.tiq-onboarding__card') || qsa('div,section,article', document).find(function(node){
      var t = text(node.textContent);
      return /welcome to contentgem/i.test(t) || /continue setup/i.test(t);
    }) || null;
  }

  function optionDisabled(mode){ return mode !== 'none' && !state.available[mode]; }

  function createCard(id, title, desc, forAi){
    var current = getActiveBuilder(forAi);
    var wrap = document.createElement('div');
    wrap.id = id;
    wrap.className = 'cgm-builder-pref-card cgm-builder-pref-card--visible' + (forAi ? ' cgm-builder-pref-card--ai' : '');
    wrap.style.cssText = 'display:block; margin:14px 0 18px; padding:16px 18px; border:1px solid rgba(139,92,246,.34); border-radius:14px; background:linear-gradient(180deg, rgba(40,25,102,.96), rgba(18,12,56,.98)); box-shadow:0 10px 24px rgba(0,0,0,.16);';
    wrap.innerHTML = ''+
      '<div style="font-size:15px;font-weight:800;color:#f5f3ff;margin:0 0 6px;">'+title+'</div>'+
      '<div style="font-size:12px;line-height:1.5;color:#c4b5fd;margin:0 0 12px;">'+desc+'</div>'+
      '<div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">'+
        '<label style="display:grid;gap:6px;min-width:240px;flex:1 1 260px;">'+
          '<span style="font-size:11px;font-weight:700;letter-spacing:.04em;color:#ddd6fe;text-transform:uppercase;">Builder</span>'+
          '<select data-role="builder-select" style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid rgba(139,92,246,.35);background:#fff;color:#1f163f;font-size:14px;">'+
            '<option value="none">Standard WordPress</option>'+
            '<option value="elementor">Elementor</option>'+
            '<option value="divi">Divi</option>'+
          '</select>'+
        '</label>'+
        '<div data-role="builder-status" style="font-size:12px;color:#ddd6fe;min-height:18px;flex:1 1 180px;">Current: '+labelFor(current)+'</div>'+
      '</div>';

    var select = qs('[data-role="builder-select"]', wrap);
    var status = qs('[data-role="builder-status"]', wrap);
    select.value = current;
    qsa('option', select).forEach(function(opt){
      if (optionDisabled(opt.value)) {
        opt.disabled = true;
        opt.textContent += ' (plugin inactive)';
      }
    });
    select.addEventListener('change', function(){
      var mode = slug(select.value || 'none');
      status.textContent = forAi ? 'Saving draft preference…' : 'Saving default preference…';
      if (forAi) {
        setOverride(mode);
        status.textContent = 'Current draft output: ' + labelFor(mode) + '.';
      } else {
        savePreferred(mode).then(function(){
          status.textContent = 'Default output: ' + labelFor(mode) + '.';
        }).catch(function(){
          status.textContent = 'Could not save builder preference.';
        });
      }
    });
    return wrap;
  }

  function placeCard(root, card){
    if (!root || !card) return false;
    var existing = qs('#' + card.id, root);
    if (existing) {
      existing.replaceWith(card);
      return true;
    }
    var header = qs('.cgm-page__header', root);
    if (header && header.parentNode === root) {
      if (header.nextSibling) root.insertBefore(card, header.nextSibling);
      else root.appendChild(card);
      return true;
    }
    var title = qs('.cgm-page__title, h1, h2, .tiq-onboarding__heading', root);
    if (title && title.parentNode === root) {
      if (title.nextSibling) root.insertBefore(card, title.nextSibling);
      else root.appendChild(card);
      return true;
    }
    var actionButton = qsa('button', root).find(function(el){
      return /save settings|continue to dashboard|generate draft/i.test(text(el.textContent));
    });
    if (actionButton && actionButton.parentNode) {
      actionButton.parentNode.insertBefore(card, actionButton.parentNode.firstChild || actionButton);
      return true;
    }
    root.insertBefore(card, root.firstChild || null);
    return true;
  }

  function cleanup(activeIds){
    SELECTOR_IDS.forEach(function(id){
      var el = qs('#' + id);
      if (el && activeIds.indexOf(id) === -1 && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  function render(){
    // v5.0.9.7 — DISABLED. The native Settings tab in admin-v23-upgrade.js
    // ships a Default-page-builder <select> in the AI & clusters sub-tab.
    // Extra cards from this script duplicated and competed with v62/v57
    // injections, producing misplaced / sticky UI. Cleanup any residue
    // that earlier versions of this script left in the DOM so users
    // don't need to hard-refresh.
    var ids = ['#cgm-builder-pref-onboarding', '#cgm-builder-pref-settings', '#cgm-builder-pref-ai'];
    document.querySelectorAll(ids.join(',')).forEach(function(el){
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  function shouldPatchUrl(url){
    try {
      var u = new URL(String(url||''), window.location.origin);
      return /\/wp-json\/contentgem\/v1\/(assistant\/draft(?:-run|-status)?|assistant\/generate|ai-assistant\/generate|ai-assistant\/save-draft|broken-links\/generate-draft|draft)$/.test(u.pathname);
    } catch(e) { return false; }
  }

  function patchPayload(body, url){
    if (!body) return body;
    try {
      var data = typeof body === 'string' ? JSON.parse(body) : body;
      if (!data || typeof data !== 'object' || Array.isArray(data)) return body;
      if (typeof data.builder_mode === 'undefined' || data.builder_mode === '' || data.builder_mode === 'auto' || data.builder_mode === 'none') {
        var forAi = /assistant|ai-assistant/.test(String(url||''));
        data.builder_mode = getActiveBuilder(forAi);
      }
      return typeof body === 'string' ? JSON.stringify(data) : data;
    } catch(e) {
      return body;
    }
  }

  var nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function(input, init){
      var url = typeof input === 'string' ? input : ((input && input.url) || '');
      var method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
      if (method === 'POST' && shouldPatchUrl(url) && init) {
        init = Object.assign({}, init);
        init.body = patchPayload(init.body, url);
      }
      return nativeFetch.call(this, input, init);
    };
  }

  var nativeOpen = XMLHttpRequest.prototype.open;
  var nativeSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url){ this.__cgmMethod = method; this.__cgmUrl = url; return nativeOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body){
    try {
      if (String(this.__cgmMethod || 'GET').toUpperCase() === 'POST' && shouldPatchUrl(this.__cgmUrl)) {
        body = patchPayload(body, this.__cgmUrl);
      }
    } catch(e){}
    return nativeSend.call(this, body);
  };

  var scheduled = false;
  function schedule(){
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function(){
      scheduled = false;
      load().finally(render);
    });
  }

  document.addEventListener('DOMContentLoaded', schedule);
  window.addEventListener('load', schedule);
  document.addEventListener('click', function(){ setTimeout(schedule, 80); }, true);
  new MutationObserver(schedule).observe(document.documentElement, { childList:true, subtree:true });
  setInterval(schedule, 1200);
})();
