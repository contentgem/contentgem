/**
 * v45 linking — NO-OP (consolidated)
 * Merged into admin-v46-linking-ui.js during v5.0.9.0 stabilisation.
 * Handle kept to preserve wp_enqueue dependency chain.
 */
(function(){ /* intentionally empty */ })();
