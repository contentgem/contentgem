/**
 * v54 gap-keyword-toggle-hardmount — DISABLED in v5.0.9.8
 * ---------------------------------------------------------------
 * The native Content Gaps page ships a Keyword-only toggle via
 * cgm-ui-filterbar-manager.js + a server-rendered inline bar
 * (#cgm-gap-keyword-only-inline-bar). Previous versions of this
 * script injected a second, absolutely-positioned toggle that
 * caused visible duplicates above the ContentGem dashboard panel.
 *
 * Cleanup pass below removes any orphaned v54 toggle nodes that
 * earlier versions of this script left in the DOM so users don't
 * need to hard-refresh to clear the residue.
 *
 * Handle kept to preserve wp_enqueue dependency chain.
 */
(function(){
  if (window.__CGMV54Disabled) return;
  window.__CGMV54Disabled = true;

  function cleanup(){
    var ids = [
      '#cgm-keyword-toggle-hardmount-v54',
      '#cgm-keyword-only-gaps-bar-v51',
      '#cgm-keyword-toggle-visible-v53',
      '#cgm-gap-keyword-only-bar',
      '#cgm-gap-keyword-only-force-bar'
    ];
    document.querySelectorAll(ids.join(',')).forEach(function(el){
      if (el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  document.addEventListener('DOMContentLoaded', cleanup);
  window.addEventListener('load', cleanup);
  setTimeout(cleanup, 500);
  setTimeout(cleanup, 2000);
  setInterval(cleanup, 5000);
})();
