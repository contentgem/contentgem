(function(){
  if (window.__CONTENTGEM_BIG_UPGRADE__) return;
  if (!window.contentgemData || !location.href.includes('page=contentgem')) return;
  const restBase = window.contentgemData.restUrl.replace(/\/$/, '');
  const nonce = (window.contentgemData && window.contentgemData.nonce) || (window.wpApiSettings && window.wpApiSettings.nonce) || '';
  const state = { settings: null, detecting: false, suggestingClusters: false, suggestingSingleCluster: false, revertingClusters: false, hardResetting: false, loadingNotice: null, analysisJobId: null, analysisPanel: null, analysisPoller: null, analysisBindingVersion: 0, lastSuggestedSingleCluster: '', titleKeywordSuggestions: [], titleKeywordIndex: 0, analysisStartedAt: 0, pillarPagesData: null, analysisProgressByJob: {}, competitorRun: null, analysisPollEpoch: 0, languageDraft: null, languageOverride: null, includeSvgVisuals: null };

  function getStoredLanguageOverride(){
    try{
      const raw = sessionStorage.getItem('cgm_language_override');
      if(!raw) return null;
      const parsed = JSON.parse(raw);
      if(!parsed || typeof parsed !== 'object') return null;
      return {
        value: String(parsed.value || 'auto'),
        customValue: String(parsed.customValue || ''),
        ts: Number(parsed.ts || Date.now())
      };
    }catch(e){
      return null;
    }
  }

  function setStoredLanguageOverride(value, customValue=''){
    const payload = { value: String(value || 'auto'), customValue: String(customValue || ''), ts: Date.now() };
    state.languageOverride = payload;
    try{ sessionStorage.setItem('cgm_language_override', JSON.stringify(payload)); }catch(e){}
    return payload;
  }

  function clearStoredLanguageOverride(){
    state.languageOverride = null;
    try{ sessionStorage.removeItem('cgm_language_override'); }catch(e){}
  }
  const LS_KEY='cgm_cluster_state_backup';
  const AI_PROMPT_VALUE_KEY='cgm_ai_prompt_value';
  const AI_PROMPT_CONTEXT_KEY='cgm_ai_prompt_context';

  function getStoredSvgToggle(){
    return false;
  }

  function setStoredSvgToggle(value){
    const normalized = !!value;
    state.includeSvgVisuals = normalized;
    return normalized;
  }

  function getAiPromptContext(){
    try{
      const parsed=JSON.parse(sessionStorage.getItem(AI_PROMPT_CONTEXT_KEY)||'{}');
      return parsed && typeof parsed==='object' ? parsed : {};
    }catch(e){ return {}; }
  }

  function setAiPromptContext(next){
    try{ sessionStorage.setItem(AI_PROMPT_CONTEXT_KEY, JSON.stringify(next||{})); }catch(e){}
  }

  function saveAiPromptValue(value){
    try{ sessionStorage.setItem(AI_PROMPT_VALUE_KEY, String(value||'')); }catch(e){}
  }

  function getAiPromptValue(){
    try{ return sessionStorage.getItem(AI_PROMPT_VALUE_KEY)||''; }catch(e){ return ''; }
  }

  function clearAiPromptContext(){
    try{ sessionStorage.removeItem(AI_PROMPT_VALUE_KEY); sessionStorage.removeItem(AI_PROMPT_CONTEXT_KEY); }catch(e){}
  }

  function buildAiContextBlock(context){
    const parts=[];
    if(context?.competitor){ parts.push(context.competitor); }
    if(context?.pillar){ parts.push(context.pillar); }
    if(context?.bulk){ parts.push(context.bulk); }
    return parts.filter(Boolean).join('\n\n');
  }

  function stripAiContextBlocks(text, context){
    let next=String(text||'');
    [context?.competitor, context?.pillar, context?.bulk].filter(Boolean).forEach(block=>{
      next = next.split(block).join('');
    });
    return next.replace(/\n{3,}/g,'\n\n').trim();
  }

  function mergePromptWithContext(manualValue, context){
    const ctx=buildAiContextBlock(context);
    const trimmedManual=stripAiContextBlocks(String(manualValue||''), getAiPromptContext());
    if(!ctx) return trimmedManual;
    if(!trimmedManual) return ctx;
    if(trimmedManual.includes(ctx)) return trimmedManual;
    return `${ctx}\n\n${trimmedManual}`;
  }

  async function api(path, options={}) {
    const res = await fetch(`${restBase}/${path.replace(/^\//,'')}`, {
      method: options.method || 'GET',
      headers: {'Content-Type':'application/json','X-WP-Nonce':nonce,'Cache-Control':'no-store',...(options.headers||{})},
      body: options.body ? JSON.stringify(options.body) : undefined,
      credentials:'same-origin',
      cache:'no-store'
    });
    let data={}; try{data=await res.json()}catch(e){}
    if(res.status===403 && /nonce/i.test(String(data?.message||''))){
      window.location.reload();
      throw new Error('Session expired. Reloading…');
    }
    if(!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
    return data;
  }



  const nativeFetch = window.fetch.bind(window);
  window.fetch = async function(input, init){
    try{
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      if(/\/settings\/(?:clusters|auto-detect-clusters)(?:\?|$)/.test(url) && init && String(init.method||'GET').toUpperCase()==='POST'){
        const override = (()=>{ try{ return sessionStorage.getItem('cgm_override_clusters')==='1'; }catch(e){ return false; } })();
        if(override && init.body){
          try{
            const payload = JSON.parse(init.body);
            payload.replace = true;
            init = Object.assign({}, init, { body: JSON.stringify(payload) });
          }catch(e){}
        }
      }
      if(/\/onboarding\/complete(?:\?|$)/.test(url) && init && String(init.method||'GET').toUpperCase()==='POST'){
        const override = (()=>{ try{ return sessionStorage.getItem('cgm_override_clusters')==='1'; }catch(e){ return false; } })();
        if(override){
          try{
            const summary = Array.from(document.querySelectorAll('span,div,p')).find(el=>/Clusters:\s*/i.test((el.textContent||'')));
            let clustersText = '';
            if(summary){
              const txt = (summary.textContent||'');
              const idx = txt.toLowerCase().indexOf('clusters:');
              if(idx !== -1) clustersText = txt.slice(idx + 9).trim();
            }
            let clusters = clustersText ? clustersText.split(',').map(s=>s.trim()).filter(Boolean) : [];
            if(!clusters.length){
              clusters = Array.from(document.querySelectorAll('button')).map(el=>(el.textContent||'').trim()).filter(Boolean).filter(t=>t.length>2 && !/^(back|next|busy|start setup|go to dashboard)$/i.test(t));
            }
            if(clusters.length){
              await api('settings/clusters',{method:'POST',body:{clusters:[...new Set(clusters)],replace:true}});
            }
          }catch(e){ console.warn('Contentgem onboarding override sync failed', e); }
        }
      }

      if(/\/assistant\/draft(?:\?|$)/.test(url) && init && String(init.method||'GET').toUpperCase()==='POST' && init.body){
        try{
          const payload = JSON.parse(init.body);
          payload.include_svg_visuals = state.includeSvgVisuals !== null ? !!state.includeSvgVisuals : getStoredSvgToggle();
          init = Object.assign({}, init, { body: JSON.stringify(payload) });
        }catch(e){}
      }
    }catch(e){}
    const response = await nativeFetch(input, init);
    try{
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      if(/\/settings\/(?:clusters|auto-detect-clusters)(?:\?|$)/.test(url) && response && response.ok){
        // keep override sticky through onboarding; clear only when onboarding UI is absent
      }
    }catch(e){}
    return response;
  };

  async function loadSettings(force=false){
    if(state.settings && !force) return state.settings;
    state.settings = await api('settings');
    const override = state.languageOverride || getStoredLanguageOverride();
    if(override && override.value){
      state.languageOverride = override;
      state.settings = Object.assign({}, state.settings || {}, {
        content_language: String(override.value || 'auto'),
        content_language_custom: String(override.value === 'custom' ? (override.customValue || '') : '')
      });
    }
    return state.settings;
  }

  async function loadPillarPages(force=false){
    if(state.pillarPagesData && !force) return state.pillarPagesData;
    state.pillarPagesData = await api('pillar-pages');
    return state.pillarPagesData;
  }

  function getSettingsRoot(){
    const pages = Array.from(document.querySelectorAll('.cgm-page'));
    const byTitle = pages.find(page => /Settings/i.test(page.querySelector('.cgm-page__title')?.textContent||''));
    if(byTitle) return byTitle;
    return pages.find(page => {
      const txt = (page.textContent || '').replace(/\s+/g, ' ').trim();
      return /Tone of voice/i.test(txt) && /Competitor domains/i.test(txt) && /Google Search Console|IndexNow/i.test(txt);
    }) || null;
  }

  function hideLegacyCompetitorCards(){
    const settingsRoot = getSettingsRoot();
    if(!settingsRoot) return;
    const textMatchers=[/Save up to 5 competitor domains/i,/Competitor domains/i,/Competitor URLs \(up to 20\)/i,/Save competitors/i];
    const blocks = Array.from(settingsRoot.querySelectorAll('div,section,.cgm-card,.components-card')).filter(el=>{
      const txt=(el.textContent||'').replace(/\s+/g,' ').trim();
      return textMatchers.some(re=>re.test(txt));
    });
    blocks.forEach(block=>{
      const txt=(block.textContent||'').replace(/\s+/g,' ').trim();
      if(/Hard reset/i.test(txt)) return;
      block.style.display='none';
    });
  }

  async function hardResetSettings(btn){
    if(state.hardResetting) return;
    if(!window.confirm('This will remove all suggested settings, clusters, and competitor domains. Do you want to continue?')) return;
    state.hardResetting = true;
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Resetting…';
    try{
      await api('settings/hard-reset',{method:'POST',body:{}});
      state.settings = null;
      await loadSettings(true);
      btn.textContent = 'Reset complete';
      window.location.reload();
    }catch(e){
      btn.textContent = 'Reset failed';
      console.warn('Contentgem hard reset failed', e);
      setTimeout(()=>{btn.disabled=false;btn.textContent=old;state.hardResetting=false;}, 1800);
      return;
    }
  }

  function ensureHardResetCard(){
    const settingsRoot = getSettingsRoot();
    if(!settingsRoot || settingsRoot.querySelector('.cgm-hard-reset-card')) return;
    const card = document.createElement('div');
    card.className='cgm-hard-reset-card';
    card.style.cssText='margin-top:16px;padding:16px;border:1px solid #F5C2C7;border-radius:10px;background:#FFF5F5;';
    card.innerHTML='<div style="font-weight:700;color:#7F1D1D;margin-bottom:6px;">Hard reset</div><div style="font-size:13px;color:#7F1D1D;margin-bottom:12px;">Remove all suggested settings, clusters, and competitor domains, including current saved cluster/category mappings.</div>';
    const btn=document.createElement('button');
    btn.type='button';
    btn.className='button button-secondary';
    btn.textContent='Hard reset plugin suggestions';
    btn.addEventListener('click',()=>hardResetSettings(btn));
    card.appendChild(btn);
    settingsRoot.appendChild(card);
  }


  function findClusterSettingsCard(){
    const settingsRoot = getSettingsRoot();
    if(!settingsRoot) return null;
    const addButtons = Array.from(settingsRoot.querySelectorAll('button')).filter(el => /add cluster/i.test((el.textContent||'').trim()));
    for (const btn of addButtons) {
      const row = btn.closest('div');
      if(!row) continue;
      const wrap = row.parentElement || row;
      const hasInput = !!Array.from(wrap.querySelectorAll('input')).find(el => el.type === 'text');
      if(hasInput) return wrap;
    }
    return Array.from(settingsRoot.querySelectorAll('div')).find(el => {
      const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
      return /New cluster/i.test(text) && /Add cluster/i.test(text);
    }) || null;
  }

  function isSettingsView(){
    return !!getSettingsRoot() && !!findClusterSettingsCard();
  }

  function findSettingsToolbarAnchor(){
    const card=findClusterSettingsCard();
    if(!card) return null;
    const preferred = Array.from(card.querySelectorAll('input,button')).find(el => /New cluster|Add cluster|Generate with AI/i.test((el.placeholder||el.textContent||'').trim()));
    return preferred || card.firstElementChild || card;
  }

  function findInputs(){
    const inputs=Array.from(document.querySelectorAll('input'));
    const titleInput=inputs.find(i=>/complete guide|content title/i.test(i.placeholder||''));
    const keywordInput=inputs.find(i=>/primary keyword|marathon training plan/i.test(i.placeholder||''));
    const clusterSelect=Array.from(document.querySelectorAll('select')).find(sel=>Array.from(sel.options||[]).some(o=>/select cluster/i.test(o.textContent||'')));
    return {titleInput,keywordInput,clusterSelect};
  }

  function isAssistantView(){
    const title=document.querySelector('.cgm-page__title');
    return /AI Assistant/i.test(title?.textContent||'');
  }


  function ensureAssistantUsesGlobalLanguage(){
    return;
  }

  function ensureAssistantSvgToggle(){
    if(!isAssistantView()){
      document.querySelectorAll('.cgm-assistant-svg-toggle').forEach(el=>el.remove());
      return;
    }
    if(state.includeSvgVisuals===null){ state.includeSvgVisuals = getStoredSvgToggle(); }
    const buttons = Array.from(document.querySelectorAll('button')).filter(btn=>/generate draft|generating/i.test((btn.textContent||'').trim()));
    const generateBtn = buttons[0];
    if(!generateBtn) return;
    const host = generateBtn.parentElement || generateBtn.closest('div');
    if(!host) return;
    let wrap = host.querySelector('.cgm-assistant-svg-toggle');
    if(!wrap){
      wrap = document.createElement('label');
      wrap.className = 'cgm-assistant-svg-toggle';
      wrap.style.cssText = 'display:flex;align-items:flex-start;gap:10px;margin:0 0 12px;padding:12px;border:1px solid #D6E6F2;border-radius:12px;background:rgba(9,12,61,.94);font-size:13px;color:#C4B5FD;';
      wrap.innerHTML = '<input type="checkbox" class="cgm-assistant-svg-toggle__input" style="margin-top:2px;"/><span><strong>Include SVG visuals in draft</strong><br/><span style="color:#B9C4FF;">Adds topical cluster visuals to the generated draft when available.</span></span>';
      host.insertBefore(wrap, generateBtn);
    }
    const input = wrap.querySelector('.cgm-assistant-svg-toggle__input');
    if(input && !input.dataset.cgmBound){
      input.dataset.cgmBound='1';
      input.checked = state.includeSvgVisuals !== null ? !!state.includeSvgVisuals : getStoredSvgToggle();
      input.addEventListener('change', ()=>{ setStoredSvgToggle(!!input.checked); });
    }
    if(input){ input.checked = state.includeSvgVisuals !== null ? !!state.includeSvgVisuals : getStoredSvgToggle(); }
  }

  function ensureOnboardingClusterOverride(){
    const heading = Array.from(document.querySelectorAll('h1,h2,h3')).find(el=>/Step 2 of 3: Content clusters|onboardingStep2Title|Content clusters/i.test(el.textContent||''));
    if(!heading) return;
    const wrap = heading.parentElement;
    if(!wrap || wrap.querySelector('.cgm-override-old-clusters-wrap')) return;
    const controls = Array.from(wrap.querySelectorAll('button')).filter(btn=>/Generate clusters with AI/i.test((btn.textContent||'').trim()));
    if(!controls.length) return;
    const box=document.createElement('label');
    box.className='cgm-override-old-clusters-wrap';
    box.style.cssText='display:flex;gap:10px;align-items:flex-start;margin:0 0 14px;padding:12px;border:1px solid #F5D7A1;border-radius:12px;background:#FFF9F0;font-size:13px;color:#7A5B2E;';
    box.innerHTML='<input type="checkbox" class="cgm-override-old-clusters-checkbox" style="margin-top:2px;"/><span><strong>Override old clusters</strong><br/>Use this when AI suggestions should replace your current saved clusters/categories.</span>';
    controls[0].parentElement.insertAdjacentElement('beforebegin', box);
    controls[0].addEventListener('click',(event)=>{
      const checked = !!wrap.querySelector('.cgm-override-old-clusters-checkbox')?.checked;
      if(!checked){ try{ sessionStorage.removeItem('cgm_override_clusters'); }catch(e){}; return; }
      const ok = window.confirm('This will override your current clusters/categories. Do you want to continue?');
      if(!ok){
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation?.();
        return false;
      }
      try{ sessionStorage.setItem('cgm_override_clusters','1'); }catch(e){}
      return true;
    }, true);
  }


  
  function syncOverrideFlagWithView(){
    const onboardingRoot = Array.from(document.querySelectorAll('h1,h2,h3')).find(el=>/Step 1 of 3|Step 2 of 3|Step 3 of 3|Content clusters|Review & start/i.test(el.textContent||''));
    if(!onboardingRoot){ try{ sessionStorage.removeItem('cgm_override_clusters'); }catch(e){} }
  }

  function hideGapSuggestionLabels(){
    const nodes=Array.from(document.querySelectorAll('div,span,p,strong')).filter(el=>/^\s*Suggestion\s*$/i.test((el.textContent||'').trim()));
    nodes.forEach(el=>{
      const line=el.closest('div,span,p,strong');
      if(line){ line.style.display='none'; } else { el.style.display='none'; }
    });
  }

  function dedupeSuggestionButtons(){
    const buttons=Array.from(document.querySelectorAll('button')).filter(btn=>/suggest title\s*\+\s*keyword|ai-suggest title/i.test((btn.textContent||'').trim()));
    if(buttons.length<=1) return;
    const native=buttons.find(btn=>/AI-suggest/i.test(btn.textContent||'')) || buttons[0];
    buttons.forEach(btn=>{ if(btn!==native) btn.remove(); });
  }

  function cleanupMvpUi(){
    hideLegacyCompetitorCards();
    ensureHardResetCard();
    hideGapSuggestionLabels();
    const moreButtons=Array.from(document.querySelectorAll('button.cgm-more-title-suggestions,button.cgm-more-title-suggestions-native'));
    moreButtons.forEach((btn,idx)=>{ if(idx>0) btn.remove(); });
    const panels=Array.from(document.querySelectorAll('.cgm-analyze-status-panel'));
    panels.forEach((panel,idx)=>{ if(idx>0) panel.remove(); });
    const pillarManagers=Array.from(document.querySelectorAll('.cgm-pillar-manager'));
    pillarManagers.forEach((panel,idx)=>{ if(idx>0) panel.remove(); });
  }

  function findAssistantControls(){
    const selects=Array.from(document.querySelectorAll('select'));
    const wordCountSelect=selects.find(sel=>Array.from(sel.options||[]).some(o=>/words/i.test(o.textContent||'')));
    const clusterSelect=selects.find(sel=>Array.from(sel.options||[]).some(o=>/select cluster/i.test(o.textContent||'')));
    const textareas=Array.from(document.querySelectorAll('textarea'));
    const promptTextarea=textareas.find(el=>/What do you want to write\?|Edit the prompt above/i.test(el.placeholder||''));
    const competitorToggle=Array.from(document.querySelectorAll('label')).find(el=>/Competitor insights/i.test(el.textContent||''));
    return {wordCountSelect,clusterSelect,promptTextarea,competitorToggle};
  }

  function findCompetitorReport(){
    try{
      const raw=localStorage.getItem('cgm_competitor_reports');
      const list=JSON.parse(raw||'[]');
      return Array.isArray(list)&&list[0]?list[0]:null;
    }catch(e){ return null; }
  }


  function saveClusterBackup(clusters, source='unknown'){
    try{
      localStorage.setItem(LS_KEY, JSON.stringify({clusters:Array.isArray(clusters)?clusters:[], source, savedAt:Date.now()}));
    }catch(e){}
  }

  function getClusterBackup(){
    try{
      const raw=localStorage.getItem(LS_KEY);
      const parsed=JSON.parse(raw||'null');
      return parsed && Array.isArray(parsed.clusters) ? parsed : null;
    }catch(e){ return null; }
  }

  function findNewClusterInput(card){
    if(!card) return null;
    const addButton = Array.from(card.querySelectorAll('button')).find(el=>/add cluster/i.test(el.textContent||''));
    const scope = addButton?.parentElement || card;
    return Array.from(scope.querySelectorAll('input')).find(el=>el.type==='text' && !/api|client|secret|competitor|domain/i.test((el.placeholder||'') + ' ' + (el.getAttribute('aria-label')||''))) || null;
  }

  async function suggestSingleCluster(btn,input){
    if(state.suggestingSingleCluster) return;
    state.suggestingSingleCluster=true;
    const old=btn.textContent;
    btn.disabled=true;
    btn.textContent='Suggesting…';
    try{
      const settings=await loadSettings();
      const data=await api('settings/suggest-single-cluster',{method:'POST',body:{niche: settings?.niche || '', description: settings?.niche_description || ''}});
      const cluster=String(data?.cluster||'').trim();
      if(!cluster) throw new Error('No cluster suggestion returned.');
      state.lastSuggestedSingleCluster=cluster;
      if(input){
        if(!input.value || input.value === 'admin') input.value='';
        input.placeholder=cluster;
        input.dataset.cgmSuggestedCluster=cluster;
        input.title=`Suggested cluster: ${cluster}`;
      }
      btn.textContent='✓ Suggested';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.suggestingSingleCluster=false;},1500);
    }catch(e){
      console.warn('Contentgem single cluster suggestion failed',e);
      btn.textContent='Suggest failed';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.suggestingSingleCluster=false;},1800);
    }
  }


  function ensureMoreSuggestionsForNativeButton(){
    document.querySelectorAll('.cgm-more-title-suggestions-native').forEach(el=>el.remove());
    const panel=document.querySelector('.cgm-title-suggestion-panel');
    if(panel){
      const buttons=Array.from(panel.querySelectorAll('.cgm-more-title-suggestions'));
      buttons.forEach((el,idx)=>{ if(idx>0) el.remove(); });
    }
  }

  function ensureAssistantHelperActions(){
    const assistantPage = Array.from(document.querySelectorAll('.cgm-page')).find(page => /AI Assistant/i.test(page.querySelector('.cgm-page__title')?.textContent || ''));
    if(!assistantPage) {
      document.querySelectorAll('.cgm-assistant-bulk-keywords, .cgm-assistant-competitor-helper, .cgm-assistant-context-summary, .cgm-assistant-language-note, .cgm-assistant-wordcount-note').forEach(el=>el.remove());
      return;
    }

    const actionsRow = assistantPage.querySelector('.cgm-ai-actions');
    const promptField = assistantPage.querySelector('#cgm-ai-prompt');
    const titleInput = assistantPage.querySelector('#cgm-ai-title');
    const keywordInput = assistantPage.querySelector('#cgm-ai-keyword');
    const clusterSelect = assistantPage.querySelector('#cgm-ai-cluster');
    if(!actionsRow || !promptField) return;

    let summary = assistantPage.querySelector('.cgm-assistant-context-summary');
    if(!summary){
      summary = document.createElement('div');
      summary.className = 'cgm-assistant-context-summary';
      summary.style.cssText = 'margin:12px 0 10px;padding:12px 14px;border:1px solid rgba(108,76,255,.35);border-radius:12px;background:rgba(9,12,61,.94);';
      actionsRow.insertAdjacentElement('afterend', summary);
    }

    let helper = assistantPage.querySelector('.cgm-assistant-competitor-helper');
    if(!helper){
      helper = document.createElement('div');
      helper.className = 'cgm-assistant-competitor-helper';
      helper.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px;';
      summary.insertAdjacentElement('afterend', helper);
    }

    let langNote = assistantPage.querySelector('.cgm-assistant-language-note');
    if(!langNote){
      langNote = document.createElement('div');
      langNote.className = 'cgm-assistant-language-note cgm-upgrade-note';
      helper.insertAdjacentElement('afterend', langNote);
    }

    const settings = state.settings || {};
    const competitorDomains = Array.isArray(settings.competitor_domains) ? settings.competitor_domains : [];
    const structure = settings.site_structure || {};
    const structureCount = [structure.homepage?.page_id, structure.about_page?.page_id].filter(Boolean).length + ((structure.service_pages||[]).length) + ((structure.case_studies||[]).length) + ((structure.nodes||[]).length);
    const toneSaved = String(settings.tone_of_voice || '').trim();
    const language = settings.content_language_custom && settings.content_language === 'custom' ? settings.content_language_custom : (settings.content_language || 'en');

    summary.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
        <div>
          <strong style="display:block;color:#F8FAFF;margin-bottom:4px;">Saved draft context</strong>
          <div class="cgm-upgrade-note">Tone of voice: <strong>${toneSaved ? 'saved' : 'not saved'}</strong> · Competitors: <strong>${competitorDomains.length}</strong> · Site structure targets: <strong>${structureCount}</strong></div>
        </div>
        <div class="cgm-upgrade-note">Use the checkboxes below to include saved tone, competitor insights, semantic keywords and pillar-page mode.</div>
      </div>`;

    langNote.textContent = `Draft language follows your global setting: ${language}. Use Settings or Onboarding to change it.`;

    helper.innerHTML = '';
    const makeBtn = (label, onClick) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'cgm-btn cgm-btn--secondary';
      btn.textContent = label;
      btn.addEventListener('click', onClick);
      return btn;
    };

    helper.appendChild(makeBtn('Use first saved cluster keyword', () => {
      const cluster = String(clusterSelect?.value || '').trim();
      const map = settings.cluster_keywords || {};
      const items = Array.isArray(map[cluster]) ? map[cluster] : [];
      if(items[0] && keywordInput) setReactInputValue(keywordInput, items[0]);
    }));

    helper.appendChild(makeBtn('Insert structure context', () => {
      const lines = [];
      const s = settings.site_structure || {};
      if(s.homepage && s.homepage.url) lines.push(`Homepage: ${s.homepage.title || 'Homepage'} — ${s.homepage.url}`);
      if(s.about_page && s.about_page.url) lines.push(`About page: ${s.about_page.title || 'About us'} — ${s.about_page.url}`);
      (s.service_pages || []).slice(0,5).forEach(item => { if(item && item.url) lines.push(`Service page: ${item.title || 'Service page'} — ${item.url}`); });
      (s.case_studies || []).slice(0,5).forEach(item => { if(item && item.url) lines.push(`Case study: ${item.title || 'Case study'} — ${item.url}`); });
      if(!lines.length) return;
      const next = String(promptField.value || '').trim();
      const block = `Important internal links:\n${lines.join('\n')}`;
      if(next.includes(block)) return;
      setReactInputValue(promptField, next ? `${next}\n\n${block}` : block);
    }));

    helper.appendChild(makeBtn('Load latest competitor context', async() => {
      try{
        const cluster = String(clusterSelect?.value || '').trim();
        if(!cluster) throw new Error('Select a cluster first.');
        const data = await api(`settings/competitor-insights?cluster=${encodeURIComponent(cluster)}`);
        const insights = String(data?.insights || '').trim();
        if(!insights) throw new Error('No competitor insights found for this cluster.');
        const next = String(promptField.value || '').trim();
        const block = `Competitor insights:\n${insights}`;
        if(next.includes(block)) return;
        setReactInputValue(promptField, next ? `${next}\n\n${block}` : block);
      }catch(e){ window.alert(e.message || 'Could not load competitor context.'); }
    }));

    helper.appendChild(makeBtn('Clear prompt', () => {
      setReactInputValue(promptField, '');
      clearAiPromptContext();
    }));
  }

  function ensureInlineClusterSuggest(){
    if(!isSettingsView()) {
      document.querySelectorAll('.cgm-inline-cluster-suggest').forEach(el=>el.remove());
      return;
    }
    const card=findClusterSettingsCard();
    if(!card) return;
    const input=findNewClusterInput(card);
    if(!input) return;
    if(!input.value.trim()){
      input.placeholder=input.dataset.cgmSuggestedCluster || state.lastSuggestedSingleCluster || 'New cluster...';
    }
    const addButton=Array.from(card.querySelectorAll('button')).find(el=>/add cluster/i.test(el.textContent||''));
    const row=(addButton && addButton.parentElement) ? addButton.parentElement : (input.parentElement || card);
    Object.assign(row.style,{display:'flex',alignItems:'center',gap:'8px',flexWrap:'wrap'});
    Array.from(row.querySelectorAll('button')).forEach(el=>{ if(el!==addButton && /ai suggest cluster/i.test((el.textContent||'').trim()) && !el.classList.contains('cgm-inline-cluster-suggest')) el.remove(); });
    Array.from(document.querySelectorAll('.cgm-inline-cluster-suggest')).forEach(el=>{
      if(el.parentElement!==row) el.remove();
    });
    let btn=row.querySelector('.cgm-inline-cluster-suggest');
    if(!btn){
      btn=document.createElement('button');
      btn.type='button';
      btn.className='cgm-inline-cluster-suggest';
      btn.textContent='AI suggest cluster';
      Object.assign(btn.style,{padding:'8px 12px',borderRadius:'8px',border:'1px solid #7B2D8B',background:'#F3E5F5',color:'#7B2D8B',fontSize:'12px',fontWeight:'700',cursor:'pointer',whiteSpace:'nowrap',flex:'0 0 auto'});
      btn.addEventListener('click',()=>suggestSingleCluster(btn,input));
    }
    if(addButton){
      if(!addButton.dataset.cgmSuggestBound){
        addButton.dataset.cgmSuggestBound='1';
        addButton.addEventListener('click',()=>{
          if(input && !input.value.trim() && input.dataset.cgmSuggestedCluster){
            setReactInputValue(input, input.dataset.cgmSuggestedCluster);
          }
        }, true);
      }
      if(btn.parentElement!==row || btn.nextSibling!==addButton){
        row.insertBefore(btn, addButton);
      }
    } else if(btn.parentElement!==row){
      row.appendChild(btn);
    }
  }

  function setReactInputValue(el,value){
    const prototype=Object.getPrototypeOf(el);
    const setter=Object.getOwnPropertyDescriptor(prototype,'value')?.set;
    if(setter) setter.call(el,value); else el.value=value;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }

  function populateClusterSelect(select,clusters){
    if(!select || !Array.isArray(clusters) || !clusters.length) return;
    const seen = new Set();
    Array.from(select.options).forEach(opt=>{
      const key=(opt.value||'').trim().toLowerCase();
      if(!key) return;
      if(seen.has(key)) opt.remove();
      else seen.add(key);
    });
    clusters.forEach(cluster=>{
      const cleaned=String(cluster||'').trim();
      const key=cleaned.toLowerCase();
      if(!cleaned || seen.has(key)) return;
      const opt=document.createElement('option');
      opt.value=cleaned;
      opt.textContent=cleaned;
      select.appendChild(opt);
      seen.add(key);
    });
  }

  async function suggestTitleAndKeyword(btn){
    const old=btn.textContent;
    btn.disabled=true;
    btn.textContent='✦ Suggesting…';
    try{
      const suggestions=await fetchTitleKeywordSuggestions();
      if(!suggestions[0]) throw new Error('No suggestions returned.');
      state.titleKeywordSuggestions=suggestions;
      state.titleKeywordIndex=0;
      const {titleInput,keywordInput}=findInputs();
      if(suggestions[0].title&&titleInput) setReactInputValue(titleInput,suggestions[0].title);
      if(suggestions[0].keyword&&keywordInput) setReactInputValue(keywordInput,suggestions[0].keyword);
      renderSuggestionChooser(suggestions);
      btn.textContent='✓ Applied';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;},1200);
    }catch(e){
      console.warn('Contentgem title suggestion failed',e);
      btn.textContent=old; btn.disabled=false;
      alert(e.message||'Title suggestion failed.');
    }
  }


  function parseJsonArrayFromText(raw){
    const cleaned=String(raw||'').replace(/```json\n?/gi,'').replace(/```\n?/g,'').trim();
    const match=cleaned.match(/\[[\s\S]*\]/);
    if(!match) throw new Error('Could not parse suggestion response.');
    const data=JSON.parse(match[0]);
    if(!Array.isArray(data)) throw new Error('Suggestion response was not an array.');
    return data;
  }

  function getCreateMoreSuggestionsButton(){
    return document.querySelector('.cgm-title-suggestion-panel .cgm-more-title-suggestions');
  }

  function renderSuggestionChooser(suggestions){
    cleanupMvpUi();
    syncOverrideFlagWithView();
    let panel=document.querySelector('.cgm-title-suggestion-panel');
    if(!suggestions || !suggestions.length){ if(panel) panel.remove(); return; }
    if(!panel){
      panel=document.createElement('div');
      panel.className='cgm-title-suggestion-panel';
      Object.assign(panel.style,{margin:'8px 0 12px',padding:'10px 12px',background:'rgba(9,12,61,.94)',border:'1px solid rgba(108,76,255,.30)',borderRadius:'10px'});
    }
    panel.innerHTML='';
    const heading=document.createElement('div');
    heading.textContent='More title + keyword suggestions';
    Object.assign(heading.style,{fontSize:'12px',fontWeight:'700',color:'#F8FAFF',marginBottom:'8px'});
    panel.appendChild(heading);
    const list=document.createElement('div');
    Object.assign(list.style,{display:'grid',gap:'8px'});
    suggestions.forEach((item,idx)=>{
      const row=document.createElement('button');
      row.type='button';
      Object.assign(row.style,{textAlign:'left',padding:'8px 10px',borderRadius:'8px',border:'1px solid rgba(108,76,255,.30)',background:'rgba(9,12,61,.94)',cursor:'pointer'});
      row.innerHTML=`<div style="font-weight:700;color:#F8FAFF;font-size:12px;">${item.title||'Untitled suggestion'}</div><div style="font-size:12px;color:#B9C4FF;margin-top:3px;">Primary keyword: ${item.keyword||'—'}</div>${item.rationale?`<div style="font-size:11px;color:#B9C4FF;margin-top:3px;">${item.rationale}</div>`:''}`;
      row.addEventListener('click',()=>{
        const {titleInput,keywordInput}=findInputs();
        if(item.title && titleInput) setReactInputValue(titleInput,item.title);
        if(item.keyword && keywordInput) setReactInputValue(keywordInput,item.keyword);
        state.titleKeywordIndex=idx;
      });
      list.appendChild(row);
    });
    panel.appendChild(list);
    const footer=document.createElement('div');
    Object.assign(footer.style,{display:'flex',justifyContent:'flex-end',marginTop:'10px'});
    const more=document.createElement('button');
    more.type='button';
    more.className='cgm-more-title-suggestions';
    more.textContent='Create more suggestions';
    Object.assign(more.style,{padding:'4px 12px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.35)',background:'rgba(9,12,61,.94)',color:'#F8FAFF',fontSize:'11px',fontWeight:'600',cursor:'pointer'});
    more.addEventListener('click',async()=>{
      const oldText=more.textContent;
      more.disabled=true;
      more.textContent='Creating…';
      try{
        const moreSuggestions=await fetchTitleKeywordSuggestions();
        state.titleKeywordSuggestions=moreSuggestions;
        state.titleKeywordIndex=0;
        renderSuggestionChooser(moreSuggestions);
        if(moreSuggestions[0]){
          const {titleInput,keywordInput}=findInputs();
          if(moreSuggestions[0].title&&titleInput) setReactInputValue(titleInput,moreSuggestions[0].title);
          if(moreSuggestions[0].keyword&&keywordInput) setReactInputValue(keywordInput,moreSuggestions[0].keyword);
        }
      }catch(e){
        alert(e.message||'Could not create more suggestions.');
      }finally{
        more.textContent=oldText;
        more.disabled=false;
      }
    });
    footer.appendChild(more);
    panel.appendChild(footer);
    panel.querySelectorAll('.cgm-more-title-suggestions').forEach((el,idx)=>{ if(idx>0) el.remove(); });

    const wrap=document.querySelector('.cgm-title-suggest-row');
    if(wrap && (!panel.isConnected || panel.previousElementSibling!==wrap)){
      wrap.insertAdjacentElement('afterend',panel);
    }
  }

  async function fetchTitleKeywordSuggestions(){
    const {titleInput,keywordInput,clusterSelect}=findInputs();
    const title=titleInput?.value?.trim()||'';
    const keyword=keywordInput?.value?.trim()||'';
    const cluster=clusterSelect?.value?.trim()||'';
    if(!title&&!keyword&&!cluster) throw new Error('Enter a title, keyword or cluster first.');
    const cacheKey=`cgm_title_keyword_suggestions::${[cluster,title,keyword].join('||').toLowerCase()}`;
    try{
      const cachedRaw=sessionStorage.getItem(cacheKey)||'';
      if(cachedRaw){
        const cached=JSON.parse(cachedRaw);
        if(cached?.items && Array.isArray(cached.items) && cached.items.length && (Date.now() - Number(cached.savedAt||0) < 10*60*1000)){
          return cached.items;
        }
      }
    }catch(e){}
    const data=await api('assistant/title-keyword-suggestions',{method:'POST',body:{title, keyword, cluster}});
    const items=Array.isArray(data?.suggestions) ? data.suggestions.filter(item=>item && (item.title||item.keyword)) : [];
    if(!items.length) throw new Error('No title suggestions returned.');
    try{ sessionStorage.setItem(cacheKey, JSON.stringify({savedAt: Date.now(), items})); }catch(e){}
    return items;
  }

  function ensureSingleSuggestionButton(){
    const assistantButtons=Array.from(document.querySelectorAll('button')).filter(btn=>/suggest title\s*\+\s*keyword|ai-suggest title/i.test((btn.textContent||'').trim()));
    const fallbackButtons=Array.from(document.querySelectorAll('.cgm-title-suggest-fallback'));
    if(assistantButtons.length){
      fallbackButtons.forEach(el=>el.remove());
      dedupeSuggestionButtons();
      ensureMoreSuggestionsForNativeButton();
      return;
    }
    if(fallbackButtons.length>1) fallbackButtons.slice(1).forEach(el=>el.remove());
    const {titleInput,keywordInput}=findInputs();
    if(!titleInput||!keywordInput) return;
    const row=titleInput.closest('div')?.parentElement;
    if(!row) return;
    let wrap=document.querySelector('.cgm-title-suggest-row');
    if(!wrap){
      wrap=document.createElement('div');
      wrap.className='cgm-title-suggest-row';
      wrap.style.display='flex';
      wrap.style.justifyContent='flex-end';
      wrap.style.margin='-2px 0 10px';
      const btn=document.createElement('button');
      btn.type='button';
      btn.className='cgm-title-suggest-fallback';
      btn.textContent='✦ Suggest title + keyword';
      Object.assign(btn.style,{padding:'4px 12px',borderRadius:'999px',border:'1px solid #7B2D8B',background:'#F3E5F5',color:'#7B2D8B',fontSize:'11px',fontWeight:'600',cursor:'pointer'});
      btn.addEventListener('click',()=>suggestTitleAndKeyword(btn));
      wrap.appendChild(btn);
    }
    if(!wrap.isConnected||wrap.previousElementSibling!==row) row.insertAdjacentElement('afterend',wrap);
  }

  async function autoDetectClusters(btn){
    if(state.detecting) return;
    state.detecting=true;
    const old=btn.textContent;
    btn.textContent='Detecting…';
    btn.disabled=true;
    try{
      const current=await loadSettings();
      saveClusterBackup(current.clusters||[],'auto_detect');
      const data=await api('settings/auto-detect-clusters',{method:'POST',body:{}});
      state.settings=null;
      const settings=await loadSettings(true);
      const {clusterSelect}=findInputs();
      populateClusterSelect(clusterSelect, settings.clusters||data.clusters||[]);
      const detected=(data.detected_clusters||[]).length;
      btn.textContent=`✓ ${detected} detected`;
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.detecting=false;},1800);
    }catch(e){
      btn.textContent='Auto-detect failed';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.detecting=false;},2200);
    }
  }

  async function suggestClusters(btn){
    if(state.suggestingClusters) return;
    state.suggestingClusters=true;
    const old=btn.textContent;
    btn.textContent='Suggesting…';
    btn.disabled=true;
    try{
      const settings=await loadSettings();
      saveClusterBackup(settings.clusters||[],'bulk_ai_suggest');
      const data=await api('suggest-clusters',{method:'POST',body:{niche: settings.niche || '', description: settings.niche_description || ''}});
      const suggestions=Array.isArray(data.clusters) ? data.clusters.filter(Boolean) : [];
      if(!suggestions.length) throw new Error('No cluster suggestions returned.');
      await api('settings/clusters',{method:'POST',body:{clusters:suggestions}});
      state.settings=null;
      await loadSettings(true);
      btn.textContent=`✓ ${suggestions.length} suggested`;
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.suggestingClusters=false;},1800);
    }catch(e){
      console.warn('Contentgem cluster suggestion failed',e);
      btn.textContent='AI suggest failed';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.suggestingClusters=false;},2200);
    }
  }

  async function revertClusters(btn){
    if(state.revertingClusters) return;
    state.revertingClusters=true;
    const old=btn.textContent;
    btn.disabled=true;
    btn.textContent='Reverting…';
    try{
      const data=await api('settings/revert-clusters',{method:'POST',body:{}});
      if(Array.isArray(data.clusters)) saveClusterBackup(data.clusters,'reverted');
      state.settings=null;
      await loadSettings(true);
      btn.textContent='✓ Reverted';
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.revertingClusters=false;},1600);
    }catch(e){
      const backup=getClusterBackup();
      if(backup && Array.isArray(backup.clusters) && backup.clusters.length){
        try{
          await api('settings/clusters',{method:'POST',body:{clusters:backup.clusters}});
          state.settings=null;
          await loadSettings(true);
          btn.textContent='✓ Reverted';
        }catch(err){
          btn.textContent='Revert failed';
        }
      }else{
        btn.textContent='Revert failed';
      }
      setTimeout(()=>{btn.textContent=old;btn.disabled=false;state.revertingClusters=false;},2200);
    }
  }


  function findPillarPagesCard(){
    const settingsRoot=getSettingsRoot();
    if(!settingsRoot) return null;
    return Array.from(settingsRoot.querySelectorAll('div')).find(el=>/pillar pages/i.test((el.textContent||''))) || null;
  }

  function ensurePillarSearch(){
    const card=findPillarPagesCard();
    if(!card){ document.querySelectorAll('.cgm-pillar-search-wrap').forEach(el=>el.remove()); return; }
    let wrap=card.querySelector('.cgm-pillar-search-wrap');
    if(!wrap){
      wrap=document.createElement('div');
      wrap.className='cgm-pillar-search-wrap';
      Object.assign(wrap.style,{margin:'10px 0 14px'});
      const input=document.createElement('input');
      input.type='search';
      input.placeholder='Search pillar pages or clusters…';
      Object.assign(input.style,{width:'100%',maxWidth:'420px',padding:'10px 12px',border:'1px solid rgba(108,76,255,.35)',borderRadius:'10px'});
      input.addEventListener('input',()=>{
        const q=input.value.trim().toLowerCase();
        const rows=Array.from(card.querySelectorAll('select')).map(sel=>sel.closest('div')).filter(Boolean);
        rows.forEach(row=>{
          const txt=(row.textContent||'').toLowerCase();
          row.style.display=!q || txt.includes(q) ? '' : 'none';
        });
      });
      wrap.appendChild(input);
      const heading=Array.from(card.querySelectorAll('h2,h3,h4')).find(el=>/pillar pages/i.test(el.textContent||''));
      if(heading) heading.insertAdjacentElement('afterend', wrap); else card.prepend(wrap);
    }
  }

  function ensureSettingsToolbar(){
    if(!isSettingsView()) {
      document.querySelectorAll('.cgm-settings-toolbar').forEach(el=>el.remove());
      return;
    }
    const anchor=findSettingsToolbarAnchor();
    if(!anchor) return;
    const container=anchor.parentElement || anchor;
    let toolbar=document.querySelector('.cgm-settings-toolbar');
    if(!toolbar){
      toolbar=document.createElement('div');
      toolbar.className='cgm-settings-toolbar';
      Object.assign(toolbar.style,{display:'flex',gap:'8px',flexWrap:'wrap',margin:'0 0 12px 0',alignItems:'center',width:'100%'});

      const detectBtn=document.createElement('button');
      detectBtn.type='button';
      detectBtn.className='cgm-settings-detect';
      detectBtn.textContent='Auto-detect existing clusters';
      Object.assign(detectBtn.style,{padding:'8px 14px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.50)',background:'rgba(108,76,255,.18)',color:'#C4B5FD',fontWeight:'700',cursor:'pointer'});
      detectBtn.addEventListener('click',()=>autoDetectClusters(detectBtn));

      const aiBtn=document.createElement('button');
      aiBtn.type='button';
      aiBtn.className='cgm-settings-ai-suggest';
      aiBtn.textContent='Auto-generate clusters';
      Object.assign(aiBtn.style,{padding:'8px 14px',borderRadius:'999px',border:'1px solid #7B2D8B',background:'#F3E5F5',color:'#7B2D8B',fontWeight:'700',cursor:'pointer'});
      aiBtn.addEventListener('click',()=>suggestClusters(aiBtn));

      const revertBtn=document.createElement('button');
      revertBtn.type='button';
      revertBtn.className='cgm-settings-revert-clusters';
      revertBtn.textContent='Revert clusters';
      Object.assign(revertBtn.style,{padding:'8px 14px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.30)',background:'rgba(9,12,61,.94)',color:'#B9C4FF',fontWeight:'700',cursor:'pointer'});
      revertBtn.addEventListener('click',()=>revertClusters(revertBtn));

      const note=document.createElement('span');
      note.textContent='Adds detected or AI-suggested clusters without overwriting your current setup. Revert restores the previous cluster set.';
      Object.assign(note.style,{fontSize:'12px',color:'#B9C4FF',flex:'1 1 220px'});

      toolbar.appendChild(detectBtn);
      toolbar.appendChild(aiBtn);
      toolbar.appendChild(revertBtn);
      toolbar.appendChild(note);
    }
    const shouldMove = !toolbar.isConnected || toolbar.parentElement!==container || toolbar.nextElementSibling!==anchor;
    if(shouldMove){
      container.insertBefore(toolbar, anchor);
    }
  }



  function getPageRootByTitle(pattern){
    const pages = Array.from(document.querySelectorAll('.cgm-page'));
    return pages.find(page => pattern.test(page.querySelector('.cgm-page__title')?.textContent||'')) || null;
  }

  function hideLegacyPillarUi(){
    const card=findPillarPagesCard();
    if(!card) return;
    Array.from(card.querySelectorAll('select')).forEach(sel=>{
      const row=sel.closest('div');
      if(row && !row.classList.contains('cgm-pillar-manager-row')) {
        row.style.display='none';
        row.setAttribute('aria-hidden','true');
      }
    });
    Array.from(card.querySelectorAll('button')).forEach(btn=>{
      if(/suggest pillar|create pillar/i.test(btn.textContent||'')){
        const row=btn.closest('div');
        if(row && !row.closest('.cgm-pillar-manager')) {
          row.style.display='none';
          row.setAttribute('aria-hidden','true');
        }
      }
    });
    Array.from(card.children).forEach(child=>{
      if(child.classList?.contains('cgm-pillar-manager') || child.classList?.contains('cgm-pillar-search-wrap')) return;
      if(/pillar pages/i.test((child.textContent||'').trim()) && /^H[1-6]$/.test(child.tagName||'')) return;
      child.style.display='none';
      child.setAttribute('aria-hidden','true');
    });
  }

  function scorePillarCandidate(clusterName, keywords, post){
    const hay=((post.title||'')+' '+(post.url||'')+' '+(post.post_type||'')).toLowerCase();
    let score=0;
    const cname=(clusterName||'').toLowerCase();
    if(cname && hay.includes(cname)) score+=12;
    (keywords||[]).forEach(kw=>{ const k=(kw||'').toLowerCase(); if(k && hay.includes(k)) score+=5; });
    if(/guide|gids|basis|complete|uitgelegd|ultimate/i.test(post.title||'')) score+=7;
    if((post.post_type||'')==='page') score+=4;
    if(post.is_pillar) score+=3;
    const tokens=(clusterName||'').toLowerCase().split(/\s+/).filter(Boolean);
    if(tokens.length){
      const hits=tokens.filter(t=>hay.includes(t)).length;
      if(hits===0) score-=8;
      else if(hits===tokens.length) score+=6;
    }
    return score;
  }

  async function savePillarSelection(clusterName, postId, btn){
    const old=btn?.textContent||'';
    if(btn){btn.disabled=true; btn.textContent='Saving…';}
    try{
      await api('pillar-pages',{method:'POST',body:{pillar_pages:{[clusterName]: postId}}});
      state.settings=null;
      await loadSettings(true);
      if(btn){btn.textContent='✓ Saved';}
      setTimeout(schedule,300);
    }catch(e){
      alert(e.message||'Could not save pillar page.');
      if(btn){btn.textContent='Save failed';}
    }finally{ if(btn){setTimeout(()=>{btn.disabled=false;btn.textContent=old||'Set as pillar';},1200);} }
  }

  async function ensurePillarManager(){
    const card=findPillarPagesCard();
    if(!card){ document.querySelectorAll('.cgm-pillar-manager').forEach(el=>el.remove()); return; }
    hideLegacyPillarUi();
    let wrap=card.querySelector('.cgm-pillar-manager');
    if(!wrap){
      wrap=document.createElement('div');
      wrap.className='cgm-pillar-manager';
      Object.assign(wrap.style,{display:'grid',gap:'14px',marginTop:'12px'});
      card.appendChild(wrap);
    }
    const data=await api('pillar-pages');
    const settings=await loadSettings();
    const clusters=(data?.clusters||[]);
    wrap.innerHTML='';
    clusters.forEach(cluster=>{
      const row=document.createElement('div');
      row.className='cgm-pillar-manager-row';
      Object.assign(row.style,{border:'1px solid rgba(108,76,255,.25)',borderRadius:'12px',padding:'12px',background:'rgba(9,12,61,.94)'});
      const header=document.createElement('div');
      header.style.display='flex'; header.style.justifyContent='space-between'; header.style.alignItems='center'; header.style.gap='12px';
      const title=document.createElement('div'); title.innerHTML=`<strong>${cluster.cluster_name}</strong><div style="font-size:12px;color:#B9C4FF;margin-top:2px;">${(cluster.keywords||[]).slice(0,6).join(', ')||'No cluster keywords yet'}</div>`;
      const search=document.createElement('input'); search.type='search'; search.placeholder=`Search pages for ${cluster.cluster_name}…`; Object.assign(search.style,{padding:'8px 10px',border:'1px solid rgba(108,76,255,.35)',borderRadius:'10px',minWidth:'250px'});
      header.appendChild(title); header.appendChild(search); row.appendChild(header);
      const actions=document.createElement('div'); Object.assign(actions.style,{display:'flex',gap:'8px',margin:'10px 0',flexWrap:'wrap'});
      const bestBtn=document.createElement('button'); bestBtn.type='button'; bestBtn.textContent='Pick best pillar page';
      const clearBtn=document.createElement('button'); clearBtn.type='button'; clearBtn.textContent='Clear pillar';
      const current=(cluster.posts||[]).find(p=>Number(p.id)===Number(cluster.current_pillar_id));
      const currentPill=document.createElement('span'); currentPill.textContent=current?`Current pillar: ${current.title}`:'No pillar selected';
      Object.assign(bestBtn.style,{padding:'8px 12px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.50)',background:'rgba(108,76,255,.18)',color:'#C4B5FD',fontWeight:'700',cursor:'pointer'});
      Object.assign(clearBtn.style,{padding:'8px 12px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.35)',background:'rgba(9,12,61,.94)',color:'#B9C4FF',fontWeight:'700',cursor:'pointer'});
      Object.assign(currentPill.style,{fontSize:'12px',color:'#B9C4FF',alignSelf:'center'});
      actions.appendChild(bestBtn); actions.appendChild(clearBtn); actions.appendChild(currentPill); row.appendChild(actions);
      const list=document.createElement('div'); Object.assign(list.style,{display:'grid',gap:'8px'});
      const posts=(cluster.posts||[]).slice().sort((a,b)=>scorePillarCandidate(cluster.cluster_name,cluster.keywords||[],b)-scorePillarCandidate(cluster.cluster_name,cluster.keywords||[],a));
      function renderList(){
        const q=(search.value||'').trim().toLowerCase();
        list.innerHTML='';
        const visible=posts.filter(post=>{
          const score=scorePillarCandidate(cluster.cluster_name,cluster.keywords||[],post);
          const matchesSearch=!q || ((post.title||'').toLowerCase().includes(q) || (post.url||'').toLowerCase().includes(q) || (cluster.cluster_name||'').toLowerCase().includes(q));
          const keep=Number(post.id)===Number(cluster.current_pillar_id) || score>=10;
          return keep && matchesSearch;
        });
        if(!visible.length){
          const empty=document.createElement('div');
          empty.textContent='No suitable pillar page candidates found for this cluster yet.';
          Object.assign(empty.style,{fontSize:'12px',color:'#B9C4FF',padding:'6px 0'});
          list.appendChild(empty);
          return;
        }
        visible.slice(0,8).forEach(post=>{
          const score=scorePillarCandidate(cluster.cluster_name,cluster.keywords||[],post);
          const item=document.createElement('div'); Object.assign(item.style,{display:'flex',justifyContent:'space-between',gap:'10px',alignItems:'center',padding:'8px 10px',border:'1px solid rgba(108,76,255,.18)',borderRadius:'10px'});
          const meta=document.createElement('div'); meta.innerHTML=`<div style="font-weight:600;color:#F8FAFF;">${post.title}</div><div style="font-size:12px;color:#B9C4FF;">${post.post_type} · score ${score}</div>`;
          const btn=document.createElement('button'); btn.type='button'; btn.textContent=Number(post.id)===Number(cluster.current_pillar_id)?'Selected':'Set as pillar'; Object.assign(btn.style,{padding:'6px 10px',borderRadius:'999px',border:'1px solid rgba(108,76,255,.35)',background:'rgba(9,12,61,.94)',cursor:'pointer'});
          btn.addEventListener('click',()=>savePillarSelection(cluster.cluster_name, post.id, btn));
          item.appendChild(meta); item.appendChild(btn); list.appendChild(item);
        });
      }
      search.addEventListener('input',renderList);
      bestBtn.addEventListener('click',()=>{ const best=posts.find(post=>scorePillarCandidate(cluster.cluster_name,cluster.keywords||[],post)>=10); if(best) savePillarSelection(cluster.cluster_name,best.id,bestBtn); });
      clearBtn.addEventListener('click',()=>savePillarSelection(cluster.cluster_name, 0, clearBtn));
      renderList();
      row.appendChild(list); wrap.appendChild(row);
    });
  }

  function getCompetitorRoot(){ return getPageRootByTitle(/Competitor/i); }

  function updateCompetitorRunUi(card, data={}){
    if(!card) return;
    const bar=card.querySelector('.cgm-bulk-progress-fill');
    const meta=card.querySelector('.cgm-bulk-progress-meta');
    const wrap=card.querySelector('.cgm-bulk-progress');
    const total=Math.max(0, parseInt(data.total||0,10)||0);
    const done=Math.max(0, parseInt(data.done||0,10)||0);
    const status=String(data.status||'idle');
    const rawPercent=total>0 ? Math.round((done/total)*100) : 0;
    const prev=Math.max(0, parseInt(card.dataset.cgmProgress||'0',10)||0);
    const percent=status==='done' ? 100 : Math.max(prev, rawPercent);
    card.dataset.cgmProgress=String(percent);
    if(wrap) wrap.style.display = (status==='idle' && percent===0) ? 'none' : 'block';
    if(bar) bar.style.width=`${percent}%`;
    if(meta){
      if(status==='done'){
        meta.textContent = `Completed ${total}/${total} keywords`;
      }else if(status==='running'){
        meta.textContent = `Progress: ${done}/${total} keywords`;
      }else if(status==='error'){
        meta.textContent = data.message || 'Competitor analysis failed.';
      }else{
        meta.textContent = total>0 ? `Progress: ${done}/${total} keywords` : '';
      }
    }
  }

  async function ensureCompetitorBulkCard(){
    const root=getCompetitorRoot();
    document.querySelectorAll('.cgm-competitor-bulk-card').forEach(el=>{ if(!root || !root.contains(el)) el.remove(); });
    if(!root) return;
    let card=root.querySelector('.cgm-competitor-bulk-card');
    if(!card){
      card=document.createElement('div'); card.className='cgm-competitor-bulk-card'; Object.assign(card.style,{margin:'14px 0',padding:'14px',border:'1px solid rgba(108,76,255,.25)',background:'rgba(9,12,61,.94)',borderRadius:'12px'});
      const header=document.createElement('h3'); header.textContent='Bulk competitor workflow'; Object.assign(header.style,{margin:'0 0 10px',fontSize:'16px'});
      const helper=document.createElement('div'); helper.className='cgm-bulk-helper'; helper.innerHTML='<strong>Order:</strong> 1. Add your own URL and competitor URLs in the competitor form above. 2. Run competitor analysis for the selected cluster. 3. Send the stored cluster keywords to AI Assistant as semantic context only.'; Object.assign(helper.style,{fontSize:'12px',color:'#B9C4FF',margin:'0 0 10px',lineHeight:'1.5'});
      const row=document.createElement('div'); Object.assign(row.style,{display:'flex',gap:'8px',flexWrap:'wrap',alignItems:'center'});
      const sel=document.createElement('select'); sel.className='cgm-bulk-cluster'; Object.assign(sel.style,{padding:'10px 12px',border:'1px solid rgba(108,76,255,.35)',borderRadius:'12px',minWidth:'220px'});
      const analyze=document.createElement('button'); analyze.type='button'; analyze.textContent='Run competitor analysis'; analyze.className='cgm-btn cgm-btn--primary';
      const send=document.createElement('button'); send.type='button'; send.textContent='Send semantic context to AI Assistant'; send.className='cgm-btn cgm-btn--secondary';
      const progressWrap=document.createElement('div'); progressWrap.className='cgm-bulk-progress'; Object.assign(progressWrap.style,{display:'none',marginTop:'10px'});
      progressWrap.innerHTML='<div style="height:8px;background:rgba(108,76,255,.18);border-radius:999px;overflow:hidden;"><div class="cgm-bulk-progress-fill" style="height:100%;width:0%;background:linear-gradient(90deg,#7B2D8B,#8B5CF6);transition:width .25s ease;"></div></div><div class="cgm-bulk-progress-meta" style="font-size:12px;color:#B9C4FF;margin-top:6px;"></div>';
      const note=document.createElement('div'); note.className='cgm-bulk-note'; Object.assign(note.style,{fontSize:'12px',color:'#B9C4FF',marginTop:'8px',lineHeight:'1.5'});
      row.appendChild(sel); row.appendChild(analyze); row.appendChild(send); card.appendChild(header); card.appendChild(helper); card.appendChild(row); card.appendChild(progressWrap); card.appendChild(note);
      const insert=root.querySelector('.cgm-page__header')?.nextElementSibling || root.firstElementChild; if(insert) insert.insertAdjacentElement('afterend',card); else root.prepend(card);
      analyze.addEventListener('click', async()=>{
        const settings=await loadSettings(true); const cluster=sel.value; const keywords=(settings.cluster_keywords||{})[cluster]||[];
        const competitorInputs=Array.from(root.querySelectorAll('input,textarea')).filter(el=>/http|url|competitor/i.test((el.placeholder||'')+' '+(el.getAttribute('aria-label')||'')));
        const allUrls=competitorInputs.flatMap(el=>(el.value||'').split(/\n|,/).map(v=>v.trim()).filter(Boolean));
        const yourUrl=allUrls[0]||''; const competitorUrls=allUrls.slice(1,6);
        if(!keywords.length){ note.textContent='No stored keywords found for this cluster yet. Save keywords first in the competitor form above.'; return; }
        if(!competitorUrls.length){ note.textContent='Add your own URL and at least one competitor URL in the competitor form above first.'; return; }
        analyze.disabled=true;
        send.disabled=true;
        state.competitorRun = { cluster, total: keywords.length, done: 0, saved: 0, status: 'running' };
        updateCompetitorRunUi(card, state.competitorRun);
        note.textContent='Running competitor analysis for the stored cluster keywords and saving each report…';
        let done=0;
        let saved=0;
        const savedReports = (()=>{ try{ const raw=localStorage.getItem('cgm_competitor_reports')||'[]'; const parsed=JSON.parse(raw); return Array.isArray(parsed)?parsed:[]; }catch(e){ return []; }})();
        for(const kw of keywords){
          try{
            note.textContent=`Analyzing ${done+1}/${keywords.length}: ${kw}`;
            const report = await api('competitor/analyze',{method:'POST',body:{keyword:kw,cluster, your_url:yourUrl, competitor_urls:competitorUrls}});
            done++;
            state.competitorRun = { cluster, total: keywords.length, done, saved, status: 'running' };
            if(report && !report.error){
              savedReports.unshift(report);
              saved++;
              state.competitorRun.saved = saved;
            }
            updateCompetitorRunUi(card, state.competitorRun);
            try{ localStorage.setItem('cgm_competitor_reports', JSON.stringify(savedReports.slice(0,50))); }catch(e){}
          }catch(e){
            done++;
            state.competitorRun = { cluster, total: keywords.length, done, saved, status: 'running' };
            updateCompetitorRunUi(card, state.competitorRun);
            console.warn(e);
          }
        }
        analyze.disabled=false;
        send.disabled=false;
        state.competitorRun = { cluster, total: keywords.length, done: keywords.length, saved, status: 'done' };
        updateCompetitorRunUi(card, state.competitorRun);
        note.textContent=`Saved ${saved} competitor reports for ${cluster}. Next step: click "Send semantic context to AI Assistant" to continue writing.`;
      });
      send.addEventListener('click', async()=>{
        const settings=await loadSettings(true); const cluster=sel.value; const keywords=(settings.cluster_keywords||{})[cluster]||[];
        if(!keywords.length){ note.textContent='No stored keywords found for this cluster yet. Save keywords first in the competitor form above.'; return; }
        try{ localStorage.setItem('cgm_ai_bulk_keywords', JSON.stringify({cluster, keywords, savedAt:Date.now()})); }catch(e){}
        const aiLink = Array.from(document.querySelectorAll('a,button,div')).find(el=>/AI Assistant/i.test(el.textContent||''));
        note.textContent=`Sent ${keywords.length} stored cluster keywords to AI Assistant as semantic context for ${cluster}. Open the AI Assistant tab to continue.`;
        if(aiLink && typeof aiLink.click === 'function'){ try{ aiLink.click(); }catch(e){} }
      });
    }
    const settings=await loadSettings(true);
    const sel=card.querySelector('.cgm-bulk-cluster');
    const note=card.querySelector('.cgm-bulk-note');
    const actionButtons=Array.from(card.querySelectorAll('button'));
    const clusters=(settings.clusters||[]).filter(Boolean);
    // Persist selected cluster in localStorage
    const LS_BULK_CLUSTER = 'cgm_bulk_cluster_selected';
    const prevSelection = sel.value || sel.dataset.cgmSelected || (localStorage.getItem(LS_BULK_CLUSTER)||'');
    const clusterHash = clusters.join('||');
    // Only rebuild options if clusters have changed
    if (sel.dataset.cgmClusterHash !== clusterHash) {
      sel.dataset.cgmClusterHash = clusterHash;
      sel.innerHTML = clusters.length
        ? `<option value="">Select cluster…</option>` + clusters.map(c=>`<option value="${c.replace(/\"/g,'&quot;')}">${c}</option>`).join('')
        : '<option value="">No clusters available</option>';
    }
    // Restore selection if valid
    if (prevSelection && Array.from(sel.options).some(o => o.value === prevSelection)) {
      sel.value = prevSelection;
      sel.dataset.cgmSelected = prevSelection;
    }
    const refreshBulkState=()=>{
      const current=sel.value;
      const count=((state.settings?.cluster_keywords||settings.cluster_keywords||{})[current]||[]).length;
      const runActive = state.competitorRun && state.competitorRun.status === 'running';
      if(!runActive){
        const keywordList=((state.settings?.cluster_keywords||settings.cluster_keywords||{})[current]||[]);
        const preview=keywordList.slice(0,3).join(', ');
        note.textContent = current
          ? (count>0
              ? `${count} stored keywords ready for ${current}${preview ? `: ${preview}${count>3 ? '…' : ''}` : ''}. Order: fill in the competitor URLs above, run competitor analysis, then send them to AI Assistant as semantic context.`
              : `No stored keywords found for ${current}. Save cluster keywords first before running the workflow.`)
          : 'Choose a cluster to start. Order: 1) fill in competitor URLs, 2) run competitor analysis, 3) send keywords to AI Assistant.';
      }
      actionButtons.forEach(btn=>{
        btn.disabled = runActive || !current || count===0;
        btn.style.opacity = (runActive || !current || count===0) ? '0.55' : '1';
      });
      if(runActive){ updateCompetitorRunUi(card, state.competitorRun); }
    };
    refreshBulkState();
    sel.onchange=()=>{
      sel.dataset.cgmSelected = sel.value;
      try{ localStorage.setItem(LS_BULK_CLUSTER, sel.value); }catch(e){}
      refreshBulkState();
    };
  }

  function getDraftsRoot(){ return getPageRootByTitle(/Drafts/i); }

  async function ensureDraftToolsCard(){
    // Draft actions already exist in the native Drafts UI; do not inject duplicate bulk tools here.
    document.querySelectorAll('.cgm-drafts-tools').forEach(el=>el.remove());
    return;
  }

  function getDashboardRoot(){
    const pages = Array.from(document.querySelectorAll('.cgm-page'));
    return pages.find(page => /Dashboard/i.test(page.querySelector('.cgm-page__title')?.textContent||'')) || null;
  }

function findAnalyzeButton(){
    // Prefer previously-marked button by data attribute for stability
    const marked = document.querySelector('button[data-cgm-role="analyze-site"]');
    if (marked) return marked;
    // Fallback: detect by original label (first render only)
    const candidates = Array.from(document.querySelectorAll('button'));
    const btn = candidates.find(b => /analyse site|analyze site/i.test((b.textContent||'').trim()));
    if (btn) {
      // Mark the button so subsequent lookups don't rely on text
      btn.dataset.cgmRole = 'analyze-site';
      return btn;
    }
    return null;
  }

// Retrieve stored progress for a specific job id from memory/sessionStorage
function getStoredProgress(jobId){
    if(!jobId) return 0;
    const mem = Number((state.analysisProgressByJob||{})[jobId]||0);
    if(mem > 0) return mem;
    try{
      const raw=sessionStorage.getItem('cgm_analysis_progress_v2')||'{}';
      const rec=JSON.parse(raw);
      return (rec.job_id===jobId ? Number(rec.progress||0) : 0) || 0;
    }catch(e){ return 0; }
}

// Persist progress for a specific job id in memory/sessionStorage
function setStoredProgress(jobId, progress){
    if(!jobId) return;
    const next = Math.max(0, Math.min(100, Number(progress)||0));
    state.analysisProgressByJob = state.analysisProgressByJob || {};
    state.analysisProgressByJob[jobId] = Math.max(Number(state.analysisProgressByJob[jobId]||0), next);
    try{
      sessionStorage.setItem('cgm_analysis_progress_v2', JSON.stringify({job_id: jobId, progress: state.analysisProgressByJob[jobId]}));
    }catch(e){}
}

function clearStoredProgress(jobId){
    if(jobId && state.analysisProgressByJob){ delete state.analysisProgressByJob[jobId]; }
    try{ sessionStorage.removeItem('cgm_analysis_progress_v2'); }catch(e){}
}

function nextAnalysisPollEpoch(){
    state.analysisPollEpoch = (Number(state.analysisPollEpoch)||0) + 1;
    return state.analysisPollEpoch;
}


  function ensureAnalyzeStatusPanel(){
    const root = getDashboardRoot();
    if(!root){
      document.querySelectorAll('.cgm-analyze-status-panel').forEach(el=>el.remove());
      state.analysisPanel = null;
      return null;
    }
    let panel = root.querySelector('.cgm-analyze-status-panel');
    if(!panel){
      panel=document.createElement('div');
      panel.className='cgm-analyze-status-panel';
      Object.assign(panel.style,{margin:'14px 0 18px',padding:'14px 16px',border:'1px solid rgba(108,76,255,.25)',background:'rgba(9,12,61,.94)',borderRadius:'12px',display:'none'});
      panel.innerHTML=`
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;">
          <div>
            <div class="cgm-analyze-status-title" style="font-weight:700;color:#F8FAFF;">Site analysis status</div>
            <div class="cgm-analyze-status-message" style="font-size:13px;color:#B9C4FF;margin-top:4px;">Waiting to start.</div>
          </div>
          <div class="cgm-analyze-status-pill" style="padding:6px 10px;border-radius:999px;background:rgba(108,76,255,.18);color:#F8FAFF;font-size:12px;font-weight:700;">Idle</div>
        </div>
        <div style="margin-top:12px;height:10px;background:rgba(108,76,255,.18);border-radius:999px;overflow:hidden;">
          <div class="cgm-analyze-status-bar" style="height:100%;width:0%;background:linear-gradient(90deg,#7B2D8B,#8B5CF6);transition:width .25s ease;"></div>
        </div>
        <div class="cgm-analyze-status-meta" style="font-size:12px;color:#B9C4FF;margin-top:8px;">No active analysis.</div>
      `;
      const header=root.querySelector('.cgm-page__header');
      if(header && header.nextSibling) header.parentElement.insertBefore(panel, header.nextSibling);
      else root.prepend(panel);
    }
    state.analysisPanel = panel;
    return panel;
  }

  function setAnalyzeButtonState(active, label){
    const btn=findAnalyzeButton();
    if(!btn) return;
    if(!btn.dataset.cgmOriginalLabel) btn.dataset.cgmOriginalLabel=(btn.textContent||'').trim();
    if(active){
      btn.disabled=true;
      btn.textContent=label||'Analyzing…';
      btn.style.opacity='0.8';
      btn.style.cursor='progress';
    }else{
      btn.disabled=false;
      btn.textContent=label||btn.dataset.cgmOriginalLabel||'Analyse site';
      btn.style.opacity='';
      btn.style.cursor='';
    }
  }

  function renderAnalyzeStatus(data){
    cleanupMvpUi();
    syncOverrideFlagWithView();
    const panel=ensureAnalyzeStatusPanel();
    if(!panel) return;
    const incomingJobId = String(data?.job_id || state.analysisJobId || '');
    const status = String(data?.status || data?.analysis_status || 'idle');
    const rawProgress = Math.max(0, Math.min(100, parseInt(data?.progress || 0, 10) || 0));
    const prev = getStoredProgress(incomingJobId);
    const progress = status === 'done' ? 100 : Math.max(prev, rawProgress);
    if(incomingJobId) setStoredProgress(incomingJobId, progress);
    const visualProgress = status==='done' ? 100 : (status==='queued' ? Math.max(progress, 4) : Math.min(99, Math.max(progress, 6)));
    const message=String(data?.message|| (status==='done' ? 'Analysis complete.' : status==='error' ? 'Analysis failed.' : 'No active analysis.'));
    const title=panel.querySelector('.cgm-analyze-status-title');
    const msg=panel.querySelector('.cgm-analyze-status-message');
    const pill=panel.querySelector('.cgm-analyze-status-pill');
    const bar=panel.querySelector('.cgm-analyze-status-bar');
    const meta=panel.querySelector('.cgm-analyze-status-meta');
    panel.style.display = status==='idle' || status==='unknown' ? 'none' : 'block';
    if(title) title.textContent='Site analysis status';
    if(msg) msg.textContent=message;
    if(pill){
      pill.textContent=status.charAt(0).toUpperCase()+status.slice(1);
      if(status==='done'){ pill.style.background='#E8F7EE'; pill.style.color='#1A7A4A'; }
      else if(status==='error' || status==='stalled'){ pill.style.background='#FDECEC'; pill.style.color='#B42318'; }
      else if(status==='running'){ pill.style.background='rgba(108,76,255,.18)'; pill.style.color='#F8FAFF'; }
      else { pill.style.background='#FFF4E5'; pill.style.color='#9A6700'; }
    }
    if(bar) bar.style.width=`${visualProgress}%`;
    if(meta){
      const updated=data?.updated ? new Date((Number(data.updated)||0)*1000) : null;
      meta.textContent = `${progress}% complete${updated && !Number.isNaN(updated.getTime()) ? ` · Last update ${updated.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}` : ''}`;
    }
    if(status === 'running' || status === 'queued' || status === 'finalizing') {
      setAnalyzeButtonState(true, status === 'queued' ? 'Queued…' : 'Analyzing…');
    } else {
      setAnalyzeButtonState(false);
      if(status === 'done' || status === 'error'){
        const finishedJobId = incomingJobId || state.analysisJobId || '';
        state.analysisJobId = '';
        try{ sessionStorage.removeItem('cgm_active_analysis_job_id'); }catch(e){}
        clearStoredProgress(finishedJobId);
      }
    }
  }

  async function pollAnalyzeStatus(forceJobId, epoch){
    const currentEpoch = Number(epoch || state.analysisPollEpoch || 0);
    const requestedJobId = forceJobId || state.analysisJobId || '';
    try{
      const data=await api(`analysis/status${requestedJobId?`?job_id=${encodeURIComponent(requestedJobId)}`:''}`);
      if(currentEpoch !== Number(state.analysisPollEpoch||0)) return;
      const responseJobId = String(data?.job_id || requestedJobId || '');
      const activeId = String(data?.active_job || responseJobId || '');
      const previousJobId = state.analysisJobId || '';
      if(activeId && activeId !== previousJobId){
        clearStoredProgress(previousJobId);
        state.analysisJobId = activeId;
        try{ sessionStorage.setItem('cgm_active_analysis_job_id', activeId); }catch(e){}
      } else if(!state.analysisJobId && responseJobId){
        state.analysisJobId = responseJobId;
      }
      renderAnalyzeStatus({...data, job_id: responseJobId});
      if(data?.status === 'done' || data?.status === 'error'){
        try{ sessionStorage.removeItem('cgm_active_analysis_job_id'); }catch(e){}
      }
      if(data?.status==='running' || data?.status==='queued' || data?.status==='finalizing'){
        if(!state.analysisPoller){
          state.analysisPoller=setTimeout(()=>{ state.analysisPoller=null; pollAnalyzeStatus(responseJobId || activeId || '', currentEpoch); }, 2500);
        }
      }else if(state.analysisPoller){
        clearTimeout(state.analysisPoller);
        state.analysisPoller=null;
      }
    }catch(e){
      if(currentEpoch !== Number(state.analysisPollEpoch||0)) return;
      console.warn('Contentgem analysis status poll failed', e);
      setAnalyzeButtonState(false);
    }
  }

  function kickoffAnalysisRun(jobId){
    if(!jobId) return;
    fetch(`${restBase}/analyze-run`, {
      method:'POST',
      headers:{'Content-Type':'application/json','X-WP-Nonce':nonce},
      credentials:'same-origin',
      body: JSON.stringify({job_id: jobId}),
      keepalive: true
    }).catch((e)=>console.warn('Contentgem background analysis kickoff failed', e));
  }

  function bindAnalyzeButton(){
    const btn=findAnalyzeButton();
    if(!btn) return;
    if(btn.dataset.cgmAnalyzeBound==='1') return;
    btn.dataset.cgmAnalyzeBound='1';
    btn.addEventListener('click', async (event)=>{
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();
      if(btn.disabled) return;
      try{
        try{
          clearStoredProgress(state.analysisJobId);
          sessionStorage.removeItem('cgm_active_analysis_job_id');
        }catch(e){}
        state.analysisJobId='';
        state.analysisStartedAt=Date.now();
        const epoch = nextAnalysisPollEpoch();
        if(state.analysisPoller){ clearTimeout(state.analysisPoller); state.analysisPoller=null; }
        setAnalyzeButtonState(true, 'Queued…');
        renderAnalyzeStatus({status:'queued', progress:1, message:'Preparing analysis…'});
        const data=await api('analysis/start',{method:'POST',body:{}});
        if(data?.job_id) { state.analysisJobId=data.job_id; try{ sessionStorage.setItem('cgm_active_analysis_job_id', data.job_id); }catch(e){} }
        renderAnalyzeStatus(data||{status:'queued',progress:1,message:'Analysis queued.'});
        kickoffAnalysisRun(data?.job_id || '');
        setTimeout(()=>pollAnalyzeStatus(data?.job_id || '', epoch), 600);
      }catch(e){
        console.warn('Contentgem analysis start failed', e);
        setAnalyzeButtonState(false);
        renderAnalyzeStatus({status:'error', progress:0, message:e.message || 'Could not start analysis.'});
      }
    }, true);
  }

  async function refreshAnalyzeNotice(){
    bindAnalyzeButton();
    ensureAnalyzeStatusPanel();
    if(!state.analysisJobId){ try{ state.analysisJobId=sessionStorage.getItem('cgm_active_analysis_job_id')||''; }catch(e){} }
    const epoch = nextAnalysisPollEpoch();
    if(state.analysisJobId){
      pollAnalyzeStatus(state.analysisJobId, epoch);
    }else{
      renderAnalyzeStatus({status:'idle', progress:0, message:''});
      setAnalyzeButtonState(false);
    }
  }


  async function saveContentLanguagePreference(value, customValue=''){
    const nextValue = String(value || 'auto');
    const nextCustomValue = String(customValue || '').trim();
    state.languageDraft = { value: nextValue, customValue: nextCustomValue };
    setStoredLanguageOverride(nextValue, nextCustomValue);
    const response = await api('settings/language',{method:'POST',body:{language:nextValue,custom_language:nextCustomValue}});
    const freshSettings = await api('settings');
    const mergedSettings = Object.assign({}, state.settings || {}, freshSettings || {}, response || {}, {
      content_language: String((response && response.content_language) || (freshSettings && freshSettings.content_language) || nextValue),
      content_language_custom: String((response && response.content_language_custom) || (freshSettings && freshSettings.content_language_custom) || (nextValue === 'custom' ? nextCustomValue : ''))
    });
    state.settings = mergedSettings;
    state.languageDraft = {
      value: mergedSettings.content_language || nextValue,
      customValue: mergedSettings.content_language_custom || ''
    };
    setStoredLanguageOverride(state.languageDraft.value, state.languageDraft.customValue);
    return mergedSettings;
  }

  function getLanguageControlState(){
    const draft = state.languageDraft;
    if(draft && typeof draft === 'object'){
      return {
        value: String(draft.value || 'auto'),
        customValue: String(draft.customValue || '')
      };
    }
    const override = state.languageOverride || getStoredLanguageOverride();
    if(override && typeof override === 'object'){
      state.languageOverride = override;
      return {
        value: String(override.value || 'auto'),
        customValue: String(override.customValue || '')
      };
    }
    const settings = state.settings || {};
    const value = String(settings.content_language || 'auto');
    const customValue = String(settings.content_language_custom || '');
    return {value, customValue};
  }

  function getLanguageChoices(){
    return [
      {value:'auto',label:'Auto detect'},
      {value:'nl',label:'Nederlands'},
      {value:'en',label:'English'},
      {value:'de',label:'Deutsch'},
      {value:'fr',label:'Français'},
      {value:'es',label:'Español'},
      {value:'it',label:'Italiano'},
      {value:'pt',label:'Português'},
      {value:'custom',label:'Custom language'}
    ];
  }

  function findOnboardingStepOneHeading(){
    return Array.from(document.querySelectorAll('h1,h2,h3')).find(el=>/Step\s*1\s*of\s*3/i.test((el.textContent||'').trim())) || null;
  }

  function hasValidatedApiInOnboarding(){
    const bodyText=(document.body?.textContent||'').replace(/\s+/g,' ').trim();
    if(/API key entered/i.test(bodyText)) return true;
    const saveStatus=Array.from(document.querySelectorAll('span,div')).find(el=>/API key entered|saved/i.test((el.textContent||'').trim()));
    if(saveStatus) return true;
    return false;
  }

  function findOnboardingNicheAnchor(){
    const labels = Array.from(document.querySelectorAll('label'));
    const topicLabel = labels.find(el=>/main topic|onderwerp|niche/i.test((el.textContent||'').trim()));
    if(topicLabel){
      return topicLabel.closest('div') || topicLabel.parentElement || null;
    }
    const headings = Array.from(document.querySelectorAll('h1,h2,h3'));
    const nicheHeading = headings.find(el=>/site niche|website topic|content setup/i.test((el.textContent||'').trim()));
    if(nicheHeading){
      return nicheHeading.closest('div') || nicheHeading.parentElement || null;
    }
    return null;
  }

  function renderLanguageControl(wrap, currentValue, currentCustomValue, helpText, options={}){
    if(!wrap) return;
    const choices=getLanguageChoices();
    const activeValue = String(currentValue || 'auto');
    const activeCustom = String(currentCustomValue || '');
    const saveMode = options.saveMode || 'explicit';
    const saveLabel = options.saveLabel || 'Save language';
    wrap.innerHTML='';

    const card=document.createElement('div');
    card.className='cgm-language-pref-card';
    Object.assign(card.style,{padding:'0',margin:'0'});
    wrap.appendChild(card);

    const label=document.createElement('label');
    label.textContent='CONTENT LANGUAGE';
    Object.assign(label.style,{display:'block',fontSize:'12px',fontWeight:'700',color:'#B9C4FF',marginBottom:'8px',letterSpacing:'.03em'});
    card.appendChild(label);

    const group=document.createElement('div');
    group.className='cgm-language-pref-buttons';
    Object.assign(group.style,{display:'flex',flexWrap:'wrap',gap:'8px'});
    card.appendChild(group);

    const customRow=document.createElement('div');
    customRow.className='cgm-language-pref-custom';
    Object.assign(customRow.style,{display:activeValue==='custom'?'flex':'none',gap:'8px',marginTop:'10px',alignItems:'center',flexWrap:'wrap'});

    const customInput=document.createElement('input');
    customInput.type='text';
    customInput.className='cgm-language-pref-custom-input';
    customInput.value=activeCustom;
    customInput.placeholder='E.g. Svenska, Polski, Japanese';
    Object.assign(customInput.style,{minWidth:'240px',flex:'1 1 260px',padding:'10px 12px',border:'1px solid rgba(108,76,255,.35)',borderRadius:'8px',fontSize:'14px',color:'#F8FAFF'});
    customRow.appendChild(customInput);
    card.appendChild(customRow);

    const help=document.createElement('div');
    help.textContent=helpText;
    Object.assign(help.style,{fontSize:'12px',color:'#B9C4FF',marginTop:'8px'});
    card.appendChild(help);

    const actionRow=document.createElement('div');
    Object.assign(actionRow.style,{display:'flex',alignItems:'center',gap:'10px',flexWrap:'wrap',marginTop:'10px'});
    card.appendChild(actionRow);

    const saveButton=document.createElement('button');
    saveButton.type='button';
    saveButton.textContent=saveLabel;
    Object.assign(saveButton.style,{padding:'10px 14px',border:'1px solid rgba(108,76,255,.50)',borderRadius:'8px',background:'rgba(108,76,255,.18)',color:'#F8FAFF',fontWeight:'600',cursor:'pointer'});
    actionRow.appendChild(saveButton);

    const status=document.createElement('div');
    Object.assign(status.style,{fontSize:'12px',color:'#1A7A4A',minHeight:'16px'});
    actionRow.appendChild(status);

    let busy=false;
    const baseState = {
      value: String((state.settings && state.settings.content_language) || 'auto'),
      customValue: String((state.settings && state.settings.content_language_custom) || '')
    };
    let draftValue = activeValue;
    let draftCustomValue = activeCustom;

    const setBusy=(next)=>{
      busy=!!next;
      group.querySelectorAll('button').forEach(btn=>btn.disabled=busy);
      customInput.disabled=busy;
      saveButton.disabled=busy;
      saveButton.style.opacity=busy?'0.7':'1';
      saveButton.style.cursor=busy?'default':'pointer';
    };

    const refreshSaveState=()=>{
      const needsCustom = draftValue === 'custom';
      const dirty = String(draftValue) !== String(baseState.value || 'auto') || String(draftCustomValue || '') !== String(baseState.customValue || '');
      const valid = !needsCustom || !!String(draftCustomValue || '').trim();
      saveButton.disabled = busy || !dirty || !valid;
      saveButton.style.opacity = saveButton.disabled ? '0.6' : '1';
      saveButton.textContent = saveMode === 'immediate' ? 'Save language' : saveLabel;
      status.textContent = busy ? 'Saving…' : (dirty ? (valid ? 'Unsaved change' : 'Enter a custom language first') : '');
      status.style.color = busy || dirty ? (valid ? '#B9C4FF' : '#B45309') : '#1A7A4A';
    };

    const rerender=(nextValue,nextCustom='')=>{
      state.languageDraft = { value: String(nextValue || 'auto'), customValue: String(nextCustom || '') };
      renderLanguageControl(wrap, state.languageDraft.value, state.languageDraft.customValue, helpText, options);
    };

    const persist=async()=>{
      if(busy) return;
      const normalizedValue = String(draftValue || 'auto');
      const normalizedCustom = String(draftCustomValue || '').trim();
      if(normalizedValue === 'custom' && !normalizedCustom) {
        refreshSaveState();
        return;
      }
      setBusy(true);
      refreshSaveState();
      try{
        const savedSettings = await saveContentLanguagePreference(normalizedValue, normalizedCustom);
        state.languageDraft = {
          value: String(savedSettings?.content_language || normalizedValue),
          customValue: String(savedSettings?.content_language_custom || (normalizedValue === 'custom' ? normalizedCustom : ''))
        };
        state.settings = Object.assign({}, state.settings || {}, {
          content_language: state.languageDraft.value,
          content_language_custom: state.languageDraft.customValue
        });
        setStoredLanguageOverride(state.languageDraft.value, state.languageDraft.customValue);
        renderLanguageControl(wrap, state.languageDraft.value, state.languageDraft.customValue, helpText, options);
      }catch(e){
        state.languageDraft = {
          value: String(baseState.value || 'auto'),
          customValue: String(baseState.customValue || '')
        };
        clearStoredLanguageOverride();
        renderLanguageControl(wrap, state.languageDraft.value, state.languageDraft.customValue, helpText, options);
        alert(e.message||'Could not save language preference.');
      }
    };

    choices.forEach(choice=>{
      const btn=document.createElement('button');
      btn.type='button';
      btn.textContent=choice.label;
      const active = choice.value===draftValue;
      Object.assign(btn.style,{padding:'9px 12px',borderRadius:'999px',border:active?'1px solid #8B5CF6':'1px solid rgba(108,76,255,.35)',background:active?'rgba(108,76,255,.14)':'#fff',color:active?'#F8FAFF':'#B9C4FF',fontWeight:active?'700':'500',cursor:'pointer'});
      const handleChoice = (e)=>{
        if(e){ e.preventDefault(); e.stopPropagation(); }
        draftValue = choice.value;
        if(choice.value!=='custom') draftCustomValue='';
        rerender(draftValue, draftCustomValue);
      };
      btn.addEventListener('mousedown',(e)=>{ e.preventDefault(); });
      btn.addEventListener('click',handleChoice);
      group.appendChild(btn);
    });

    customInput.addEventListener('input', ()=>{
      draftValue='custom';
      draftCustomValue=customInput.value;
      refreshSaveState();
    });
    customInput.addEventListener('keydown', async(e)=>{
      if(e.key==='Enter'){
        e.preventDefault();
        draftValue='custom';
        draftCustomValue=customInput.value;
        await persist();
      }
    });
    saveButton.addEventListener('mousedown',(e)=>{ e.preventDefault(); });
    saveButton.addEventListener('click', async(e)=>{
      e.preventDefault();
      e.stopPropagation();
      draftValue = draftValue || 'auto';
      draftCustomValue = customInput.value;
      await persist();
    });

    refreshSaveState();
  }

  function ensureLanguagePreferenceControl(){
    const {value, customValue} = getLanguageControlState();
    const settings = state.settings || {};
    const onboardingHeading = findOnboardingStepOneHeading();
    const onboardingAnchor = findOnboardingNicheAnchor();

    if(onboardingHeading && onboardingAnchor){
      let wrap = document.querySelector('.cgm-language-pref-wrap.cgm-language-pref-wrap--onboarding');
      if(!wrap){
        wrap=document.createElement('div');
        wrap.className='cgm-language-pref-wrap cgm-language-pref-wrap--onboarding';
        Object.assign(wrap.style,{margin:'0 0 18px'});
      }
      if(onboardingAnchor.parentElement && wrap.parentElement !== onboardingAnchor.parentElement){
        onboardingAnchor.parentElement.insertBefore(wrap, onboardingAnchor);
      }
      const apiReady = !!settings.api_key_set || hasValidatedApiInOnboarding();
      const staleWraps = Array.from(document.querySelectorAll('.cgm-language-pref-wrap')).filter(el=>!el.classList.contains('cgm-language-pref-wrap--onboarding') && !el.classList.contains('cgm-language-pref-wrap--settings'));
      staleWraps.forEach(el=>{ if(onboardingHeading && onboardingHeading.parentElement && onboardingHeading.parentElement.contains(el)) el.remove(); });
      if(!apiReady){
        wrap.innerHTML='';
        wrap.style.display='none';
      }else{
        wrap.style.display='block';
        renderLanguageControl(wrap, value, customValue, 'Kies eerst je API en sla daarna hier de hoofdtaal op voor clusters, content gaps en drafts. Zet onderwerp en beschrijving hieronder.', { saveMode:'explicit', saveLabel:'Save language' });
      }
    }

    const settingsRoot=getSettingsRoot();
    if(settingsRoot){
      const title=Array.from(settingsRoot.querySelectorAll('h1,h2,h3')).find(el=>/settings/i.test(el.textContent||''));
      if(title){
        let wrap = title.nextElementSibling && title.nextElementSibling.classList && title.nextElementSibling.classList.contains('cgm-language-pref-wrap--settings') ? title.nextElementSibling : null;
        if(!wrap){
          wrap=document.createElement('div');
          wrap.className='cgm-language-pref-wrap cgm-language-pref-wrap--settings';
          Object.assign(wrap.style,{margin:'12px 0 18px',padding:'12px',border:'1px solid rgba(108,76,255,.25)',borderRadius:'12px',background:'rgba(9,12,61,.94)'});
          title.insertAdjacentElement('afterend', wrap);
        }
        renderLanguageControl(wrap, value, customValue, 'This preference is used for cluster suggestions, content gaps, and draft generation.', { saveMode:'explicit', saveLabel:'Save language' });
      }
    }
  }

  async function enhance(){
    try{
      const settings=await loadSettings();
      const {clusterSelect}=findInputs();
      populateClusterSelect(clusterSelect, settings.clusters||[]);
      ensureSingleSuggestionButton();
      ensureSettingsToolbar();
      ensureInlineClusterSuggest();
      ensureAssistantHelperActions();
      ensureAssistantUsesGlobalLanguage();
      ensureAssistantSvgToggle();
      ensureLanguagePreferenceControl();
      ensureOnboardingClusterOverride();
      ensurePillarSearch();
      ensurePillarManager();
      ensureCompetitorBulkCard();
      ensureDraftToolsCard();
      cleanupMvpUi();
      applyAdminBranding();
    syncOverrideFlagWithView();
      refreshAnalyzeNotice();
    }catch(e){
      console.warn('Contentgem enhancement init failed',e);
    }
  }

  let scheduled=false;
  let observer=null;
  const shouldPauseEnhancements=()=>{
    const active=document.activeElement;
    if(!active) return false;
    if(active.closest && active.closest('.cgm-language-pref-wrap')) return true;
    const tag=(active.tagName||'').toLowerCase();
    return ['input','textarea','select'].includes(tag);
  };
  const schedule=()=>{
    if(scheduled || shouldPauseEnhancements()) return;
    scheduled=true;
    setTimeout(()=>{scheduled=false; enhance();},180);
  };
  const isRelevantMutationNode=(node)=>{
    if(!node || node.nodeType!==1) return false;
    const el=node;
    if(el.matches && el.matches('.cgm-page, .cgm-card, .components-card, .cgm-settings-tabs, .cgm-ai-actions, .cgm-competitor-tabs')) return true;
    return !!(el.querySelector && el.querySelector('.cgm-page, .cgm-card, .components-card, .cgm-settings-tabs, .cgm-ai-actions, .cgm-competitor-tabs'));
  };
  const startObserver=()=>{
    if(observer) return;
    const root=document.getElementById('contentgem-dashboard') || document.querySelector('.contentgem-main') || document.body;
    observer=new MutationObserver((mutations)=>{
      if(shouldPauseEnhancements()) return;
      const relevant = mutations.some(m=>Array.from(m.addedNodes||[]).some(isRelevantMutationNode) || Array.from(m.removedNodes||[]).some(isRelevantMutationNode));
      if(relevant) schedule();
    });
    observer.observe(root,{childList:true,subtree:true});
  };


  function getBrandLockupMarkup() {
    return `
      <span class="cgm-brand-lockup" aria-label="ContentGem">
        <svg class="cgm-brand-lockup__gem" width="34" height="32" viewBox="0 0 60 56" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
          <defs>
            <linearGradient id="cgmAdminGemA" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C4B5FD"/><stop offset="100%" stop-color="#7C3AED"/></linearGradient>
            <linearGradient id="cgmAdminGemB" x1="0.5" y1="0" x2="0.5" y2="1"><stop offset="0%" stop-color="#EDE9FE"/><stop offset="100%" stop-color="#A78BFA"/></linearGradient>
            <linearGradient id="cgmAdminGemC" x1="1" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#C4B5FD"/><stop offset="100%" stop-color="#A855F7"/></linearGradient>
            <linearGradient id="cgmAdminGemP1" x1="0" y1="0" x2="0.6" y2="1"><stop offset="0%" stop-color="#6D28D9"/><stop offset="100%" stop-color="#1E1B4B"/></linearGradient>
            <linearGradient id="cgmAdminGemP2" x1="0.5" y1="0" x2="0.5" y2="1"><stop offset="0%" stop-color="#4C1D95"/><stop offset="100%" stop-color="#0F0E2B"/></linearGradient>
            <linearGradient id="cgmAdminGemP3" x1="1" y1="0" x2="0.4" y2="1"><stop offset="0%" stop-color="#8B5CF6"/><stop offset="100%" stop-color="#1E1B4B"/></linearGradient>
          </defs>
          <polygon points="0,22 3,10 15,22" fill="#2A145E" opacity="0.88"/>
          <polygon points="3,10 15,0 15,22" fill="url(#cgmAdminGemA)"/>
          <polygon points="15,0 30,0 15,22" fill="url(#cgmAdminGemB)"/>
          <polygon points="30,0 45,0 45,22" fill="url(#cgmAdminGemB)" opacity="0.92"/>
          <polygon points="45,0 57,10 45,22" fill="url(#cgmAdminGemC)"/>
          <polygon points="57,10 60,22 45,22" fill="#2D2369" opacity="0.84"/>
          <line x1="0" y1="22" x2="60" y2="22" stroke="rgba(167,139,250,.45)" stroke-width="0.8"/>
          <polygon points="0,22 15,22 30,56" fill="url(#cgmAdminGemP1)"/>
          <polygon points="15,22 30,22 30,56" fill="url(#cgmAdminGemP2)"/>
          <polygon points="30,22 45,22 30,56" fill="#24155D"/>
          <polygon points="45,22 60,22 30,56" fill="url(#cgmAdminGemP3)"/>
          <circle cx="30" cy="55" r="1.5" fill="white" opacity="0.6"/>
        </svg>
        <span class="cgm-brand-lockup__text">ContentGem</span>
      </span>`;
  }

  function applyAdminBranding() {
    const candidates = [];
    const explicit = document.querySelector('.cgm-nav__brand');
    if (explicit) candidates.push(explicit);
    const nav = document.querySelector('.contentgem-app aside');
    if (nav && nav.firstElementChild) candidates.push(nav.firstElementChild);
    candidates.forEach((el) => {
      if (!el || el.dataset.cgmBrandified === '1') return;
      const text = String(el.textContent || '').trim();
      if (!/contentgem/i.test(text)) return;
      el.dataset.cgmBrandified = '1';
      el.classList.add('cgm-nav__brand');
      el.innerHTML = getBrandLockupMarkup();
    });
  }

  function removeGapSuggestionUi() {
    const pages = Array.from(document.querySelectorAll('.cgm-page, .contentgem-main, #contentgem-dashboard'));
    pages.forEach((scope) => {
      scope.querySelectorAll('*').forEach((el) => {
        const text = String(el.textContent || '').trim();
        if (/^suggestion$/i.test(text)) {
          const row = el.closest('.cgm-gap-card, .cgm-card, .cgm-list-row, .cgm-table-row, li, p, div, span');
          if (row && String(row.textContent || '').trim().toLowerCase() === 'suggestion') row.remove();
          else el.remove();
        }
      });
      scope.querySelectorAll('button, a').forEach((el) => {
        const label = String(el.textContent || '').trim();
        if (/^(suggest|suggestions?)$/i.test(label) || /suggestion/i.test(label) || /more suggestions/i.test(label) || /create more suggestions/i.test(label)) {
          el.remove();
        }
      });
      scope.querySelectorAll('[data-action="suggest"], [data-cgm-action="suggest"]').forEach((el) => el.remove());
      scope.querySelectorAll('.cgm-gap-card, .cgm-card, .cgm-list-row, .cgm-table-row, li, div, span, p, strong, th, td').forEach((el) => {
        const text = String(el.textContent || '').trim().toLowerCase();
        if (text === 'suggestion' || text === 'suggestions' || text === 'more suggestions' || text === 'create more suggestions') {
          if (el.closest('.cgm-gap-card, .cgm-card, .cgm-list-row, .cgm-table-row')) {
            el.remove();
          }
        }
      });
    });
  }

  function flagCannibalizationStructurePriority() {
    document.querySelectorAll('.cgm-cannibalization-card, .cgm-card, tr, li').forEach((el) => {
      const text = String(el.textContent || '');
      if (/main structure page \(priority\)/i.test(text) && !el.querySelector('.cgm-structure-priority-note')) {
        const note = document.createElement('div');
        note.className = 'cgm-structure-priority-note';
        note.textContent = 'Conflict with a site structure page. The main structure page has priority; the post has lower value in this conflict.';
        el.appendChild(note);
      }
    });
  }


  function translatePluginChromeToEnglish() {
    const replacements = new Map([
      ['Contacteer Ons', 'Contact us'],
      ['Supportforum', 'Support forum'],
      ['Bekijk article', 'View article'],
      ['Bekijk artikel', 'View article'],
      ['Rij toevoegen', 'Add row'],
      ['Nog een keyword analyseren', 'Analyze another keyword'],
      ['Nog geen analyses', 'No analyses yet'],
      ['Wacht', 'Waiting'],
      ['Gereed', 'Done'],
      ['Fout', 'Error'],
      ['Selecteer een cluster', 'Select a cluster'],
      ['Nog geen keyword analyses', 'No keyword analyses yet'],
    ]);
    document.querySelectorAll('a, button, span, div, p, small, strong, label').forEach((el) => {
      const text = String(el.textContent || '').trim();
      if (replacements.has(text)) el.textContent = replacements.get(text);
    });
  }

  

  function styleDraftActionButtons() {
    document.querySelectorAll('a, button').forEach((el) => {
      const text = String(el.textContent || '').trim();
      if (!/^(view article|bekijk article|bekijk artikel)$/i.test(text)) return;
      el.classList.add('cgm-btn--view-article');
      if (el.style && typeof el.style.setProperty === 'function') {
        el.style.setProperty('background', 'rgba(29,35,74,.92)', 'important');
        el.style.setProperty('color', '#F4F1FF', 'important');
        el.style.setProperty('border', '1px solid rgba(124,58,237,.24)', 'important');
        el.style.setProperty('box-shadow', 'none', 'important');
        el.style.setProperty('border-radius', '12px', 'important');
        el.style.setProperty('font-weight', '700', 'important');
        el.style.setProperty('text-decoration', 'none', 'important');
      }
    });
  }


  function markTopicalCoveragePanel() {
    const dashboardRoot = document.querySelector('#contentgem-dashboard .cgm-page .cgm-page__title') && Array.from(document.querySelectorAll('#contentgem-dashboard .cgm-page')).find((page) => /dashboard/i.test(page.querySelector('.cgm-page__title')?.textContent || ''));
    if (!dashboardRoot) return;
    const heading = Array.from(dashboardRoot.querySelectorAll('h2')).find((node) => /topical coverage/i.test(node.textContent || ''));
    if (!heading) return;
    const panel = heading.closest('div[style]') || heading.parentElement?.closest('div') || heading.closest('section, div');
    if (!panel) return;
    panel.classList.add('cgm-topical-coverage-panel');
    const table = panel.querySelector('table');
    if (table) table.classList.add('cgm-topical-coverage-table');
  }

function runContentGemUiCleanup() {
    removeGapSuggestionUi();
    translatePluginChromeToEnglish();
    flagCannibalizationStructurePriority();
    styleDraftActionButtons();
    markTopicalCoveragePanel();
  }

  document.addEventListener('DOMContentLoaded',()=>{
    schedule();
    startObserver();
    document.addEventListener('click',(event)=>{
      const trigger = event.target && event.target.closest && event.target.closest('.cgm-nav__item, a[href*="page=contentgem"], .cgm-settings-tabs .cgm-tab-btn, .cgm-competitor-tabs .cgm-tab-btn, #cgm-ob-tabs .cgm-tab-btn');
      if(trigger) {
        setTimeout(schedule, 80);
        setTimeout(runContentGemUiCleanup, 140);
      }
    }, true);
    window.addEventListener('popstate', () => { setTimeout(schedule, 60); });
    setTimeout(()=>{ try{ refreshAnalyzeNotice(); }catch(e){} }, 800);
    setTimeout(runContentGemUiCleanup, 150);
    setTimeout(runContentGemUiCleanup, 700);
    setTimeout(runContentGemUiCleanup, 1600);
    setTimeout(applyAdminBranding, 80);
    setTimeout(startObserver, 1200);
  });
})();
