
(function(){
  if (!window.contentgemData || !location.href.includes('page=contentgem')) return;

  const restBase = String(window.contentgemData.restUrl || '').replace(/\/$/, '');
  const nonce = (window.contentgemData && window.contentgemData.nonce) || '';
  const endpoint = '/differentiation/analyze';

  function pageTitle(page){
    return (page && page.querySelector('.cgm-page__title') && page.querySelector('.cgm-page__title').textContent || '').trim();
  }

  function getPageRootByTitle(pattern){
    return Array.from(document.querySelectorAll('.cgm-page')).find(page => pattern.test(pageTitle(page))) || null;
  }

  async function postJSON(path, payload){
    const res = await fetch(restBase + path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': nonce
      },
      body: JSON.stringify(payload || {})
    });
    return res.json();
  }

  function fmtRisk(risk){
    if (risk === 'high') return 'High overlap risk';
    if (risk === 'medium') return 'Moderate overlap risk';
    return 'Low overlap risk';
  }

  function inferClusterId(root){
    const select = root && root.querySelector('select');
    if (select && select.value) {
      const n = parseInt(select.value, 10);
      return Number.isFinite(n) ? n : 0;
    }
    return 0;
  }

  function findInputByLabel(root, labelText){
    const labels = Array.from(root.querySelectorAll('label, span, div'));
    const label = labels.find(el => (el.textContent || '').trim().toLowerCase() === labelText.toLowerCase());
    if (!label) return null;
    let next = label.nextElementSibling;
    if (next && /input|textarea|select/i.test(next.tagName)) return next;
    const field = (label.parentElement && label.parentElement.querySelector('input, textarea, select')) || null;
    return field;
  }

  function updateAICard(card, data){
    const kpis = card.querySelectorAll('.cgm-diff-kpi strong');
    if (kpis[0]) kpis[0].textContent = `${Number(data.overlap_score || 0).toFixed(1)}%`;
    if (kpis[1]) kpis[1].textContent = fmtRisk(data.risk_level);
    if (kpis[2]) kpis[2].textContent = (data.recommendations && data.recommendations.intent) || '—';
    const angle = card.querySelector('.cgm-diff-angle');
    const structure = card.querySelector('.cgm-diff-structure');
    if (angle) angle.textContent = (data.recommendations && data.recommendations.angle) || '—';
    if (structure) structure.textContent = (data.recommendations && data.recommendations.structure) || '—';
    const items = (data.similar_posts || []).map(item => `<li><strong>${item.title}</strong><small>${Math.round((item.similarity_score || 0) * 100)}% similarity • ${item.status}</small></li>`).join('');
    const list = card.querySelector('.cgm-diff-list');
    if (list) list.innerHTML = items || '<li>No meaningful overlap found.</li>';
    const pill = card.querySelector('.cgm-diff-pill');
    const copy = card.querySelector('.cgm-diff-copy');
    if (pill) pill.textContent = data.risk_level === 'high' ? 'Attention' : 'Ready';
    if (copy) copy.textContent = (data.recommendations && data.recommendations.writer_brief) || 'Differentiation brief ready.';
  }

  function mountAIAssistant(root){
    if (!root) return;
    let card = root.querySelector('.cgm-diff-card');
    const titleInput = findInputByLabel(root, 'CONTENT TITLE') || root.querySelector('input[placeholder*="semantic"], input[placeholder*="guide"]');
    const keywordInput = findInputByLabel(root, 'PRIMARY KEYWORD') || Array.from(root.querySelectorAll('input')).find(el => (el.value || '').trim().length > 0);
    const briefInput = root.querySelector('textarea');
    if (!titleInput && !keywordInput && !briefInput) return;

    if (!card) {
      card = document.createElement('section');
      card.className = 'cgm-diff-card';
      card.innerHTML = `
        <div class="cgm-diff-card__head">
          <div>
            <h3>Semantic differentiation</h3>
            <p>Check overlap before generating the draft so the article keeps a unique angle.</p>
          </div>
          <button type="button" class="button button-primary cgm-diff-run">Run differentiation check</button>
        </div>
        <div class="cgm-diff-status">
          <span class="cgm-diff-pill">Ready</span>
          <span class="cgm-diff-copy">Use the current title, keyword and brief to compare against existing content.</span>
        </div>
        <div class="cgm-diff-body">
          <div class="cgm-diff-summary">
            <div class="cgm-diff-kpi"><span>Overlap score</span><strong>—</strong></div>
            <div class="cgm-diff-kpi"><span>Risk level</span><strong>—</strong></div>
            <div class="cgm-diff-kpi"><span>Recommended intent</span><strong>—</strong></div>
          </div>
          <div class="cgm-diff-grid">
            <div class="cgm-diff-panel">
              <h4>Recommended angle</h4>
              <p class="cgm-diff-angle">Run the check to get a recommended angle.</p>
              <h4>Recommended structure</h4>
              <p class="cgm-diff-structure">Run the check to get a recommended structure.</p>
            </div>
            <div class="cgm-diff-panel">
              <h4>Closest existing posts</h4>
              <ul class="cgm-diff-list"><li>No analysis yet.</li></ul>
            </div>
          </div>
        </div>`;
      const target = briefInput ? briefInput.closest('div, section') : (titleInput ? titleInput.closest('div, section') : root.firstElementChild);
      (target || root).insertAdjacentElement('beforebegin', card);
    }

    const button = card.querySelector('.cgm-diff-run');
    if (!button || button.dataset.cgmBound === '1') return;
    button.dataset.cgmBound = '1';

    const run = async () => {
      const payload = {
        title: titleInput ? (titleInput.value || '') : '',
        keyword: keywordInput ? (keywordInput.value || '') : '',
        brief: briefInput ? (briefInput.value || '') : '',
        cluster_id: inferClusterId(root)
      };
      if (!payload.title && !payload.keyword && !payload.brief) return;

      const pill = card.querySelector('.cgm-diff-pill');
      const copy = card.querySelector('.cgm-diff-copy');
      if (pill) pill.textContent = 'Checking';
      if (copy) copy.textContent = 'Comparing this draft against existing content.';

      try{
        const res = await postJSON(endpoint, payload);
        if (!res || !res.success || !res.data) throw new Error('Request failed');
        updateAICard(card, res.data);
      }catch(e){
        if (pill) pill.textContent = 'Error';
        if (copy) copy.textContent = 'Differentiation check could not be completed.';
      }
    };

    button.addEventListener('click', run);
  }

  function collectGapCards(root){
    if (!root) return [];
    const selectors = [
      '.cgm-gap-card',
      '[data-cgm-gap-card]',
      '.cgm-content-gap-card',
      '.cgm-card[data-gap-id]',
      '[data-gap-id]'
    ];
    const cards = Array.from(root.querySelectorAll(selectors.join(',')));
    const filtered = cards.filter(card => {
      const txt = (card.textContent || '').toLowerCase();
      return txt.includes('draft generation requires') || txt.includes('cluster:') || txt.includes('upgrade');
    });
    const uniq = [];
    const seen = new Set();
    filtered.forEach(card => {
      const titleEl = card.querySelector('h3, h4, strong, .cgm-card__title');
      const key = ((titleEl && titleEl.textContent) || card.textContent || '').trim().toLowerCase().slice(0, 180);
      if (!key || seen.has(key)) return;
      seen.add(key);
      uniq.push(card);
    });
    return uniq;
  }

  async function mountContentGapHints(root){
    return; // v4.7 — Differentiation guard removed from Content Gaps (no user value).
    if (!root) return;
    if (!root.querySelector('.cgm-diff-gap-card')) {
      const panel = document.createElement('section');
      panel.className = 'cgm-diff-gap-card';
      panel.innerHTML = `
        <div class="cgm-diff-card__head">
          <div>
            <h3>Differentiation guard</h3>
            <p>Content gaps now get a uniqueness check before drafting, so high-overlap ideas can be reframed first.</p>
          </div>
        </div>`;
      const target = root.querySelector('.cgm-page__header') || root.firstElementChild || root;
      target.insertAdjacentElement('afterend', panel);
    }

    const cards = collectGapCards(root).slice(0, 14);
    for (const card of cards){
      if (card.dataset.cgmDiffProcessed === '1') continue;

      const titleEl = card.querySelector('h3, h4, strong, .cgm-card__title');
      const title = (titleEl && titleEl.textContent || '').trim();
      if (!title || title.length < 12) continue;

      card.dataset.cgmDiffProcessed = '1';

      try{
        const res = await postJSON(endpoint, { title, keyword: '', brief: '' });
        if (!res || !res.success || !res.data) continue;

        const existing = card.querySelector('.cgm-diff-inline-wrap, .cgm-diff-inline');
        if (existing) continue;

        const wrap = document.createElement('div');
        wrap.className = 'cgm-diff-inline-wrap';
        const badge = document.createElement('div');
        badge.className = 'cgm-diff-inline';
        badge.textContent = res.data.risk_level === 'high' ? 'High overlap risk' : (res.data.risk_level === 'medium' ? 'Differentiate angle' : 'Unique angle likely');
        wrap.appendChild(badge);
        const anchor = titleEl || card.firstElementChild || card;
        anchor.insertAdjacentElement('afterend', wrap);
      }catch(e){
        card.dataset.cgmDiffProcessed = '0';
      }
    }
  }

  function boot(){
    mountAIAssistant(getPageRootByTitle(/AI Assistant/i));
    mountContentGapHints(getPageRootByTitle(/Content Gaps/i));
  }

  document.addEventListener('DOMContentLoaded', boot);
  setTimeout(boot, 1200);
  (function(){var _obs=new MutationObserver(()=>boot());var _attach=function(){var d=document.getElementById("contentgem-dashboard");if(d){_obs.observe(d,{childList:true,subtree:true});}else{setTimeout(_attach,600);}};_attach();})();
})();
