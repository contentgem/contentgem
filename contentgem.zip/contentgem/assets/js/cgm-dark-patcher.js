/**
 * cgm-dark-patcher v4.0
 * Patches every remaining light/blue inline style from the React bundle.
 * Based on exhaustive color catalog of main-Pl6dbQI7.js.
 */
(function () {
  if (!location.href.includes('page=contentgem')) return;

  // Brand palette - Competitor Analysis reference
  const CARD  = 'linear-gradient(180deg,rgba(9,12,61,.94),rgba(10,14,74,.92))';
  const BTN   = 'linear-gradient(135deg,#7C3AED,#A855F7)';
  const INPUT = 'rgba(10,14,52,0.90)';
  const PAGE  = '#090b1e';
  const TXT   = '#F8FAFF';
  const MUTED = '#B9C4FF';
  const LINK  = '#C4B5FD';
  const OK    = '#86efac';
  const ERR   = '#fca5a5';
  const WARN  = '#fde68a';
  const BORDER= 'rgba(108,76,255,0.35)';
  const BSUB  = 'rgba(108,76,255,0.20)';
  const PURPLE_BADGE = 'rgba(108,76,255,0.18)';
  const SUCCESS_BG   = 'rgba(20,83,45,0.30)';
  const DANGER_BG    = 'rgba(127,29,29,0.30)';
  const WARN_BG      = 'rgba(120,80,0,0.30)';

  // Exact backgrounds from bundle catalog
  const BG = {
    // Light / white surfaces
    '#fff': CARD,
    '#ffffff': CARD,
    'rgb(255, 255, 255)': CARD,
    '#f8fafc': CARD,
    '#f9fafb': CARD,
    '#f9fbff': CARD,
    '#f8fcff': CARD,
    '#f0f4f8': CARD,
    '#f0f0f0': CARD,
    '#f2f2f6': CARD,
    '#e8e8ee': CARD,
    '#ebf5fb': PURPLE_BADGE,
    '#eff8ff': PURPLE_BADGE,
    '#e2e8f0': CARD,
    '#e5e7eb': CARD,
    '#bee3f8': CARD,
    'rgb(248, 250, 252)': CARD,
    'rgb(249, 250, 251)': CARD,
    'rgb(249, 251, 255)': CARD,
    'rgb(248, 252, 255)': CARD,
    'rgb(240, 244, 248)': CARD,
    'rgb(240, 240, 240)': CARD,
    'rgb(235, 245, 251)': PURPLE_BADGE,
    'rgb(239, 248, 255)': PURPLE_BADGE,
    'rgb(226, 232, 240)': CARD,
    'rgb(229, 231, 235)': CARD,
    'rgb(190, 227, 248)': CARD,
    'rgba(12,15,48,.92)': CARD,
    'rgba(9,12,61,.94)': CARD,
    'rgba(108,76,255,.14)': PURPLE_BADGE,
    'rgba(108,76,255,.18)': PURPLE_BADGE,
    'rgba(108,76,255,.20)': CARD,
    'rgba(6,182,212,.18)': PURPLE_BADGE,
    'rgba(6,182,212,.14)': PURPLE_BADGE,
    'rgba(59,130,246,.14)': PURPLE_BADGE,
    'rgba(59,130,246,.18)': PURPLE_BADGE,
    'rgba(59,130,246,.22)': CARD,
    'rgba(14,165,233,.18)': PURPLE_BADGE,
    'rgba(56,189,248,.18)': PURPLE_BADGE,
    'rgba(8,12,54,.62)': CARD,
    // Semantic surfaces
    '#d5f0e0': SUCCESS_BG,
    '#f0fdf4': SUCCESS_BG,
    '#ecfdf5': SUCCESS_BG,
    'rgb(213, 240, 224)': SUCCESS_BG,
    'rgb(240, 253, 244)': SUCCESS_BG,
    '#fee2e2': DANGER_BG,
    '#fef2f2': DANGER_BG,
    '#fce8e8': DANGER_BG,
    'rgb(254, 226, 226)': DANGER_BG,
    'rgb(254, 242, 242)': DANGER_BG,
    '#fff3e0': WARN_BG,
    '#fffbeb': WARN_BG,
    '#fef3c7': WARN_BG,
    '#fef9c3': WARN_BG,
    '#f3e5f5': 'rgba(88,28,135,0.25)',
    // Buttons / fills
    'linear-gradient(135deg, #8b5cf6, #6d28d9)': BTN,
    'linear-gradient(135deg,#8b5cf6,#6d28d9)': BTN,
    'linear-gradient(135deg, #8B5CF6, #6D28D9)': BTN,
    'linear-gradient(135deg,#8B5CF6,#6D28D9)': BTN,
    '#8b5cf6': 'linear-gradient(90deg,#7C3AED,#A855F7)',
    '#8B5CF6': 'linear-gradient(90deg,#7C3AED,#A855F7)',
    '#3b82f6': 'linear-gradient(90deg,#7C3AED,#A855F7)',
    '#3B82F6': 'linear-gradient(90deg,#7C3AED,#A855F7)',
    '#60a5fa': 'linear-gradient(90deg,#7C3AED,#A855F7)',
    '#60A5FA': 'linear-gradient(90deg,#7C3AED,#A855F7)',
  };

  // Text colors from catalog
  const COL = {
    '#1e3a5f': TXT,
    '#1E3A5F': TXT,
    '#f8faff': TXT,
    '#F8FAFF': TXT,
    '#ede9fe': TXT,
    '#EDE9FE': TXT,
    '#6b6b8a': MUTED,
    '#6B6B8A': MUTED,
    '#6b6b6b': MUTED,
    '#6B6B6B': MUTED,
    '#4a4a4a': MUTED,
    '#4A4A4A': MUTED,
    '#3a3a3a': MUTED,
    '#3A3A3A': MUTED,
    '#3a3a5c': MUTED,
    '#3A3A5C': MUTED,
    '#374151': MUTED,
    '#475569': MUTED,
    '#334155': MUTED,
    '#6b7280': MUTED,
    '#6B7280': MUTED,
    '#64748b': MUTED,
    '#64748B': MUTED,
    '#b9c4ff': MUTED,
    '#B9C4FF': MUTED,
    '#c4b5fd': LINK,
    '#C4B5FD': LINK,
    '#8b5cf6': LINK,
    '#8B5CF6': LINK,
    '#67e8f9': LINK,
    '#67E8F9': LINK,
    '#93c5fd': LINK,
    '#93C5FD': LINK,
    '#60a5fa': LINK,
    '#60A5FA': LINK,
    '#3b82f6': LINK,
    '#3B82F6': LINK,
    '#9fb0f3': MUTED,
    '#9FB0F3': MUTED,
    '#eff4ff': TXT,
    '#EFF4FF': TXT,
    '#1a7a4a': OK,
    '#1A7A4A': OK,
    '#c0392b': ERR,
    '#C0392B': ERR,
    '#c62828': ERR,
    '#991b1b': ERR,
    '#991B1B': ERR,
    '#dc2626': ERR,
    '#DC2626': ERR,
    '#92400e': WARN,
    '#92400E': WARN,
    'rgb(30, 58, 95)': TXT,
    'rgb(107, 107, 138)': MUTED,
    'rgb(107, 107, 107)': MUTED,
    'rgb(46, 134, 171)': LINK,
    'rgb(103, 232, 249)': LINK,
    'rgb(147, 197, 253)': LINK,
    'rgb(96, 165, 250)': LINK,
    'rgb(59, 130, 246)': LINK,
  };

  // Border colors
  const BCOL = {
    '#e2e8f0': BORDER,
    '#E2E8F0': BORDER,
    '#cbd5e0': BSUB,
    '#CBD5E0': BSUB,
    '#d7e3f0': BSUB,
    '#D7E3F0': BSUB,
    '#d6d9e0': BSUB,
    '#D6D9E0': BSUB,
    '#e5e7eb': BSUB,
    '#E5E7EB': BSUB,
    '#bee3f8': BSUB,
    '#BEE3F8': BSUB,
    '#8b5cf6': BORDER,
    '#8B5CF6': BORDER,
    'rgba(108,76,255,.18)': BSUB,
    'rgba(108,76,255,.20)': BORDER,
    'rgba(108,76,255,.35)': BSUB,
    '#fecaca': 'rgba(248,113,113,0.35)',
    '#fca5a5': 'rgba(248,113,113,0.30)',
    '#f0f4f8': BSUB,
    'rgb(226, 232, 240)': BORDER,
    'rgb(203, 213, 224)': BSUB,
    'rgba(59,130,246,.18)': BSUB,
    'rgba(59,130,246,.22)': BSUB,
    'rgba(6,182,212,.18)': BSUB,
    'rgba(6,182,212,.22)': BSUB,
  };



  function normalize(v) { return String(v || '').trim(); }

  function mapColor(value, table) {
    const raw = normalize(value);
    if (!raw) return '';
    if (table[raw] !== undefined) return table[raw];
    const lower = raw.toLowerCase();
    if (table[lower] !== undefined) return table[lower];
    for (const [key, out] of Object.entries(table)) {
      if (lower.includes(String(key).toLowerCase())) return out;
    }
    return '';
  }

  function patchEl(el) {
    if (!el || !el.style) return;
    const s = el.style;

    const bg = normalize(s.background || s.backgroundColor || s.backgroundImage);
    const fg = normalize(s.color);
    const bc = normalize(s.borderColor);
    const border = normalize(s.border);
    const fill = normalize(s.fill);
    const stroke = normalize(s.stroke);

    const newBg = mapColor(bg, BG);
    if (newBg) s.setProperty('background', newBg, 'important');

    const newFg = mapColor(fg, COL);
    if (newFg) s.setProperty('color', newFg, 'important');

    const newBc = mapColor(bc, BCOL) || mapColor(border, BCOL);
    if (newBc) {
      s.setProperty('border-color', newBc, 'important');
      if (border) s.setProperty('border', border.replace(/(#(?:[0-9a-fA-F]{3,8})|rgba?\([^)]*\))/g, newBc), 'important');
    }

    const newFill = mapColor(fill, COL) || mapColor(fill, BG);
    if (newFill) s.setProperty('fill', newFill, 'important');

    const newStroke = mapColor(stroke, COL) || mapColor(stroke, BCOL);
    if (newStroke) s.setProperty('stroke', newStroke, 'important');

    if ((bg || '').toLowerCase().includes('linear-gradient') && /(3b82f6|60a5fa|06b6d4|0ea5e9|67e8f9|93c5fd)/i.test(bg)) {
      s.setProperty('background', BTN, 'important');
    }
  }

  const SKIP_INPUT = new Set(['checkbox','radio','range','submit','button','reset','file','image','color']);

  function forceInput(el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if ((tag === 'input' && !SKIP_INPUT.has(type)) || tag === 'textarea' || tag === 'select') {
      el.style.setProperty('background', INPUT, 'important');
      el.style.setProperty('color', TXT, 'important');
      el.style.setProperty('border', '1px solid rgba(108,76,255,0.35)', 'important');
    }
  }

  function forceButton(el) {
    if (el.tagName.toLowerCase() !== 'button') return;
    const s = el.style;
    const bg = (s.background || s.backgroundColor || '').toLowerCase();
    const col = (s.color || '').toLowerCase();
    if (bg.includes('2e86ab') || bg.includes('1a6a8a') || bg.includes('8b5cf6') || bg.includes('a855f7')) {
      s.setProperty('background', BTN, 'important');
      s.setProperty('border', 'none', 'important');
      s.setProperty('color', '#fff', 'important');
      return;
    }
    // Danger buttons - keep red
    if (col.includes('c0392b') || col.includes('dc2626') || col.includes('991b1b') || bg.includes('fef2f2') || bg.includes('fee2e2')) {
      s.setProperty('background', DANGER_BG, 'important');
      s.setProperty('border', '1px solid rgba(248,113,113,.35)', 'important');
      s.setProperty('color', ERR, 'important');
      return;
    }
    // Light/white buttons → subtle purple
    const isLight = bg === '#fff' || bg === '#ffffff' || bg === 'rgba(12,15,48,.92)' ||
                    bg.includes('rgb(255, 255, 255)') ||
                    bg.includes('rgb(248, 250') || bg.includes('rgb(249,') ||
                    bg.includes('rgb(240,') || bg.includes('f8fafc') || bg.includes('f9fafb');
    if (isLight) {
      s.setProperty('background', 'rgba(108,76,255,0.14)', 'important');
      s.setProperty('border', '1px solid rgba(108,76,255,0.40)', 'important');
      s.setProperty('color', '#C4B5FD', 'important');
    }
  }

  function patchAll() {
    const root = document.getElementById('contentgem-dashboard');
    if (!root) return;
    root.querySelectorAll('*').forEach(el => { patchEl(el); forceInput(el); forceButton(el); });
  }

  /* ── Content Gaps keyword controls ── */
  const rb = String((window.contentgemData || {}).restUrl || '').replace(/\/$/, '');
  const nc = (window.contentgemData || {}).nonce || '';
  const STACK_ID = 'cgm-gap-toggle-stack';
  const STRICT_ID = 'cgm-strict-keyword-toggle';
  const KEYWORD_ONLY_ID = 'cgm-keyword-only-toggle';
  const KEYWORD_ONLY_STORAGE = 'cgm-gap-keyword-only';
  let mounting = false, retryT = null;

  function gj(p) { return fetch(rb + p, { headers: { 'X-WP-Nonce': nc } }).then(r => r.json()); }
  function pj(p, b) { return fetch(rb + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nc }, body: JSON.stringify(b || {}) }).then(r => r.json()); }

  function gapsRoot() {
    for (const pg of document.querySelectorAll('.cgm-page')) {
      const t = pg.querySelector('.cgm-page__title, .cgm-page__header h1, h1, h2');
      if (t && /^Content Gaps/i.test((t.textContent || '').trim())) return pg;
    }
    for (const h of document.querySelectorAll('h1, h2, [class*="title"], [class*="header"]')) {
      if (/^Content Gaps/i.test((h.textContent || '').trim())) {
        return h.closest('.cgm-page, [data-cgm-page], .contentgem-main, main, [class*="page"], [class*="content"]') || h.parentElement;
      }
    }
    const main = document.querySelector('.contentgem-main, main');
    if (main && /Content Gaps/i.test(main.textContent || '')) return main;
    return null;
  }

  function findGapControlsAnchor(root) {
    if (!root) return null;
    const explicit = root.querySelector('.cgm-gap-toolbar, .cgm-gaps-toolbar, .cgm-page__filters, .cgm-filters, [data-cgm-gaps-toolbar]');
    if (explicit) return explicit;

    const candidates = Array.from(root.querySelectorAll('div, section, header'));
    return candidates.find(el => {
      const text = String(el.textContent || '').trim();
      const selects = el.querySelectorAll('select').length;
      return selects >= 1 && /filter/i.test(text);
    }) || null;
  }

  function normalizeText(v) {
    return String(v || '').toLowerCase().replace(/<[^>]*>/g, ' ').replace(/[^\p{L}\p{N}\s]+/gu, ' ').replace(/\s+/g, ' ').trim();
  }

  function getKeywordMap() {
    const map = (((window.contentgemData || {}).bootstrapSettings || {}).cluster_keywords) || {};
    return map && typeof map === 'object' ? map : {};
  }

  function getAllSavedKeywords() {
    const out = [];
    const seen = new Set();
    const map = getKeywordMap();
    Object.entries(map).forEach(([cluster, list]) => {
      const values = Array.isArray(list) ? list : [];
      if (!values.length) values.push(cluster);
      values.forEach(keyword => {
        const value = normalizeText(keyword);
        if (value && !seen.has(value)) {
          seen.add(value);
          out.push(value);
        }
      });
    });
    return out;
  }

  function itemMatchesKeywordText(text) {
    const hay = normalizeText(text);
    if (!hay) return false;
    const tokens = new Set(hay.split(' ').filter(Boolean));
    const keywords = getAllSavedKeywords();
    if (!keywords.length) return true;
    return keywords.some(keyword => {
      if (hay.includes(keyword)) return true;
      const parts = keyword.split(' ').filter(Boolean);
      if (!parts.length) return false;
      const overlap = parts.filter(part => tokens.has(part)).length;
      const required = parts.length <= 1 ? 1 : Math.min(2, parts.length);
      return overlap >= required;
    });
  }

  function getKeywordOnlySaved() {
    try { return localStorage.getItem(KEYWORD_ONLY_STORAGE) === '1'; } catch (e) { return false; }
  }

  function setKeywordOnlySaved(value) {
    try { localStorage.setItem(KEYWORD_ONLY_STORAGE, value ? '1' : '0'); } catch (e) {}
  }

  function shouldApplyKeywordOnly() {
    return getKeywordOnlySaved() && !!gapsRoot();
  }

  function isGapsCollectionUrl(raw) {
    try {
      const url = new URL(String(raw || ''), location.origin);
      return /\/gaps$/.test(url.pathname);
    } catch (e) {
      return false;
    }
  }

  (function interceptGapRequests() {
    if (window.__cgmKeywordOnlyIntercepted) return;
    window.__cgmKeywordOnlyIntercepted = true;

    const nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') {
      window.fetch = function(input, init) {
        try {
          const method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
          const rawUrl = typeof input === 'string' ? input : (input && input.url) || '';
          if (method === 'GET' && shouldApplyKeywordOnly() && isGapsCollectionUrl(rawUrl)) {
            const url = new URL(rawUrl, location.origin);
            url.searchParams.set('keyword_only', 'true');
            if (typeof input === 'string') {
              input = url.toString();
            } else if (input instanceof Request) {
              input = new Request(url.toString(), input);
            }
          }
        } catch (e) {}
        return nativeFetch.call(this, input, init);
      };
    }

    const nativeOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      let nextUrl = url;
      try {
        if (String(method || 'GET').toUpperCase() === 'GET' && shouldApplyKeywordOnly() && isGapsCollectionUrl(url)) {
          const parsed = new URL(String(url || ''), location.origin);
          parsed.searchParams.set('keyword_only', 'true');
          nextUrl = parsed.toString();
        }
      } catch (e) {}
      return nativeOpen.call(this, method, nextUrl, ...rest);
    };
  })();

  function ensureToggleStack(root) {
    let stack = document.getElementById(STACK_ID);
    if (stack && root.contains(stack)) return stack;
    if (stack && stack.parentNode) stack.parentNode.removeChild(stack);
    stack = document.createElement('div');
    stack.id = STACK_ID;
    stack.className = 'cgm-gap-toggle-stack cgm-gap-toggle-stack--inline';

    const anchor = findGapControlsAnchor(root);
    const hdr = root.querySelector('.cgm-page__header, .cgm-page__title, h1, h2');
    if (anchor) {
      anchor.insertAdjacentElement('afterend', stack);
    } else if (hdr && hdr.parentNode) {
      hdr.insertAdjacentElement('afterend', stack);
    } else if (root.firstChild) {
      root.insertBefore(stack, root.firstChild.nextSibling || root.firstChild);
    } else {
      root.appendChild(stack);
    }
    return stack;
  }

  function buildToggle(id, title, description) {
    const w = document.createElement('label');
    w.id = id;
    w.className = 'cgm-strict-keyword-toggle';
    w.innerHTML = `
      <input type="checkbox" />
      <span class="cgm-strict-keyword-toggle__ui"><span></span></span>
      <span class="cgm-strict-keyword-toggle__copy">
        <strong>${title}</strong>
        <small>${description}</small>
      </span>`;
    return w;
  }

  function findPageButton(key, pattern) {
    const candidates = Array.from(document.querySelectorAll('[data-page], button, a'));
    return candidates.find(el => {
      const dataPage = String(el.getAttribute('data-page') || '').toLowerCase();
      const text = String(el.textContent || '').trim();
      return dataPage === key || pattern.test(text);
    }) || null;
  }

  function collectGapCards(root) {
    const selectors = [
      '.cgm-gap-card',
      '[data-cgm-gap-card]',
      '.cgm-content-gap-card',
      '.cgm-card[data-gap-id]',
      '[data-gap-id]'
    ];
    const items = new Set();
    selectors.forEach(sel => root.querySelectorAll(sel).forEach(el => items.add(el)));
    return Array.from(items);
  }

  function ensureKeywordEmptyState(root, visibleCount, enabled) {
    let box = root.querySelector('.cgm-keyword-only-empty-state');
    if (!enabled || visibleCount > 0) {
      if (box) box.remove();
      return;
    }
    if (!box) {
      box = document.createElement('div');
      box.className = 'cgm-keyword-only-empty-state';
      box.style.cssText = 'margin:12px 0 0;padding:14px 16px;border-radius:14px;background:linear-gradient(160deg,rgba(30,27,75,.92),rgba(16,18,49,.92));border:1px solid rgba(124,58,237,.24);color:#d7ccff;font-size:13px;';
      box.textContent = 'No saved-keyword matches are visible on this page. Turn the toggle off to include the other criteria again.';
      root.appendChild(box);
    }
  }

  function applyVisibleGapFilter() {
    const root = gapsRoot();
    if (!root) return;
    const enabled = getKeywordOnlySaved();
    const cards = collectGapCards(root);
    let visible = 0;
    cards.forEach(card => {
      if (!enabled) {
        card.style.removeProperty('display');
        visible += 1;
        return;
      }
      const match = itemMatchesKeywordText(card.textContent || '');
      card.style.setProperty('display', match ? '' : 'none', 'important');
      if (match) visible += 1;
    });
    ensureKeywordEmptyState(root, visible, enabled);
  }

  function refreshGapsView() {
    applyVisibleGapFilter();
    const dashBtn = findPageButton('dashboard', /^Dashboard$/i);
    const gapsBtn = findPageButton('gaps', /^Content Gaps$/i);
    if (dashBtn && gapsBtn) {
      try {
        dashBtn.click();
        setTimeout(() => { gapsBtn.click(); setTimeout(applyVisibleGapFilter, 500); }, 90);
        return;
      } catch (e) {}
    }
    setTimeout(applyVisibleGapFilter, 250);
    setTimeout(applyVisibleGapFilter, 900);
  }

  async function mountToggle() {
    if (mounting) return;
    const root = gapsRoot();
    if (!root) {
      if (!retryT) retryT = setTimeout(() => { retryT = null; mountToggle(); }, 500);
      return;
    }
    mounting = true;
    const stack = ensureToggleStack(root);

    let keywordToggle = document.getElementById(KEYWORD_ONLY_ID);
    if (!keywordToggle) {
      keywordToggle = buildToggle(
        KEYWORD_ONLY_ID,
        'Keyword-only gaps',
        'Only show content gaps that match your saved cluster keywords. Turn it off to include the other criteria as well.'
      );
      stack.appendChild(keywordToggle);
      keywordToggle.setAttribute('data-cgm-mounted', 'keyword-only');
      const inp = keywordToggle.querySelector('input');
      inp.checked = getKeywordOnlySaved();
      keywordToggle.classList.toggle('is-on', inp.checked);
      inp.addEventListener('change', async () => {
        const en = !!inp.checked;
        setKeywordOnlySaved(en);
        keywordToggle.classList.toggle('is-on', en);
        keywordToggle.classList.add('is-saving');
        try { await pj('/gaps/keyword-only', { enabled: en }); } catch (e) {}
        keywordToggle.classList.remove('is-saving');
        refreshGapsView();
      });
      try {
        const r = await gj('/gaps/keyword-only');
        const enabled = !!(r && r.success && r.enabled);
        setKeywordOnlySaved(enabled);
        inp.checked = enabled;
        keywordToggle.classList.toggle('is-on', enabled);
      } catch (e) {}
    }

    let strictToggle = document.getElementById(STRICT_ID);
    if (!strictToggle) {
      strictToggle = buildToggle(
        STRICT_ID,
        'Strict keyword match',
        'Only generate titles containing a cluster keyword. Re-run analysis to apply this generation setting.'
      );
      stack.appendChild(strictToggle);
      strictToggle.setAttribute('data-cgm-mounted', 'strict-match');
      const inp = strictToggle.querySelector('input');
      try {
        const r = await gj('/gaps/strict-match');
        inp.checked = !!(r && r.success && r.enabled);
        strictToggle.classList.toggle('is-on', inp.checked);
      } catch (e) {}
      inp.addEventListener('change', async () => {
        const en = !!inp.checked;
        strictToggle.classList.toggle('is-on', en);
        strictToggle.classList.add('is-saving');
        try { await pj('/gaps/strict-match', { enabled: en }); } catch (e) {}
        strictToggle.classList.remove('is-saving');
      });
    }

    mounting = false;
    applyVisibleGapFilter();
  }

  function dismount() {
    const stack = document.getElementById(STACK_ID);
    if (stack && !gapsRoot()) stack.remove();
  }

  function run() {
    patchAll();
    dismount();
    mountToggle();
    applyVisibleGapFilter();
  }

  document.addEventListener('DOMContentLoaded', run);
  setTimeout(run, 100);
  setTimeout(run, 500);
  setTimeout(run, 1500);
  setTimeout(run, 4000);
  setTimeout(run, 7000);
  setTimeout(run, 10000);

  let mot = null;
  new MutationObserver(() => {
    if (mot) return;
    mot = setTimeout(() => { mot = null; run(); }, 200);
  }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class'] });
})();
