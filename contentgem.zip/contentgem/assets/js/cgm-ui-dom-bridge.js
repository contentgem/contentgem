(function(){
  if (window.__CGMUIDomBridge) return;
  window.__CGMUIDomBridge = true;

  function qs(s,r){ return (r||document).querySelector(s); }
  function qsa(s,r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function txt(el){ return String((el && el.textContent) || '').replace(/\s+/g,' ').trim(); }
  function visible(el){ return !!(el && el.nodeType===1 && txt(el).length); }
  function root(){ return qs('#contentgem-dashboard'); }
  function main(rootEl){ return qs('.contentgem-main', rootEl) || rootEl; }
  function activePage(rootEl){
    var btn = qs('[data-page].is-active,[data-page][aria-current="page"]', rootEl);
    if (btn) return String(btn.getAttribute('data-page') || '').toLowerCase();
    var title = qs('.cgm-page__title,h1,h2', main(rootEl));
    var t = txt(title).toLowerCase();
    if (/content gaps/.test(t)) return 'content-gaps';
    if (/optimizer/.test(t)) return 'optimizer';
    if (/assistant/.test(t)) return 'assistant';
    if (/settings/.test(t)) return 'settings';
    if (/drafts/.test(t)) return 'drafts';
    if (/competitor/.test(t)) return 'competitor';
    return 'dashboard';
  }
  function clearPageClasses(rootEl){
    ['dashboard','content-gaps','optimizer','assistant','competitor','drafts','settings'].forEach(function(page){
      rootEl.classList.remove('cgm-page--' + page);
    });
  }
  function pageNode(rootEl,page){
    var m = main(rootEl);
    var pages = qsa(':scope > .cgm-page, :scope > div', m).filter(visible);
    if (!pages.length) return m.firstElementChild || m;
    if (page === 'content-gaps') {
      return pages.find(function(el){ return el.classList.contains('cgm-page') && /content gaps/i.test(txt(qs('.cgm-page__title,h1,h2', el))); }) || pages.find(function(el){ return !!qs('.cgm-gap-list,.cgm-gap-card,select', el); }) || pages[0];
    }
    if (page === 'dashboard') {
      return pages.find(function(el){ return /dashboard/i.test(txt(qs('.cgm-page__title,h1,h2', el))); }) || pages[0];
    }
    return pages[0];
  }
  function markCard(el, extra){
    if (!el || el.classList.contains('cgm-page__header')) return;
    el.classList.add('cgm-card');
    el.setAttribute('data-cgm-card','1');
    (extra||[]).forEach(function(c){ el.classList.add(c); });
  }
  function classifyDashboard(shell){
    shell.classList.add('cgm-page','cgm-page--dashboard');
    var children = qsa(':scope > *', shell).filter(visible);
    children.forEach(function(child){
      if (child.classList.contains('cgm-page__header')) return;
      var t = txt(child).toLowerCase();
      var hasTable = !!qs('table', child);
      var heading = txt(qs('h2,h3,strong', child)).toLowerCase();
      if (/analyse complete|analyse failed|api key/i.test(t)) {
        child.classList.add('cgm-banner');
        if (/failed/i.test(t)) child.classList.add('cgm-banner--danger');
        else if (/complete/i.test(t)) child.classList.add('cgm-banner--success');
        else child.classList.add('cgm-banner--warning');
        return;
      }
      if (child.classList.contains('cgm-dashboard-progress') || /detecting content gaps|analysing|analysis complete|analyse running|analyse site/i.test(t)) {
        markCard(child, ['cgm-dashboard-progress','cgm-section','cgm-section--progress','cgm-progress-surface']);
        return;
      }
      if (hasTable || /topical coverage|topical authority overview|gsc intelligence|indexation monitor/.test(t)) {
        markCard(child, ['cgm-card--table','cgm-dashboard-card']);
      } else {
        markCard(child, ['cgm-dashboard-card']);
      }
      if (/ai credits this month|open content gap|topic clusters|internal link network/.test(t) && !hasTable) {
        child.classList.add('cgm-card--metric');
      }
      if (/topical coverage/.test(t)) child.classList.add('cgm-dashboard-card--coverage');
      if (/topical authority overview/.test(t)) child.classList.add('cgm-dashboard-card--authority');
      if (/gsc intelligence/.test(t)) child.classList.add('cgm-dashboard-card--gsc');
      if (/indexation monitor/.test(t)) child.classList.add('cgm-dashboard-card--indexation');
      if (/ai credits this month/.test(t)) child.classList.add('cgm-dashboard-card--credits');
      if (heading && qs('h2,h3', child)) {
        var title = qs('h2,h3', child);
        title.classList.add('cgm-card__title');
      }
    });
  }
  function classifyGaps(shell){
    shell.classList.add('cgm-page','cgm-page--content-gaps');
    var filterbar = qsa(':scope > div', shell).find(function(el){ return qsa('select', el).length >= 2 && /all clusters/i.test(txt(el)) && /all intents/i.test(txt(el)); });
    if (filterbar) filterbar.classList.add('cgm-filterbar','cgm-filterbar--sticky');

    var summary = qsa(':scope > div', shell).find(function(el){ return !!qs('input[type="checkbox"]', el) && /generate/i.test(txt(el)); });
    if (summary) summary.classList.add('cgm-results-summary','cgm-results-summary--bulk','cgm-card');

    var list = qs(':scope > .cgm-gap-list', shell);
    if (list) list.classList.add('cgm-gap-list','cgm-gap-grid');

    qsa('.cgm-gap-card', shell).forEach(function(card){
      markCard(card, ['cgm-card--gap']);
      var header = qs('.cgm-gap-card__header', card);
      if (header) header.classList.add('cgm-card__header');
      var title = qs('h3', card); if (title) title.classList.add('cgm-card__title');
      qsa('button,a', card).forEach(function(action){
        var label = txt(action).toLowerCase();
        if (/generate|create|draft|write/.test(label)) action.classList.add('cgm-btn','cgm-btn--primary');
        else if (/delete|remove|dismiss|ignore/.test(label)) action.classList.add('cgm-btn','cgm-btn--ghost');
        else if (/view|open|details|pillar/.test(label)) action.classList.add('cgm-btn','cgm-btn--secondary');
      });
    });

    qsa(':scope > div', shell).forEach(function(el){
      var t = txt(el).toLowerCase();
      if (/no gaps match the current filters/.test(t)) {
        el.classList.add('cgm-empty-state','is-filtered-empty','cgm-card');
      } else if (/no open gaps/.test(t) || /run an analysis first/.test(t)) {
        el.classList.add('cgm-empty-state','is-empty','cgm-card');
      } else if (/page \d+ of \d+/i.test(txt(el)) && qsa('button', el).length >= 2) {
        el.classList.add('cgm-pagination');
      }
    });
  }
  function apply(){
    var r = root();
    if (!r) return;
    r.classList.add('cgm-admin','cgm-theme-purple');
    var page = activePage(r);
    clearPageClasses(r);
    r.classList.add('cgm-page--' + page);
    r.setAttribute('data-cgm-page', page);
    var shell = pageNode(r, page);
    if (!shell) return;
    if (page === 'dashboard') classifyDashboard(shell);
    if (page === 'content-gaps') classifyGaps(shell);
  }
  document.addEventListener('DOMContentLoaded', apply);
  window.addEventListener('load', apply);
  new MutationObserver(function(){ apply(); }).observe(document.documentElement, {childList:true, subtree:true});
})();
