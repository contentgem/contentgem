
(function(){
  document.addEventListener('mousedown', function(e){
    const openDropdowns = document.querySelectorAll('.cg-dropdown.open');
    openDropdowns.forEach(dd=>{
      if(!dd.contains(e.target)){
        dd.classList.remove('open');
      }
    });
  });

  document.addEventListener('click', function(e){
    const toggle = e.target.closest('[data-cg-dropdown-toggle]');
    if(toggle){
      const dd = toggle.closest('.cg-dropdown');
      if(dd){
        dd.classList.toggle('open');
      }
    }
  });

  document.addEventListener('mousedown', function(e){
    const option = e.target.closest('[data-cg-option]');
    if(option){
      e.preventDefault();
    }
  });
})();
